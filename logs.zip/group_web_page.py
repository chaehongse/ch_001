import json
import re
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from html import unescape
from pathlib import Path
from threading import Lock
from time import sleep
from urllib.parse import quote

import streamlit as st
import streamlit.components.v1 as components

KST = timezone(timedelta(hours=9))
HTTP_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
}
PARTNER_COMPANIES = [
    {"name": "디케이", "location": "거제"},
    {"name": "오리엔탈마린텍", "location": "창원"},
    {"name": "디에이치아이", "location": "통영"},
    {"name": "HSG성동", "location": "통영"},
    {"name": "금강중공업", "location": "고성"},
    {"name": "이케이중공업", "location": "고성"},
]

RELATED_COMPANIES = [
    {"name": "삼성중공업", "location": "거제"},
    {"name": "HD현대중공업", "location": "울산"},
    {"name": "한화오션", "location": "거제"},
    {"name": "HD현대삼호", "location": "목포"},
    {"name": "대불공단", "location": "영암"},
    {"name": "삼성전자", "location": "평택"},
]

AI_NEWS_EXCLUDED_LOCAL_SOURCES = [
    "거제신문", "거제뉴스광장", "거제타임즈", "통영신문", "통영뉴스", "경남신문", "경남도민일보",
    "부산일보", "국제신문", "영남일보", "매일신문", "경상일보", "울산매일", "경인일보", "인천일보",
    "강원일보", "중도일보", "대전일보", "충청일보", "충청투데이", "전북일보", "전남일보",
    "무등일보", "광주일보", "제민일보", "한라일보", "기호일보", "경북일보",
]
AI_NEWS_EXCLUDED_TOPIC_KEYWORDS = [
    "조류독감",
    "조류 인플루엔자",
    "고병원성 ai",
    "avian influenza",
    "bird flu",
]
AI_NEWS_EXCLUDED_POLITICS_KEYWORDS = [
    "정당",
    "국민의힘",
    "더불어민주당",
    "민주당",
    "조국혁신당",
    "개혁신당",
    "진보당",
    "정의당",
    "대선",
    "총선",
    "지방선거",
    "원내대표",
    "당대표",
    "비대위",
    "국회",
    "정치권",
    "국회의원",
    "의원",
    "예비후보"
    "후보"
]
AI_NEWS_KEYWORDS = [
    "AI",
    "인공지능",
    "AX",
    "업무자동화",
    "사무자동화",
    "디지털트윈",
    "Data Science",
    "Data Technology",
    "Digital Twins",
    "피지컬 AI",
]

PARTNER_ALIAS_MAP = {
    "디케이": ["디케이", "(주)디케이", "DK", "건화", "(주)건화"],
    "오리엔탈마린텍": ["오리엔탈마린텍", "오리엔탈 마린텍", "Oriental Marine Tech"],
    "디에이치아이": ["디에이치아이", "디에이치 아이"],
    "HSG성동": ["HSG성동", "HSG성동조선", "성동조선"],
    "금강중공업": ["금강중공업", "금강 중공업", "(주)금강중공업"],
    "이케이중공업": ["이케이중공업", "이케이 중공업"],
    "HD현대삼호": ["HD현대삼호", "현대삼호", "현대삼호중공업"],
    "HD현대중공업": ["HD현대중공업", "현대중공업"],
    "한화오션": ["한화오션", "대우조선해양"],
    "대불공단": ["대불공단", "대불산단"],
}

# 이 집합에 포함된 회사명은 별칭이 단독 단어로 등장해야만 매칭 (다른 회사명의 일부일 경우 제외)
PARTNER_STRICT_BOUNDARY = {"디케이"}

PARTNER_INDUSTRY_KEYWORDS = ["조선", "해양", "선박", "블록", "야드", "도크", "풍력", "중대재해", "기업회생", "인력"]
COMPANY_NEWS_EXCLUDED_POLITICS_KEYWORDS = [
    "국회의원", " 의원",  # " 의원X" 모든 형태 포함 (의원이/은/을/의/과/,/space 등)
    "원내대표", "당대표", "비대위", "여야", "의정활동",
    "더불어민주당", "국민의힘", "조국혁신당", "개혁신당", "진보당",
    "선거", "총선", "대선", "지방선거", "보궐선거",
    "출마", "출마선언", "예비후보", "후보", "공천", "정당", "정치"
]
NEWS_HTTP_TIMEOUT_SEC = 10.0
AI_FETCH_ITEMS_PER_SOURCE = 14
COMPANY_FETCH_ITEMS_PER_SOURCE = 10
MAX_COMPANY_QUERIES = 6
AI_FETCH_WORKERS = 6
COMPANY_FETCH_WORKERS = 8
NEWS_REFRESH_HOURS = (6, 12)
NEWS_BOOTSTRAP_CACHE_PATH = Path(__file__).parent / "news_bootstrap_cache.json"
_NEWS_BOOTSTRAP_CACHE_LOCK = Lock()

def _is_ai_keyword_matched(item: dict) -> bool:
    title = f"{item.get('title', '')}".lower()
    return any(str(kw).lower() in title for kw in AI_NEWS_KEYWORDS)


def _build_google_news_rss_url(query: str) -> str:
    q = quote(query)
    return f"https://news.google.com/rss/search?q={q}&hl=ko&gl=KR&ceid=KR:ko"


def _build_google_news_search_url(query: str, days: int) -> str:
    q = quote(query)
    if days <= 1:
        tbs = "qdr:d"
    elif days <= 7:
        tbs = "qdr:w"
    else:
        tbs = "qdr:m"
    return f"https://www.google.com/search?tbm=nws&hl=ko&gl=KR&tbs={tbs}&q={q}"


def _with_google_when(query: str, days: int) -> str:
    d = max(1, int(days))
    return f"{str(query or '').strip()} when:{d}d".strip()


def _build_naver_news_search_url(query: str) -> str:
    return (
        "https://search.naver.com/search.naver"
        f"?where=news&query={quote(query)}&sort=1&sm=tab_opt&nso=so:r,p:2w"
    )


def _parse_rss_pubdate(text: str) -> str:
    """RFC 2822 형식(RSS pubDate)을 ISO 8601로 변환. 실패 시 빈 문자열 반환."""
    src = str(text or "").strip()
    if not src:
        return ""
    try:
        dt = parsedate_to_datetime(src)
        return dt.astimezone(KST).isoformat()
    except Exception:
        return _parse_ko_relative_date_to_iso(src)


# 에러 로그를 저장할 디렉토리 설정
LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

def save_error_log(error_msg: str, url: str = "", function_name: str = "") -> None:
    """
    에러 로그를 JSON 파일로 저장합니다.
    
    Args:
        error_msg (str): 에러 메시지
        url (str): 에러가 발생한 URL (선택)
        function_name (str): 에러가 발생한 함수 이름 (선택)
    """
    log_entry = {
        "timestamp": datetime.now().isoformat(),
        "error": error_msg,
        "url": url,
        "function": function_name
    }
    
    # 로그 파일 경로 설정
    log_file = LOG_DIR / "error_log.json"
    
    # 기존 로그 읽기
    logs = []
    if log_file.exists():
        try:
            with open(log_file, "r", encoding="utf-8") as f:
                logs = json.load(f)
        except Exception:
            logs = []
    
    # 새 로그 추가
    logs.append(log_entry)
    
    # JSON 파일로 저장 (최대 100개 로그 유지)
    if len(logs) > 100:
        logs = logs[-100:]
    
    try:
        with open(log_file, "w", encoding="utf-8") as f:
            json.dump(logs, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"로그 파일 저장 실패: {e}")

# InsecureRequestWarning 억제 코드 추가
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from urllib3.exceptions import InsecureRequestWarning
import urllib3

# 경고 억제
urllib3.disable_warnings(InsecureRequestWarning)

print("INFO: 뉴스 조회 순서: Google RSS -> Google HTML -> Naver HTML")

# 기존 _fetch_text 함수에 에러 로그 저장 기능 추가
def _fetch_text(url: str, timeout_sec: int = 10) -> str:
    try:
        # requests 세션 설정 (재시도 및 SSL 무시 옵션)
        session = requests.Session()
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            # 타임아웃 에러도 재시도 대상에 추가
            allowed_methods=["HEAD", "GET", "OPTIONS"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        # SSL 인증서 검증 비활성화 (개발용)
        response = session.get(url, headers=HTTP_HEADERS, timeout=timeout_sec, verify=False)
        response.raise_for_status()
        return response.text
    except Exception as e:
        # 에러 로그 저장
        save_error_log(str(e), url, "_fetch_text")
        raise RuntimeError(f"news fetch failed for url={url}: {e}")


def _make_empty_news_item(message: str = "뉴스 조회 결과 없음") -> dict:
    return {
        "title": message,
        "link": "",
        "pubDate": datetime.now(KST).isoformat(),
        "author": "시스템",
        "description": "",
        "provider": "시스템",
    }


def _safe_strip(text: str) -> str:
    return (text or "").strip()


def _strip_html(text: str) -> str:
    return re.sub(r"<[^>]+>", "", _safe_strip(unescape(text)))


def _unwrap_google_news_link(link: str) -> str:
    src = _safe_strip(unescape(link)).replace("&amp;", "&")
    if not src:
        return ""
    if src.startswith("/url?") or "url?q=" in src:
        m = re.search(r"[?&]q=([^&]+)", src)
        if m:
            return _safe_strip(unescape(m.group(1)))
    if src.startswith("http://") or src.startswith("https://"):
        return src
    return ""


@lru_cache(maxsize=512)
def _fetch_article_text(url: str) -> str:
    if not url:
        return ""
    try:
        html = _fetch_text(url, timeout_sec=NEWS_HTTP_TIMEOUT_SEC)
    except Exception:
        return ""
    return _strip_html(html).lower()


def _naver_article_contains_company(item: dict, company_name: str) -> bool:
    if not company_name:
        return False
    # 1차: 검색 결과 제목/요약에서 확인
    if _text_contains_company(item, company_name):
        return True
    # 2차: 본문 텍스트에서 확인
    link = str(item.get("link", "")).strip()
    if not link:
        return False
    text = _fetch_article_text(link)
    if not text:
        return False
    return _text_contains_company({"title": text, "description": "", "author": ""}, company_name)


def _parse_ko_relative_date_to_iso(text: str) -> str:
    now = datetime.now(KST)
    src = str(text or "").strip()
    m_day = re.search(r"(\d+)\s*일\s*전", src)
    if m_day:
        dt = now - timedelta(days=int(m_day.group(1)))
        return dt.isoformat()
    m_hour = re.search(r"(\d+)\s*시간\s*전", src)
    if m_hour:
        dt = now - timedelta(hours=int(m_hour.group(1)))
        return dt.isoformat()
    m_min = re.search(r"(\d+)\s*분\s*전", src)
    if m_min:
        dt = now - timedelta(minutes=int(m_min.group(1)))
        return dt.isoformat()
    m_abs = re.search(r"(20\d{2})\.(\d{1,2})\.(\d{1,2})\.?", src)
    if m_abs:
        y, mo, d = (int(m_abs.group(1)), int(m_abs.group(2)), int(m_abs.group(3)))
        return datetime(y, mo, d, 12, 0, tzinfo=KST).isoformat()
    return ""


def _extract_date_from_url_iso(url: str) -> str:
    src = str(url or "").strip()
    if not src:
        return ""
    # 예: key=20221130010008818, /20221130010008818, /2022/11/30/
    m = re.search(r"(20\d{2})(\d{2})(\d{2})\d{4,}", src)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            return datetime(y, mo, d, 12, 0, tzinfo=KST).isoformat()
        except Exception:
            pass
    m = re.search(r"(20\d{2})[/-](\d{1,2})[/-](\d{1,2})", src)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            return datetime(y, mo, d, 12, 0, tzinfo=KST).isoformat()
        except Exception:
            pass
    return ""


def _parse_ko_or_iso_datetime_to_iso(text: str) -> str:
    src = str(text or "").strip()
    if not src:
        return ""
    src = re.sub(r"\s+", " ", src.replace("\\/", "/")).strip()
    try:
        dt = datetime.fromisoformat(src.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=KST)
        return dt.astimezone(KST).isoformat()
    except Exception:
        pass

    m = re.search(
        r"(20\d{2})[./-](\d{1,2})[./-](\d{1,2})\.?\s*(?:(오전|오후|AM|PM|am|pm)\s*)?(\d{1,2}):(\d{2})(?::(\d{2}))?",
        src,
    )
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        ap = (m.group(4) or "").lower()
        h, mi, sec = int(m.group(5)), int(m.group(6)), int(m.group(7) or 0)
        if ap in {"오후", "pm"} and h < 12:
            h += 12
        if ap in {"오전", "am"} and h == 12:
            h = 0
        return datetime(y, mo, d, h, mi, sec, tzinfo=KST).isoformat()

    m = re.search(r"(20\d{2})[./-](\d{1,2})[./-](\d{1,2})\.?", src)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return datetime(y, mo, d, 12, 0, tzinfo=KST).isoformat()
    return ""


def _extract_input_or_registered_date_iso(text: str) -> str:
    src = str(text or "")
    if not src:
        return ""
    # 입력/등록/배포/발행일이 있으면 최우선 사용 (수정일은 제외)
    for pat in (
        r"(?:기사\s*)?(?:승인|입력|등록|배포|발행)\s*[:：]?\s*([0-9]{4}[./-][0-9]{1,2}[./-][0-9]{1,2}\.?\s*(?:오전|오후|AM|PM|am|pm)?\s*[0-9]{1,2}:[0-9]{2}(?::[0-9]{2})?)",
        r"(?:기사\s*)?(?:승인|입력|등록|배포|발행)\s*[:：]?\s*([0-9]{4}[./-][0-9]{1,2}[./-][0-9]{1,2}(?:[ T][0-9]{1,2}:[0-9]{2}(?::[0-9]{2})?(?:Z|[+-][0-9]{2}:[0-9]{2})?)?)",
    ):
        m = re.search(pat, src, flags=re.IGNORECASE)
        if m:
            parsed = _parse_ko_or_iso_datetime_to_iso(m.group(1))
            if parsed:
                return parsed
    return ""


@lru_cache(maxsize=512)
def _fetch_article_input_or_registered_date_iso(url: str) -> str:
    if not url:
        return ""
    try:
        html = _fetch_text(url, timeout_sec=NEWS_HTTP_TIMEOUT_SEC)
    except Exception:
        return ""

    # 구조화 데이터/메타 태그의 게시일 우선
    for pat in (
        r'"datePublished"\s*:\s*"([^"]+)"',
        r'<meta[^>]+property="article:published_time"[^>]+content="([^"]+)"',
        r'<meta[^>]+name="article:published_time"[^>]+content="([^"]+)"',
        r'data-date-time="([^"]+)"',
    ):
        m = re.search(pat, html, flags=re.IGNORECASE)
        if m:
            parsed = _parse_ko_or_iso_datetime_to_iso(unescape(m.group(1)))
            if parsed:
                return parsed

    # 본문 내 입력/등록 라벨 확인
    body_text = _strip_html(unescape(html))
    parsed = _extract_input_or_registered_date_iso(body_text)
    if parsed:
        return parsed
    return ""


def _resolve_pubdate_iso(nearby_text: str, link: str, default_iso: str) -> str:
    parsed = _extract_input_or_registered_date_iso(nearby_text)
    if parsed:
        return parsed
    # "수정" 표기만 보이면 업데이트 시각일 가능성이 있어 상대시간 해석은 건너뜀
    if not (("수정" in str(nearby_text)) and ("입력" not in str(nearby_text)) and ("등록" not in str(nearby_text))):
        parsed = _parse_ko_relative_date_to_iso(nearby_text)
        if parsed:
            return parsed
    parsed = _fetch_article_input_or_registered_date_iso(link)
    if parsed:
        return parsed
    parsed = _extract_date_from_url_iso(link)
    if parsed:
        return parsed
    return default_iso


# Naver HTML 스크래핑 서킷 브레이커 — 세션 중 403 최초 감지 시 이후 요청 전부 생략
_naver_html_blocked: list[bool] = [False]


def _fetch_naver_news_search_items(query: str, limit: int) -> list[dict]:
    if _naver_html_blocked[0]:
        return []
    url = _build_naver_news_search_url(query)
    try:
        html = _fetch_text(url, timeout_sec=NEWS_HTTP_TIMEOUT_SEC)
    except Exception as e:
        if "403" in str(e):
            if not _naver_html_blocked[0]:
                _naver_html_blocked[0] = True
                print("INFO: Naver HTML 검색 차단(403) 감지 — 이번 세션은 Google RSS만 사용합니다.")
        else:
            print(f"ERROR: Naver search 조회 실패 (query='{query}'): {e}")
        return []

    items: list[dict] = []
    seen_links: set[str] = set()
    link_iter = re.finditer(
        r'<a[^>]+class="[^"]*news_tit[^"]*"[^>]+href="([^"]+)"[^>]+title="([^"]+)"',
        html,
        flags=re.IGNORECASE,
    )
    for m in link_iter:
        link = unescape(m.group(1)).strip()
        title = _strip_html(unescape(m.group(2)).strip())
        if not link or not title or link in seen_links:
            continue
        pos = m.end()
        nearby = html[pos: pos + 1200]
        desc_patterns = (
            r'<div[^>]+class="[^"]*news_dsc[^"]*"[^>]*>(.*?)</div>',
            r'<span[^>]+class="[^"]*news_dsc[^"]*"[^>]*>(.*?)</span>',
            r'<div[^>]+class="[^"]*api_txt_lines[^"]*"[^>]*>(.*?)</div>',
            r'<span[^>]+class="[^"]*api_txt_lines[^"]*"[^>]*>(.*?)</span>',
            r'<div[^>]+class="[^"]*dsc_txt_wrap[^"]*"[^>]*>(.*?)</div>',
            r'<span[^>]+class="[^"]*dsc_txt_wrap[^"]*"[^>]*>(.*?)</span>',
            r'<div[^>]+class="[^"]*dsc_txt[^"]*"[^>]*>(.*?)</div>',
            r'<span[^>]+class="[^"]*dsc_txt[^"]*"[^>]*>(.*?)</span>',
        )
        desc = ""
        for pat in desc_patterns:
            desc_m = re.search(pat, nearby, flags=re.IGNORECASE | re.DOTALL)
            if desc_m:
                desc = _strip_html(unescape(desc_m.group(1)).strip())
                break
        if not desc:
            nearby_text = _strip_html(unescape(nearby))
            nearby_text = re.sub(r"\s+", " ", nearby_text).strip()
            desc = nearby_text[:180] if nearby_text else ""
        pub = _resolve_pubdate_iso(nearby, link, "")
        items.append(
            {
                "title": title,
                "link": link,
                "pubDate": pub,
                "author": "Naver News",
                "description": desc,
                "provider": "Naver News",
            }
        )
        seen_links.add(link)
        if len(items) >= limit:
            break

    if len(items) < limit:
        pattern = re.compile(
            r'\},"title":"(?P<title>[^"]+)","titleHref":"(?P<link>https?://[^"]+)","type":"searchBasic"',
            flags=re.IGNORECASE,
        )
        for m in pattern.finditer(html):
            link = unescape(m.group("link")).strip().replace("\\/", "/")
            title = _strip_html(unescape(m.group("title"))).strip()
            if not link or not title or link in seen_links:
                continue
            if "media.naver.com/press/" in link or "help.naver.com" in link:
                continue
            pub = _fetch_article_input_or_registered_date_iso(link) or _extract_date_from_url_iso(link)
            items.append(
                {
                    "title": title,
                    "link": link,
                    "pubDate": pub,
                    "author": "Naver News",
                    "description": "",
                    "provider": "Naver News",
                }
            )
            seen_links.add(link)
            if len(items) >= limit:
                break

    if len(items) < limit:
        pattern_news_naver = re.compile(
            r'<a[^>]+href="(?P<link>https?://n\\.news\\.naver\\.com/[^"]+)"[^>]*>(?P<title>.*?)</a>',
            flags=re.IGNORECASE | re.DOTALL,
        )
        for m in pattern_news_naver.finditer(html):
            link = unescape(m.group("link")).strip()
            title = _strip_html(unescape(m.group("title"))).strip()
            if not link or not title or link in seen_links:
                continue
            pub = _fetch_article_input_or_registered_date_iso(link) or _extract_date_from_url_iso(link)
            items.append(
                {
                    "title": title,
                    "link": link,
                    "pubDate": pub,
                    "author": "Naver News",
                    "description": "",
                    "provider": "Naver News",
                }
            )
            seen_links.add(link)
            if len(items) >= limit:
                break
    return items


# Google 뉴스 HTML 검색 (병행 조회 후에도 결과 부족 시 보완용)
def _fetch_google_news_html_items(query: str, limit: int, days: int) -> list[dict]:
    url = _build_google_news_search_url(query, days)
    try:
        html = _fetch_text(url, timeout_sec=NEWS_HTTP_TIMEOUT_SEC)
    except Exception as e:
        print(f"ERROR: Failed to fetch Google HTML for query '{query}': {e}")
        return []

    items: list[dict] = []
    seen_links: set[str] = set()
    # 1) /url?q=... 형태 링크 + 주변 제목 텍스트 추출
    link_iter = re.finditer(
        r'<a[^>]+href="(?P<href>/url\\?[^"]+|https?://[^"]+)"[^>]*>(?P<body>.*?)</a>',
        html,
        flags=re.IGNORECASE | re.DOTALL,
    )
    for m in link_iter:
        link = _unwrap_google_news_link(m.group("href"))
        if not link or link in seen_links:
            continue
        body = m.group("body")
        title_m = re.search(r'<div[^>]*>(?P<t>[^<]{6,200})</div>', body, flags=re.IGNORECASE)
        title = _strip_html(title_m.group("t")) if title_m else ""
        if not title:
            title = _strip_html(body)
        if not title:
            continue
        pos = m.end()
        nearby = html[pos: pos + 1200]
        pub = _resolve_pubdate_iso(nearby, link, "")
        items.append(
            {
                "title": title,
                "link": link,
                "pubDate": pub,
                "author": "Google News",
                "description": "",
                "provider": "Google News",
            }
        )
        seen_links.add(link)
        if len(items) >= limit:
            break
    return items


# 기존 _fetch_google_news_rss_items 함수에 에러 핸들링 추가
def _fetch_google_news_rss_items(query: str, limit: int) -> list[dict]:
    """Google News RSS(news.google.com/rss/search)에서 뉴스 항목을 가져온다.
    HTML 스크래핑보다 안정적이며 봇 차단 없이 동작한다."""
    url = _build_google_news_rss_url(query)
    try:
        xml = _fetch_text(url, timeout_sec=NEWS_HTTP_TIMEOUT_SEC)
    except Exception as e:
        print(f"ERROR: Failed to fetch Google RSS for query '{query}': {e}")
        return []
    
    items: list[dict] = []
    seen_links: set[str] = set()

    item_blocks = re.findall(r"<item>(.*?)</item>", xml, flags=re.DOTALL | re.IGNORECASE)
    now = datetime.now(KST)

    for block in item_blocks:
        # 제목 추출 (CDATA 래핑 포함)
        title_m = re.search(
            r"<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>", block, flags=re.DOTALL | re.IGNORECASE
        )
        if not title_m:
            continue
        title = _strip_html(unescape(title_m.group(1).strip()))
        if not title:
            continue

        # 링크 추출 (<link> → <guid> 순)
        link_m = re.search(r"<link>(.*?)</link>", block, flags=re.DOTALL | re.IGNORECASE)
        if not link_m:
            link_m = re.search(r"<guid[^>]*>(.*?)</guid>", block, flags=re.DOTALL | re.IGNORECASE)
        link = unescape((link_m.group(1).strip() if link_m else "")).replace("&amp;", "&").strip()
        if not link or link in seen_links:
            continue

        # 날짜 추출
        pub_m = re.search(r"<pubDate>(.*?)</pubDate>", block, flags=re.DOTALL | re.IGNORECASE)
        pub = _parse_rss_pubdate(pub_m.group(1).strip() if pub_m else "") or now.isoformat()

        # 출처(언론사) 추출
        source_m = re.search(r"<source[^>]*>(.*?)</source>", block, flags=re.DOTALL | re.IGNORECASE)
        source = _strip_html(unescape(source_m.group(1).strip())) if source_m else "Google News"
        # 요약 추출 (지역/정치 키워드 필터 정확도 개선)
        desc_m = re.search(
            r"<description>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</description>",
            block,
            flags=re.DOTALL | re.IGNORECASE,
        )
        desc = _strip_html(unescape(desc_m.group(1).strip())) if desc_m else ""

        items.append({
            "title": title,
            "link": link,
            "pubDate": pub,
            "author": source or "Google News",
            "description": desc,
            "provider": source or "Google News",
        })
        seen_links.add(link)
        if len(items) >= limit:
            break

    return items


def _extend_merged_items(merged: list[dict], incoming: list[dict], target_limit: int) -> list[dict]:
    if len(merged) >= target_limit:
        return merged
    seen_links = {
        str(item.get("link", "")).strip()
        for item in merged
        if str(item.get("link", "")).strip()
    }
    seen_keys = {
        str(item.get("title", "")).strip() + "|" + str(item.get("pubDate", "")).strip()
        for item in merged
    }
    for item in incoming:
        if len(merged) >= target_limit:
            break
        link = str(item.get("link", "")).strip()
        if link:
            if link in seen_links:
                continue
            seen_links.add(link)
        else:
            key = str(item.get("title", "")).strip() + "|" + str(item.get("pubDate", "")).strip()
            if key in seen_keys:
                continue
            seen_keys.add(key)
        merged.append(item)
    return merged


def _fetch_news_items_in_order(query: str, limit: int, days: int) -> list[dict]:
    """뉴스 수집 우선순위:
    1) Google RSS
    2) Google HTML + Naver HTML 병행 보완
    """
    target_limit = max(1, int(limit))
    merged: list[dict] = []

    # 1) Google RSS
    try:
        merged = _extend_merged_items(
            merged,
            _fetch_google_news_rss_items(_with_google_when(query, days), target_limit),
            target_limit,
        )
    except Exception:
        pass

    # 2) HTML 소스 병행 보완 (Google + Naver)
    if len(merged) < target_limit:
        supplement_limit = max(3, target_limit - len(merged))
        google_items: list[dict] = []
        naver_items: list[dict] = []
        with ThreadPoolExecutor(max_workers=2) as ex:
            google_f = ex.submit(_fetch_google_news_html_items, query, supplement_limit, days)
            naver_f = ex.submit(_fetch_naver_news_search_items, query, supplement_limit)
            try:
                google_items = google_f.result()
            except Exception:
                google_items = []
            try:
                naver_items = naver_f.result()
            except Exception:
                naver_items = []
        merged = _extend_merged_items(merged, google_items, target_limit)
        merged = _extend_merged_items(merged, naver_items, target_limit)

    return _dedupe_sort_limit(merged, target_limit)


def _item_dt_utc(item: dict) -> datetime | None:
    raw = str(item.get("pubDate", "")).strip()
    if not raw:
        return None
    try:
        dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _filter_by_days(items: list[dict], days: int) -> list[dict]:
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(days=max(1, int(days)))
    out = []
    for item in items:
        dt = _item_dt_utc(item)
        if dt and cutoff <= dt <= now:
            out.append(item)
    return out


def _contains_politics_keywords(item: dict, keywords: list[str]) -> bool:
    text = f"{item.get('title', '')} {item.get('description', '')} {item.get('author', '')}".lower()
    text_compact = re.sub(r"\s+", "", text)
    for kw in keywords:
        token = str(kw).strip().lower()
        if not token:
            continue
        if token in text or re.sub(r"\s+", "", token) in text_compact:
            return True
    return False


def _dedupe_sort_limit(items: list[dict], limit: int) -> list[dict]:
    uniq: dict[str, dict] = {}
    for item in items:
        link = str(item.get("link", "")).strip()
        if not link:
            key = f"{item.get('title', '')}|{item.get('pubDate', '')}"
        else:
            key = link
        if key and key not in uniq:
            uniq[key] = item
    sorted_items = sorted(
        uniq.values(),
        key=lambda x: _item_dt_utc(x) or datetime(1970, 1, 1, tzinfo=timezone.utc),
        reverse=True,
    )
    return sorted_items[:limit]


def _build_company_queries(company: dict) -> list[str]:
    name_raw = str(company.get("name", "")).strip()
    names = PARTNER_ALIAS_MAP.get(name_raw, [name_raw])
    location = str(company.get("location", "")).strip()
    candidates: list[str] = []
    # Always bind company alias with location to reduce unrelated matches.
    for name in names:
        q = " ".join([p for p in [name, location] if p])
        if q:
            candidates.append(q)
    if not candidates and name_raw:
        candidates.append(name_raw)
    # Keep order while removing duplicates.
    return list(dict.fromkeys(candidates))


def _text_contains_company(item: dict, company_name: str) -> bool:
    full = " ".join(
        [
            str(item.get("title", "")),
            str(item.get("description", "")),
            str(item.get("author", "")),
        ]
    ).lower()
    aliases = PARTNER_ALIAS_MAP.get(company_name, [company_name])
    strict = company_name in PARTNER_STRICT_BOUNDARY
    if company_name == "디케이":
        # "디케이" 뒤에 텍스트가 이어지면 다른 법인/문맥으로 보고 제외.
        # ex) "디케이중공업", "디케이 산업", "디케이테크" -> 제외
        return bool(re.search(r"(?<![가-힣a-zA-Z0-9])디케이(?!\s*[가-힣a-zA-Z0-9])", full))
    for alias in aliases:
        a = alias.lower()
        if a not in full:
            continue
        if strict:
            # 앞뒤에 한글·영문·숫자가 이어지면 다른 회사명의 일부로 간주해 제외
            pat = r"(?<![가-힣a-zA-Z0-9])" + re.escape(a) + r"(?![가-힣a-zA-Z0-9])"
            if re.search(pat, full):
                return True
        else:
            return True
    return False


def _text_contains_location(item: dict, location: str) -> bool:
    loc = str(location or "").strip().lower()
    if not loc:
        return True
    full = " ".join(
        [
            str(item.get("title", "")),
            str(item.get("description", "")),
            str(item.get("author", "")),
        ]
    ).lower()
    if loc in full:
        return True
    full_compact = re.sub(r"\s+", "", full)
    loc_compact = re.sub(r"\s+", "", loc)
    return bool(loc_compact) and (loc_compact in full_compact)


def _is_partner_fallback_candidate(item: dict, company: dict, query: str, enforce_location: bool = True) -> bool:
    full = " ".join(
        [
            str(item.get("title", "")),
            str(item.get("description", "")),
            str(item.get("author", "")),
        ]
    ).lower()
    company_name = str(company.get("name", "")).strip()
    location = str(company.get("location", "")).strip()
    company_ok = _text_contains_company(item, company_name)
    location_ok = _text_contains_location(item, location)
    if enforce_location and not location_ok:
        return False
    if company_name in PARTNER_STRICT_BOUNDARY:
        return company_ok
    industry_ok = any(kw.lower() in full for kw in PARTNER_INDUSTRY_KEYWORDS)
    query_tokens = [
        t.lower()
        for t in str(query).split()
        if t and t.lower() not in {"or", "뉴스"} and len(t) >= 2
    ]
    token_hits = sum(1 for t in query_tokens if t in full)
    return company_ok or (token_hits >= 1 and (industry_ok or location_ok or token_hits >= 2))


def _fetch_company_news(company: dict, top_n: int, days: int, enforce_location: bool = True) -> list[dict]:
    queries = _build_company_queries(company)[:MAX_COMPANY_QUERIES]
    company_name = str(company.get("name", "")).strip()
    strict_pool: list[dict] = []
    loose_pool: list[dict] = []
    for query in queries:
        _limit = max(top_n * 3, COMPANY_FETCH_ITEMS_PER_SOURCE)
        merged = _fetch_news_items_in_order(query, _limit, days)
        # Naver 소스 결과는 회사 관련 기사만 유지(기존 스타일 유지)
        merged = [
            item
            for item in merged
            if ("naver" not in str(item.get("provider", "")).lower())
            or _naver_article_contains_company(item, company_name)
        ]
        
        if not merged:
            continue
        in_range_all = _filter_by_days(merged, days)
        # 정치성 기사 우선 제거 (카드 노출 전 1차 필터)
        in_range_all = [
            item for item in in_range_all
            if not _contains_politics_keywords(item, COMPANY_NEWS_EXCLUDED_POLITICS_KEYWORDS)
        ]
        if enforce_location:
            in_range_all = [
                item for item in in_range_all
                if _text_contains_location(item, company.get("location", ""))
            ]
        strict_pool.extend(
            [item for item in in_range_all if _text_contains_company(item, company.get("name", ""))]
        )
        # 폴백: 쿼리/날짜 조건은 유지하되 쿼리 토큰 관련성은 유지
        loose_pool.extend(
            [item for item in in_range_all if _is_partner_fallback_candidate(item, company, query, enforce_location)]
        )
    strict_selected = _dedupe_sort_limit(strict_pool, top_n)
    if strict_selected:
        return strict_selected
    loose_selected = _dedupe_sort_limit(loose_pool, top_n)
    if loose_selected:
        return loose_selected
    return [_make_empty_news_item("뉴스 조회 결과 없음")]



def _fetch_ai_for_keyword(keyword: str) -> list[dict]:
    # 우선순위: Google RSS -> Google HTML -> Naver HTML
    try:
        merged = _fetch_news_items_in_order(keyword, AI_FETCH_ITEMS_PER_SOURCE, 2)
    except Exception:
        merged = []
    if not merged:
        merged.append(_make_empty_news_item("뉴스 조회 결과 없음"))
    return merged


def _fetch_company_news_safe(
    company: dict, top_n: int, days: int, enforce_location: bool = True
) -> tuple[str, list[dict]]:
    name = str(company.get("name", "")).strip()
    for attempt in range(2):
        try:
            items = _fetch_company_news(company, top_n=top_n, days=days, enforce_location=enforce_location)
            if items:
                return name, items
        except Exception:
            pass
        if attempt < 1:
            sleep(0.35)
    return name, []


def _collect_news_once() -> dict:
    ai_items: list[dict] = []
    try:
        ai_merged: list[dict] = []
        ai_keywords = AI_NEWS_KEYWORDS
        with ThreadPoolExecutor(max_workers=AI_FETCH_WORKERS) as executor:
            futures = [executor.submit(_fetch_ai_for_keyword, kw) for kw in ai_keywords]
            for future in as_completed(futures):
                try:
                    ai_merged.extend(future.result())
                except Exception:
                    pass
        ai_filtered = _filter_by_days(ai_merged, 2)
        ai_filtered = [
            item for item in ai_filtered
            if _is_ai_keyword_matched(item)
            and not any(src in f"{item.get('author', '')} {item.get('title', '')}" for src in AI_NEWS_EXCLUDED_LOCAL_SOURCES)
            and not any(
                kw in f"{item.get('author', '')} {item.get('title', '')} {item.get('description', '')}".lower()
                for kw in AI_NEWS_EXCLUDED_TOPIC_KEYWORDS
            )
            and not any(
                kw in f"{item.get('author', '')} {item.get('title', '')} {item.get('description', '')}".lower()
                for kw in AI_NEWS_EXCLUDED_POLITICS_KEYWORDS
            )
        ]
        ai_items = _dedupe_sort_limit(ai_filtered, 10)
        if not ai_items:
            ai_items = [_make_empty_news_item("뉴스 조회 결과 없음")]
    except Exception:
        ai_items = []

    partner_news: dict[str, list[dict]] = {}
    related_news: dict[str, list[dict]] = {}
    with ThreadPoolExecutor(max_workers=COMPANY_FETCH_WORKERS) as executor:
        partner_futures = [
            executor.submit(_fetch_company_news_safe, company, 3, 14, True)
            for company in PARTNER_COMPANIES
        ]
        for future in as_completed(partner_futures):
            name, items = future.result()
            partner_news[name] = items

        related_futures = [
            executor.submit(_fetch_company_news_safe, company, 3, 7, False)
            for company in RELATED_COMPANIES
        ]
        for future in as_completed(related_futures):
            name, items = future.result()
            related_news[name] = items

    # Retry empty buckets once to reduce misses from transient fetch/source variability.
    for company in PARTNER_COMPANIES:
        name = str(company.get("name", "")).strip()
        if partner_news.get(name):
            continue
        _, retry_items = _fetch_company_news_safe(company, 3, 14, True)
        if retry_items:
            partner_news[name] = retry_items
    for company in RELATED_COMPANIES:
        name = str(company.get("name", "")).strip()
        if related_news.get(name):
            continue
        _, retry_items = _fetch_company_news_safe(company, 3, 7, False)
        if retry_items:
            related_news[name] = retry_items

    # Keep original company order in output JSON.
    partner_news = {c["name"]: partner_news.get(c["name"], []) for c in PARTNER_COMPANIES}
    related_news = {c["name"]: related_news.get(c["name"], []) for c in RELATED_COMPANIES}

    return {
        "generatedAt": datetime.now(KST).isoformat(),
        "aiNews": ai_items,
        "partnerNews": partner_news,
        "relatedNews": related_news,
    }


def _current_refresh_slot_kst(now: datetime | None = None) -> tuple[str, datetime]:
    base = now or datetime.now(KST)
    d6 = base.replace(hour=NEWS_REFRESH_HOURS[0], minute=0, second=0, microsecond=0)
    d12 = base.replace(hour=NEWS_REFRESH_HOURS[1], minute=0, second=0, microsecond=0)
    if base >= d12:
        slot = d12
    elif base >= d6:
        slot = d6
    else:
        slot = d12 - timedelta(days=1)
    return slot.strftime("%Y%m%d_%H"), slot


def _next_refresh_time_kst(now: datetime | None = None) -> datetime:
    base = now or datetime.now(KST)
    d6 = base.replace(hour=NEWS_REFRESH_HOURS[0], minute=0, second=0, microsecond=0)
    d12 = base.replace(hour=NEWS_REFRESH_HOURS[1], minute=0, second=0, microsecond=0)
    if base < d6:
        return d6
    if base < d12:
        return d12
    return d6 + timedelta(days=1)


def _load_news_bootstrap_cache() -> dict | None:
    if not NEWS_BOOTSTRAP_CACHE_PATH.exists():
        return None
    try:
        raw = json.loads(NEWS_BOOTSTRAP_CACHE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return None
    if not isinstance(raw, dict):
        return None
    if not isinstance(raw.get("data"), dict):
        return None
    if not str(raw.get("slotKey", "")).strip():
        return None
    return raw


def _save_news_bootstrap_cache(cache_doc: dict) -> None:
    tmp_path = NEWS_BOOTSTRAP_CACHE_PATH.with_suffix(".tmp")
    tmp_path.write_text(json.dumps(cache_doc, ensure_ascii=False), encoding="utf-8")
    tmp_path.replace(NEWS_BOOTSTRAP_CACHE_PATH)


def _build_news_bootstrap(cache_buster: str = "v11") -> dict:
    _ = cache_buster
    slot_key, slot_start = _current_refresh_slot_kst()
    with _NEWS_BOOTSTRAP_CACHE_LOCK:
        cached = _load_news_bootstrap_cache()
        if cached and cached.get("slotKey") == slot_key:
            return cached["data"]
        try:
            data = _collect_news_once()
        except Exception:
            if cached and isinstance(cached.get("data"), dict):
                return cached["data"]
            raise
        cache_doc = {
            "slotKey": slot_key,
            "slotStart": slot_start.isoformat(),
            "savedAt": datetime.now(KST).isoformat(),
            "data": data,
        }
        _save_news_bootstrap_cache(cache_doc)
        return data


st.set_page_config(page_title="사외구조조달1그룹", layout="wide")

st.markdown(
    """
    <style>
    html, body, [data-testid="stApp"], [data-testid="stAppViewContainer"] {
        height: 100vh;
        overflow: hidden !important;
    }
    [data-testid="stHeader"],
    [data-testid="stToolbar"],
    [data-testid="stDecoration"] {
        display: none !important;
    }
    #MainMenu, footer {
        visibility: hidden !important;
    }
    [data-testid="stAppViewContainer"] > .main {
        height: 100vh !important;
        overflow: hidden !important;
    }
    .block-container, [data-testid="stAppViewBlockContainer"] {
        max-width: 100% !important;
        padding: 0 !important;
        margin: 0 !important;
        height: 100vh !important;
        overflow: hidden !important;
    }
    [data-testid="stIFrame"],
    [data-testid="stIFrame"] > iframe,
    [data-testid="stHtml"] iframe,
    .stIFrame iframe,
    iframe[title="st.iframe"] {
        height: 100vh !important;
        width: 100% !important;
        border: 0 !important;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

next_refresh_kst = _next_refresh_time_kst()
st.markdown(
    f"""
    <script>
    (() => {{
      const next = new Date("{next_refresh_kst.isoformat()}");
      const ms = Math.max(0, next.getTime() - Date.now());
      setTimeout(() => window.location.reload(), ms);
    }})();
    </script>
    """,
    unsafe_allow_html=True,
)

loading_slot = st.empty()
loading_slot.markdown(
    """
    <style>
      .boot-loader-wrap {
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #f8fffb, #ebf6ff);
      }
      .boot-loader {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 12px;
        color: #0f172a;
        font-family: "Segoe UI", "Noto Sans KR", sans-serif;
      }
      .boot-ring {
        width: 52px;
        height: 52px;
        border: 4px solid #bae6fd;
        border-top-color: #0284c7;
        border-radius: 50%;
        animation: boot-spin 1s linear infinite;
      }
      .boot-dots {
        display: inline-flex;
        gap: 6px;
      }
      .boot-dots i {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #0284c7;
        animation: boot-bounce 1.2s ease-in-out infinite;
      }
      .boot-dots i:nth-child(2) { animation-delay: 0.15s; }
      .boot-dots i:nth-child(3) { animation-delay: 0.3s; }
      @keyframes boot-spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
      @keyframes boot-bounce {
        0%, 80%, 100% { transform: translateY(0); opacity: 0.5; }
        40% { transform: translateY(-5px); opacity: 1; }
      }
    </style>
    <div class="boot-loader-wrap">
      <div class="boot-loader">
        <div class="boot-ring"></div>
        <div>화면 로딩 중</div>
        <div class="boot-dots"><i></i><i></i><i></i></div>
      </div>
    </div>
    """,
    unsafe_allow_html=True,
)

html_path = Path(__file__).parent / "group_web_page.html"
vocab_json_path = Path(__file__).parent / "vocab_pool.json"

if not html_path.exists():
    st.error(f"HTML 파일을 찾을 수 없습니다: {html_path}")
else:
    html_content = html_path.read_text(encoding="utf-8")
    inject_scripts = []
    if vocab_json_path.exists():
        vocab_json_text = vocab_json_path.read_text(encoding="utf-8")
        inject_scripts.append(f"<script>window.__VOCAB_POOL_JSON__ = {vocab_json_text};</script>")
    else:
        st.warning(f"vocab JSON 파일을 찾을 수 없습니다: {vocab_json_path}")
    try:
        news_bootstrap = _build_news_bootstrap("v11")
        news_bootstrap_json = json.dumps(news_bootstrap, ensure_ascii=False)
        inject_scripts.append(f"<script>window.__NEWS_BOOTSTRAP__ = {news_bootstrap_json};</script>")
    except Exception:
        inject_scripts.append("<script>window.__NEWS_BOOTSTRAP__ = null;</script>")
    html_content = html_content.replace("</head>", f"{''.join(inject_scripts)}</head>", 1)
    components.html(html_content, height=900, scrolling=True)
    loading_slot.empty()
