def main():
    print("Hello from 011-goup-web-page!")


if __name__ == "__main__":
    main()
