﻿const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

const colorPicker = document.getElementById('colorPicker');
const sizePicker = document.getElementById('sizePicker');
const clearBtn = document.getElementById('clearBtn');
const saveBtn = document.getElementById('saveBtn');
const toolButtons = [...document.querySelectorAll('[data-tool]')];

let tool = 'line';
let drawing = false;
let startX = 0;
let startY = 0;
let imageBitmap = null;
let snapshot = null;

const state = {
  color: colorPicker.value,
  size: Number(sizePicker.value),
};

function setActiveTool(nextTool) {
  tool = nextTool;
  toolButtons.forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.tool === nextTool);
  });
}

function redrawBase() {
  if (!imageBitmap) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(imageBitmap, 0, 0, canvas.width, canvas.height);
}

function getPos(event) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: event.clientX - rect.left,
    y: event.clientY - rect.top,
  };
}

function drawShape(currentX, currentY) {
  const width = currentX - startX;
  const height = currentY - startY;

  redrawBase();
  if (snapshot) ctx.putImageData(snapshot, 0, 0);

  ctx.strokeStyle = state.color;
  ctx.lineWidth = state.size;
  ctx.fillStyle = state.color;

  if (tool === 'line') {
    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(currentX, currentY);
    ctx.stroke();
  }

  if (tool === 'rect') {
    ctx.strokeRect(startX, startY, width, height);
  }

  if (tool === 'circle') {
    const radius = Math.hypot(width, height);
    ctx.beginPath();
    ctx.arc(startX, startY, radius, 0, Math.PI * 2);
    ctx.stroke();
  }
}

canvas.addEventListener('pointerdown', (event) => {
  if (!imageBitmap) return;
  const { x, y } = getPos(event);

  drawing = true;
  startX = x;
  startY = y;

  if (tool === 'text') {
    const text = prompt('입력할 텍스트를 작성하세요.');
    if (text) {
      ctx.fillStyle = state.color;
      ctx.font = `${Math.max(14, state.size * 6)}px "Noto Sans KR", sans-serif`;
      ctx.fillText(text, x, y);
      imageBitmap = null;
      const image = new Image();
      image.onload = () => {
        imageBitmap = image;
      };
      image.src = canvas.toDataURL('image/png');
    }
    drawing = false;
    return;
  }

  if (tool === 'eraser') {
    ctx.globalCompositeOperation = 'destination-out';
    ctx.lineWidth = state.size * 2;
    ctx.beginPath();
    ctx.moveTo(x, y);
    return;
  }

  snapshot = ctx.getImageData(0, 0, canvas.width, canvas.height);
});

canvas.addEventListener('pointermove', (event) => {
  if (!drawing) return;
  const { x, y } = getPos(event);

  if (tool === 'eraser') {
    ctx.lineTo(x, y);
    ctx.stroke();
    return;
  }

  drawShape(x, y);
});

canvas.addEventListener('pointerup', () => {
  if (!drawing) return;
  drawing = false;

  if (tool === 'eraser') {
    ctx.globalCompositeOperation = 'source-over';
  }

  snapshot = ctx.getImageData(0, 0, canvas.width, canvas.height);
});

toolButtons.forEach((btn) => {
  btn.addEventListener('click', () => setActiveTool(btn.dataset.tool));
});

colorPicker.addEventListener('input', () => {
  state.color = colorPicker.value;
});

sizePicker.addEventListener('input', () => {
  state.size = Number(sizePicker.value);
});

clearBtn.addEventListener('click', () => {
  redrawBase();
  snapshot = ctx.getImageData(0, 0, canvas.width, canvas.height);
});

saveBtn.addEventListener('click', () => {
  const imageDataUrl = canvas.toDataURL('image/png');

  if (window.opener) {
    window.opener.postMessage(
      {
        type: 'ANNOTATOR_SAVE',
        payload: { imageDataUrl },
      },
      window.location.origin
    );
  }

  window.close();
});

window.addEventListener('message', (event) => {
  if (event.origin !== window.location.origin) return;
  if (event.data?.type !== 'ANNOTATOR_INIT') return;

  const { imageDataUrl } = event.data.payload || {};
  if (!imageDataUrl) return;

  const image = new Image();
  image.onload = () => {
    canvas.width = image.width;
    canvas.height = image.height;
    imageBitmap = image;
    redrawBase();
    snapshot = ctx.getImageData(0, 0, canvas.width, canvas.height);
  };
  image.src = imageDataUrl;
});

setActiveTool(tool);
