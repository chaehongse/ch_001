﻿const imageInput = document.getElementById('imageInput');
const openToolPopupBtn = document.getElementById('openToolPopupBtn');
const closeToolPopupBtn = document.getElementById('closeToolPopupBtn');
const saveImageBtn = document.getElementById('saveImageBtn');
const clearOverlayBtn = document.getElementById('clearOverlayBtn');
const undoBtn = document.getElementById('undoBtn');
const redoBtn = document.getElementById('redoBtn');
const downloadLink = document.getElementById('downloadLink');

const toolPopup = document.getElementById('toolPopup');
const baseImage = document.getElementById('baseImage');
const stage = document.getElementById('stage');
const canvas = document.getElementById('drawCanvas');
const ctx = canvas.getContext('2d');

const colorPicker = document.getElementById('colorPicker');
const sizePicker = document.getElementById('sizePicker');
const textInput = document.getElementById('textInput');
const toolButtons = [...document.querySelectorAll('[data-tool]')];

let imageDataUrl = '';
let drawing = false;
let startX = 0;
let startY = 0;
let lastX = 0;
let lastY = 0;
let snapshot = null;
let activeTool = 'pen';
let history = [];
let historyIndex = -1;

const MAX_HISTORY = 40;

const state = {
  color: colorPicker.value,
  size: Number(sizePicker.value),
};

function setTool(tool) {
  activeTool = tool;
  toolButtons.forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.tool === tool);
  });
}

function setActionButtons() {
  undoBtn.disabled = historyIndex <= 0;
  redoBtn.disabled = historyIndex >= history.length - 1;
}

function pushHistory() {
  if (!canvas.width || !canvas.height) return;

  const dataUrl = canvas.toDataURL('image/png');
  history = history.slice(0, historyIndex + 1);
  history.push(dataUrl);

  if (history.length > MAX_HISTORY) {
    const overflowCount = history.length - MAX_HISTORY;
    history.splice(0, overflowCount);
  }

  historyIndex = history.length - 1;
  setActionButtons();
}

function restoreHistory(index) {
  if (index < 0 || index >= history.length) return;

  const snap = history[index];
  const image = new Image();
  image.onload = () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
  };
  image.src = snap;

  historyIndex = index;
  setActionButtons();
}

function resetHistory() {
  history = [];
  historyIndex = -1;
  pushHistory();
}

function syncCanvasSize() {
  if (!baseImage.naturalWidth || !baseImage.naturalHeight) return;

  const previousOverlay = canvas.width && canvas.height ? canvas.toDataURL('image/png') : '';

  const width = baseImage.clientWidth;
  const height = baseImage.clientHeight;

  canvas.style.width = `${width}px`;
  canvas.style.height = `${height}px`;
  canvas.width = width;
  canvas.height = height;

  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  if (!previousOverlay) return;

  const overlayImage = new Image();
  overlayImage.onload = () => {
    ctx.drawImage(overlayImage, 0, 0, width, height);
  };
  overlayImage.src = previousOverlay;
}

function getCanvasPoint(event) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: event.clientX - rect.left,
    y: event.clientY - rect.top,
  };
}

function drawPreview(x, y) {
  if (!snapshot) return;
  ctx.putImageData(snapshot, 0, 0);

  const w = x - startX;
  const h = y - startY;
  ctx.strokeStyle = state.color;
  ctx.lineWidth = state.size;

  if (activeTool === 'line') {
    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(x, y);
    ctx.stroke();
  }

  if (activeTool === 'rect') {
    ctx.strokeRect(startX, startY, w, h);
  }

  if (activeTool === 'circle') {
    const radius = Math.hypot(w, h);
    ctx.beginPath();
    ctx.arc(startX, startY, radius, 0, Math.PI * 2);
    ctx.stroke();
  }
}

function applyStrokeSettings() {
  ctx.strokeStyle = state.color;
  ctx.fillStyle = state.color;
  ctx.lineWidth = state.size;
}

canvas.addEventListener('pointerdown', (event) => {
  if (!imageDataUrl) return;

  const { x, y } = getCanvasPoint(event);
  startX = x;
  startY = y;
  lastX = x;
  lastY = y;
  drawing = true;

  if (activeTool === 'text') {
    const text = (textInput.value || '').trim();
    if (!text) {
      alert('텍스트 내용을 먼저 입력해주세요.');
      drawing = false;
      return;
    }

    ctx.fillStyle = state.color;
    ctx.font = `${Math.max(14, state.size * 5)}px "Noto Sans KR", sans-serif`;
    ctx.fillText(text, x, y);
    pushHistory();
    drawing = false;
    return;
  }

  if (activeTool === 'eraser') {
    ctx.globalCompositeOperation = 'destination-out';
    ctx.lineWidth = state.size * 2;
    ctx.beginPath();
    ctx.moveTo(x, y);
    return;
  }

  snapshot = ctx.getImageData(0, 0, canvas.width, canvas.height);

  if (activeTool === 'pen') {
    applyStrokeSettings();
    ctx.beginPath();
    ctx.moveTo(x, y);
  }
});

canvas.addEventListener('pointermove', (event) => {
  if (!drawing) return;

  const { x, y } = getCanvasPoint(event);
  lastX = x;
  lastY = y;

  if (activeTool === 'eraser') {
    ctx.lineTo(x, y);
    ctx.stroke();
    return;
  }

  if (activeTool === 'pen') {
    applyStrokeSettings();
    ctx.lineTo(x, y);
    ctx.stroke();
    return;
  }

  drawPreview(x, y);
});

canvas.addEventListener('pointerup', (event) => {
  if (!drawing) return;
  drawing = false;

  const { x, y } = getCanvasPoint(event);
  lastX = x;
  lastY = y;

  if (activeTool === 'eraser') {
    ctx.globalCompositeOperation = 'source-over';
    pushHistory();
    return;
  }

  if (activeTool === 'pen') {
    pushHistory();
    return;
  }

  if (activeTool === 'line' || activeTool === 'rect' || activeTool === 'circle') {
    drawPreview(lastX, lastY);
    pushHistory();
  }
});

canvas.addEventListener('pointerleave', () => {
  if (!drawing) return;

  if (activeTool === 'eraser') {
    ctx.globalCompositeOperation = 'source-over';
    drawing = false;
    pushHistory();
    return;
  }

  if (activeTool === 'pen') {
    drawing = false;
    pushHistory();
    return;
  }

  drawing = false;
});

toolButtons.forEach((button) => {
  button.addEventListener('click', () => {
    setTool(button.dataset.tool);
  });
});

colorPicker.addEventListener('input', () => {
  state.color = colorPicker.value;
});

sizePicker.addEventListener('input', () => {
  state.size = Number(sizePicker.value);
});

openToolPopupBtn.addEventListener('click', () => {
  if (!imageDataUrl) {
    alert('먼저 이미지를 선택해주세요.');
    return;
  }
  toolPopup.classList.toggle('hidden');
});

closeToolPopupBtn.addEventListener('click', () => {
  toolPopup.classList.add('hidden');
});

clearOverlayBtn.addEventListener('click', () => {
  if (!canvas.width || !canvas.height) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  pushHistory();
});

undoBtn.addEventListener('click', () => {
  if (historyIndex <= 0) return;
  restoreHistory(historyIndex - 1);
});

redoBtn.addEventListener('click', () => {
  if (historyIndex >= history.length - 1) return;
  restoreHistory(historyIndex + 1);
});

saveImageBtn.addEventListener('click', () => {
  if (!imageDataUrl) {
    alert('저장할 이미지가 없습니다.');
    return;
  }

  const merged = document.createElement('canvas');
  merged.width = baseImage.naturalWidth;
  merged.height = baseImage.naturalHeight;
  const mergedCtx = merged.getContext('2d');

  mergedCtx.drawImage(baseImage, 0, 0, merged.width, merged.height);
  mergedCtx.drawImage(canvas, 0, 0, merged.width, merged.height);

  imageDataUrl = merged.toDataURL('image/png');
  baseImage.src = imageDataUrl;

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  resetHistory();

  downloadLink.href = imageDataUrl;
  downloadLink.style.display = 'block';
});

imageInput.addEventListener('change', () => {
  const file = imageInput.files?.[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = () => {
    imageDataUrl = String(reader.result || '');
    baseImage.src = imageDataUrl;
  };
  reader.readAsDataURL(file);
});

baseImage.addEventListener('load', () => {
  baseImage.style.display = 'block';
  canvas.style.display = 'block';

  syncCanvasSize();
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  resetHistory();

  stage.scrollTop = 0;
  stage.scrollLeft = 0;
});

window.addEventListener('resize', () => {
  if (!imageDataUrl) return;
  syncCanvasSize();
});

setTool(activeTool);
setActionButtons();
