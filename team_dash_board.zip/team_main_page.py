import importlib.util
import json
import pathlib
import sys

import streamlit as st
import streamlit.components.v1 as components


BASE_DIR  = pathlib.Path(__file__).resolve().parent
HTML_PATH = BASE_DIR / "team_main_page.html"

PAGES = [
    "메인",
    "사외뉴스기사",
    "사외구조조달1그룹",
    "사외구조조달2그룹",
    "사외의장조달1그룹",
    "사외의장조달2그룹",
    "팀자체개발앱",
]


def render_main_page() -> None:
    if not HTML_PATH.exists():
        st.error("team_main_page.html 파일을 찾을 수 없습니다.")
        return
    html = HTML_PATH.read_text(encoding="utf-8", errors="replace")
    components.html(html, height=900, scrolling=False)


def render_placeholder(title: str) -> None:
    if st.button("← 메인으로 돌아가기"):
        st.query_params["page"] = "메인"
        st.rerun()
    st.title(title)
    st.caption("여기에 콘텐츠를 추가하세요.")


def _exec_module_from_path(module_name: str, module_path: pathlib.Path):
    if not module_path.exists():
        st.error(f"파일을 찾을 수 없습니다: {module_path}")
        return None
    module_dir = str(module_path.parent)
    if module_dir not in sys.path:
        sys.path.insert(0, module_dir)
    # sys.modules 중복 캐시 방지: 재실행 시 이전 모듈 제거
    sys.modules.pop(module_name, None)
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        st.error(f"모듈 로드 실패: {module_path}")
        return None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main() -> None:
    # 새 창(inner 라우트)별 브라우저 탭 제목 동적 설정
    inner_q = st.query_params.get("inner", "")
    sub_q = st.query_params.get("sub", "")
    page_title = "Team Dashboard"
    if inner_q == "사외구조조달1그룹" and sub_q == "조립공정":
        page_title = "사외 블록 조립 예측 대시보드"
    elif inner_q == "사외구조조달1그룹" and sub_q == "셀가이드공정":
        page_title = "셀가이드공정"
    elif inner_q == "사외구조조달1그룹" and sub_q == "사외현장점검현황":
        page_title = "사외현장점검현황"
    elif inner_q == "사외구조조달1그룹" and sub_q == "사외현장점검입력":
        page_title = "사외현장점검입력"
    elif inner_q:
        page_title = f"{inner_q}{' - ' + sub_q if sub_q else ''}"

    st.set_page_config(page_title=page_title, layout="wide")

    # Streamlit chrome 최소화 – 모든 레이아웃·디자인은 HTML 파일에서 처리
    _hide_chrome = """
        <style>
        header[data-testid="stHeader"],
        footer,
        #MainMenu,
        [data-testid="stSidebarCollapsedControl"] { display: none !important; }
        </style>
    """
    _main_page_lock = """
        <style>
        html, body,
        .stApp,
        [data-testid="stAppViewContainer"],
        [data-testid="stMainBlockContainer"],
        [data-testid="stMain"],
        section.main,
        .main,
        .block-container {
            overflow: hidden !important;
            height: 100vh !important;
            padding: 0 !important;
            margin: 0 !important;
            max-width: 100% !important;
        }
        iframe {
            width: 100% !important;
            height: 100vh !important;
            border: none !important;
            display: block !important;
        }
        </style>
    """
    if inner_q:
        # 내부 앱 새창: 헤더/푸터만 숨기고 스크롤은 허용
        st.markdown(_hide_chrome, unsafe_allow_html=True)
    else:
        # 메인 대시보드: HTML iframe 전체 제어, 스크롤 잠금
        st.markdown(_hide_chrome + _main_page_lock, unsafe_allow_html=True)

    # ?inner= 는 내부 iframe 콘텐츠 전용 라우트 (사이드바 없음)
    inner = inner_q
    sub = sub_q
    if inner:
        if inner == "사외뉴스기사":
            _mod = _exec_module_from_path("news", BASE_DIR / "new" / "news.py")
            if _mod and hasattr(_mod, "render"):
                _mod.render()

        elif inner == "사외구조조달1그룹" and sub == "사외현장점검현황":
            _exec_module_from_path(
                "safety_daily_report",
                BASE_DIR / "group_st_1" / "safety" / "safety_daily_report" / "safety_daily_report.py",
            )
        elif inner == "사외구조조달1그룹" and sub == "사외현장점검입력":
            _exec_module_from_path(
                "safety_report_input",
                BASE_DIR / "group_st_1" / "safety" / "safety_daily_report" / "report_input.py",
            )
        elif inner == "사외구조조달1그룹" and sub == "조립공정":
            _exec_module_from_path(
                "blk_ass_main_page",
                BASE_DIR / "group_st_1" / "process" / "blk_ass" / "main_page.py",
            )

        elif inner == "사외구조조달1그룹" and sub == "셀가이드공정":
            _exec_module_from_path(
                "cell_guide_main_page",
                BASE_DIR / "group_st_1" / "process" / "cell_guide" / "main_page.py",
            )

        elif inner == "사외구조조달1그룹" and sub == "달력":
            cal_path = BASE_DIR / "group_st_1" / "calendar" / "calendar.html"
            if not cal_path.exists():
                st.error(f"calendar.html 파일을 찾을 수 없습니다: {cal_path}")
            else:
                cal_html = cal_path.read_text(encoding="utf-8", errors="replace")
                data_path = BASE_DIR / "group_st_1" / "calendar" / "calendar_data.json"
                cal_data = {}
                if data_path.exists():
                    try:
                        cal_data = json.loads(data_path.read_text(encoding="utf-8"))
                    except Exception:
                        cal_data = {}
                safe_data = json.dumps(cal_data, ensure_ascii=True).replace("</", "<\\/")
                inject = f"<script>window.__CALENDAR_FILE_DATA__ = {safe_data};</script>"
                cal_html = cal_html.replace("</head>", f"{inject}</head>", 1)
                components.html(cal_html, height=900, scrolling=True)

        else:
            st.title(f"{inner}{' - ' + sub if sub else ''}")
            st.caption("여기에 콘텐츠를 추가하세요.")
        return

    # 사이드바가 포함된 HTML 항상 렌더링
    render_main_page()


if __name__ == "__main__":
    main()
