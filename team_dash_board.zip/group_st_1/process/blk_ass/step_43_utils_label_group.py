from __future__ import annotations
"""
step_43_utils_label_group.py

엑셀 행렬표(능력/계획/실적/누계차/지연일수)를 출력할 때 사용하는

- 행 라벨(ROW_LABELS)
- 협력사 기본 순서(BASE_VENDORS)
- 최종 출력 순서(PRINT_ORDER)
- 그룹 정의(GROUP_DEFS)
- 공통 테두리 스타일(BORDER_THIN)
- 그룹/협력사 이름을 실제 개별 협력사 목록으로 풀어주는 함수(resolve_group_members)

를 모아둔 유틸 모듈입니다.

다른 step 파일들에서는 이 모듈을 import 해서
엑셀 타이틀/섹션 순서/그룹 합산 등에 재사용합니다.
"""

from typing import List
from openpyxl.styles import Border, Side

# ─────────────────────────────────────────────
# 표 행(Row) 라벨 정의
# ─────────────────────────────────────────────
# 모든 행렬표에서 공통으로 사용하는 5개 행 순서
ROW_LABELS = ["능력", "계획", "실적", "누계차", "지연일수"]

# ─────────────────────────────────────────────
# 개별 협력사 기본 순서
# ─────────────────────────────────────────────
# - 데이터 상의 협력사를 이 순서대로 정렬할 때 사용
# - vendors_all 과의 교집합만 실제로 사용됩니다.
BASE_VENDORS = [
    "기민",
    "디케이(건화)",
    "기득",
    "EK",
    "신한",
    "동림",
    "HSG성동",
    "금강",
    "기민(코밍)",
    "호진",
    "DHI(통영)",
    "오리엔탈",
    "욱일",
    "HSG성동(해양)",
    "HSG(사천)(해양)",
]

# ─────────────────────────────────────────────
# 최종 엑셀 출력 순서
# ─────────────────────────────────────────────
# - 섹션(전체/그룹/개별 협력사)을 출력하는 순서
# - '전체' → '일반' → 개별 협력사들 → 그룹들 → 해양 순으로 구성
PRINT_ORDER = [
    "전체",
    "일반",
    "기민",
    "디케이(건화)",
    "기득",
    "EK",
    "신한",
    "동림",
    "HSG성동",
    "전문화",
    "T-BHD",
    "금강",
    "H/COAMING",
    "기민(코밍)",
    "호진",
    "선실",
    "DHI(통영)",
    "오리엔탈",
    "욱일",
    "해양",
    "HSG성동(해양)",
    "HSG(사천)(해양)",
]

# ─────────────────────────────────────────────
# 그룹 정의
# ─────────────────────────────────────────────
# - key: 그룹 이름
# - value: 자식(하위 그룹 또는 개별 협력사) 리스트
# - resolve_group_members() 에서 재귀적으로 펼쳐서
#   최종 개별 협력사 목록을 만들 때 사용합니다.
GROUP_DEFS: dict[str, list[str]] = {
    # 1차 그룹
    "일반": ["기민", "디케이(건화)", "기득", "EK", "신한", "동림"],
    "T-BHD": ["금강"],
    "H/COAMING": ["기민(코밍)", "호진"],
    "선실": ["DHI(통영)", "오리엔탈", "욱일"],
    "해양": ["HSG성동(해양)", "HSG(사천)(해양)"],

    # 상위 그룹 (그룹 안에 그룹 포함)
    "전문화": ["T-BHD", "H/COAMING", "선실"],
    "전체": ["일반", "HSG성동", "전문화", "해양"],
}

# ─────────────────────────────────────────────
# 공통 테두리 스타일 (엑셀 출력용)
# ─────────────────────────────────────────────
thin = Side(style="thin", color="000000")
BORDER_THIN = Border(left=thin, right=thin, top=thin, bottom=thin)


# ─────────────────────────────────────────────
# 그룹/협력사 이름 → 실제 개별 협력사 목록으로 풀기
# ─────────────────────────────────────────────
def resolve_group_members(name: str, vendors_all: List[str]) -> List[str]:
    """
    그룹/협력사 이름을 실제 개별 협력사 목록으로 풀어주는 함수.

    Parameters
    ----------
    name : str
        - "전체", "일반", "전문화", "해양" 같은 그룹 이름
        - 또는 "기민", "금강" 같은 개별 협력사 이름
    vendors_all : List[str]
        - 실제 데이터에 존재하는 협력사 목록
        - 이 목록에 없는 이름은 최종 결과에서 제외됩니다.

    Returns
    -------
    List[str]
        - name 이 그룹이면, 재귀적으로 GROUP_DEFS 를 따라 내려가면서
          모든 하위 그룹을 펼쳐서 "개별 협력사"만 리스트로 반환
        - name 이 개별 협력사이고 vendors_all 에 포함되어 있으면 [name]
        - 중복되는 협력사는 한 번만 포함 (순서는 GROUP_DEFS 지정 순서를 유지)

    예시
    ----
    vendors_all = ["기민", "디케이(건화)", "HSG성동", "금강", "기민(코밍)", "호진", ... ]

    >>> resolve_group_members("일반", vendors_all)
    ["기민", "디케이(건화)", "기득", "EK", "신한", "동림"]  # vendors_all 에 있는 것만 반환

    >>> resolve_group_members("전문화", vendors_all)
    ["금강", "기민(코밍)", "호진", "DHI(통영)", "오리엔탈", "욱일"]

    >>> resolve_group_members("전체", vendors_all)
    ["기민", "디케이(건화)", "기득", "EK", "신한", "동림",
     "HSG성동",
     "금강", "기민(코밍)", "호진",
     "DHI(통영)", "오리엔탈", "욱일",
     "HSG성동(해양)", "HSG(사천)(해양)"]
    """

    def _expand(n: str) -> List[str]:
        """
        내부 재귀 함수.
        - n 이 GROUP_DEFS 에 있으면 하위 항목들을 재귀적으로 펼침
        - 없으면 개별 협력사로 간주하고 [n] 반환
        """
        if n in GROUP_DEFS:
            result: List[str] = []
            for child in GROUP_DEFS[n]:
                result.extend(_expand(child))
            return result
        return [n]

    # name 을 재귀적으로 풀어서(flat) → 실제 존재하는 협력사만 필터링
    flat = _expand(name)

    seen: set[str] = set()
    resolved: List[str] = []
    for v in flat:
        # 실제 데이터에 존재하고, 아직 추가하지 않은 협력사만 추가
        if v in vendors_all and v not in seen:
            seen.add(v)
            resolved.append(v)

    return resolved
