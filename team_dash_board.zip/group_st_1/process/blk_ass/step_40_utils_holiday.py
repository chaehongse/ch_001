from __future__ import annotations

import datetime as dt
import os
from typing import Iterable, List, Dict, Optional, Set


# ─────────────────────────────────────────────
# CONFIG: 회사 달력에 맞게 수정하는 영역
# ─────────────────────────────────────────────

# 1) 고정 양력 공휴일 (월, 일)
#    - 실제 사용하는 공휴일만 남기거나 추가해서 사용하세요.
FIXED_SOLAR_HOLIDAYS: List[tuple[int, int]] = [
    (1, 1),   # 신정
    (3, 1),   # 삼일절
    (5, 5),   # 어린이날
    (6, 6),   # 현충일
    (8, 15),  # 광복절
    (10, 3),  # 개천절
    (10, 9),  # 한글날
    (12, 25), # 성탄절
]

# 2) 명절 등 양력으로 변환된 휴일 날짜 (연도별로 관리)
#    - 실제 회사/국가 달력에 맞게 "양력 기준 (월, 일)" 값으로 채워 넣으시면 됩니다.
#    - 예시: 2025년 설/추석 연휴 (임의 날짜 예시, 실제와 다를 수 있음)
LUNAR_HOLIDAYS_BY_YEAR: Dict[int, List[tuple[int, int]]] = {
    2025: [
        # 설날 연휴 예시
        (1, 27), (1, 28), (1, 29), (1, 30),
        # 추석 연휴 예시
        (10, 5), (10, 6), (10, 7), (10, 9), (10, 10),
    ],
    2026: [
        # 설날 연휴 예시
        (2, 16), (2, 17), (2, 18),
        # 추석 연휴 예시
        (9, 24), (9, 25),
        # 회사 연중 휴무
        (1, 2), (2, 19), (9, 28),
        # 부처님 오신날/광복절/개천절 대체휴일
        (5, 25), (8, 17), (10, 5),
    ],
}

# 3) 회사 휴가/창립기념일 등 "기간" 단위 휴무 (start ~ end, 양끝 포함, 양력 기준)
#    - 실제 연도/기간에 맞게 수정하세요.
COMPANY_VACATION_RANGES: List[dict] = [
    # 예시) 2025년 여름휴가: 8/4 ~ 8/8
    {
        "name": "2025년 하계휴가",
        "start": dt.date(2025, 8, 4),
        "end": dt.date(2025, 8, 8),
    },
    {
        "name": "2026년 하계휴가",
        "start": dt.date(2026, 8, 3),
        "end": dt.date(2026, 8, 7),
    },
]

# 4) 주말을 휴무로 볼지 여부 (True: 토/일을 자동 휴무로 처리)
WEEKEND_IS_HOLIDAY: bool = True

# 5) 회사 MS 서버 휴일 테이블 사용 설정
#    - 출근 후 DB 접속 정보와 테이블/컬럼명을 입력해서 사용하세요.
#    - 설정이 비어있거나 접속 실패 시, 아래 로컬(고정/명절/회사휴가) 설정으로 대체됩니다.
USE_DB_HOLIDAYS: bool = True
HOLIDAY_DB_URL: Optional[str] = os.getenv("HOLIDAY_DB_URL")  # 예: "mssql+pyodbc://user:pwd@SERVER/DB?driver=ODBC+Driver+17+for+SQL+Server"
HOLIDAY_TABLE: str = os.getenv("HOLIDAY_TABLE", "holiday_calendar")
HOLIDAY_DATE_COL: str = os.getenv("HOLIDAY_DATE_COL", "holiday_date")
# 필요 시: 휴일 여부 플래그 컬럼 (없으면 None)
HOLIDAY_FLAG_COL: Optional[str] = os.getenv("HOLIDAY_FLAG_COL", None)  # 예: "is_holiday"

# db_config.py 값이 있으면 우선 사용
try:
    from db_config import (
        USE_DB_HOLIDAYS as _CFG_USE_DB_HOLIDAYS,
        HOLIDAY_DB_URL as _CFG_HOLIDAY_DB_URL,
        HOLIDAY_TABLE as _CFG_HOLIDAY_TABLE,
        HOLIDAY_DATE_COL as _CFG_HOLIDAY_DATE_COL,
        HOLIDAY_FLAG_COL as _CFG_HOLIDAY_FLAG_COL,
    )

    USE_DB_HOLIDAYS = _CFG_USE_DB_HOLIDAYS
    if _CFG_HOLIDAY_DB_URL:
        HOLIDAY_DB_URL = _CFG_HOLIDAY_DB_URL
    if _CFG_HOLIDAY_TABLE:
        HOLIDAY_TABLE = _CFG_HOLIDAY_TABLE
    if _CFG_HOLIDAY_DATE_COL:
        HOLIDAY_DATE_COL = _CFG_HOLIDAY_DATE_COL
    if _CFG_HOLIDAY_FLAG_COL is not None:
        HOLIDAY_FLAG_COL = _CFG_HOLIDAY_FLAG_COL
except Exception:
    pass


def _coerce_dates(rows: Iterable) -> Set[dt.date]:
    """DB 결과를 date 집합으로 변환."""
    out: Set[dt.date] = set()
    for r in rows:
        if isinstance(r, dt.datetime):
            out.add(r.date())
        elif isinstance(r, dt.date):
            out.add(r)
        else:
            try:
                out.add(dt.date.fromisoformat(str(r)))
            except Exception:
                continue
    return out


def _db_holidays(year: int) -> Set[dt.date]:
    """
    MS 서버 휴일 테이블에서 해당 연도 휴일을 조회.
    - HOLIDAY_DB_URL / HOLIDAY_TABLE / HOLIDAY_DATE_COL 기준
    - HOLIDAY_FLAG_COL 이 있으면 1/True 인 것만 사용
    """
    if not USE_DB_HOLIDAYS or not HOLIDAY_DB_URL:
        return set()

    try:
        from sqlalchemy import create_engine, text
    except Exception:
        return set()

    start = dt.date(year, 1, 1)
    end = dt.date(year, 12, 31)

    if HOLIDAY_FLAG_COL:
        sql = text(
            f"SELECT {HOLIDAY_DATE_COL} "
            f"FROM {HOLIDAY_TABLE} "
            f"WHERE {HOLIDAY_DATE_COL} BETWEEN :start AND :end "
            f"AND {HOLIDAY_FLAG_COL} = 1"
        )
    else:
        sql = text(
            f"SELECT {HOLIDAY_DATE_COL} "
            f"FROM {HOLIDAY_TABLE} "
            f"WHERE {HOLIDAY_DATE_COL} BETWEEN :start AND :end"
        )

    engine = create_engine(HOLIDAY_DB_URL, pool_pre_ping=True)
    try:
        with engine.connect() as conn:
            rows = [r[0] for r in conn.execute(sql, {"start": start, "end": end}).fetchall()]
    finally:
        engine.dispose()

    return _coerce_dates(rows)


# ─────────────────────────────────────────────
# 내부 유틸
# ─────────────────────────────────────────────

def _iter_dates(start: dt.date, end: dt.date):
    """
    start ~ end (양끝 포함) 날짜를 하루 단위로 생성하는 제너레이터.
    예) 2025-01-01 ~ 2025-01-03 → 1, 2, 3일 세 날짜를 순서대로 yield
    """
    cur = start
    while cur <= end:
        yield cur
        cur += dt.timedelta(days=1)


def _fixed_solar_holidays(year: int) -> Set[dt.date]:
    """
    고정 양력 공휴일을 해당 연도의 date 집합으로 변환.
    예) (3, 1) → 2025-03-01
    """
    return {dt.date(year, m, d) for (m, d) in FIXED_SOLAR_HOLIDAYS}


def _lunar_holidays_to_solar(year: int) -> Set[dt.date]:
    """
    명절(설날/추석 등) 휴일 (양력 기준)을 date 집합으로 변환.

    LUNAR_HOLIDAYS_BY_YEAR 에는 이미 "양력 (월, 일)" 이 들어있다고 가정합니다.
    실제 사용 시에는 각 연도별 설/추석 양력 날짜를 LUNAR_HOLIDAYS_BY_YEAR 에 등록하세요.
    """
    md_list = LUNAR_HOLIDAYS_BY_YEAR.get(year, [])
    return {dt.date(year, m, d) for (m, d) in md_list}


def _company_vacation_days(year: int) -> Set[dt.date]:
    """
    회사 휴가/창립기념일 등의 기간 휴무일을 date 집합으로 생성.
    - COMPANY_VACATION_RANGES 각 항목의 start~end 범위 중
      지정한 year에 해당하는 날짜만 포함합니다.
    """
    days: Set[dt.date] = set()
    for item in COMPANY_VACATION_RANGES:
        start: dt.date = item["start"]
        end: dt.date = item["end"]
        # 다른 연도와 걸쳐 있을 수 있으므로 year에 해당하는 날짜만 포함
        for d in _iter_dates(start, end):
            if d.year == year:
                days.add(d)
    return days


def _weekend_days(year: int) -> Set[dt.date]:
    """
    해당 연도의 모든 토/일 날짜 집합.
    - WEEKEND_IS_HOLIDAY=True 일 때만 build_holiday_set 에서 사용됩니다.
    """
    first = dt.date(year, 1, 1)
    last = dt.date(year, 12, 31)
    days: Set[dt.date] = set()
    for d in _iter_dates(first, last):
        if d.weekday() >= 5:  # 5=토요일, 6=일요일
            days.add(d)
    return days


# ─────────────────────────────────────────────
# 공개 함수
# ─────────────────────────────────────────────

def _local_holidays(year: int) -> Set[dt.date]:
    """
    로컬 하드코딩 기반 휴무일 집합.
    - 주말 + 고정 양력 공휴일 + 명절 + 회사 휴가

    DB 조회 실패 또는 미설정 시 폴백으로 사용됩니다.
    """
    days: Set[dt.date] = set()
    if WEEKEND_IS_HOLIDAY:
        days |= _weekend_days(year)
    days |= _fixed_solar_holidays(year)
    days |= _lunar_holidays_to_solar(year)
    days |= _company_vacation_days(year)
    return days


def build_holiday_set(year: int) -> Set[dt.date]:
    """
    주말, 고정 공휴일, 명절, 회사 휴가일을 모두 포함한
    '해당 연도의 휴무일(date) 집합'을 생성합니다.

    우선순위
    --------
    1. USE_DB_HOLIDAYS=True 이고 HOLIDAY_DB_URL 이 설정된 경우
       → MS 서버(Azure SQL) 휴일 테이블에서 조회
       → 조회 성공 + 데이터 있으면 DB 결과 사용 (주말 자동 합산)
       → 조회 성공 + 데이터 없으면 경고 후 로컬 폴백
       → 접속/쿼리 실패(예외) 시 경고 후 로컬 폴백
    2. 그 외 → 로컬 하드코딩(FIXED_SOLAR_HOLIDAYS, LUNAR_HOLIDAYS_BY_YEAR,
                              COMPANY_VACATION_RANGES) 사용

    사용 예)
        holidays_2025 = build_holiday_set(2025)
        if dt.date(2025, 3, 1) in holidays_2025:
            ...
    """
    # 0) MS 서버 휴일 테이블 우선 사용
    if USE_DB_HOLIDAYS and HOLIDAY_DB_URL:
        try:
            db_days = _db_holidays(year)
            if db_days:
                holiday_days = set(db_days)
                if WEEKEND_IS_HOLIDAY:
                    holiday_days |= _weekend_days(year)
                return holiday_days
            # 접속은 성공했지만 해당 연도 데이터가 없는 경우
            print(
                f"[HOLIDAY-WARN] MS 서버 DB에서 {year}년 휴일 데이터가 없습니다."
                " → 로컬 하드코딩으로 대체합니다."
            )
        except Exception as e:
            print(
                f"[HOLIDAY-WARN] MS 서버 휴일 DB 조회 실패 → 로컬 하드코딩으로 대체합니다."
                f" (사유: {e})"
            )

    # 1) 로컬 폴백: 주말 + 고정 공휴일 + 명절 + 회사 휴가
    return _local_holidays(year)


def is_holiday(d: dt.date) -> bool:
    """
    해당 날짜가 휴무일이면 True, 아니면 False 를 반환.
    - 주말/고정 공휴일/명절/회사 휴가 모두 포함.

    인자 타입이 date 가 아니면 TypeError 를 발생시켜
    잘못된 사용을 조기에 발견합니다.
    """
    if not isinstance(d, dt.date):
        raise TypeError("is_holiday()는 datetime.date 객체를 인자로 받습니다.")
    holidays = build_holiday_set(d.year)
    return d in holidays


def next_working_day(d: dt.date) -> dt.date:
    """
    d가 휴무일이면, 휴무일이 아닌 날짜가 나올 때까지 하루씩(+1일) 이동해서 반환.
    d가 이미 영업일이면 그대로 d를 반환합니다.

    무한 루프 방지를 위해 최대 400일까지만 탐색하도록 되어 있습니다.
    (실제 상황에서 이 한계에 도달할 일은 거의 없습니다.)
    """
    if not isinstance(d, dt.date):
        raise TypeError("next_working_day()는 datetime.date 객체를 인자로 받습니다.")

    cur = d
    for _ in range(400):
        if not is_holiday(cur):
            return cur
        cur += dt.timedelta(days=1)

    # 이론상 도달하지 않지만, 방어적으로 마지막 값을 반환
    return cur


if __name__ == "__main__":
    # 간단 동작 테스트
    today = dt.date.today()
    year = today.year

    hset = build_holiday_set(year)
    print(f"[DEBUG] {year}년 휴무일 개수: {len(hset)}")
    print("오늘:", today, "휴무일 여부:", is_holiday(today))
    print("다음 영업일:", next_working_day(today))
