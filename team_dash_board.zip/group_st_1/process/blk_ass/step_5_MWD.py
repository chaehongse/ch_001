from __future__ import annotations

"""
step_5_MWD.py

역할 요약
---------
1. step_2_BPA_Data.outside_df2() 로 조회년도(year) 사외조립 데이터를 불러옵니다.
2. 기준계획/실적 데이터를 기준으로
   - 월별 집계 (plan_month / act_month)
   - 주별 집계 (plan_week  / act_week)
   - 일별 집계 (plan_day   / act_day)
   로 나누어 집계합니다.
3. 조회일(TODAY)을 기준으로 '하이브리드 축'을 만듭니다.
   - 조회월 이전: 월 단위 (1월, 2월, ...)
   - 조회월 내 조회주 이전: 주 단위 (15주, 16주, ...)
   - 조회주: 일 단위 (10/1, 10/2, ...)
   - 조회주 이후~조회월 내: 주 단위
   - 조회월 이후: 월 단위
4. 위 하이브리드 축을 기준으로 협력사/그룹/전체 단위 행렬을 생성합니다.
   - 능력(ton/일 → 월/주/일 단위 환산)
   - 계획
   - 실적 (조회일 이후는 공란 처리)
   - 누계차 (실적-계획 누적, 월↔주 경계 중복분 보정)
   - 지연일수 (누계차 / 능력)
5. step_3, step_4 와 동일한 스타일의 엑셀 파일로 저장합니다.
"""

import argparse
import datetime as dt
from typing import List, Tuple, Dict

import numpy as np
import pandas as pd

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font
from openpyxl.formatting.rule import CellIsRule
from openpyxl.utils import get_column_letter

# 자체 모듈
from step_0_MSF import OUT_DIR
from step_2_BPA_Data import outside_df2
from step_42_utils_calendar import (
    TODAY,
    DEFAULT_YEAR,
    _to_date,
    week_no_mon,
    week_span,
    dates_of_week,
    weeks_in_month,
)
from step_43_utils_label_group import (
    ROW_LABELS,
    BASE_VENDORS,
    PRINT_ORDER,
    GROUP_DEFS,
    BORDER_THIN,
    resolve_group_members,
)
from step_44_utils_TPD import (
    load_capacity,
    tpd_month,
    tpd_week,
    tpd_day,
)

# ─────────────────────────────────────────────
# 원천 → 월/주/일 집계 (정규화/치환 없음)
# ─────────────────────────────────────────────
def _weight_col(df: pd.DataFrame) -> str:
    """
    사용해야 할 중량 컬럼명을 자동 판별합니다.

    우선순위
    1) '고유_중량'
    2) '중량_고유'
    """
    if "고유_중량" in df.columns:
        return "고유_중량"
    if "중량_고유" in df.columns:
        return "중량_고유"
    raise KeyError("중량 컬럼 누락 ('고유_중량' 또는 '중량_고유').")


def build_aggregates(df_year: pd.DataFrame, year: int) -> dict:
    """
    연도별 원천 데이터를
    - 월
    - 주(월요일 시작 주차)
    - 일자
    단위로 집계한 결과를 dict로 반환합니다.
    """
    wcol = _weight_col(df_year)
    df = df_year.copy()

    # 필수 컬럼 확인
    if "협력사" not in df.columns:
        raise KeyError("협력사 누락")
    if "기준계획_완료" not in df.columns:
        raise KeyError("기준계획_완료 누락")
    if "실적_완료" not in df.columns:
        raise KeyError("실적_완료 누락")

    # 기준계획/실적 일자 변환
    df["계획일"] = df["기준계획_완료"].apply(_to_date)
    df["실적일"] = df["실적_완료"].apply(_to_date)

    # 해당 연도만 분리
    mask_plan_year = df["계획일"].apply(
        lambda d: isinstance(d, dt.date) and d.year == year
    )
    mask_act_year = df["실적일"].apply(
        lambda d: isinstance(d, dt.date) and d.year == year
    )
    df_plan = df.loc[mask_plan_year].copy()
    df_act = df.loc[mask_act_year].copy()

    # 월 / 주 / 일자 컬럼 세팅
    df_plan["월"] = df_plan["계획일"].apply(lambda d: d.month)
    df_plan["주"] = df_plan["계획일"].apply(lambda d: week_no_mon(d, year))
    df_plan["일자"] = df_plan["계획일"]

    df_act["월"] = df_act["실적일"].apply(lambda d: d.month)
    df_act["주"] = df_act["실적일"].apply(lambda d: week_no_mon(d, year))
    df_act["일자"] = df_act["실적일"]

    # 월별 집계
    plan_month = (
        df_plan.groupby(["협력사", "월"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "계획"})
    )
    act_month = (
        df_act.groupby(["협력사", "월"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "실적"})
    )

    # 주별 집계
    plan_week = (
        df_plan.dropna(subset=["주"])
        .groupby(["협력사", "주"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "계획"})
    )
    act_week = (
        df_act.dropna(subset=["주"])
        .groupby(["협력사", "주"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "실적"})
    )

    # 일별 집계
    plan_day = (
        df_plan.groupby(["협력사", "일자"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "계획"})
    )
    act_day = (
        df_act.groupby(["협력사", "일자"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "실적"})
    )

    return {
        "plan_month": plan_month,
        "act_month": act_month,
        "plan_week": plan_week,
        "act_week": act_week,
        "plan_day": plan_day,
        "act_day": act_day,
    }

def _recent_tpd_month(cap_df: pd.DataFrame, vendor: str, month: int):
    """
    월별 TPD:
    - 해당 월(month)에 값이 있으면 그 값
    - 없으면 과거 월 중 가장 최근 값
    - 전부 없으면 None
    """
    v = tpd_month(cap_df, vendor, month)
    if not pd.isna(v):
        return float(v)

    for m in range(month - 1, 0, -1):
        prev = tpd_month(cap_df, vendor, m)
        if not pd.isna(prev):
            return float(prev)
    return None


def _recent_tpd_week(cap_df: pd.DataFrame, vendor: str, year: int, week: int):
    """
    주간 TPD:
    - 해당 주(week)에 값이 있으면 그 값
    - 없으면 과거 주 중 가장 최근 값
    - 전부 없으면 None
    """
    v = tpd_week(cap_df, vendor, year, week)
    if not pd.isna(v):
        return float(v)

    for w in range(week - 1, 0, -1):
        prev = tpd_week(cap_df, vendor, year, w)
        if not pd.isna(prev):
            return float(prev)
    return None


def _recent_tpd_day(cap_df: pd.DataFrame, vendor: str, date: dt.date):
    """
    일별 TPD:
    - 해당 날짜에 값이 있으면 그 값
    - 없으면 같은 연도에서 과거 날짜 중 가장 최근 값
    - 전부 없으면 None
    """
    v = tpd_day(cap_df, vendor, date)
    if not pd.isna(v):
        return float(v)

    d = date - dt.timedelta(days=1)
    while d.year == date.year:
        prev = tpd_day(cap_df, vendor, d)
        if not pd.isna(prev):
            return float(prev)
        d -= dt.timedelta(days=1)
    return None

# ─────────────────────────────────────────────
# 하이브리드 축 구성 (월/주/일 혼합)
# ─────────────────────────────────────────────
def build_hybrid_axis(year: int, query_date: dt.date) -> List[Tuple[str, dict]]:
    """
    조회일 기준 '하이브리드 축'을 생성합니다.

    축 구성 규칙
    -----------
    1) 조회월 이전: 월 단위
    2) 조회월 내에서 조회주 이전: 주 단위
    3) 조회주: 일 단위
    4) 조회주 이후~조회월: 주 단위
    5) 조회월 이후: 월 단위
    """
    qm = query_date.month
    qw = week_no_mon(query_date, year)

    labels: List[Tuple[str, dict]] = []

    # 1) 조회월 이전 월
    for m in range(1, qm):
        labels.append((f"{m}월", {"type": "month", "month": m}))

    # 2) 조회월 내 주(해당 월에 걸친 주 번호 목록)
    wlist = weeks_in_month(year, qm)
    if qw not in wlist:
        # week 목록에 조회주가 없으면 추가
        wlist = sorted(set(wlist + ([qw] if qw else [])))

    # 2-1) 조회주 이전 주
    for w in [x for x in wlist if x < qw]:
        labels.append((f"{w}주", {"type": "week", "week": w}))

    # 3) 조회주: 일 단위 (해당 연도/월만)
    for d in dates_of_week(year, qw):
        if d.year == year and d.month == qm:
            labels.append((f"{d.month}/{d.day}", {"type": "day", "date": d}))

    # 4) 조회주 이후 주
    for w in [x for x in wlist if x > qw]:
        labels.append((f"{w}주", {"type": "week", "week": w}))

    # 5) 조회월 이후 월
    for m in range(qm + 1, 12 + 1):
        labels.append((f"{m}월", {"type": "month", "month": m}))

    return labels


# ─────────────────────────────────────────────
# 값 생성 (벤더 단위)
#  - 월/주/일 중복 구간 보정
#  - 능력 규칙/미래 구간 마스킹
# ─────────────────────────────────────────────
def _daily_dicts_for_vendor(
    agg: dict, vendor: str
) -> Tuple[Dict[dt.date, float], Dict[dt.date, float]]:
    """
    해당 협력사의 일별 계획/실적을 dict(date → float) 형태로 반환합니다.
    """
    pdict: Dict[dt.date, float] = {}
    if not agg["plan_day"].empty:
        sub = agg["plan_day"].loc[agg["plan_day"]["협력사"] == vendor]
        pdict = {
            pd.to_datetime(r["일자"]).date(): float(r["계획"]) for _, r in sub.iterrows()
        }

    adict: Dict[dt.date, float] = {}
    if not agg["act_day"].empty:
        sub = agg["act_day"].loc[agg["act_day"]["협력사"] == vendor]
        adict = {
            pd.to_datetime(r["일자"]).date(): float(r["실적"]) for _, r in sub.iterrows()
        }

    return pdict, adict


def series_for_vendor(
    vendor: str,
    cap_df: pd.DataFrame,
    agg: dict,
    axis_meta: List[Tuple[str, dict]],
    year: int,
    query_date: dt.date,
):
    """
    단일 협력사에 대해,
    하이브리드 축 기준의 시계열(능력, 계획, 실적, 누계차, 지연일수)을 생성합니다.
    """
    # 월/주별 집계 Series 준비 (없으면 빈 Series)
    pm = (
        agg["plan_month"]
        .loc[agg["plan_month"]["협력사"] == vendor]
        .set_index("월")["계획"]
        if not agg["plan_month"].empty
        else pd.Series(dtype=float)
    )
    am = (
        agg["act_month"]
        .loc[agg["act_month"]["협력사"] == vendor]
        .set_index("월")["실적"]
        if not agg["act_month"].empty
        else pd.Series(dtype=float)
    )
    pw = (
        agg["plan_week"]
        .loc[agg["plan_week"]["협력사"] == vendor]
        .set_index("주")["계획"]
        if not agg["plan_week"].empty
        else pd.Series(dtype=float)
    )
    aw = (
        agg["act_week"]
        .loc[agg["act_week"]["협력사"] == vendor]
        .set_index("주")["실적"]
        if not agg["act_week"].empty
        else pd.Series(dtype=float)
    )

    # 일별 dict
    pdict, adict = _daily_dicts_for_vendor(agg, vendor)

    # 축별 리스트 초기화
    cap_calc_list: List[float] = []  # 지연일수 계산용 능력(숫자)
    cap_out_list: List[object] = []  # 엑셀 표기용 능력(None 허용)
    plan_list: List[float] = []
    act_list: List[float] = []

    overlap_delta_by_idx: Dict[int, float] = {}  # 월↔주 경계 중복분 보정용
    compare_dates: List[dt.date] = []  # 각 축 포인트의 대표 날짜(미래 판정용)

    # ── 축 메타 정보 순회 ──────────────────────────
    for idx, (_, meta) in enumerate(axis_meta):
        if meta["type"] == "month":
            # 월 단위 구간
            m = meta["month"]
            cap_val = _recent_tpd_month(cap_df, vendor, m)
            cap_calc_list.append(cap_val)

            plan_list.append(float(pm.get(m, 0.0)))
            act_list.append(float(am.get(m, 0.0)))

            # 대표 날짜: 해당 월의 말일
            last_day = (dt.date(year, m, 1).replace(day=28) + dt.timedelta(days=4))
            last_day = last_day.replace(day=1) - dt.timedelta(days=1)
            compare_dates.append(last_day)

            # 조회일 포함 이후 구간: 능력은 표시 안 함(None)
            cap_out_list.append(None if last_day >= query_date else cap_val)

        elif meta["type"] == "week":
            # 주 단위 구간
            w = meta["week"]
            cap_val = _recent_tpd_week(cap_df, vendor, year, w)
            cap_calc_list.append(cap_val)

            plan_list.append(float(pw.get(w, 0.0)))
            act_list.append(float(aw.get(w, 0.0)))

            # 대표 날짜: 해당 주의 종료일
            _, end = week_span(year, w)
            compare_dates.append(end)

            cap_out_list.append(None if end >= query_date else cap_val)

            # 월↔주 경계에서, 이전 월에 해당하는 일자분(월/주 중복)을 추출해서 보정값 저장
            s, e = week_span(year, w)
            if s.month != e.month:
                prev_month_days = [
                    d
                    for d in dates_of_week(year, w)
                    if d.month == s.month and d.year == year
                ]
                plan_overlap = sum(pdict.get(d, 0.0) for d in prev_month_days)
                act_overlap = sum(adict.get(d, 0.0) for d in prev_month_days)
                overlap_delta_by_idx[idx] = act_overlap - plan_overlap

        else:  # meta["type"] == "day"
            d = meta["date"]
            cap_val = _recent_tpd_day(cap_df, vendor, d)
            cap_calc_list.append(cap_val)
            plan_list.append(float(pdict.get(d, 0.0)))
            act_list.append(float(adict.get(d, 0.0)))
            compare_dates.append(d)

            cap_out_list.append(None if d >= query_date else cap_val)

    # ── numpy 배열로 변환 ──────────────────────────
    cap_calc = np.array(
        [np.nan if pd.isna(x) else float(x) for x in cap_calc_list], dtype=float
    )
    plan_arr = np.array(plan_list, dtype=float)
    act_arr = np.array(act_list, dtype=float)

    # 조회일 기준 미래 구간 마스크 (대표 날짜 >= 조회일)
    mask_future = np.array([cd >= query_date for cd in compare_dates], dtype=bool)

    # 누계차 계산용 실적: 미래 구간은 0으로 두고 diff 계산
    actual_numeric = act_arr.copy()
    actual_numeric[mask_future] = 0.0
    diff = np.nan_to_num(actual_numeric) - np.nan_to_num(plan_arr)
    cumsum = np.cumsum(diff)

    # 월↔주 경계 중복 감산 (해당 인덱스 이후 전체에서 delta 보정)
    for i, delta in overlap_delta_by_idx.items():
        if delta:
            cumsum[i:] -= delta

    # 엑셀 표기용 배열 준비
    cap_out = np.array(cap_out_list, dtype=object)
    act_out = actual_numeric.astype(object)
    cumsum_out = cumsum.astype(object)
    delay_out = np.empty_like(cumsum, dtype=object)

    for i in range(len(cap_out)):
        if mask_future[i]:
            # 미래 구간: 실적/누계차/지연일수는 공란
            act_out[i] = None
            cumsum_out[i] = None
            delay_out[i] = None
        else:
            denom = cap_calc[i]
            if (
                isinstance(denom, (int, float, np.floating))
                and not np.isnan(denom)
                and denom != 0
            ):
                delay_out[i] = cumsum[i] / denom
            else:
                delay_out[i] = None

    return cap_out, plan_arr, act_out, cumsum_out, delay_out


def matrix_vendor(
    vendor: str,
    cap_df: pd.DataFrame,
    agg: dict,
    axis_meta: List[Tuple[str, dict]],
    year: int,
    query_date: dt.date,
) -> pd.DataFrame:
    """
    단일 협력사의 하이브리드 축 행렬 생성.

    행: ROW_LABELS (능력, 계획, 실적, 누계차, 지연일수)
    열: 축 레이블(예: '1월', '2월', '15주', '10/1', ...)
    """
    cap, plan, act, csum, delay = series_for_vendor(
        vendor, cap_df, agg, axis_meta, year, query_date
    )
    cols = [lbl for (lbl, _) in axis_meta]
    return pd.DataFrame(
        [cap, plan, act, csum, delay],
        index=ROW_LABELS,
        columns=cols,
    )


def matrix_total(
    vendors: List[str],
    cap_df: pd.DataFrame,
    agg: dict,
    axis_meta: List[Tuple[str, dict]],
    year: int,
    query_date: dt.date,
) -> pd.DataFrame:
    """
    여러 협력사(그룹/전체)에 대한 하이브리드 축 합산 행렬 생성.
    """
    mats = [matrix_vendor(v, cap_df, agg, axis_meta, year, query_date) for v in vendors]
    cols = [lbl for (lbl, _) in axis_meta]

    if not mats:
        return pd.DataFrame(0, index=ROW_LABELS, columns=cols, dtype=object)

    # ── 능력 합계(지연일수 계산용 숫자) ─────────────────
    cap_arrays_num = [
        [
            0.0
            if (val is None or (isinstance(val, float) and np.isnan(val)))
            else float(val)
            for val in m.loc["능력"].values
        ]
        for m in mats
    ]
    cap_sum_numeric = np.nansum(cap_arrays_num, axis=0)

    # 계획 합계
    plan = np.nansum(
        [m.loc["계획"].values.astype(float) for m in mats],
        axis=0,
    )

    # 실적 합계 (None → 0)
    act_arrays = [
        [0.0 if v is None else float(v) for v in m.loc["실적"].values]
        for m in mats
    ]
    act_sum = np.nansum(act_arrays, axis=0)

    # 누계차 합계 (None → 0)
    csum_arrays = [
        [0.0 if v is None else float(v) for v in m.loc["누계차"].values]
        for m in mats
    ]
    csum_sum = np.nansum(csum_arrays, axis=0)

    # 지연일수 = 누계차 / 능력합
    delay_out = np.empty_like(csum_sum, dtype=object)
    for i in range(len(cols)):
        denom = cap_sum_numeric[i]
        if denom and not np.isnan(denom) and denom != 0:
            delay_out[i] = csum_sum[i] / denom
        else:
            delay_out[i] = None

    # ── 능력 표기용(협력사별 능력합) ───────────────────
    cap_out = np.array(
        [
            sum(
                0.0
                if (
                    val is None
                    or (isinstance(val, float) and np.isnan(val))
                )
                else float(val)
                for val in [mats[k].loc["능력", cols[i]] for k in range(len(mats))]
            )
            for i in range(len(cols))
        ],
        dtype=float,
    ).astype(object)

    # 축 포인트별 대표 날짜 계산 (미래 구간 마스킹용)
    compare_dates: List[dt.date] = []
    for _, meta in axis_meta:
        if meta["type"] == "month":
            m = meta["month"]
            last_day = (dt.date(year, m, 1).replace(day=28) + dt.timedelta(days=4))
            last_day = last_day.replace(day=1) - dt.timedelta(days=1)
            compare_dates.append(last_day)
        elif meta["type"] == "week":
            _, end = week_span(year, meta["week"])
            compare_dates.append(end)
        else:  # day
            compare_dates.append(meta["date"])

    mask_future = np.array([cd >= query_date for cd in compare_dates], dtype=bool)

    # 미래 구간: 능력/실적/누계차/지연일수 모두 공란 처리
    for i in range(len(cols)):
        if mask_future[i]:
            cap_out[i] = None

    act_out = act_sum.astype(object)
    csum_out = csum_sum.astype(object)
    for i in range(len(cols)):
        if mask_future[i]:
            act_out[i] = None
            csum_out[i] = None
            delay_out[i] = None

    return pd.DataFrame(
        [cap_out, plan, act_out, csum_out, delay_out],
        index=ROW_LABELS,
        columns=cols,
    )


# ─────────────────────────────────────────────
# Excel 출력 유틸
# ─────────────────────────────────────────────
def borders(ws, r1: int, r2: int, c1: int = 1, c2: int | None = None) -> None:
    """
    지정한 범위(r1~r2, c1~c2)에 얇은 테두리(BORDER_THIN)를 적용합니다.
    """
    if c2 is None:
        c2 = ws.max_column
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            ws.cell(row=r, column=c).border = BORDER_THIN


def write_header_row(ws, row: int, cols: List[str]) -> None:
    """
    상단 헤더행(구분 / 하이브리드 축 레이블)을 그립니다.
    """
    # A열: '구분 (단위: ton)'
    ca = ws.cell(row=row, column=1, value="구분 (단위: ton)")
    ca.font = Font(bold=True)
    ca.alignment = Alignment(horizontal="center", vertical="center")

    # B열 이후: 축 레이블 (예: 1월, 2월, 3월, 15주, 10/1, ...)
    for idx, name in enumerate(cols, start=2):
        cell = ws.cell(row=row, column=idx, value=name)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.column_dimensions[get_column_letter(idx)].width = 10

    borders(ws, row, row, 1, 1 + len(cols))


def write_block(ws, start_row: int, title: str, mat: pd.DataFrame) -> int:
    """
    타이틀 + 헤더 + 데이터 영역을 하나의 블록으로 작성하고,
    다음 블록이 시작될 행 번호를 반환합니다.
    """
    # ── 타이틀 행 ────────────────────────────────
    t = ws.cell(row=start_row, column=1, value=title)
    t.font = Font(bold=True, size=12)
    t.alignment = Alignment(horizontal="left", vertical="center")

    # ── 헤더 행 ─────────────────────────────────
    hdr = start_row + 1
    cols = mat.columns.tolist()
    write_header_row(ws, hdr, cols)

    # ── 데이터 행(능력·계획·실적·누계차·지연일수) ──
    data_start = hdr + 1
    for i, rname in enumerate(ROW_LABELS):
        r = data_start + i
        # 왼쪽 라벨(능력/계획/실적/누계차/지연일수)
        ws.cell(row=r, column=1, value=rname).alignment = Alignment(
            horizontal="left", vertical="center"
        )
        # 축별 값
        for j, col in enumerate(cols, start=2):
            val = mat.loc[rname, col]
            cell = ws.cell(row=r, column=j, value=val)
            cell.alignment = Alignment(horizontal="right", vertical="center")
            # 지연일수는 소수 1자리, 나머지는 정수(천단위 콤마)
            cell.number_format = "0.0" if rname == "지연일수" else "#,##0"

    last_col = 1 + len(cols)

    # 음수 값 빨간색 처리(조건부 서식)
    rng = (
        f"{get_column_letter(2)}{data_start}:"
        f"{get_column_letter(last_col)}{data_start + len(ROW_LABELS) - 1}"
    )
    ws.conditional_formatting.add(
        rng,
        CellIsRule(
            operator="lessThan",
            formula=["0"],
            stopIfTrue=False,
            font=Font(color="FF0000"),
        ),
    )

    # 테두리 적용 및 다음 시작 행 반환
    borders(ws, data_start, data_start + len(ROW_LABELS) - 1, 1, last_col)
    return data_start + len(ROW_LABELS) + 1


def autosize_left(ws) -> None:
    """
    A열(구분) 너비를 고정폭으로 설정합니다.
    """
    ws.column_dimensions["A"].width = 16


# ─────────────────────────────────────────────
# 메인
# ─────────────────────────────────────────────
def main(year: int = DEFAULT_YEAR) -> None:
    """
    조립 계획/실적 (하이브리드 월/주/일) 엑셀 리포트를 생성합니다.
    """
    query_date = TODAY  # 필요 시 argparse 옵션으로 특정 날짜를 받을 수도 있음

    # 1) 원천 데이터
    df_year = outside_df2(year)
    if df_year.empty:
        raise ValueError(f"[step_2] {year}년 데이터가 비어 있습니다.")

    if "협력사" not in df_year.columns:
        raise KeyError("협력사 컬럼 누락")
    vendors_all = df_year["협력사"].astype(str).str.strip().unique().tolist()

    # 실제 존재하는 협력사만 BASE_VENDORS 순서대로 사용
    ordered_vendors = [v for v in BASE_VENDORS if v in vendors_all]

    # 2) 능력(TPD) / 집계 데이터 / 축 메타 정보
    cap_df = load_capacity(year)
    agg = build_aggregates(df_year, year)
    axis_meta = build_hybrid_axis(year, query_date)

    # 3) 타이틀용 TPD: 조회일이 속한 주(qw)의 TPD가 없으면 과거 주의 최근 TPD 사용
    qw = week_no_mon(query_date, year) or 1
    vendor_title_tpd: Dict[str, float] = {}
    for v in ordered_vendors:
        w_tpd = _recent_tpd_week(cap_df, v, year, qw)
        vendor_title_tpd[v] = 0.0 if w_tpd is None else float(w_tpd)

    def title_tpd(name: str) -> float:
        """
        타이틀 문자열에 들어갈 TPD 값을 계산합니다.
        - 개별: 해당 협력사 주간 TPD
        - 그룹/전체: 구성원 협력사의 주간 TPD 합
        """
        if name in vendor_title_tpd:
            return vendor_title_tpd[name]

        members = resolve_group_members(name, vendors_all)
        if not members:
            return 0.0
        return float(sum(vendor_title_tpd.get(v, 0.0) for v in members))

    # 4) 엑셀 워크북 생성
    wb = Workbook()
    ws = wb.active
    ws.title = "조립_계획실적"

    row = 1

    # 5) 출력 순서대로(PRINT_ORDER) 블록 작성
    for name in PRINT_ORDER:
        # (1) 전체 / 그룹
        if name == "전체":
            members = resolve_group_members("전체", vendors_all)
            if members:
                mat = matrix_total(
                    members, cap_df, agg, axis_meta, year, query_date
                )
            else:
                cols = [lbl for (lbl, _) in axis_meta]
                mat = pd.DataFrame(
                    0, index=ROW_LABELS, columns=cols, dtype=object
                )
        elif name in GROUP_DEFS:
            members = resolve_group_members(name, vendors_all)
            if members:
                mat = matrix_total(
                    members, cap_df, agg, axis_meta, year, query_date
                )
            else:
                cols = [lbl for (lbl, _) in axis_meta]
                mat = pd.DataFrame(
                    0, index=ROW_LABELS, columns=cols, dtype=object
                )

        # (2) 개별 협력사
        else:
            mat = matrix_vendor(name, cap_df, agg, axis_meta, year, query_date)

        tpd_val = title_tpd(name)
        row = write_block(ws, row, f"{name}_{tpd_val:,.1f}톤/일", mat)

    autosize_left(ws)

    # 6) 파일 저장
    query_date = dt.date.today()
    date_folder = query_date.strftime("%Y-%m-%d")  
    target_dir = OUT_DIR / date_folder
    target_dir.mkdir(parents=True, exist_ok=True)
    date_suffix = query_date.strftime("%y%m%d")
    file_name = f"{year}년도_사외_조립_계획실적_현황_{date_suffix}.xlsx"
    out_path = target_dir / file_name
    wb.save(out_path)
    print(f"[OK] 저장 완료: {out_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="조립 계획/실적 (하이브리드 월/주/일)"
    )
    parser.add_argument("-y", "--year", type=int, default=DEFAULT_YEAR)
    args = parser.parse_args()
    main(year=args.year)
