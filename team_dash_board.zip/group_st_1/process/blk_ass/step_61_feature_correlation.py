from __future__ import annotations
"""
step_61_feature_correlation.py

독립변수(피처) 간 상관계수 분석
---------------------------------
step_47_utils_train_table._build_vendor_table 에서 생성되는 피처 행렬을
협력사별·전체 데이터 기준으로 피어슨 상관계수를 계산하여 엑셀로 저장한다.

분석 내용
---------
  1) 기술통계 요약                       (시트: "기술통계_요약")
  2) 피처 간 상관계수 히트맵 매트릭스   (시트: "피처간_상관계수")
  3) 타겟(lag_days) vs 각 피처 상관계수 (시트: "타겟_상관계수")
  4) 협력사별 타겟 상관계수 요약        (시트: "협력사별_요약")

출력 엑셀
----------
  파일명: {year}년도_피처_상관계수_분석_{YYMMDD}.xlsx
  저장위치: OUT_DIR (날짜 폴더 없이 루트에 바로 저장)

사용 방법
---------
  python step_61_feature_correlation.py              # 자동: 올해 연도
  python step_61_feature_correlation.py --year 2025  # 연도 고정
  python step_61_feature_correlation.py --vendor 기민 # 특정 협력사만
"""

import argparse
import datetime as dt
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy import stats
from sqlalchemy import create_engine, text

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from step_0_MSF import OUT_DIR
from step_43_utils_label_group import BASE_VENDORS
from step_47_utils_train_table import _build_vendor_table
from db_config import DB_URL


# ─────────────────────────────────────────────
# 상수
# ─────────────────────────────────────────────
TODAY = dt.date.today()
FEATURE_CORR_TABLE = "특성_상관관계"

# 상관계수 강도 임계값 (절댓값 기준)
CORR_HIGH   = 0.7   # 강한 상관
CORR_MED    = 0.4   # 중간 상관
CORR_LOW    = 0.2   # 약한 상관

# ─────────────────────────────────────────────
# 스타일 상수
# ─────────────────────────────────────────────
_THIN = Side(border_style="thin", color="000000")
BORDER_THIN = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

FILL_HEADER  = PatternFill("solid", fgColor="4472C4")   # 파란색 (헤더)
FILL_TITLE   = PatternFill("solid", fgColor="BDD7EE")   # 연파랑 (섹션 타이틀)
FILL_DIAG    = PatternFill("solid", fgColor="D6DCE4")   # 회색 (대각선)
FILL_HIGH_P  = PatternFill("solid", fgColor="FF0000")   # 빨강 (강한 양의 상관)
FILL_MED_P   = PatternFill("solid", fgColor="FF9999")   # 연빨강 (중간 양의 상관)
FILL_LOW_P   = PatternFill("solid", fgColor="FFCCCC")   # 매우연빨강 (약한 양의 상관)
FILL_HIGH_N  = PatternFill("solid", fgColor="4472C4")   # 파랑 (강한 음의 상관)
FILL_MED_N   = PatternFill("solid", fgColor="9DC3E6")   # 연파랑 (중간 음의 상관)
FILL_LOW_N   = PatternFill("solid", fgColor="DEEAF1")   # 매우연파랑 (약한 음의 상관)
FILL_NEUTRAL = PatternFill("solid", fgColor="FFFFFF")   # 흰색 (무상관)
FILL_TARGET  = PatternFill("solid", fgColor="E2EFDA")   # 연초록 (타겟 행)
FILL_SUMMARY = PatternFill("solid", fgColor="D9E1F2")   # 연보라 (요약 헤더)

FONT_WHITE_BOLD = Font(color="FFFFFF", bold=True)
FONT_BOLD       = Font(bold=True)
FONT_RED        = Font(color="FF0000", bold=True)
FONT_BLUE       = Font(color="1F4E79", bold=True)


# ═══════════════════════════════════════════════
# 1. 데이터 로드 및 피처 행렬 생성
# ═══════════════════════════════════════════════

def _load_bpa_uploaded_table() -> pd.DataFrame:
    """
    step_49 업로드 테이블(사외_조립_계획_실적)에서 원천 데이터 로드.
    """
    engine = create_engine(DB_URL, pool_pre_ping=True)
    try:
        with engine.connect() as conn:
            return pd.read_sql(text("SELECT * FROM `사외_조립_계획_실적`"), conn)
    finally:
        engine.dispose()


def _filter_year_rows(df: pd.DataFrame, year: int) -> pd.DataFrame:
    """
    기준계획_완료 또는 실적_완료가 해당 연도인 행만 필터링.
    """
    if df.empty:
        return df

    out = df.copy()
    mask = pd.Series(False, index=out.index)
    for col in ("기준계획_완료", "실적_완료"):
        if col in out.columns:
            dt_col = pd.to_datetime(out[col], errors="coerce")
            mask |= dt_col.dt.year.eq(year)
    return out[mask].copy() if mask.any() else out.iloc[0:0].copy()


def load_all_vendor_data(
    year: int,
    vendors: Optional[List[str]] = None,
) -> Tuple[pd.DataFrame, List[str]]:
    """
    전체(또는 지정) 협력사 데이터를 로드하여 피처 DataFrame 을 반환한다.

    Parameters
    ----------
    year : int
        분석 연도
    vendors : List[str], optional
        분석할 협력사 목록. None 이면 BASE_VENDORS 전체.

    Returns
    -------
    (df_all, feats)
        df_all : 컬럼 = feats + ["lag_days", "vendor"]
        feats  : 피처 이름 리스트
    """
    print(f"[INFO] DB(사외_조립_계획_실적) 데이터 로딩 중 (연도: {year})...")
    df_src = _load_bpa_uploaded_table()
    df_raw = _filter_year_rows(df_src, year)

    if df_raw.empty:
        raise ValueError(f"{year}년도 데이터가 없습니다.")

    target_vendors = vendors if vendors else BASE_VENDORS
    # BASE_VENDORS 에 없는 협력사도 df_raw 에 있으면 포함
    all_vendors_in_data = df_raw["협력사"].unique().tolist()
    if vendors:
        target_vendors = [v for v in vendors if v in all_vendors_in_data]
    else:
        target_vendors = [v for v in BASE_VENDORS if v in all_vendors_in_data]
        remaining = [v for v in all_vendors_in_data if v not in target_vendors]
        target_vendors += remaining

    records: List[pd.DataFrame] = []
    feats_ref: List[str] = []

    for vendor in target_vendors:
        result = _build_vendor_table(df_raw, vendor)
        if result is None:
            print(f"  [SKIP] {vendor}: 학습 가능 데이터 없음")
            continue

        X, y, feats, dates = result

        if not feats_ref:
            feats_ref = feats

        df_vendor = pd.DataFrame(X, columns=feats)
        df_vendor["lag_days"] = y
        df_vendor["vendor"]   = vendor
        records.append(df_vendor)
        print(f"  [OK] {vendor}: {len(df_vendor):,}건")

    if not records:
        raise ValueError("분석 가능한 협력사 데이터가 없습니다.")

    df_all = pd.concat(records, ignore_index=True)
    print(f"[INFO] 전체 데이터: {len(df_all):,}건  협력사: {len(records)}개")
    return df_all, feats_ref


# ═══════════════════════════════════════════════
# 2. 상관계수 계산
# ═══════════════════════════════════════════════

def calc_corr_matrix(
    df: pd.DataFrame,
    feats: List[str],
) -> pd.DataFrame:
    """
    피처 간 피어슨 상관계수 행렬을 계산한다.

    NaN 이 포함된 행은 pairwise complete observation(기본) 방식으로 처리한다.
    """
    return df[feats].corr(method="pearson")


def calc_target_corr(
    df: pd.DataFrame,
    feats: List[str],
    target_col: str = "lag_days",
) -> pd.DataFrame:
    """
    각 피처와 타겟(lag_days) 간 피어슨 상관계수 및 p-value 를 계산한다.

    Returns
    -------
    pd.DataFrame
        컬럼: ["feature", "corr", "p_value", "n", "abs_corr", "강도"]
        index: 피처명
    """
    results = []
    y = df[target_col].dropna().values

    for feat in feats:
        x = df[feat].dropna()
        # 공통 인덱스만 사용
        common_idx = df[feat].notna() & df[target_col].notna()
        x_vals = df.loc[common_idx, feat].values
        y_vals = df.loc[common_idx, target_col].values

        n = len(x_vals)
        if n < 3:
            results.append({
                "feature": feat, "corr": np.nan, "p_value": np.nan,
                "n": n, "abs_corr": np.nan, "강도": "데이터부족",
            })
            continue

        r, p = stats.pearsonr(x_vals, y_vals)
        abs_r = abs(r)

        if abs_r >= CORR_HIGH:
            strength = "강함"
        elif abs_r >= CORR_MED:
            strength = "중간"
        elif abs_r >= CORR_LOW:
            strength = "약함"
        else:
            strength = "무상관"

        results.append({
            "feature": feat,
            "corr"   : round(r, 4),
            "p_value": round(p, 6),
            "n"      : n,
            "abs_corr": round(abs_r, 4),
            "강도"   : strength,
        })

    df_result = pd.DataFrame(results).set_index("feature")
    # 절댓값 기준 내림차순 정렬
    return df_result.sort_values("abs_corr", ascending=False)


def calc_vendor_target_corr(
    df_all: pd.DataFrame,
    feats: List[str],
    target_col: str = "lag_days",
) -> pd.DataFrame:
    """
    협력사별로 각 피처와 타겟 상관계수를 계산한다.

    Returns
    -------
    pd.DataFrame
        index=협력사, columns=feats (상관계수 값)
    """
    vendors = df_all["vendor"].unique()
    rows: Dict[str, Dict[str, float]] = {}

    for vendor in vendors:
        df_v = df_all[df_all["vendor"] == vendor]
        corr_series: Dict[str, float] = {}
        for feat in feats:
            common = df_v[feat].notna() & df_v[target_col].notna()
            x_vals = df_v.loc[common, feat].values
            y_vals = df_v.loc[common, target_col].values
            if len(x_vals) < 3:
                corr_series[feat] = np.nan
            else:
                r, _ = stats.pearsonr(x_vals, y_vals)
                corr_series[feat] = round(r, 4)
        rows[vendor] = corr_series

    return pd.DataFrame(rows).T   # shape: (n_vendors, n_feats)


# ═══════════════════════════════════════════════
# 3. 기술통계 계산
# ═══════════════════════════════════════════════

def calc_descriptive_stats(
    df: pd.DataFrame,
    feats: List[str],
    target_col: str = "lag_days",
) -> pd.DataFrame:
    """
    피처 전체 + 타겟(lag_days) 에 대한 기술통계를 계산한다.

    반환 컬럼
    ----------
    유효수(N) · 결측수 · 결측률(%) · 평균 · 표준편차 · 최솟값 ·
    1사분위수(Q1) · 중앙값(Q2) · 3사분위수(Q3) · 최댓값 ·
    IQR · 범위(Range) · 왜도(Skewness) · 첨도(Kurtosis)
    MAE · RMSE · MAPE(%) · R²(vs lag_days)

    MAE / RMSE: 0을 기준값으로 한 절대오차/제곱근오차 (lag_days 도메인에서 "계획 대비 편차")
    MAPE(%):
      - target_col(lag_days): mean(|lag_days| / max(plan_duration, 1)) × 100
      - 그 외 피처     : mean(|x - μ| / max(|μ|, 1)) × 100  (정규화 평균절대편차)
    R²(vs lag_days): 피처-타겟 피어슨 상관계수의 제곱 (결정계수)
      - target_col 자신: 1.0

    Returns
    -------
    pd.DataFrame
        index = 컬럼명(feats + [target_col])
    """
    cols = feats + [target_col]
    rows: List[Dict] = []

    n_total = len(df)

    # 타겟 시리즈 (R² 계산용)
    target_vals = df[target_col].dropna().values if target_col in df.columns else np.array([])

    for col in cols:
        s = df[col]
        valid   = s.dropna()
        n_valid = len(valid)
        n_miss  = n_total - n_valid
        miss_pct = round(n_miss / n_total * 100, 2) if n_total > 0 else np.nan

        if n_valid == 0:
            rows.append({"컬럼": col, "유효수(N)": 0, "결측수": n_miss,
                         "결측률(%)": 100.0,
                         "평균": np.nan, "표준편차": np.nan,
                         "최솟값": np.nan, "Q1(25%)": np.nan,
                         "중앙값(Q2)": np.nan, "Q3(75%)": np.nan,
                         "최댓값": np.nan, "IQR": np.nan,
                         "범위(Range)": np.nan,
                         "왜도(Skewness)": np.nan, "첨도(Kurtosis)": np.nan,
                         "MAE": np.nan, "RMSE": np.nan,
                         "MAPE(%)": np.nan, "R²(vs lag_days)": np.nan})
            continue

        q1  = float(np.percentile(valid, 25))
        q2  = float(np.percentile(valid, 50))
        q3  = float(np.percentile(valid, 75))
        iqr = round(q3 - q1, 4)
        rng = round(float(valid.max() - valid.min()), 4)

        v = valid.values.astype(float)

        # MAE / RMSE (0 기준)
        mae  = round(float(np.mean(np.abs(v))), 4)
        rmse = round(float(np.sqrt(np.mean(v ** 2))), 4)

        # MAPE
        if col == target_col:
            if "plan_duration" in df.columns:
                common = df[col].notna() & df["plan_duration"].notna()
                tgt_v  = df.loc[common, col].values.astype(float)
                dur_v  = np.maximum(np.abs(df.loc[common, "plan_duration"].values.astype(float)), 1)
                mape   = round(float(np.mean(np.abs(tgt_v) / dur_v) * 100), 4) if len(tgt_v) > 0 else np.nan
            else:
                mu_abs = max(abs(float(valid.mean())), 1.0)
                mape   = round(float(np.mean(np.abs(v) / mu_abs) * 100), 4)
        else:
            mu = float(valid.mean())
            denom = max(abs(mu), 1.0)
            mape = round(float(np.mean(np.abs(v - mu) / denom) * 100), 4)

        # R²(vs lag_days)
        if col == target_col:
            r2_lag = 1.0
        else:
            common_mask = df[col].notna() & df[target_col].notna()
            x_c = df.loc[common_mask, col].values
            y_c = df.loc[common_mask, target_col].values
            if len(x_c) >= 3:
                r_val, _ = stats.pearsonr(x_c, y_c)
                r2_lag = round(float(r_val ** 2), 4)
            else:
                r2_lag = np.nan

        rows.append({
            "컬럼"              : col,
            "유효수(N)"         : n_valid,
            "결측수"            : n_miss,
            "결측률(%)"         : miss_pct,
            "평균"              : round(float(valid.mean()), 4),
            "표준편차"          : round(float(valid.std(ddof=1)), 4),
            "최솟값"            : round(float(valid.min()), 4),
            "Q1(25%)"           : round(q1, 4),
            "중앙값(Q2)"        : round(q2, 4),
            "Q3(75%)"           : round(q3, 4),
            "최댓값"            : round(float(valid.max()), 4),
            "IQR"               : iqr,
            "범위(Range)"       : rng,
            "왜도(Skewness)"    : round(float(stats.skew(valid)), 4),
            "첨도(Kurtosis)"    : round(float(stats.kurtosis(valid)), 4),
            "MAE"               : mae,
            "RMSE"              : rmse,
            "MAPE(%)"           : mape,
            "R²(vs lag_days)"   : r2_lag,
        })

    return pd.DataFrame(rows).set_index("컬럼")


# ═══════════════════════════════════════════════
# 4. 상관계수 셀 색상 결정
# ═══════════════════════════════════════════════

def _corr_fill(val: float) -> Optional[PatternFill]:
    """상관계수 절댓값에 따라 배경색 반환."""
    if pd.isna(val):
        return FILL_NEUTRAL
    abs_v = abs(val)
    if val > 0:
        if abs_v >= CORR_HIGH: return FILL_HIGH_P
        if abs_v >= CORR_MED:  return FILL_MED_P
        if abs_v >= CORR_LOW:  return FILL_LOW_P
    else:
        if abs_v >= CORR_HIGH: return FILL_HIGH_N
        if abs_v >= CORR_MED:  return FILL_MED_N
        if abs_v >= CORR_LOW:  return FILL_LOW_N
    return FILL_NEUTRAL


# ═══════════════════════════════════════════════
# 5. 엑셀 시트 작성 – 기술통계 요약
# ═══════════════════════════════════════════════

# 피처 설명 매핑 (시트 간 공유)
FEAT_DESC: Dict[str, str] = {
    "plan_month_sin"         : "계획월 sin 순환인코딩 (12주기)",
    "plan_month_cos"         : "계획월 cos 순환인코딩 (12주기)",
    "plan_week_sin"          : "계획 주차 sin 순환인코딩 (53주기)",
    "plan_week_cos"          : "계획 주차 cos 순환인코딩 (53주기)",
    "plan_quarter"           : "계획일 분기 (1~4)",
    "plan_dow"               : "계획일 요일 (월=0 ~ 일=6)",
    "plan_dom"               : "계획일 일(day-of-month, 1~31)",
    "plan_days_to_month_end" : "계획일~월말 잔여일 (0=월말)",
    "plan_duration"          : "계획 작업 기간 (일, 착수→완료)",
    "weight_per_day"         : "일당 처리 중량 (ton/일)",
    "start_lag"              : "착수 지연일 (실적_착수 - 기준계획_착수)",
    "proc_days"              : "실제 작업 기간 (실적_완료 - 실적_착수)",
    "block_zone"             : "블록 구역 (1:선수/2:중앙/3:선미/4:상부/5:미상)",
    "block_num_last_digit"   : "블록코드 숫자 마지막 자리 (0=대조, 1~9=중조, -1=미상)",
    "family_mid_count"       : "패밀리 내 중조 수 (대조 선행 의존성)",
    "family_mid_plan_range"  : "패밀리 내 중조 계획일 범위 (일)",
    "is_mid"                 : "중조 여부 (0/1)",
    "is_large"               : "대조 여부 (0/1)",
    "weight"                 : "블록 중량 (ton)",
    "vendor_rolling_lag"     : "직전 10건 평균 지연일 (shift(1) 적용)",
    "vendor_cumcount"        : "협력사 누적 처리 블록 수 (학습 곡선)",
    "lag_days"               : "타겟: 실적_완료일 - 기준계획_완료일 (단위: 일)",
}

# 왜도/첨도 판정 기준
_SKEW_THRESH = 1.0   # |왜도| > 1.0 → 강한 비대칭
_KURT_THRESH = 3.0   # 첨도 > 3 → 뾰족(leptokurtic), < -3 → 평탄(platykurtic)


def _skew_label(s: float) -> str:
    if pd.isna(s): return "—"
    if s >  _SKEW_THRESH: return "우편향↑"
    if s < -_SKEW_THRESH: return "좌편향↓"
    if s >  0.5: return "약한 우편향"
    if s < -0.5: return "약한 좌편향"
    return "대칭"


def _kurt_label(k: float) -> str:
    if pd.isna(k): return "—"
    if k >  _KURT_THRESH: return "뾰족(이상치多)"
    if k < -_KURT_THRESH: return "평탄(이상치少)"
    return "정규"


def _write_desc_stats_sheet(
    wb: Workbook,
    desc_df: pd.DataFrame,
    feats: List[str],
    year: int,
    n_total: int,
) -> None:
    """
    시트 1: 기술통계 요약
    행=피처+타겟, 열=각 통계량
    """
    ws = wb.create_sheet(title="기술통계_요약")

    stat_cols = [
        "유효수(N)", "결측수", "결측률(%)",
        "평균", "표준편차",
        "최솟값", "Q1(25%)", "중앙값(Q2)", "Q3(75%)", "최댓값",
        "IQR", "범위(Range)",
        "왜도(Skewness)", "왜도_판정",
        "첨도(Kurtosis)", "첨도_판정",
        "MAE", "RMSE", "MAPE(%)", "R²(vs lag_days)",
        "설명",
    ]

    r = 1
    # 타이틀
    tc = ws.cell(row=r, column=1,
                 value=f"{year}년도  독립변수·타겟 기술통계 요약  "
                       f"(전체 샘플 수: {n_total:,}건  /  분석일: {TODAY.strftime('%Y-%m-%d')})")
    tc.font = Font(bold=True, size=12)
    tc.fill = FILL_TITLE
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=len(stat_cols) + 1)
    r += 2

    # 헤더
    ws.cell(row=r, column=1, value="피처명").fill      = FILL_HEADER
    ws.cell(row=r, column=1).font                       = FONT_WHITE_BOLD
    ws.cell(row=r, column=1).border                     = BORDER_THIN
    ws.cell(row=r, column=1).alignment                  = Alignment(horizontal="center", vertical="center")
    for j, h in enumerate(stat_cols, start=2):
        c = ws.cell(row=r, column=j, value=h)
        c.fill      = FILL_HEADER
        c.font      = FONT_WHITE_BOLD
        c.border    = BORDER_THIN
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    r += 1

    # 표시할 순서: feats 순서 + lag_days 마지막
    display_order = feats + ["lag_days"]

    for col_name in display_order:
        if col_name not in desc_df.index:
            continue

        row_data = desc_df.loc[col_name]
        is_target = (col_name == "lag_days")

        # 행 배경: 타겟은 연초록, 피처는 흰색
        row_fill = FILL_TARGET if is_target else FILL_NEUTRAL

        # 피처명 셀
        c0 = ws.cell(row=r, column=1, value=col_name)
        c0.fill      = FILL_SUMMARY if is_target else FILL_HEADER
        c0.font      = FONT_WHITE_BOLD if is_target else FONT_WHITE_BOLD
        c0.border    = BORDER_THIN
        c0.alignment = Alignment(horizontal="left", vertical="center")

        skew_v = row_data.get("왜도(Skewness)", np.nan)
        kurt_v = row_data.get("첨도(Kurtosis)", np.nan)
        miss_pct = row_data.get("결측률(%)", np.nan)

        values_map: Dict[str, object] = {
            "유효수(N)"         : row_data.get("유효수(N)"),
            "결측수"            : row_data.get("결측수"),
            "결측률(%)"         : miss_pct,
            "평균"              : row_data.get("평균"),
            "표준편차"          : row_data.get("표준편차"),
            "최솟값"            : row_data.get("최솟값"),
            "Q1(25%)"           : row_data.get("Q1(25%)"),
            "중앙값(Q2)"        : row_data.get("중앙값(Q2)"),
            "Q3(75%)"           : row_data.get("Q3(75%)"),
            "최댓값"            : row_data.get("최댓값"),
            "IQR"               : row_data.get("IQR"),
            "범위(Range)"       : row_data.get("범위(Range)"),
            "왜도(Skewness)"    : skew_v,
            "왜도_판정"         : _skew_label(skew_v),
            "첨도(Kurtosis)"    : kurt_v,
            "첨도_판정"         : _kurt_label(kurt_v),
            "MAE"               : row_data.get("MAE"),
            "RMSE"              : row_data.get("RMSE"),
            "MAPE(%)"           : row_data.get("MAPE(%)"),
            "R²(vs lag_days)"   : row_data.get("R²(vs lag_days)"),
            "설명"              : FEAT_DESC.get(col_name, ""),
        }

        for j, stat_name in enumerate(stat_cols, start=2):
            val = values_map.get(stat_name)
            c = ws.cell(row=r, column=j)
            c.border    = BORDER_THIN
            c.fill      = row_fill
            c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=(stat_name == "설명"))

            if val is None or (isinstance(val, float) and pd.isna(val)):
                c.value = "—"
                continue

            c.value = val

            # 숫자 포맷
            if stat_name in ("유효수(N)", "결측수"):
                c.number_format = "#,##0"
                c.alignment     = Alignment(horizontal="right")
            elif stat_name == "결측률(%)":
                c.number_format = "0.00"
                # 결측이 있으면 주황색 강조
                if isinstance(val, float) and val > 0:
                    c.fill = PatternFill("solid", fgColor="FFF2CC")
            elif stat_name in ("왜도_판정", "첨도_판정", "설명"):
                c.alignment = Alignment(horizontal="left", wrap_text=True)
                # 왜도/첨도 판정 색상
                if stat_name == "왜도_판정" and "편향↑" in str(val) or "편향↓" in str(val):
                    c.fill = PatternFill("solid", fgColor="FCE4D6")
                elif stat_name == "첨도_판정" and "뾰족" in str(val):
                    c.fill = PatternFill("solid", fgColor="FCE4D6")
            elif stat_name in ("MAE", "RMSE"):
                c.number_format = "#,##0.0000"
                c.alignment     = Alignment(horizontal="right")
                if is_target:
                    c.fill = PatternFill("solid", fgColor="E2EFDA")
            elif stat_name == "MAPE(%)":
                c.number_format = "#,##0.00"
                c.alignment     = Alignment(horizontal="right")
                if is_target:
                    c.fill = PatternFill("solid", fgColor="E2EFDA")
            elif stat_name == "R²(vs lag_days)":
                c.number_format = "0.0000"
                c.alignment     = Alignment(horizontal="right")
                # R² 강도 색상: >= 0.49 → 연초록, >= 0.16 → 연노랑
                if isinstance(val, float) and not pd.isna(val):
                    if val >= 0.49:
                        c.fill = PatternFill("solid", fgColor="C6EFCE")
                    elif val >= 0.16:
                        c.fill = PatternFill("solid", fgColor="FFEB9C")
            elif isinstance(val, (int, float)):
                c.number_format = "#,##0.0000"
                c.alignment     = Alignment(horizontal="right")

        r += 1

    # 통계 해석 가이드
    r += 1
    guide_lines = [
        "※ 왜도(Skewness): |왜도| > 1.0 → 강한 비대칭 (데이터 분포 편향 심함)",
        "※ 첨도(Kurtosis): 초과 첨도 기준, > 3 → 뾰족(이상치 多), < -3 → 평탄(이상치 少)",
        "※ IQR = Q3 - Q1,  범위(Range) = 최댓값 - 최솟값",
        "※ 결측률(%) > 0 인 항목은 연노랑으로 강조 표시",
        "※ lag_days = 실적_완료일 - 기준계획_완료일 (단위: 일, 양수=지연, 음수=조기완료, 클리핑: -90~180)",
        "※ MAE  = mean(|x|)  /  RMSE = sqrt(mean(x²))  — 0(계획 기준)으로부터의 절대오차·제곱근오차",
        "※ MAPE(%) : lag_days → mean(|lag_days|/plan_duration)×100 / 피처 → 정규화 평균절대편차",
        "※ R²(vs lag_days) = 피처-타겟 피어슨 상관계수² (결정계수). MAPE는 선정 기준 제외, 참고 지표",
    ]
    for line in guide_lines:
        ws.cell(row=r, column=1, value=line).font = Font(italic=True, size=9)
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=len(stat_cols) + 1)
        r += 1

    # 열 너비
    ws.column_dimensions["A"].width = 26
    col_widths = {
        "유효수(N)": 10, "결측수": 9, "결측률(%)": 10,
        "평균": 12, "표준편차": 12,
        "최솟값": 12, "Q1(25%)": 12, "중앙값(Q2)": 12, "Q3(75%)": 12, "최댓값": 12,
        "IQR": 10, "범위(Range)": 12,
        "왜도(Skewness)": 14, "왜도_판정": 14,
        "첨도(Kurtosis)": 14, "첨도_판정": 14,
        "MAE": 12, "RMSE": 12, "MAPE(%)": 12, "R²(vs lag_days)": 16,
        "설명": 40,
    }
    for j, stat_name in enumerate(stat_cols, start=2):
        ws.column_dimensions[get_column_letter(j)].width = col_widths.get(stat_name, 12)

    # 헤더 행 높이
    ws.row_dimensions[r - len(display_order) - len(guide_lines) - 1].height = 36


# ═══════════════════════════════════════════════
# 6. 엑셀 시트 작성 – 피처 간 상관계수 행렬
# ═══════════════════════════════════════════════

def _write_corr_matrix_sheet(
    wb: Workbook,
    corr_df: pd.DataFrame,
    feats: List[str],
    year: int,
    n_total: int,
) -> None:
    """
    시트 1: 피처 간 상관계수 히트맵 행렬
    """
    ws = wb.create_sheet(title="피처간_상관계수")

    r = 1
    # 타이틀
    tc = ws.cell(row=r, column=1,
                 value=f"{year}년도  독립변수 간 피어슨 상관계수 매트릭스  "
                       f"(전체 샘플 수: {n_total:,}건  /  분석일: {TODAY.strftime('%Y-%m-%d')})")
    tc.font = Font(bold=True, size=12)
    tc.fill = FILL_TITLE
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=len(feats) + 1)
    r += 2

    n = len(feats)

    # 헤더 행 (열 레이블)
    ws.cell(row=r, column=1, value="피처명").fill  = FILL_HEADER
    ws.cell(row=r, column=1).font                   = FONT_WHITE_BOLD
    ws.cell(row=r, column=1).border                 = BORDER_THIN
    ws.cell(row=r, column=1).alignment              = Alignment(horizontal="center", vertical="center")
    for j, feat in enumerate(feats, start=2):
        c = ws.cell(row=r, column=j, value=feat)
        c.fill      = FILL_HEADER
        c.font      = FONT_WHITE_BOLD
        c.border    = BORDER_THIN
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    r += 1

    # 데이터 행
    for i, feat_row in enumerate(feats):
        # 행 레이블
        lc = ws.cell(row=r, column=1, value=feat_row)
        lc.fill      = FILL_HEADER
        lc.font      = FONT_WHITE_BOLD
        lc.border    = BORDER_THIN
        lc.alignment = Alignment(horizontal="left", vertical="center")

        for j, feat_col in enumerate(feats, start=2):
            val = corr_df.loc[feat_row, feat_col]
            c = ws.cell(row=r, column=j)
            c.border    = BORDER_THIN
            c.alignment = Alignment(horizontal="center")

            if i == j - 2:  # 대각선 (자기 자신)
                c.value  = 1.0
                c.fill   = FILL_DIAG
                c.number_format = "0.00"
            elif pd.isna(val):
                c.value = "—"
                c.fill  = FILL_NEUTRAL
            else:
                c.value         = val
                c.fill          = _corr_fill(val)
                c.number_format = "0.00"
                if abs(val) >= CORR_HIGH:
                    c.font = FONT_BOLD
        r += 1

    # 범례
    r += 1
    ws.cell(row=r, column=1, value="※ 색상 범례 (절댓값 기준)").font = FONT_BOLD
    r += 1
    legend = [
        (f"|r| ≥ {CORR_HIGH}  강한 양의 상관", FILL_HIGH_P),
        (f"|r| ≥ {CORR_MED}  중간 양의 상관", FILL_MED_P),
        (f"|r| ≥ {CORR_LOW}  약한 양의 상관", FILL_LOW_P),
        ("무상관",                              FILL_NEUTRAL),
        (f"|r| ≥ {CORR_LOW}  약한 음의 상관", FILL_LOW_N),
        (f"|r| ≥ {CORR_MED}  중간 음의 상관", FILL_MED_N),
        (f"|r| ≥ {CORR_HIGH}  강한 음의 상관", FILL_HIGH_N),
    ]
    for label, fill in legend:
        c = ws.cell(row=r, column=1, value=f"  {label}")
        c.fill   = fill
        c.border = BORDER_THIN
        r += 1

    # 열 너비
    ws.column_dimensions["A"].width = 26
    for col in range(2, n + 2):
        ws.column_dimensions[get_column_letter(col)].width = 14
    # 행 높이(헤더)
    ws.row_dimensions[r - n - 3].height = 40


# ═══════════════════════════════════════════════
# 7. 엑셀 시트 작성 – 타겟 상관계수
# ═══════════════════════════════════════════════

def _write_target_corr_sheet(
    wb: Workbook,
    tc_df: pd.DataFrame,
    year: int,
) -> None:
    """
    시트 2: 타겟(lag_days) vs 각 피처 상관계수 테이블
    """
    ws = wb.create_sheet(title="타겟_상관계수")

    r = 1
    title_c = ws.cell(row=r, column=1,
                      value=f"{year}년도  타겟(lag_days) vs 독립변수 피어슨 상관계수"
                            f"  (분석일: {TODAY.strftime('%Y-%m-%d')})")
    title_c.font = Font(bold=True, size=12)
    title_c.fill = FILL_TITLE
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=7)
    r += 2

    # 헤더
    hdrs = ["피처명", "상관계수(r)", "절댓값|r|", "p-value", "샘플 수", "강도", "설명"]
    for j, h in enumerate(hdrs, start=1):
        c = ws.cell(row=r, column=j, value=h)
        c.fill      = FILL_HEADER
        c.font      = FONT_WHITE_BOLD
        c.border    = BORDER_THIN
        c.alignment = Alignment(horizontal="center", vertical="center")
    r += 1

    for feat, row_data in tc_df.iterrows():
        corr_val  = row_data["corr"]
        abs_corr  = row_data["abs_corr"]
        p_val     = row_data["p_value"]
        n_val     = row_data["n"]
        strength  = row_data["강도"]
        desc      = FEAT_DESC.get(feat, "")

        fill = _corr_fill(corr_val) if not pd.isna(corr_val) else FILL_NEUTRAL
        is_sig = (not pd.isna(p_val)) and (p_val < 0.05)

        # 피처명
        c1 = ws.cell(row=r, column=1, value=feat)
        c1.border = BORDER_THIN
        c1.fill   = fill
        c1.alignment = Alignment(horizontal="left", vertical="center")

        # 상관계수
        c2 = ws.cell(row=r, column=2,
                     value=corr_val if not pd.isna(corr_val) else "—")
        c2.border       = BORDER_THIN
        c2.fill         = fill
        c2.alignment    = Alignment(horizontal="center")
        if not pd.isna(corr_val):
            c2.number_format = "0.0000"
            if abs_corr >= CORR_HIGH:
                c2.font = FONT_BOLD

        # 절댓값
        c3 = ws.cell(row=r, column=3,
                     value=abs_corr if not pd.isna(abs_corr) else "—")
        c3.border    = BORDER_THIN
        c3.fill      = fill
        c3.alignment = Alignment(horizontal="center")
        if not pd.isna(abs_corr):
            c3.number_format = "0.0000"

        # p-value
        p_disp = f"{p_val:.2e}" if not pd.isna(p_val) else "—"
        c4 = ws.cell(row=r, column=4, value=p_disp)
        c4.border    = BORDER_THIN
        c4.alignment = Alignment(horizontal="center")
        if is_sig:
            c4.font = FONT_RED

        # 샘플 수
        c5 = ws.cell(row=r, column=5, value=n_val if not pd.isna(n_val) else "—")
        c5.border       = BORDER_THIN
        c5.alignment    = Alignment(horizontal="right")
        if isinstance(n_val, (int, float)):
            c5.number_format = "#,##0"

        # 강도
        c6 = ws.cell(row=r, column=6, value=strength)
        c6.border    = BORDER_THIN
        c6.fill      = fill
        c6.alignment = Alignment(horizontal="center")

        # 설명
        c7 = ws.cell(row=r, column=7, value=desc)
        c7.border    = BORDER_THIN
        c7.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)

        r += 1

    # 참고 주석
    r += 1
    ws.cell(row=r, column=1,
            value="※ p-value < 0.05 인 경우 빨간색 표시 (통계적 유의).  "
                  "lag_days = 실적_완료일 - 기준계획_완료일 (단위: 일, 양수=지연, 음수=조기완료)").font = Font(italic=True, size=9)

    # 열 너비
    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 14
    ws.column_dimensions["C"].width = 14
    ws.column_dimensions["D"].width = 14
    ws.column_dimensions["E"].width = 10
    ws.column_dimensions["F"].width = 10
    ws.column_dimensions["G"].width = 44


# ═══════════════════════════════════════════════
# 8. 엑셀 시트 작성 – 협력사별 타겟 상관계수 요약
# ═══════════════════════════════════════════════

def _write_vendor_summary_sheet(
    wb: Workbook,
    vendor_corr_df: pd.DataFrame,
    feats: List[str],
    year: int,
) -> None:
    """
    시트 3: 협력사별 타겟(lag_days) 상관계수 요약 매트릭스
    행=협력사, 열=피처
    """
    ws = wb.create_sheet(title="협력사별_요약")

    r = 1
    n_vendors = len(vendor_corr_df)
    n_feats   = len(feats)

    tc = ws.cell(row=r, column=1,
                 value=f"{year}년도  협력사별 타겟(lag_days) 상관계수 요약"
                       f"  (분석일: {TODAY.strftime('%Y-%m-%d')})")
    tc.font = Font(bold=True, size=12)
    tc.fill = FILL_TITLE
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=n_feats + 1)
    r += 2

    # 헤더 – 피처명
    ws.cell(row=r, column=1, value="협력사").fill      = FILL_HEADER
    ws.cell(row=r, column=1).font                       = FONT_WHITE_BOLD
    ws.cell(row=r, column=1).border                     = BORDER_THIN
    ws.cell(row=r, column=1).alignment                  = Alignment(horizontal="center", vertical="center")
    for j, feat in enumerate(feats, start=2):
        c = ws.cell(row=r, column=j, value=feat)
        c.fill      = FILL_HEADER
        c.font      = FONT_WHITE_BOLD
        c.border    = BORDER_THIN
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    r += 1

    # 데이터 행 (협력사별)
    for vendor, row_data in vendor_corr_df.iterrows():
        c0 = ws.cell(row=r, column=1, value=vendor)
        c0.fill      = FILL_SUMMARY
        c0.font      = FONT_BOLD
        c0.border    = BORDER_THIN
        c0.alignment = Alignment(horizontal="center", vertical="center")

        for j, feat in enumerate(feats, start=2):
            val = row_data.get(feat, np.nan)
            c = ws.cell(row=r, column=j)
            c.border    = BORDER_THIN
            c.alignment = Alignment(horizontal="center")

            if pd.isna(val):
                c.value = "—"
            else:
                c.value         = val
                c.fill          = _corr_fill(val)
                c.number_format = "0.00"
                if abs(val) >= CORR_HIGH:
                    c.font = FONT_BOLD
        r += 1

    # 전체 평균 행
    c0 = ws.cell(row=r, column=1, value="[전체 평균]")
    c0.fill      = FILL_TARGET
    c0.font      = FONT_BOLD
    c0.border    = BORDER_THIN
    c0.alignment = Alignment(horizontal="center")

    for j, feat in enumerate(feats, start=2):
        col_vals = vendor_corr_df[feat].dropna()
        if col_vals.empty:
            c = ws.cell(row=r, column=j, value="—")
        else:
            avg = round(col_vals.mean(), 4)
            c = ws.cell(row=r, column=j, value=avg)
            c.fill          = _corr_fill(avg)
            c.number_format = "0.00"
            if abs(avg) >= CORR_HIGH:
                c.font = FONT_BOLD
        c.border    = BORDER_THIN
        c.alignment = Alignment(horizontal="center")

    # 열 너비
    ws.column_dimensions["A"].width = 18
    for col in range(2, n_feats + 2):
        ws.column_dimensions[get_column_letter(col)].width = 16
    # 헤더 행 높이
    ws.row_dimensions[r - n_vendors - 1].height = 50


# ═══════════════════════════════════════════════
# 9. 메인 실행 함수
# ═══════════════════════════════════════════════

def _ensure_feature_corr_table() -> None:
    create_sql = f"""
    CREATE TABLE IF NOT EXISTS `{FEATURE_CORR_TABLE}` (
        `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
        `year` INT NOT NULL,
        `analysis_date` DATE NOT NULL,
        `section` VARCHAR(40) NOT NULL,
        `row_key` VARCHAR(255) NULL,
        `col_key` VARCHAR(255) NULL,
        `value_num` DOUBLE NULL,
        `value_text` TEXT NULL,
        `n_total` INT NULL,
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_year_section` (`year`, `section`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    """
    engine = create_engine(DB_URL, pool_pre_ping=True)
    try:
        with engine.begin() as conn:
            conn.execute(text(create_sql))
    finally:
        engine.dispose()


def _safe_float(v) -> Optional[float]:
    try:
        if pd.isna(v):
            return None
        return float(v)
    except Exception:
        return None


def _save_analysis_to_db(
    year: int,
    analysis_date: dt.date,
    feats: List[str],
    n_total: int,
    desc_stats: pd.DataFrame,
    corr_matrix: pd.DataFrame,
    target_corr: pd.DataFrame,
    vendor_corr: pd.DataFrame,
) -> None:
    """
    분석 결과를 DB 테이블(특성_상관관계)에 연도 단위 replace 저장.
    """
    _ensure_feature_corr_table()
    rows: List[Dict[str, object]] = []

    # 메타
    rows.append({
        "year": year,
        "analysis_date": analysis_date,
        "section": "meta",
        "row_key": "feats_order",
        "col_key": "json",
        "value_num": None,
        "value_text": json.dumps(feats, ensure_ascii=False),
        "n_total": n_total,
    })

    # 기술통계
    for ridx, row in desc_stats.iterrows():
        for col in desc_stats.columns:
            v = row[col]
            rows.append({
                "year": year,
                "analysis_date": analysis_date,
                "section": "desc",
                "row_key": str(ridx),
                "col_key": str(col),
                "value_num": _safe_float(v),
                "value_text": None if _safe_float(v) is not None else (None if pd.isna(v) else str(v)),
                "n_total": n_total,
            })

    # 피처간 상관계수
    for rfeat in corr_matrix.index:
        for cfeat in corr_matrix.columns:
            v = corr_matrix.loc[rfeat, cfeat]
            rows.append({
                "year": year,
                "analysis_date": analysis_date,
                "section": "corr_matrix",
                "row_key": str(rfeat),
                "col_key": str(cfeat),
                "value_num": _safe_float(v),
                "value_text": None,
                "n_total": n_total,
            })

    # 타겟 상관계수
    for feat, row in target_corr.iterrows():
        for col in target_corr.columns:
            v = row[col]
            rows.append({
                "year": year,
                "analysis_date": analysis_date,
                "section": "target_corr",
                "row_key": str(feat),
                "col_key": str(col),
                "value_num": _safe_float(v),
                "value_text": None if _safe_float(v) is not None else (None if pd.isna(v) else str(v)),
                "n_total": n_total,
            })

    # 협력사 요약
    for vendor, row in vendor_corr.iterrows():
        for feat in vendor_corr.columns:
            v = row[feat]
            rows.append({
                "year": year,
                "analysis_date": analysis_date,
                "section": "vendor_corr",
                "row_key": str(vendor),
                "col_key": str(feat),
                "value_num": _safe_float(v),
                "value_text": None,
                "n_total": n_total,
            })

    df_rows = pd.DataFrame(rows)
    engine = create_engine(DB_URL, pool_pre_ping=True)
    try:
        with engine.begin() as conn:
            conn.execute(text(f"DELETE FROM `{FEATURE_CORR_TABLE}` WHERE year = :y"), {"y": year})
            df_rows.to_sql(FEATURE_CORR_TABLE, con=conn, if_exists="append", index=False, method="multi", chunksize=2000)
    finally:
        engine.dispose()

    print(f"[DB] '{FEATURE_CORR_TABLE}' 저장 완료 (year={year}, rows={len(df_rows):,})")


def load_analysis_from_db(year: int) -> Optional[Dict[str, pd.DataFrame]]:
    """
    DB 테이블(특성_상관관계)에서 연도별 분석 결과를 복원.
    """
    engine = create_engine(DB_URL, pool_pre_ping=True)
    try:
        with engine.connect() as conn:
            df = pd.read_sql(
                text(
                    f"SELECT year, analysis_date, section, row_key, col_key, value_num, value_text, n_total "
                    f"FROM `{FEATURE_CORR_TABLE}` WHERE year = :y"
                ),
                conn,
                params={"y": year},
            )
    except Exception:
        return None
    finally:
        engine.dispose()

    if df.empty:
        return None

    meta = df[df["section"] == "meta"]
    feats: List[str] = []
    if not meta.empty:
        m = meta[(meta["row_key"] == "feats_order") & (meta["col_key"] == "json")]
        if not m.empty:
            try:
                feats = json.loads(m.iloc[0]["value_text"] or "[]")
            except Exception:
                feats = []

    def _pivot_num_text(section: str) -> pd.DataFrame:
        d = df[df["section"] == section].copy()
        if d.empty:
            return pd.DataFrame()
        d["value"] = d["value_num"].where(d["value_num"].notna(), d["value_text"])
        p = d.pivot_table(index="row_key", columns="col_key", values="value", aggfunc="first")
        p.index.name = None
        p.columns.name = None
        return p

    desc = _pivot_num_text("desc")
    corr = _pivot_num_text("corr_matrix")
    target = _pivot_num_text("target_corr")
    vendor = _pivot_num_text("vendor_corr")

    # 타입 복원
    for c in ("유효수(N)", "결측수", "결측률(%)", "평균", "표준편차", "최솟값", "Q1(25%)",
              "중앙값(Q2)", "Q3(75%)", "최댓값", "IQR", "범위(Range)", "왜도(Skewness)",
              "첨도(Kurtosis)", "MAE", "RMSE", "MAPE(%)", "R²(vs lag_days)"):
        if c in desc.columns:
            desc[c] = pd.to_numeric(desc[c], errors="coerce")

    if not corr.empty:
        corr = corr.apply(pd.to_numeric, errors="coerce")
    if not target.empty:
        for c in ("corr", "p_value", "n", "abs_corr"):
            if c in target.columns:
                target[c] = pd.to_numeric(target[c], errors="coerce")
    if not vendor.empty:
        vendor = vendor.apply(pd.to_numeric, errors="coerce")

    if feats:
        if not corr.empty:
            corr = corr.reindex(index=feats, columns=feats)
        if not vendor.empty:
            keep = [f for f in feats if f in vendor.columns]
            vendor = vendor.reindex(columns=keep)

    analysis_date = pd.to_datetime(df["analysis_date"], errors="coerce").dropna()
    analysis_dt = analysis_date.max().date() if not analysis_date.empty else TODAY
    n_total_vals = pd.to_numeric(df["n_total"], errors="coerce").dropna()
    n_total = int(n_total_vals.max()) if not n_total_vals.empty else 0

    return {
        "desc_stats": desc,
        "corr_matrix": corr,
        "target_corr": target,
        "vendor_corr": vendor,
        "feats": feats,
        "analysis_date": analysis_dt,
        "n_total": n_total,
    }

def run(
    year: Optional[int] = None,
    vendor_filter: Optional[List[str]] = None,
) -> Optional[Path]:
    """
    독립변수 상관계수 분석을 실행하고 결과 엑셀을 저장한다.

    Parameters
    ----------
    year : int, optional
        분석 연도. None 이면 오늘 기준 연도.
    vendor_filter : List[str], optional
        분석할 협력사 목록. None 이면 전체.

    Returns
    -------
    Path | None  저장된 엑셀 경로
    """
    year = year or TODAY.year

    # ── 1) 데이터 로딩
    try:
        df_all, feats = load_all_vendor_data(year, vendors=vendor_filter)
    except ValueError as e:
        print(f"[ERROR] {e}")
        return None

    n_total = len(df_all)

    # ── 2) 기술통계 요약
    print("[INFO] 기술통계 계산 중...")
    desc_stats = calc_descriptive_stats(df_all, feats)

    # ── 3) 피처 간 상관계수 행렬
    print("[INFO] 피처 간 상관계수 계산 중...")
    corr_matrix = calc_corr_matrix(df_all, feats)

    # ── 4) 타겟 상관계수
    print("[INFO] 타겟(lag_days) 상관계수 계산 중...")
    target_corr = calc_target_corr(df_all, feats)

    # ── 5) 협력사별 타겟 상관계수
    print("[INFO] 협력사별 상관계수 계산 중...")
    vendor_corr = calc_vendor_target_corr(df_all, feats)

    # 협력사 순서 정렬 (BASE_VENDORS 기준)
    ordered_vendors = [v for v in BASE_VENDORS if v in vendor_corr.index]
    remaining = [v for v in vendor_corr.index if v not in ordered_vendors]
    vendor_corr = vendor_corr.loc[ordered_vendors + remaining]

    # ── 6) DB 저장 (특성_상관관계, year 단위 replace)
    analysis_date = dt.date.today()
    print(f"[INFO] DB 저장 중... (table={FEATURE_CORR_TABLE})")
    _save_analysis_to_db(
        year=year,
        analysis_date=analysis_date,
        feats=feats,
        n_total=n_total,
        desc_stats=desc_stats,
        corr_matrix=corr_matrix,
        target_corr=target_corr,
        vendor_corr=vendor_corr,
    )

    # ── 7) 엑셀 작성
    print("[INFO] 엑셀 작성 중...")
    wb = Workbook()
    # 기본 시트 제거 전에 시트를 먼저 생성
    _write_desc_stats_sheet(wb, desc_stats, feats, year, n_total)
    _write_corr_matrix_sheet(wb, corr_matrix, feats, year, n_total)
    _write_target_corr_sheet(wb, target_corr, year)
    _write_vendor_summary_sheet(wb, vendor_corr, feats, year)

    # 기본 Sheet 제거
    if "Sheet" in wb.sheetnames:
        del wb["Sheet"]

    # ── 8) 저장 (blk_ass/save_folder)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    date_suffix = TODAY.strftime("%y%m%d")
    out_path = OUT_DIR / f"{year}년도_피처_상관계수_분석_{date_suffix}.xlsx"

    try:
        out_path.unlink(missing_ok=True)
    except Exception:
        pass

    wb.save(out_path)
    print(f"\n[SAVE] 저장 완료 → {out_path}")

    # 상위 상관 피처 콘솔 출력
    print("\n[INFO] 타겟(lag_days)과 상위 10개 상관 피처:")
    top10 = target_corr.head(10)
    for feat, row_data in top10.iterrows():
        r_val = row_data["corr"]
        p_val = row_data["p_value"]
        sig   = "**" if (not pd.isna(p_val) and p_val < 0.05) else "  "
        print(f"  {sig} {feat:<30}  r={r_val:+.4f}  |r|={row_data['abs_corr']:.4f}  "
              f"p={p_val:.2e}  강도={row_data['강도']}")

    return out_path


# ═══════════════════════════════════════════════
# CLI 진입점
# ═══════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="독립변수(피처) 간 상관계수 및 타겟(lag_days) 상관계수를 분석합니다."
    )
    parser.add_argument(
        "--year", type=int, default=None,
        help="분석 연도 (기본값: 오늘 기준 연도)",
    )
    parser.add_argument(
        "--vendor", type=str, default=None, nargs="+",
        help="분석할 협력사명 (공백 구분, 기본값: 전체)",
    )
    args = parser.parse_args()

    result_path = run(year=args.year, vendor_filter=args.vendor)
    if result_path:
        print(f"\n✅  분석 완료: {result_path}")
    else:
        print("\n❌  분석 실패 또는 대상 데이터 없음")
