from __future__ import annotations
"""
step_49_utils_BPA_upload.py

outside_df2 기준 "조립 계획·실적" 데이터를 MySQL(구조조달1_db)에 업로드하는 유틸.

- DB 정보: db_config.py 참조

- 사용 테이블
  1) 사외_조립_계획_실적
  2) 사외_조립_계획_실적_예측_ml
  3) 사외_조립_계획_실적_예측_dl
"""

from typing import Optional

import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.types import Text
from sqlalchemy.exc import OperationalError  # ← 에러 캐치용 추가

# ─────────────────────────────────────────────
# DB 접속 설정
# ─────────────────────────────────────────────
from db_config import DB_URL


def _get_engine() -> Engine:
    """공용 SQLAlchemy Engine 생성."""
    return create_engine(DB_URL, pool_pre_ping=True, future=True)


def _normalize_dates(df: pd.DataFrame) -> pd.DataFrame:
    """
    날짜 컬럼 안전하게 datetime으로 정리.
    - 기준계획_완료, 실적_완료 있으면 to_datetime 적용
    """
    df = df.copy()
    for col in ["기준계획_완료", "실적_완료"]:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")
    return df


def _fill_actual_from_pred(df: pd.DataFrame) -> pd.DataFrame:
    """
    '실적_완료'가 비어 있으면 '예측일'로 대체.
    step_51/53 업로드용 안전 장치.
    """
    df = df.copy()
    if "실적_완료" in df.columns and "예측일" in df.columns:
        def _is_blank(x) -> bool:
            if pd.isna(x):
                return True
            if isinstance(x, str) and x.strip() == "":
                return True
            return False

        mask = df["실적_완료"].apply(_is_blank)
        if mask.any():
            df.loc[mask, "실적_완료"] = df.loc[mask, "예측일"]
    return df


def _upload_df(
    df: pd.DataFrame,
    table_name: str,
    if_exists: str = "replace",
) -> None:
    """
    공통 업로드 함수.

    - df 가 비어 있으면 업로드 스킵
    - 문자열(object) 컬럼은 모두 TEXT 타입으로 강제해서
      "Row size too large (> 8126)" 에러를 피함
    """
    if df is None or df.empty:
        print(f"[BPA-UPLOAD] '{table_name}' 에 업로드할 데이터가 없습니다. (빈 DataFrame)")
        return

    # 날짜 컬럼 정리
    df = _normalize_dates(df)

    # 🔹 문자열 컬럼은 모두 TEXT로 강제 → 행 크기 축소
    dtype_map = {}
    for col in df.columns:
        if pd.api.types.is_object_dtype(df[col]):
            dtype_map[col] = Text()

    engine = _get_engine()
    try:
        with engine.begin() as conn:
            df.to_sql(
                table_name,
                con=conn,
                if_exists=if_exists,   # 기본 replace
                index=False,
                dtype=dtype_map,       # ← 여기서 TEXT 적용
                chunksize=1000,
                method="multi",
            )
    except OperationalError as e:
        # MySQL 1118 (Row size too large) 등 에러 메시지 출력용
        print(f"[BPA-UPLOAD][ERROR] 테이블 '{table_name}' 업로드 중 에러 발생: {e}")
        print(
            "▶ Row size too large 관련 에러라면: "
            "   1) 현재 파일의 dtype_map(Text 강제) 코드가 제대로 반영됐는지 확인하고 "
            "   2) 여전히 실패하면, 너무 긴 문자열/불필요한 컬럼 일부를 드롭해서 업로드해야 합니다."
        )
        raise

    print(
        f"[BPA-UPLOAD] 테이블 '{table_name}' 업로드 완료 "
        f"(rows={len(df):,}, cols={len(df.columns)})"
    )


# ─────────────────────────────────────────────
# 1) 사외_조립_계획_실적 : outside_df2 원본 업로드
# ─────────────────────────────────────────────
def upload_bpa_data(df_outside: pd.DataFrame) -> None:
    """사외_조립_계획_실적 테이블 업로드 (replace)."""
    _upload_df(df_outside, "사외_조립_계획_실적", if_exists="replace")


# ─────────────────────────────────────────────
# 2) 사외_조립_계획_실적_예측_ml : ML 예측 실적일 반영 버전 업로드
# ─────────────────────────────────────────────
def upload_bpa_predict_ml(df_ml: pd.DataFrame) -> None:
    """
    사외_조립_계획_실적_예측_ml 테이블 업로드.

    - outside_df2 기반으로,
      '실적_완료' 빈칸을 step_51의 "예측 실적일"로 채운 DataFrame
    """
    df_ml = _fill_actual_from_pred(df_ml)
    _upload_df(df_ml, "사외_조립_계획_실적_예측_ml", if_exists="replace")


# ─────────────────────────────────────────────
# 3) 사외_조립_계획_실적_예측_dl : DL 예측 실적일 반영 버전 업로드
# ─────────────────────────────────────────────
def upload_bpa_predict_dl(df_dl: pd.DataFrame) -> None:
    """사외_조립_계획_실적_예측_dl 테이블 업로드 (replace)."""
    df_dl = _fill_actual_from_pred(df_dl)
    _upload_df(df_dl, "사외_조립_계획_실적_예측_dl", if_exists="replace")
