from __future__ import annotations

"""
step_46_utils_save_logcsv_common.py

ML/DL 로그 CSV 저장 공통 유틸.
"""

import datetime as dt
import json
from pathlib import Path
from typing import Callable, List

import pandas as pd


def write_csv_log_common(
    year: int,
    query_date: dt.date,
    rows: List[dict],
    engine_tag: str,
    db_url: str,
    table_name: str,
    logs_dir: Path,
    priority_cols: List[str],
    upload_func: Callable[[pd.DataFrame, str], None],
) -> None:
    if not rows:
        print("[LOG] 기록할 데이터가 없습니다. (빈 로그)")
        return

    logs_dir.mkdir(parents=True, exist_ok=True)
    date_suffix = query_date.strftime("%y%m%d")
    csv_path = logs_dir / f"{year}_model_selection_log_{engine_tag}_{date_suffix}.csv"

    try:
        csv_path.unlink(missing_ok=True)
    except Exception as e:
        print(f"[LOG] 기존 로그 삭제 실패: {e}")

    df = pd.DataFrame(rows)

    def _ensure_dict(v):
        if isinstance(v, dict):
            return v
        if isinstance(v, (str, bytes)):
            try:
                return json.loads(v)
            except Exception:
                print(f"[LOG-WARN] params_json 파싱 실패 (원본 유지): {str(v)[:80]}")
                return {"_raw": str(v)}
        return {"_raw": None}

    if "params_json" in df.columns:
        params_df = pd.json_normalize(df["params_json"].apply(_ensure_dict)).add_prefix("param_")
        df = pd.concat([df.drop(columns=["params_json"]), params_df], axis=1)

    param_cols = sorted([c for c in df.columns if c.startswith("param_")])
    other_cols = [c for c in df.columns if c not in priority_cols + param_cols]
    ordered_cols = [c for c in priority_cols if c in df.columns] + param_cols + other_cols
    df = df[ordered_cols]

    df.to_csv(csv_path, mode="w", header=True, index=False, encoding="utf-8-sig")
    print(
        f"[LOG] {engine_tag} 로그 CSV 저장 {csv_path} "
        f"(rows={len(df)}, cols={len(df.columns)})"
    )

    upload_func(df, db_url)
