from __future__ import annotations
"""
main_page.py  —  사외 블록 조립 예측 시스템 대시보드
======================================================
blk_ass 폴더 내 전체 파이프라인 결과를 Streamlit 으로 시각화한다.

탭 구성
-------
  1) 📊  데이터 현황   — BPA 원천 데이터 분포 요약
  2) 🔗  피처 분석     — step_61 출력 기반 상관계수 히트맵 + 기술통계
  3) 🤖  ML 모델 성능  — 머신러닝 모델 학습 로그 + Best 선정 결과
  4) 🧠  DL 모델 성능  — 딥러닝 모델 학습 로그 + Best 선정 결과
  5) 🎯  예측 정확도   — step_60 출력 기반 MAPE / MAE / RMSE 비교
  6) 🗺️  파이프라인    — step 파일 전체 구조 및 역할 설명

실행 방법
---------
  독립 실행:
    cd group_st_1/process/blk_ass
    streamlit run main_page.py

  team_main_page.py 연동 (새창):
    team_main_page.py에서 inner=사외구조조달1그룹&sub=조립공정 라우트로 자동 실행됨.
    team_main_page.py가 먼저 st.set_page_config()를 호출하므로
    이 파일의 set_page_config()는 try/except 로 감싸 중복 호출을 무시한다.
"""

import datetime as dt
import json
import re
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

_PAGE_LOAD_START = time.time()   # 페이지 로딩 시작 시각

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

# ── blk_ass 폴더를 sys.path 에 추가 (IDE 실행 대응)
_HERE = Path(__file__).parent.resolve()
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

# ── 프로젝트 모듈
try:
    from step_0_MSF import OUT_DIR
    from step_2_BPA_Data import outside_df
    from step_43_utils_label_group import (
        BASE_VENDORS,
        PRINT_ORDER,
        ROW_LABELS,
        GROUP_DEFS,
        resolve_group_members,
    )
    from db_config import DB_URL, DB_URL_MART
    _MODULES_OK = True
except Exception as _e:
    _MODULES_OK = False
    _MODULE_ERR = str(_e)

# ─────────────────────────────────────────────
# 페이지 설정
# ─────────────────────────────────────────────
try:
    st.set_page_config(
        page_title="사외 조립 대시보드",
        page_icon="",
        layout="wide",
        initial_sidebar_state="expanded",
    )
except Exception:
    pass

# ─────────────────────────────────────────────
# 공통 CSS
# ─────────────────────────────────────────────
st.markdown("""
<style>
  .stApp { background: linear-gradient(160deg, #f0f4ff 0%, #ffffff 40%); }
  section.main > div.block-container {
      padding-top: 1.2rem; padding-bottom: 4rem;
      padding-left: 2.5rem; padding-right: 2.5rem;
  }
  .kpi-row { display: flex; gap: 14px; flex-wrap: wrap; margin-bottom: 1rem; }
  .kpi-card {
      flex: 1; min-width: 140px; padding: 14px 18px; border-radius: 14px;
      background: #fff; border: 1px solid #e5e7eb;
      box-shadow: 0 4px 12px rgba(15,23,42,.07);
  }
  .kpi-label { font-size: 11px; color: #64748b; letter-spacing: .04em; margin-bottom: 4px; }
  .kpi-value { font-size: 22px; font-weight: 800; color: #0f172a; }
  .kpi-sub   { font-size: 11px; color: #94a3b8; margin-top: 3px; }
  .step-badge {
      display: inline-block; padding: 2px 8px; border-radius: 20px;
      font-size: 11px; font-weight: 700; margin-right: 4px;
  }
  .badge-data   { background:#dbeafe; color:#1d4ed8; }
  .badge-ml     { background:#dcfce7; color:#15803d; }
  .badge-dl     { background:#fce7f3; color:#9d174d; }
  .badge-util   { background:#f3f4f6; color:#374151; }
  .badge-out    { background:#fef3c7; color:#92400e; }
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────
# 협력사/그룹 트리 라벨 빌더
# ─────────────────────────────────────────────
def _build_vendor_tree_option_map(options: List[str]) -> Dict[str, str]:
    """
    selectbox 표시용 트리 라벨 -> 실제 값 매핑 생성.
    """
    if not options:
        return {}

    option_set = set(options)
    child_set = set()
    for parent, children in GROUP_DEFS.items():
        if parent in option_set:
            for c in children:
                if c in option_set:
                    child_set.add(c)

    roots = [o for o in options if o not in child_set]
    if not roots:
        roots = options[:]

    label_map: Dict[str, str] = {}
    visited: set[str] = set()

    def _walk(node: str, prefix: str, is_last: bool, depth: int) -> None:
        if node in visited:
            return
        visited.add(node)

        if depth == 0:
            label = f"■ {node}"
        else:
            branch = "└─ " if is_last else "├─ "
            label = f"{prefix}{branch}{node}"
        label_map[label] = node

        children = [c for c in GROUP_DEFS.get(node, []) if c in option_set]
        for idx, child in enumerate(children):
            last_child = (idx == len(children) - 1)
            next_prefix = prefix + ("   " if is_last else "│  ")
            _walk(child, next_prefix, last_child, depth + 1)

    for ridx, root in enumerate(roots):
        _walk(root, "", ridx == len(roots) - 1, 0)

    for o in options:
        if o not in visited:
            label_map[f"■ {o}"] = o

    return label_map


# ─────────────────────────────────────────────
# 즉시 로딩 표시 (페이지 진입 직후)
# ─────────────────────────────────────────────
_boot_loading = st.empty()
_boot_loading.markdown(
    """
    <style>
      .boot-loader-wrap {
        height: 70vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: transparent;
        border-radius: 16px;
        border: 1px solid transparent;
      }
      .boot-loader {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 12px;
        color: #0f172a;
        font-family: "Segoe UI", "Noto Sans KR", sans-serif;
      }
      .boot-ring {
        width: 52px;
        height: 52px;
        border: 4px solid #bae6fd;
        border-top-color: #0284c7;
        border-radius: 50%;
        animation: boot-spin 1s linear infinite;
      }
      .boot-dots {
        display: inline-flex;
        gap: 6px;
      }
      .boot-dots i {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #0284c7;
        animation: boot-bounce 1.2s ease-in-out infinite;
      }
      .boot-dots i:nth-child(2) { animation-delay: 0.15s; }
      .boot-dots i:nth-child(3) { animation-delay: 0.3s; }
      @keyframes boot-spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
      @keyframes boot-bounce {
        0%, 80%, 100% { transform: translateY(0); opacity: 0.5; }
        40% { transform: translateY(-5px); opacity: 1; }
      }
    </style>
    <div style="max-width: 720px; margin: 30px auto;">
      <div class="boot-loader-wrap">
        <div class="boot-loader">
          <div class="boot-ring"></div>
          <div style="font-size:18px; font-weight:700;">화면 로딩 중</div>
          <div style="font-size:14px; color:#475569;">초기 UI 준비 중...</div>
          <div class="boot-dots"><i></i><i></i><i></i></div>
        </div>
      </div>
    </div>
    """,
    unsafe_allow_html=True,
)


# ─────────────────────────────────────────────
# 사이드바
# ─────────────────────────────────────────────
with st.sidebar:
    st.title("대시보드 설정")
    st.markdown("---")

    year_sel = st.selectbox(
        "📅 조회 연도",
        options=list(range(dt.date.today().year, dt.date.today().year - 4, -1)),
        index=0,
    )
    st.markdown("---")

    # 조립 현황 조회 옵션
    vendor_options = PRINT_ORDER if _MODULES_OK else []
    vendor_option_map = _build_vendor_tree_option_map(vendor_options) if vendor_options else {}
    vendor_display_options = list(vendor_option_map.keys())
    value_to_label = {v: k for k, v in vendor_option_map.items()}
    if "asm_vendor" not in st.session_state:
        st.session_state["asm_vendor"] = vendor_options[0] if vendor_options else ""
    if "asm_excluded_vendors" not in st.session_state:
        st.session_state["asm_excluded_vendors"] = []
    if "asm_mode" not in st.session_state:
        st.session_state["asm_mode"] = "기본"

    if vendor_display_options:
        current_vendor = st.session_state["asm_vendor"]
        current_label = value_to_label.get(current_vendor, vendor_display_options[0])
        selected_label = st.selectbox(
            "🏭 협력사/그룹 선택",
            options=vendor_display_options,
            index=vendor_display_options.index(current_label)
            if current_label in vendor_display_options
            else 0,
        )
        vendor_sel = vendor_option_map.get(selected_label, current_vendor)
    else:
        vendor_sel = ""
        st.info("협력사 목록을 불러올 수 없습니다.")

    exclude_vendor_options = [v for v in BASE_VENDORS if v in vendor_options]
    excluded_sel = st.multiselect(
        "🚫 조회 협력사 제외",
        options=exclude_vendor_options,
        default=[v for v in st.session_state.get("asm_excluded_vendors", []) if v in exclude_vendor_options],
        help="선택한 협력사는 조립 현황/전망 계산에서 제외됩니다.",
    )
    mode_sel = st.radio(
        "조회 구분",
        options=["기본", "월간", "주간"],
        horizontal=True,
        index=["기본", "월간", "주간"].index(st.session_state["asm_mode"]),
    )
    if st.button("조회", use_container_width=True):
        st.session_state["asm_vendor"] = vendor_sel
        st.session_state["asm_excluded_vendors"] = excluded_sel
        st.session_state["asm_mode"] = mode_sel

    st.markdown("---")

    # 모듈 연결 상태
    if _MODULES_OK:
        st.success("✅ 모듈 연결 정상")
        try:
            out_exists = Path(OUT_DIR).exists()
            st.info(f"📁 OUT_DIR\n`{OUT_DIR}`\n{'존재' if out_exists else '⚠️ 없음'}")
        except Exception:
            st.warning("OUT_DIR 확인 불가")
    else:
        st.error(f"❌ 모듈 오류\n{_MODULE_ERR}")

    st.markdown("---")
    st.caption(f"조회 기준일: {dt.date.today().strftime('%Y-%m-%d')}")


# ─────────────────────────────────────────────
# 헬퍼: 캐시 데이터 로더
# ─────────────────────────────────────────────

@st.cache_data(ttl=300, show_spinner=False)
def _load_bpa(year: int) -> pd.DataFrame:
    return outside_df(year)


@st.cache_data(ttl=300, show_spinner=False)
def _load_ml_log() -> pd.DataFrame:
    from sqlalchemy import create_engine, text
    engine = create_engine(DB_URL, pool_pre_ping=True)
    with engine.connect() as conn:
        df = pd.read_sql(text("SELECT * FROM 예측_모델_log ORDER BY timestamp DESC"), conn)
    engine.dispose()
    return df


@st.cache_data(ttl=300, show_spinner=False)
def _load_dl_log() -> pd.DataFrame:
    from sqlalchemy import create_engine, text
    engine = create_engine(DB_URL, pool_pre_ping=True)
    with engine.connect() as conn:
        df = pd.read_sql(text("SELECT * FROM 예측_모델_log_dl ORDER BY timestamp DESC"), conn)
    engine.dispose()
    return df


@st.cache_data(ttl=600, show_spinner=False)
def _load_best_json(tag: str) -> dict:
    """best_model_by_vendor_ML.json / best_model_by_vendor_DL.json 로드."""
    p = Path(OUT_DIR) / f"best_model_by_vendor_{tag}.json"
    if not p.exists():
        return {}
    return json.loads(p.read_text(encoding="utf-8"))


@st.cache_data(ttl=600, show_spinner=False)
def _scan_accuracy_excel() -> List[Path]:
    """OUT_DIR 에서 예측정확도 엑셀 파일 목록 반환."""
    root = Path(OUT_DIR)
    if not root.exists():
        return []
    return sorted(root.glob("*년도_예측정확도_분석_*.xlsx"), reverse=True)


@st.cache_data(ttl=600, show_spinner=False)
def _scan_corr_excel() -> List[Path]:
    root = Path(OUT_DIR)
    if not root.exists():
        return []
    return sorted(root.glob("*년도_피처_상관계수_분석_*.xlsx"), reverse=True)


@st.cache_data(ttl=300, show_spinner=False)
def _run_step61_and_load_from_db(year: int, run_token: str) -> Dict[str, object]:
    """
    step_61 자동 실행 후 DB(특성_상관관계) 결과를 로드.
    run_token: 캐시 갱신용(예: YYYY-MM-DD)
    """
    from step_61_feature_correlation import run as run_step61
    from step_61_feature_correlation import load_analysis_from_db

    run_step61(year=year)
    loaded = load_analysis_from_db(year)
    if not loaded:
        raise RuntimeError("DB 테이블 '특성_상관관계'에서 분석 결과를 찾지 못했습니다.")
    return loaded


@st.cache_data(ttl=300, show_spinner=False)
def _run_step60_and_load_summary(year: int, run_token: str) -> tuple[Path, pd.DataFrame]:
    """
    step_60 자동 실행 후 요약 시트(시트0) 로드.
    run_token: 캐시 갱신용(예: YYYY-MM-DD)
    """
    from step_60_predict_accuracy import run as run_step60

    out_path = run_step60(year=year)
    if not out_path:
        raise RuntimeError("step_60 실행 결과 파일이 생성되지 않았습니다.")

    df_acc_sum = _read_excel_sheet(out_path, sheet=0)
    if df_acc_sum is None or df_acc_sum.empty:
        raise RuntimeError(f"step_60 결과 요약 시트를 읽을 수 없습니다: {out_path.name}")
    return out_path, df_acc_sum


def _read_excel_sheet(path: Path, sheet: int | str = 0) -> Optional[pd.DataFrame]:
    try:
        return pd.read_excel(path, sheet_name=sheet, engine="openpyxl")
    except Exception:
        return None


@st.cache_data(ttl=180, show_spinner=False)
def _load_bpa_uploaded() -> pd.DataFrame:
    """
    step_49 업로드 테이블(사외_조립_계획_실적) 로드.
    """
    from sqlalchemy import create_engine, text

    engine = create_engine(DB_URL, pool_pre_ping=True)
    try:
        with engine.connect() as conn:
            df = pd.read_sql(text("SELECT * FROM `사외_조립_계획_실적`"), conn)
    finally:
        engine.dispose()
    return df


@st.cache_data(ttl=180, show_spinner=False)
def _load_bpa_predict_uploaded(model_tag: str) -> tuple[pd.DataFrame, str]:
    """
    step_49 예측 업로드 테이블 로드.
    - ML: 사외_조립_계획_실적_예측_ML 우선, 없으면 ..._ml
    - DL: 사용자 요청 테이블(오타 포함) 우선, 없으면 ..._dl
    """
    from sqlalchemy import create_engine, text

    tag = (model_tag or "").upper()
    if tag == "ML":
        candidates = ["사외_조립_계획_실적_예측_ML", "사외_조립_계획_실적_예측_ml"]
    else:
        candidates = ["사외ㅈ_조립_계획_실적_예측_dl", "사외_조립_계획_실적_예측_dl"]

    engine = create_engine(DB_URL, pool_pre_ping=True)
    last_err: Optional[Exception] = None
    try:
        with engine.connect() as conn:
            for tbl in candidates:
                try:
                    df = pd.read_sql(text(f"SELECT * FROM `{tbl}`"), conn)
                    return df, tbl
                except Exception as e:
                    last_err = e
                    continue
    finally:
        engine.dispose()

    raise RuntimeError(
        f"{tag} 예측 테이블을 찾지 못했습니다. 시도 테이블: {candidates}. "
        f"마지막 에러: {last_err}"
    )


def _filter_year_rows(df: pd.DataFrame, year: int) -> pd.DataFrame:
    """
    기준계획_완료 또는 실적_완료가 해당 연도인 행만 필터링.
    """
    if df.empty:
        return df

    out = df.copy()
    mask = pd.Series(False, index=out.index)
    for col in ("기준계획_완료", "실적_완료"):
        if col in out.columns:
            dt_col = pd.to_datetime(out[col], errors="coerce")
            mask |= dt_col.dt.year.eq(year)
    return out[mask].copy() if mask.any() else out.iloc[0:0].copy()


def _apply_excluded_vendors(df: pd.DataFrame, excluded_vendors: tuple[str, ...]) -> pd.DataFrame:
    """
    제외 협력사 목록을 원천 데이터에서 제거.
    """
    if df.empty or not excluded_vendors:
        return df
    if "협력사" not in df.columns:
        return df
    ex = set(str(v).strip() for v in excluded_vendors if str(v).strip())
    if not ex:
        return df
    return df[~df["협력사"].astype(str).str.strip().isin(ex)].copy()


@st.cache_data(ttl=180, show_spinner=False)
def _build_assembly_block_from_db(
    year: int,
    mode: str,
    vendor: str,
    excluded_vendors: tuple[str, ...] = (),
) -> pd.DataFrame:
    """
    조립 현황(tab_asm)용 블록을 DB 테이블 기반으로 생성.
    - source: step_49 업로드 테이블 `사외_조립_계획_실적`
    - logic : step_3(월간), step_4(주간), step_5(기본)
    """
    from step_42_utils_calendar import week_no_mon
    from step_44_utils_TPD import load_capacity

    df_src = _load_bpa_uploaded()
    df_year = _filter_year_rows(df_src, year)
    df_year = _apply_excluded_vendors(df_year, excluded_vendors)
    if df_year.empty:
        raise ValueError(f"DB 테이블(사외_조립_계획_실적)에 {year}년 데이터가 없거나 제외 필터로 모두 제거되었습니다.")
    if "협력사" not in df_year.columns:
        raise KeyError("DB 테이블에 '협력사' 컬럼이 없습니다.")

    vendors_all = df_year["협력사"].astype(str).str.strip().unique().tolist()
    cap_df = load_capacity(year)
    today = dt.date.today()

    if mode == "월간":
        from step_3_Monthly import build_monthly_plan_actual, matrix_total, matrix_vendor, MONTH_COLS

        plan_pv, actual_pv = build_monthly_plan_actual(df_year, year)
        q_month = today.month

        if vendor == "전체" or vendor in GROUP_DEFS:
            members = resolve_group_members(vendor, vendors_all)
            return matrix_total(cap_df, plan_pv, actual_pv, members, q_month)
        if vendor in vendors_all:
            return matrix_vendor(cap_df, plan_pv, actual_pv, vendor, q_month)
        return pd.DataFrame(0, index=ROW_LABELS, columns=MONTH_COLS, dtype=object)

    if mode == "주간":
        from step_4_Weekly import build_weekly_plan_actual, matrix_total, matrix_vendor, WEEK_COLS

        plan_pv, actual_pv = build_weekly_plan_actual(df_year, year)
        q_week = week_no_mon(today, year) or 1

        if vendor == "전체" or vendor in GROUP_DEFS:
            members = resolve_group_members(vendor, vendors_all)
            return matrix_total(cap_df, plan_pv, actual_pv, members, year, q_week)
        if vendor in vendors_all:
            return matrix_vendor(cap_df, plan_pv, actual_pv, vendor, year, q_week)
        return pd.DataFrame(0, index=ROW_LABELS, columns=WEEK_COLS, dtype=object)

    # 기본(MWD)
    from step_5_MWD import build_aggregates, build_hybrid_axis, matrix_total, matrix_vendor

    agg = build_aggregates(df_year, year)
    axis_meta = build_hybrid_axis(year, today)
    cols = [lbl for (lbl, _) in axis_meta]

    if vendor == "전체" or vendor in GROUP_DEFS:
        members = resolve_group_members(vendor, vendors_all)
        return matrix_total(members, cap_df, agg, axis_meta, year, today)
    if vendor in vendors_all:
        return matrix_vendor(vendor, cap_df, agg, axis_meta, year, today)
    return pd.DataFrame(0, index=ROW_LABELS, columns=cols, dtype=object)


@st.cache_data(ttl=180, show_spinner=False)
def _build_forecast_block_from_db(
    year: int,
    vendor: str,
    model_tag: str,
    excluded_vendors: tuple[str, ...] = (),
) -> tuple[pd.DataFrame, str, dt.date]:
    """
    조립 전망(tab_forecast)용 블록을 DB 예측 테이블 기반으로 생성.
    - source: step_49 업로드 테이블 (ML/DL)
    - logic : step_5_MWD 하이브리드 축 집계
    """
    from step_44_utils_TPD import load_capacity
    from step_5_MWD import build_aggregates, build_hybrid_axis, matrix_total, matrix_vendor

    df_src, used_table = _load_bpa_predict_uploaded(model_tag)
    df_year = _filter_year_rows(df_src, year)
    df_year = _apply_excluded_vendors(df_year, excluded_vendors)
    if df_year.empty:
        raise ValueError(f"{used_table} 테이블에 {year}년 데이터가 없거나 제외 필터로 모두 제거되었습니다.")
    if "협력사" not in df_year.columns:
        raise KeyError(f"{used_table} 테이블에 '협력사' 컬럼이 없습니다.")

    today = dt.date.today()
    vendors_all = df_year["협력사"].astype(str).str.strip().unique().tolist()
    cap_df = load_capacity(year)
    agg = build_aggregates(df_year, year)
    axis_meta = build_hybrid_axis(year, today)
    cols = [lbl for (lbl, _) in axis_meta]

    if vendor == "전체" or vendor in GROUP_DEFS:
        members = resolve_group_members(vendor, vendors_all)
        mat = matrix_total(members, cap_df, agg, axis_meta, year, today)
    elif vendor in vendors_all:
        mat = matrix_vendor(vendor, cap_df, agg, axis_meta, year, today)
    else:
        mat = pd.DataFrame(0, index=ROW_LABELS, columns=cols, dtype=object)

    return mat, used_table, today


@st.cache_data(ttl=300, show_spinner=False)
def _find_latest_assembly_excel(year: int, mode: str) -> Optional[Path]:
    """
    step_3/4/5 결과 엑셀 중 최신 파일 1개 반환.
    mode: "기본"(step_5), "월간"(step_3), "주간"(step_4)
    """
    root = Path(OUT_DIR)
    if not root.exists():
        return None

    if mode == "월간":
        pattern = f"{year}년도_사외_월별_조립_계획실적_현황_*.xlsx"
    elif mode == "주간":
        pattern = f"{year}년도_사외_주간_조립_계획실적_현황_*.xlsx"
    else:
        pattern = f"{year}년도_사외_조립_계획실적_현황_*.xlsx"

    files = list(root.rglob(pattern))
    if not files:
        return None

    return max(files, key=lambda p: p.stat().st_mtime)


@st.cache_data(ttl=300, show_spinner=False)
def _find_latest_predict_excel(year: int, model_tag: str) -> Optional[Path]:
    """
    step_51/53 결과 예측 엑셀 최신 파일 반환.
    model_tag: "ML" or "DL"
    """
    root = Path(OUT_DIR)
    if not root.exists():
        return None

    if model_tag.upper() == "DL":
        pattern = f"{year}년도_사외_조립_계획실적_예측_현황(DL최적)_*.xlsx"
    else:
        pattern = f"{year}년도_사외_조립_계획실적_예측_현황(ML_최적)_*.xlsx"

    files = list(root.rglob(pattern))
    if not files:
        return None
    return max(files, key=lambda p: p.stat().st_mtime)


def _extract_block_from_excel(path: Path, label: str) -> Optional[pd.DataFrame]:
    """
    엑셀 시트에서 label(협력사/그룹) 블록을 찾아 DataFrame으로 추출.
    """
    try:
        raw = pd.read_excel(path, sheet_name=0, header=None, engine="openpyxl")
    except Exception:
        return None

    if raw.empty:
        return None

    title_row = None
    for i, val in enumerate(raw.iloc[:, 0].fillna("").astype(str).tolist()):
        v = val.strip()
        if v.startswith(f"{label}_") or v == label:
            title_row = i
            break

    if title_row is None:
        return None

    header_row = title_row + 1
    data_start = title_row + 2
    cols = raw.iloc[header_row, 1:].tolist()
    cols = [c for c in cols if pd.notna(c)]
    if not cols:
        return None

    data = raw.iloc[data_start:data_start + len(ROW_LABELS), 1:1 + len(cols)]
    df = pd.DataFrame(data.values, index=ROW_LABELS, columns=cols)
    return df


def _add_totals(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    num = df.apply(pd.to_numeric, errors="coerce")
    df_out = df.copy()
    df_out["합계"] = num.sum(axis=1)
    total_row = num.sum(axis=0)
    total_row["합계"] = num.values.sum()
    df_out.loc["합계"] = total_row
    return df_out


def _style_totals(df: pd.DataFrame) -> "pd.io.formats.style.Styler":
    if df.empty:
        return df.style

    def _highlight_totals(row):
        if row.name == "합계":
            return ["background-color: #eef2ff; font-weight: 700;"] * len(row)
        return [""] * len(row)

    def _highlight_total_cols(col):
        if col.name == "합계":
            return ["background-color: #eef2ff; font-weight: 700;"] * len(col)
        return [""] * len(col)

    styler = df.style
    styler = styler.apply(_highlight_totals, axis=1)
    styler = styler.apply(_highlight_total_cols, axis=0)

    # 숫자 포맷
    fmt = {}
    for r in df.index:
        if "지연" in str(r) or "일수" in str(r):
            fmt[r] = "{:,.1f}"
        else:
            fmt[r] = "{:,.0f}"
    styler = styler.format(fmt, axis=0)
    return styler


def _style_totals_with_alerts(
    df: pd.DataFrame,
    alert_row: Optional[str],
    alert_cols: List[str],
) -> "pd.io.formats.style.Styler":
    styler = _style_totals(df)
    if not alert_row or not alert_cols:
        return styler

    def _alert_cells(data):
        styles = pd.DataFrame("", index=data.index, columns=data.columns)
        if alert_row in data.index:
            for c in alert_cols:
                if c in data.columns:
                    styles.loc[alert_row, c] = "background-color: #fee2e2; font-weight: 700;"
        return styles

    return styler.apply(_alert_cells, axis=None)


def _parse_query_date_from_filename(path: Path) -> Optional[dt.date]:
    m = re.search(r"_(\\d{6})\\.xlsx$", path.name)
    if not m:
        return None
    try:
        return dt.datetime.strptime(m.group(1), "%y%m%d").date()
    except Exception:
        return None


def _is_future_col(label: str, query_date: dt.date) -> bool:
    s = str(label).strip()
    # daily: "MM/DD"
    if "/" in s:
        try:
            m, d = s.split("/")
            dtt = dt.date(query_date.year, int(m), int(d))
            return dtt >= query_date
        except Exception:
            return False
    # weekly: "15주"
    if s.endswith("주"):
        try:
            wk = int(s.replace("주", ""))
            return wk >= query_date.isocalendar().week
        except Exception:
            return False
    # monthly: "3월"
    if s.endswith("월"):
        try:
            mm = int(s.replace("월", ""))
            return mm >= query_date.month
        except Exception:
            return False
    return False


def _alert_cols_for_delay(
    df_block: pd.DataFrame,
    query_date: dt.date,
    threshold: float = 3.0,
    days: int = 14,
) -> List[str]:
    delay_row = next((r for r in df_block.index if "지연" in str(r)), None)
    if not delay_row:
        return []

    cols_alert: List[str] = []
    end_date = query_date + dt.timedelta(days=days)
    for col in df_block.columns:
        s = str(col).strip()
        in_window = False
        # daily
        if "/" in s:
            try:
                m, d = s.split("/")
                dtt = dt.date(query_date.year, int(m), int(d))
                in_window = query_date <= dtt <= end_date
            except Exception:
                in_window = False
        elif s.endswith("주"):
            try:
                wk = int(s.replace("주", ""))
                in_window = wk in {query_date.isocalendar().week, query_date.isocalendar().week + 1}
            except Exception:
                in_window = False

        if not in_window:
            continue

        try:
            val = float(pd.to_numeric(df_block.loc[delay_row, col], errors="coerce"))
        except Exception:
            val = None
        if val is not None and val > threshold:
            cols_alert.append(col)

    return cols_alert


# ─────────────────────────────────────────────
# 파이프라인 메타데이터
# ─────────────────────────────────────────────
PIPELINE: List[dict] = [
    # 공통 설정/도구
    dict(step="db_config",            tag="util", role="DB 연결 정보 및 휴일 테이블 설정"),
    dict(step="utils_drm",            tag="util", role="DRM 파일 복호화 유틸"),
    dict(step="main_page",            tag="util", role="대시보드 UI/시각화 진입점 (조립 현황/전망 DB 기반 렌더)"),
    # 데이터 준비
    dict(step="step_0_MSF",           tag="data", role="공유 폴더(네트워크 드라이브) 마운트 및 OUT_DIR 준비"),
    dict(step="step_1_TPD",           tag="data", role="협력사 일일 조립 생산능력(TPD) 엑셀 → DB 업로드"),
    dict(step="step_2_BPA_Data",      tag="data", role="MySQL BPA 원천 데이터 로드·필터·협력사 매핑"),
    dict(step="step_3_Monthly",       tag="data", role="월간 계획/실적/누계차/지연일수 집계 로직 (대시보드 DB데이터로 재계산 시각화)"),
    dict(step="step_4_Weekly",        tag="data", role="주간 계획/실적/누계차/지연일수 집계 로직 (대시보드 DB데이터로 재계산 시각화)"),
    dict(step="step_5_MWD",           tag="data", role="월·주·일 혼합(하이브리드) 집계 로직 (대시보드 DB데이터로 재계산 시각화)"),
    # ML 모델
    dict(step="step_6_KNN",           tag="ml",   role="K-최근접이웃(KNN) 모델 학습·예측·엑셀 저장"),
    dict(step="step_7_AR",            tag="ml",   role="자기회귀(AR) 모델 학습·예측·엑셀 저장"),
    dict(step="step_8_MA",            tag="ml",   role="이동평균(MA) 모델 학습·예측·엑셀 저장"),
    dict(step="step_9_ARIMA",         tag="ml",   role="ARIMA 모델 학습·예측·엑셀 저장"),
    dict(step="step_10_Linear",       tag="ml",   role="선형 회귀(Linear Regression) 모델"),
    dict(step="step_11_Ridge",        tag="ml",   role="릿지 회귀(Ridge Regression) 모델"),
    dict(step="step_12_LightGBM",     tag="ml",   role="LightGBM 그래디언트 부스팅 모델"),
    dict(step="step_13_XGBoost",      tag="ml",   role="XGBoost 그래디언트 부스팅 모델"),
    dict(step="step_14_Catboost",     tag="ml",   role="CatBoost 그래디언트 부스팅 모델"),
    dict(step="step_50_utils_best_model_select_ML", tag="util", role="(유틸) 복합 점수로 Best ML 모델 선정"),
    dict(step="step_51_utils_best_predict_ML",      tag="util", role="(유틸) Best ML 모델 적용 예측 실행"),
    # DL 모델
    dict(step="step_20_MLP",          tag="dl",   role="다층 퍼셉트론(MLP) PyTorch 모델 학습·예측"),
    dict(step="step_21_CNN",          tag="dl",   role="1D 합성곱 신경망(CNN) PyTorch 모델 학습·예측"),
    dict(step="step_22_TCN",          tag="dl",   role="시계열 합성곱(TCN) PyTorch 모델 학습·예측"),
    dict(step="step_23_LSTM",         tag="dl",   role="장단기 기억망(LSTM) PyTorch 모델 학습·예측"),
    dict(step="step_52_utils_best_model_select_DL", tag="util", role="(유틸) 복합 점수로 Best DL 모델 선정"),
    dict(step="step_53_utils_best_predict_DL",      tag="util", role="(유틸) Best DL 모델 적용 예측 실행"),
    # 유틸 모듈
    dict(step="step_40_utils_holiday",        tag="util", role="공휴일·영업일 계산 유틸"),
    dict(step="step_41_utils_save_to_folder", tag="util", role="날짜별 폴더 경로 생성 유틸"),
    dict(step="step_42_utils_calendar",       tag="util", role="월·주·일 달력 연산 유틸"),
    dict(step="step_43_utils_label_group",    tag="util", role="행 라벨·협력사 순서·그룹 정의"),
    dict(step="step_44_utils_TPD",            tag="util", role="협력사별 월·주·일 생산능력(TPD) 조회"),
    dict(step="step_45_utils_save_excel",     tag="util", role="공통 엑셀 저장 유틸(헤더·서식·타이틀)"),
    dict(step="step_46_utils_save_logcsv_ML", tag="util", role="ML 모델 선정 로그 CSV + DB 저장"),
    dict(step="step_46_utils_save_logcsv_DL", tag="util", role="DL 모델 선정 로그 CSV + DB 저장"),
    dict(step="step_47_utils_train_table",    tag="util", role="협력사별 학습용 피처 행렬(X, y) 생성"),
    dict(step="step_48_utils_logs_upload_ML", tag="util", role="ML 로그 DataFrame → DB 업로드"),
    dict(step="step_48_utils_logs_upload_DL", tag="util", role="DL 로그 DataFrame → DB 업로드"),
    dict(step="step_49_utils_BPA_upload",     tag="util", role="BPA 원천/예측(ML·DL) 데이터 → DB 업로드"),
    # 분석 출력
    dict(step="step_60_predict_accuracy",     tag="out", role="예측 정확도 분석(MAE·RMSE·MAPE) — 탭 진입 시 자동 실행/시각화"),
    dict(step="step_61_feature_correlation",  tag="out", role="피처 상관·기술통계 분석 — 탭 진입 시 자동 실행 + DB(특성_상관관계) 저장/조회 + 엑셀 저장"),
]

TAG_BADGE = {
    "data": '<span class="step-badge badge-data">데이터</span>',
    "ml":   '<span class="step-badge badge-ml">ML</span>',
    "dl":   '<span class="step-badge badge-dl">DL</span>',
    "util": '<span class="step-badge badge-util">유틸</span>',
    "out":  '<span class="step-badge badge-out">분석출력</span>',
}

TAG_COLOR = {"data": "#3b82f6", "ml": "#22c55e", "dl": "#ec4899", "util": "#9ca3af", "out": "#f59e0b"}


# ─────────────────────────────────────────────
# 로딩 진행률 표시
# ─────────────────────────────────────────────
_LOAD_STAGES = [
    (0.20, "🔌 모듈 및 설정 로드 확인 중..."),
    (0.40, "🗄️ DB 연결 준비 중..."),
    (0.60, "📦 캐시 데이터 로더 초기화 중..."),
    (0.80, "🖥️ UI 레이아웃 구성 중..."),
    (1.00, "✅ 로딩 완료"),
]

_loading = _boot_loading
for _pct, _msg in _LOAD_STAGES:
    _elapsed = time.time() - _PAGE_LOAD_START
    with _loading.container():
        st.markdown(
            f"""
            <style>
              .boot-loader-wrap {{
                height: 70vh;
                display: flex;
                align-items: center;
                justify-content: center;
                background: transparent;
                border-radius: 16px;
                border: 1px solid transparent;
              }}
              .boot-loader {{
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 12px;
                color: #0f172a;
                font-family: "Segoe UI", "Noto Sans KR", sans-serif;
              }}
              .boot-ring {{
                width: 52px;
                height: 52px;
                border: 4px solid #bae6fd;
                border-top-color: #0284c7;
                border-radius: 50%;
                animation: boot-spin 1s linear infinite;
              }}
              .boot-dots {{
                display: inline-flex;
                gap: 6px;
              }}
              .boot-dots i {{
                width: 6px;
                height: 6px;
                border-radius: 50%;
                background: #0284c7;
                animation: boot-bounce 1.2s ease-in-out infinite;
              }}
              .boot-dots i:nth-child(2) {{ animation-delay: 0.15s; }}
              .boot-dots i:nth-child(3) {{ animation-delay: 0.3s; }}
              @keyframes boot-spin {{
                from {{ transform: rotate(0deg); }}
                to {{ transform: rotate(360deg); }}
              }}
              @keyframes boot-bounce {{
                0%, 80%, 100% {{ transform: translateY(0); opacity: 0.5; }}
                40% {{ transform: translateY(-5px); opacity: 1; }}
              }}
            </style>
            <div style="
                max-width: 720px; margin: 30px auto;
            ">
              <div class="boot-loader-wrap">
                <div class="boot-loader">
                  <div class="boot-ring"></div>
                  <div style="font-size:18px; font-weight:700;">화면 로딩 중</div>
                  <div style="font-size:14px; color:#475569;">{_msg}</div>
                  <div class="boot-dots"><i></i><i></i><i></i></div>
                  <div style="font-size:12px; color:#94a3b8; margin-top:6px;">
                    ⏱️ 경과 시간: <b>{_elapsed:.2f}초</b>
                    &nbsp;|&nbsp;
                    🕐 로딩 시작: <b>{dt.datetime.fromtimestamp(_PAGE_LOAD_START).strftime('%H:%M:%S')}</b>
                  </div>
                </div>
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.progress(_pct)
    time.sleep(0.07)

_load_elapsed = time.time() - _PAGE_LOAD_START
_loading.empty()   # 로딩 UI 제거


# ═══════════════════════════════════════════════════════════════
# 메인 탭 구성
# ═══════════════════════════════════════════════════════════════
st.title("사외 조립 계획_실적_전망 대시보드")
st.caption(
    f"🕐 로딩 시작: {dt.datetime.fromtimestamp(_PAGE_LOAD_START).strftime('%Y-%m-%d %H:%M:%S')}"
    f"　　⏱️ 총 로딩 시간: {_load_elapsed:.2f}초"
)

tab_asm, tab_forecast, tab_data, tab_feat, tab_ml, tab_dl, tab_acc, tab_pipe = st.tabs([
    "🧱 조립 현황",
    "📈 조립 전망",
    "📊 데이터 현황",
    "🔗 피처 분석",
    "🤖 ML 모델 성능",
    "🧠 DL 모델 성능",
    "🎯 예측 정확도",
    "🗺️ 파이프라인",
])
# 기존 with-블록 변수명과 매핑 (코드 블록 이동 없이 순서만 변경)
tab1, tab2, tab3, tab4, tab5, tab6 = tab_pipe, tab_data, tab_ml, tab_dl, tab_acc, tab_feat


# ───────────────────────────────────────────────
# TAB 0  조립 현황
# ───────────────────────────────────────────────
with tab_asm:
    st.subheader("협력사별 조립 계획·실적 현황")

    if not _MODULES_OK:
        st.error(f"모듈 오류: {_MODULE_ERR}")
    else:
        vendor_sel = st.session_state.get("asm_vendor", "")
        excluded_vendors = tuple(st.session_state.get("asm_excluded_vendors", []))
        mode_sel = st.session_state.get("asm_mode", "기본")

        excluded_txt = ", ".join(excluded_vendors) if excluded_vendors else "없음"
        st.caption(f"조회 설정: {year_sel}년 | {vendor_sel} | {mode_sel} | 제외: {excluded_txt}")

        with st.spinner("DB 테이블 기반 조립 현황 계산 중..."):
            try:
                df_block = _build_assembly_block_from_db(
                    year_sel, mode_sel, vendor_sel, excluded_vendors
                )
            except Exception as e:
                df_block = pd.DataFrame()
                st.error(f"조립 현황 계산 실패: {e}")

        if df_block is None or df_block.empty:
            st.warning(
                "표시할 데이터가 없습니다. "
                "step_2 실행 후 step_49 업로드 테이블(사외_조립_계획_실적) 상태를 확인하세요."
            )
        else:
            st.caption("소스: MySQL 테이블 `사외_조립_계획_실적` (step_49 업로드)")

            # 그래프 토글
            default_rows = [r for r in ["계획", "실적"] if r in df_block.index]
            if not default_rows:
                default_rows = list(df_block.index[:2])

            sel_rows = st.multiselect(
                "그래프 항목 선택",
                options=list(df_block.index),
                default=default_rows,
            )

            # 그래프 (계획 vs 실적)
            if sel_rows:
                plot_df = pd.DataFrame({"구간": df_block.columns})
                for r in sel_rows:
                    plot_df[r] = pd.to_numeric(df_block.loc[r].values, errors="coerce")

                if len(sel_rows) <= 2:
                    fig = px.bar(
                        plot_df, x="구간", y=sel_rows,
                        barmode="group",
                        title="조립 계획/실적/능력 현황",
                    )
                else:
                    fig = px.line(
                        plot_df, x="구간", y=sel_rows,
                        markers=True,
                        title="조립 계획/실적/능력 현황",
                    )
                fig.update_layout(height=380, margin=dict(t=50, b=20))
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("그래프 항목을 선택하세요.")

            st.markdown("---")
            st.subheader("조립 계획·실적 테이블")
            df_show = _add_totals(df_block)
            st.dataframe(_style_totals(df_show), use_container_width=True)


# ───────────────────────────────────────────────
# TAB 0-2  조립 전망
# ───────────────────────────────────────────────
with tab_forecast:
    st.subheader("협력사별 조립 전망 (Best 모델)")

    if not _MODULES_OK:
        st.error(f"모듈 오류: {_MODULE_ERR}")
    else:
        vendor_sel = st.session_state.get("asm_vendor", "")
        excluded_vendors = tuple(st.session_state.get("asm_excluded_vendors", []))
        excluded_txt = ", ".join(excluded_vendors) if excluded_vendors else "없음"
        st.caption(f"조회 설정: {year_sel}년 | {vendor_sel} | 제외: {excluded_txt}")

        sub_ml, sub_dl = st.tabs(["ML 최적", "DL 최적"])

        def _render_forecast(model_tag: str):
            with st.spinner("DB 예측 테이블 기반 조립 전망 계산 중..."):
                try:
                    df_block, table_name, query_date = _build_forecast_block_from_db(
                        year_sel, vendor_sel, model_tag, excluded_vendors
                    )
                except Exception as e:
                    df_block = pd.DataFrame()
                    st.error(f"조립 전망 계산 실패: {e}")
                    return

            if df_block is None or df_block.empty:
                st.warning("선택한 협력사/그룹의 전망 데이터를 찾지 못했습니다.")
                return
            st.caption(
                f"소스: MySQL 테이블 `{table_name}` (step_49 업로드) | "
                f"조회일: {query_date.strftime('%Y-%m-%d')}"
            )

            plan_row = next((r for r in df_block.index if "계획" in str(r)), None)
            act_row = next((r for r in df_block.index if "실적" in str(r)), None)
            if not plan_row or not act_row:
                st.info("계획/실적 행을 찾지 못했습니다. 테이블만 표시합니다.")
            else:
                future_mask = [_is_future_col(c, query_date) for c in df_block.columns]
                plan_vals = pd.to_numeric(df_block.loc[plan_row].values, errors="coerce")
                act_vals = pd.to_numeric(df_block.loc[act_row].values, errors="coerce")

                actual_series = [v if not is_future else None for v, is_future in zip(act_vals, future_mask)]
                predict_series = [v if is_future else None for v, is_future in zip(act_vals, future_mask)]

                plot_df = pd.DataFrame({
                    "구간": df_block.columns,
                    "계획": plan_vals,
                    "실적": actual_series,
                    "예측": predict_series,
                })

                fig = px.line(
                    plot_df,
                    x="구간",
                    y=["계획", "실적", "예측"],
                    markers=True,
                    title="계획 · 실적 · 예측",
                )
                fig.update_layout(height=380, margin=dict(t=50, b=20))

                # 지연일수 경고 표시
                alert_cols = _alert_cols_for_delay(df_block, query_date)
                if alert_cols:
                    for col in alert_cols:
                        x = col
                        try:
                            idx = list(df_block.columns).index(col)
                            y = predict_series[idx]
                            if y is None:
                                y = actual_series[idx]
                            if y is None:
                                y = plan_vals[idx]
                        except Exception:
                            y = None

                        if y is not None:
                            fig.add_scatter(
                                x=[x],
                                y=[y],
                                mode="markers",
                                marker=dict(size=12, color="#ef4444", symbol="triangle-up"),
                                name="지연>3.0일",
                            )
                            fig.add_annotation(
                                x=x, y=y,
                                text="지연>3.0d",
                                showarrow=True,
                                arrowhead=2,
                                arrowsize=1,
                                arrowcolor="#ef4444",
                                ax=0, ay=-30,
                                bgcolor="#fee2e2",
                            )

                st.plotly_chart(fig, use_container_width=True)

            st.markdown("---")
            st.subheader("조립 전망 테이블")
            df_show = _add_totals(df_block)
            delay_row = next((r for r in df_show.index if "지연" in str(r)), None)
            alert_cols = _alert_cols_for_delay(df_block, query_date)
            st.dataframe(
                _style_totals_with_alerts(df_show, delay_row, alert_cols),
                use_container_width=True,
            )

        with sub_ml:
            _render_forecast("ML")

        with sub_dl:
            _render_forecast("DL")


# ───────────────────────────────────────────────
# TAB 1  파이프라인 구조
# ───────────────────────────────────────────────
with tab1:
    st.subheader("전체 파이프라인 구조")

    # 태그별 건수 KPI
    counts = {}
    for p in PIPELINE:
        counts[p["tag"]] = counts.get(p["tag"], 0) + 1

    kpi_html = '<div class="kpi-row">'
    for tag, label in [("data","데이터 준비"), ("ml","ML 모델"), ("dl","DL 모델"),
                       ("util","유틸 모듈"), ("out","분석 출력")]:
        kpi_html += f"""
        <div class="kpi-card">
          <div class="kpi-label">{label}</div>
          <div class="kpi-value">{counts.get(tag, 0)}</div>
          <div class="kpi-sub"></div>
        </div>"""
    kpi_html += f"""
        <div class="kpi-card">
          <div class="kpi-label">전체</div>
          <div class="kpi-value">{len(PIPELINE)}</div>
          <div class="kpi-sub"></div>
        </div>"""
    kpi_html += '</div>'
    st.markdown(kpi_html, unsafe_allow_html=True)

    # 태그 필터
    tag_filter = st.multiselect(
        "태그 필터",
        options=["data", "ml", "dl", "util", "out"],
        default=["data", "ml", "dl", "util", "out"],
        format_func=lambda t: {"data":"데이터","ml":"ML","dl":"DL","util":"유틸","out":"분석출력"}[t],
    )

    filtered = [p for p in PIPELINE if p["tag"] in tag_filter]

    # 파이프라인 테이블
    rows_html = ""
    for p in filtered:
        badge  = TAG_BADGE.get(p["tag"], "")
        color  = TAG_COLOR.get(p["tag"], "#aaa")
        rows_html += f"""
        <tr>
          <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;
                     font-family:monospace;font-size:13px;color:{color};font-weight:600;">
            {p['step']}.py
          </td>
          <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;">{badge}</td>
          <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-size:13px;color:#374151;">
            {p['role']}
          </td>
        </tr>"""

    st.markdown(f"""
    <table style="width:100%;border-collapse:collapse;background:#fff;
                  border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.06);">
      <thead>
        <tr style="background:#1e293b;color:#fff;">
          <th style="padding:10px 10px;text-align:left;font-size:13px;width:28%;">파일명</th>
          <th style="padding:10px 10px;text-align:left;font-size:13px;width:10%;">구분</th>
          <th style="padding:10px 10px;text-align:left;font-size:13px;">역할</th>
        </tr>
      </thead>
      <tbody>{rows_html}</tbody>
    </table>
    """, unsafe_allow_html=True)

    # 흐름도 (Sankey 스타일 대신 간단한 단계 다이어그램)
    st.markdown("---")
    st.subheader("실행 흐름")
    flow_cols = st.columns(6)
    flow_items = [
        ("데이터 준비", "step_0 ~ 5 + step_49(DB 업로드)", "#dbeafe", "#1d4ed8"),
        ("ML 모델 학습", "step_6 ~ 14", "#dcfce7", "#15803d"),
        ("DL 모델 학습", "step_20 ~ 23", "#fce7f3", "#9d174d"),
        ("유틸리티", "step_40 ~ 53", "#f3f4f6", "#374151"),
        ("예측 정확도", "step_60 (탭 자동 실행)", "#fef3c7", "#92400e"),
        ("피처 분석", "step_61 (탭 자동 실행+DB)", "#ede9fe", "#5b21b6"),
    ]
    for col, (title, steps, bg, fg) in zip(flow_cols, flow_items):
        col.markdown(f"""
        <div style="background:{bg};border-radius:12px;padding:14px;text-align:center;height:80px;">
          <div style="color:{fg};font-weight:800;font-size:14px;">{title}</div>
          <div style="color:{fg};font-size:12px;margin-top:4px;">{steps}</div>
        </div>
        """, unsafe_allow_html=True)


# ───────────────────────────────────────────────
# TAB 2  데이터 현황
# ───────────────────────────────────────────────
with tab2:
    st.subheader(f"{year_sel}년 사외 조립 data 현황")

    if not _MODULES_OK:
        st.error(f"모듈 오류: {_MODULE_ERR}")
    else:
        with st.spinner("BPA 데이터 로딩 중..."):
            try:
                df_bpa = _load_bpa(year_sel)
            except Exception as e:
                df_bpa = pd.DataFrame()
                st.error(f"데이터 로드 실패: {e}")

        if df_bpa.empty:
            st.warning("데이터가 없습니다.")
        else:
            # 날짜 파싱
            for col in ("기준계획_완료", "실적_완료"):
                if col in df_bpa.columns:
                    df_bpa[col] = pd.to_datetime(df_bpa[col], errors="coerce")

            # lag_days 계산
            if {"기준계획_완료", "실적_완료"} <= set(df_bpa.columns):
                df_bpa["lag_days"] = (
                    df_bpa["실적_완료"] - df_bpa["기준계획_완료"]
                ).dt.days

            # KPI
            n_total   = len(df_bpa)
            n_vendors = df_bpa["협력사"].nunique() if "협력사" in df_bpa.columns else 0
            lag_mean  = df_bpa["lag_days"].mean() if "lag_days" in df_bpa.columns else float("nan")
            lag_med   = df_bpa["lag_days"].median() if "lag_days" in df_bpa.columns else float("nan")

            kc1, kc2, kc3, kc4 = st.columns(4)
            kc1.metric("전체 블록 수", f"{n_total:,}건")
            kc2.metric("협력사 수", f"{n_vendors}개")
            kc3.metric("평균 지연일(lag)", f"{lag_mean:+.1f}일" if not np.isnan(lag_mean) else "—")
            kc4.metric("중앙 지연일(lag)", f"{lag_med:+.1f}일" if not np.isnan(lag_med) else "—")

            st.markdown("---")
            c_left, c_right = st.columns(2)

            # ① 협력사별 블록 수
            if "협력사" in df_bpa.columns:
                vendor_cnt = (
                    df_bpa["협력사"].value_counts()
                    .reset_index()
                    .rename(columns={"count": "블록수"})
                )
                fig_v = px.bar(
                    vendor_cnt, x="협력사", y="블록수",
                    title="협력사별 블록 수",
                    color="블록수", color_continuous_scale="Blues",
                    text="블록수",
                )
                fig_v.update_traces(textposition="outside")
                fig_v.update_layout(showlegend=False, coloraxis_showscale=False,
                                    height=380, margin=dict(t=40, b=20))
                c_left.plotly_chart(fig_v, use_container_width=True)

            # ② lag_days 분포
            if "lag_days" in df_bpa.columns:
                lag_clean = df_bpa["lag_days"].dropna().clip(-90, 180)
                fig_lag = px.histogram(
                    lag_clean, nbins=60,
                    title="지연일수(lag_days) 분포  [-90 ~ 180 클리핑]",
                    labels={"value": "lag_days (일)", "count": "건수"},
                    color_discrete_sequence=["#6366f1"],
                )
                fig_lag.add_vline(x=0, line_dash="dash", line_color="red",
                                  annotation_text="기준(0일)")
                fig_lag.add_vline(x=lag_mean, line_dash="dot", line_color="orange",
                                  annotation_text=f"평균 {lag_mean:.1f}일")
                fig_lag.update_layout(height=380, margin=dict(t=40, b=20))
                c_right.plotly_chart(fig_lag, use_container_width=True)

            # ③ 월별 계획/실적 건수 추이
            st.markdown("---")
            if "기준계획_완료" in df_bpa.columns:
                df_bpa["계획_월"] = df_bpa["기준계획_완료"].dt.to_period("M").astype(str)
                df_bpa["실적_월"] = (
                    df_bpa["실적_완료"].dt.to_period("M").astype(str)
                    if "실적_완료" in df_bpa.columns else None
                )
                plan_m = df_bpa.groupby("계획_월").size().rename("계획 건수")
                act_m  = df_bpa.groupby("실적_월").size().rename("실적 건수") if "실적_완료" in df_bpa.columns else None

                fig_m = go.Figure()
                fig_m.add_bar(x=plan_m.index, y=plan_m.values, name="계획",
                              marker_color="#93c5fd", opacity=0.8)
                if act_m is not None:
                    fig_m.add_bar(x=act_m.index, y=act_m.values, name="실적",
                                  marker_color="#34d399", opacity=0.8)
                fig_m.update_layout(
                    barmode="group", title="월별 계획·실적 블록 건수",
                    xaxis_title="월", yaxis_title="건수",
                    height=340, margin=dict(t=40, b=20),
                )
                st.plotly_chart(fig_m, use_container_width=True)

            # ④ 협력사별 평균 lag_days
            if {"협력사", "lag_days"} <= set(df_bpa.columns):
                vlag = (
                    df_bpa.groupby("협력사")["lag_days"]
                    .agg(["mean", "median", "std", "count"])
                    .rename(columns={"mean":"평균","median":"중앙값","std":"표준편차","count":"건수"})
                    .sort_values("평균")
                    .reset_index()
                )
                fig_vl = px.bar(
                    vlag, x="협력사", y="평균",
                    error_y="표준편차",
                    title="협력사별 평균 지연일수(lag_days)",
                    color="평균",
                    color_continuous_scale="RdYlGn_r",
                    hover_data=["중앙값", "건수"],
                    text=vlag["평균"].round(1),
                )
                fig_vl.add_hline(y=0, line_dash="dash", line_color="gray")
                fig_vl.update_traces(textposition="outside")
                fig_vl.update_layout(height=380, margin=dict(t=40, b=20),
                                     coloraxis_showscale=False)
                st.plotly_chart(fig_vl, use_container_width=True)

                with st.expander("📋 협력사별 통계 테이블"):
                    st.dataframe(
                        vlag.style.format({"평균": "{:+.1f}", "중앙값": "{:+.1f}",
                                           "표준편차": "{:.1f}", "건수": "{:,}"}),
                        use_container_width=True,
                    )


# ───────────────────────────────────────────────
# 공통: ML / DL 로그 렌더링
# ───────────────────────────────────────────────
def _render_model_log(df_log: pd.DataFrame, best_json: dict, tag: str) -> None:
    """ML 또는 DL 모델 로그 탭 공통 렌더링."""
    if df_log.empty:
        st.warning("로그 데이터가 없습니다.")
        return

    # 연도 필터
    if "year" in df_log.columns:
        df_log = df_log[df_log["year"] == year_sel]

    if df_log.empty:
        st.info(f"{year_sel}년도 로그가 없습니다.")
        return

    # KPI
    n_rows    = len(df_log)
    n_vendors = df_log["협력사"].nunique() if "협력사" in df_log.columns else 0
    engines   = df_log["engine"].nunique() if "engine" in df_log.columns else 0
    best_cnt  = len(best_json)

    kc1, kc2, kc3, kc4 = st.columns(4)
    kc1.metric("로그 건수", f"{n_rows:,}")
    kc2.metric("분석 협력사", f"{n_vendors}개")
    kc3.metric("모델 종류", f"{engines}종")
    kc4.metric("Best 선정 협력사", f"{best_cnt}개")

    st.markdown("---")

    # ① 엔진별 평균 성능 (R2 / RMSE / MAE)
    perf_cols = [c for c in ("R2_valid", "RMSE_valid", "MAE_valid") if c in df_log.columns]
    if perf_cols and "engine" in df_log.columns:
        eng_perf = df_log.groupby("engine")[perf_cols].mean().reset_index()
        c1, c2 = st.columns(2)

        if "R2_valid" in eng_perf.columns:
            fig_r2 = px.bar(
                eng_perf.sort_values("R2_valid", ascending=False),
                x="engine", y="R2_valid",
                title="엔진별 평균 R² (검증)",
                color="R2_valid", color_continuous_scale="Greens",
                text=eng_perf.sort_values("R2_valid", ascending=False)["R2_valid"].round(3),
            )
            fig_r2.add_hline(y=0, line_dash="dash", line_color="gray")
            fig_r2.update_traces(textposition="outside")
            fig_r2.update_layout(height=360, margin=dict(t=40, b=20),
                                  coloraxis_showscale=False)
            c1.plotly_chart(fig_r2, use_container_width=True)

        if "RMSE_valid" in eng_perf.columns:
            fig_rmse = px.bar(
                eng_perf.sort_values("RMSE_valid"),
                x="engine", y="RMSE_valid",
                title="엔진별 평균 RMSE (검증, 낮을수록 우수)",
                color="RMSE_valid", color_continuous_scale="Reds_r",
                text=eng_perf.sort_values("RMSE_valid")["RMSE_valid"].round(2),
            )
            fig_rmse.update_traces(textposition="outside")
            fig_rmse.update_layout(height=360, margin=dict(t=40, b=20),
                                    coloraxis_showscale=False)
            c2.plotly_chart(fig_rmse, use_container_width=True)

    st.markdown("---")

    # ② 협력사별 Best 모델 결과
    if best_json:
        st.subheader(f"협력사별 Best {tag} 모델")
        rows_best = []
        for vendor, info in best_json.items():
            rows_best.append({
                "협력사"    : vendor,
                "Best 모델" : info.get("engine", info.get("model", "—")),
                "R²"        : info.get("R2_valid", np.nan),
                "RMSE"      : info.get("RMSE_valid", np.nan),
                "MAE"       : info.get("MAE_valid", np.nan),
                "분할 비율" : info.get("split_ratio", "—"),
            })
        df_best = pd.DataFrame(rows_best)

        # 협력사 순서 정렬
        ordered = [v for v in BASE_VENDORS if v in df_best["협력사"].values]
        rest    = [v for v in df_best["협력사"] if v not in ordered]
        df_best = df_best.set_index("협력사").loc[ordered + rest].reset_index()

        # Best 모델 분포 파이차트
        bc1, bc2 = st.columns([1, 2])
        eng_cnt = df_best["Best 모델"].value_counts().reset_index()
        fig_pie = px.pie(
            eng_cnt, names="Best 모델", values="count",
            title="Best 모델 분포",
            hole=0.45,
            color_discrete_sequence=px.colors.qualitative.Set2,
        )
        fig_pie.update_layout(height=300, margin=dict(t=40, b=0))
        bc1.plotly_chart(fig_pie, use_container_width=True)

        # Best 모델 성능 테이블
        fmt_dict = {}
        if "R²" in df_best.columns:    fmt_dict["R²"] = "{:+.4f}"
        if "RMSE" in df_best.columns:  fmt_dict["RMSE"] = "{:.2f}"
        if "MAE" in df_best.columns:   fmt_dict["MAE"] = "{:.2f}"
        bc2.dataframe(
            df_best.style.format(fmt_dict).background_gradient(
                subset=["R²"] if "R²" in df_best.columns else [],
                cmap="Greens",
            ),
            use_container_width=True, height=300,
        )

    # ③ 협력사 × 엔진 R² 히트맵
    if {"협력사", "engine", "R2_valid"} <= set(df_log.columns):
        st.markdown("---")
        st.subheader("협력사 × 엔진별 R² 히트맵")
        pivot = (
            df_log.groupby(["협력사", "engine"])["R2_valid"]
            .mean()
            .unstack(fill_value=np.nan)
        )
        # 협력사 순서
        ordered_v = [v for v in BASE_VENDORS if v in pivot.index]
        rest_v    = [v for v in pivot.index if v not in ordered_v]
        pivot     = pivot.loc[ordered_v + rest_v]

        fig_hm = px.imshow(
            pivot,
            text_auto=".2f",
            color_continuous_scale="RdYlGn",
            zmin=-0.5, zmax=1.0,
            title="협력사 × 엔진별 평균 R²(검증)",
            aspect="auto",
        )
        fig_hm.update_layout(height=max(300, len(pivot) * 35 + 100),
                              margin=dict(t=50, b=20))
        st.plotly_chart(fig_hm, use_container_width=True)

    # ④ 상세 로그 테이블
    with st.expander("📋 전체 로그 테이블"):
        show_cols = [c for c in ("timestamp","협력사","engine","R2_train","R2_valid",
                                  "MAE_valid","RMSE_valid","split_ratio","train_range",
                                  "valid_range") if c in df_log.columns]
        st.dataframe(df_log[show_cols].reset_index(drop=True), use_container_width=True)


def _infer_hyperparam_cols(df_log: pd.DataFrame) -> List[str]:
    """로그 컬럼에서 하이퍼파라미터로 추정되는 컬럼 목록."""
    if df_log.empty:
        return []

    exclude = {
        "timestamp", "timestamp_dt", "ts_f", "ts_filled",
        "year", "month", "date", "day", "week",
        "협력사", "vendor", "engine", "model",
        "split_ratio", "train_range", "valid_range", "data_range",
        "composite_score", "rank", "score",
        "R2_train", "R2_valid", "RMSE_valid", "MAE_valid", "MAPE_valid",
        "val_loss", "train_loss",
    }

    def is_metric_col(c: str) -> bool:
        c_low = str(c).lower()
        if c in exclude:
            return True
        if c_low.endswith(("_valid", "_train")):
            return True
        if "r2" in c_low or "rmse" in c_low or "mae" in c_low or "mape" in c_low:
            return True
        if c_low in {"loss", "val_loss", "train_loss"}:
            return True
        return False

    cols = [c for c in df_log.columns if not is_metric_col(c)]
    # 가끔 생기는 index/Unnamed 제거
    cols = [c for c in cols if not str(c).startswith("Unnamed")]
    return cols


# ───────────────────────────────────────────────
# TAB 3  ML 모델 성능
# ───────────────────────────────────────────────
with tab3:
    st.subheader(f"{year_sel}년 ML 모델 학습 성능")
    st.info(
        "Best 모델 선정 기준(ML)\n"
        "- 복합 점수 = w_r2*R2_norm + w_rmse*RMSE_norm + w_mae*MAE_norm (그룹 내 순위 정규화)\n"
        "- 기본 가중치: w_r2=0.20 / w_rmse=0.35 / w_mae=0.45\n"
        "- R2 < 0 모델은 패널티(-0.1)\n"
        "- 동점이면 최신 timestamp 우선"
    )
    st.info(
        "하이퍼파라미터 안내(ML)\n"
        "- 하이퍼파라미터는 모델 학습 로그 테이블의 컬럼으로 저장됩니다.\n"
        "- 모델별로 사용하는 파라미터명이 다르므로, 상세 로그 테이블에서 해당 컬럼을 확인하세요."
    )
    if not _MODULES_OK:
        st.error(f"모듈 오류: {_MODULE_ERR}")
    else:
        with st.spinner("ML 로그 로딩 중..."):
            try:
                df_ml  = _load_ml_log()
                bj_ml  = _load_best_json("ML")
            except Exception as e:
                df_ml  = pd.DataFrame()
                bj_ml  = {}
                st.error(f"ML 로그 로드 실패: {e}")
        hp_cols_ml = _infer_hyperparam_cols(df_ml)
        with st.expander("하이퍼파라미터 컬럼 (ML)"):
            if hp_cols_ml:
                st.code(", ".join(hp_cols_ml), language="text")
            else:
                st.caption("표시할 하이퍼파라미터 컬럼이 없습니다.")
        _render_model_log(df_ml, bj_ml, "ML")


# ───────────────────────────────────────────────
# TAB 4  DL 모델 성능
# ───────────────────────────────────────────────
with tab4:
    st.subheader(f"{year_sel}년 DL 모델 학습 성능")
    st.info(
        "Best 모델 선정 기준(DL)\n"
        "- 복합 점수 = w_vl*val_loss_norm + w_rmse*RMSE_norm + w_mae*MAE_norm (그룹 내 순위 정규화)\n"
        "- 기본 가중치: w_vl=0.50 / w_rmse=0.30 / w_mae=0.20\n"
        "- R2 < 0 모델은 패널티(-0.1)\n"
        "- 동점이면 최신 timestamp 우선"
    )
    st.info(
        "하이퍼파라미터 안내(DL)\n"
        "- 하이퍼파라미터는 모델 학습 로그 테이블의 컬럼으로 저장됩니다.\n"
        "- 모델별로 사용하는 파라미터명이 다르므로, 상세 로그 테이블에서 해당 컬럼을 확인하세요."
    )
    if not _MODULES_OK:
        st.error(f"모듈 오류: {_MODULE_ERR}")
    else:
        with st.spinner("DL 로그 로딩 중..."):
            try:
                df_dl = _load_dl_log()
                bj_dl = _load_best_json("DL")
            except Exception as e:
                df_dl = pd.DataFrame()
                bj_dl = {}
                st.error(f"DL 로그 로드 실패: {e}")
        hp_cols_dl = _infer_hyperparam_cols(df_dl)
        with st.expander("하이퍼파라미터 컬럼 (DL)"):
            if hp_cols_dl:
                st.code(", ".join(hp_cols_dl), language="text")
            else:
                st.caption("표시할 하이퍼파라미터 컬럼이 없습니다.")
        _render_model_log(df_dl, bj_dl, "DL")


# ───────────────────────────────────────────────
# TAB 5  예측 정확도 (step_60 출력)
# ───────────────────────────────────────────────
with tab5:
    st.subheader("예측 정확도 분석")

    if not _MODULES_OK:
        st.error(f"모듈 오류: {_MODULE_ERR}")
    else:
        today_token = dt.date.today().strftime("%Y-%m-%d")
        with st.spinner("step_60 자동 실행 및 정확도 결과 로딩 중..."):
            try:
                out_path, df_acc_sum = _run_step60_and_load_summary(year_sel, today_token)
            except Exception as e:
                out_path = None
                df_acc_sum = pd.DataFrame()
                st.error(f"예측 정확도 준비 실패: {e}")

        if df_acc_sum is None or df_acc_sum.empty:
            st.warning("요약 시트를 읽을 수 없습니다.")
        else:
            if out_path:
                st.markdown(f"**자동 생성 파일**: `{out_path.name}`")

            with st.expander("📋 요약 시트 (전체)", expanded=True):
                st.dataframe(df_acc_sum, use_container_width=True)

            mape_cols = [c for c in df_acc_sum.columns if "MAPE" in str(c)]
            vendor_col = df_acc_sum.columns[0]

            if mape_cols:
                st.markdown("---")
                df_mape = df_acc_sum[[vendor_col] + mape_cols].copy()
                df_mape = df_mape[df_mape[vendor_col].notna()]
                df_mape = df_mape[~df_mape[vendor_col].astype(str).str.startswith("※")]
                df_mape = df_mape.set_index(vendor_col)

                for col in mape_cols:
                    df_mape[col] = pd.to_numeric(df_mape[col], errors="coerce")

                if not df_mape.empty:
                    fig_mape = px.imshow(
                        df_mape.astype(float),
                        text_auto=".1f",
                        color_continuous_scale="RdYlGn_r",
                        zmin=0, zmax=30,
                        title="협력사 × 예측파일별 MAPE(%) 히트맵  (낮을수록 우수)",
                        aspect="auto",
                    )
                    fig_mape.update_layout(
                        height=max(300, len(df_mape) * 36 + 100),
                        margin=dict(t=50, b=20),
                        coloraxis_colorbar=dict(title="MAPE(%)"),
                    )
                    st.plotly_chart(fig_mape, use_container_width=True)

                    df_mape["평균MAPE"] = df_mape.mean(axis=1)
                    fig_avg = px.bar(
                        df_mape.reset_index().sort_values("평균MAPE"),
                        x=vendor_col, y="평균MAPE",
                        color="평균MAPE",
                        color_continuous_scale="RdYlGn_r",
                        title="협력사별 평균 MAPE(%) 비교",
                        text=df_mape.reset_index().sort_values("평균MAPE")["평균MAPE"].round(1),
                    )
                    fig_avg.add_hline(y=10, line_dash="dot", line_color="green", annotation_text="목표 10%")
                    fig_avg.update_traces(textposition="outside")
                    fig_avg.update_layout(height=380, margin=dict(t=40, b=20), coloraxis_showscale=False)
                    st.plotly_chart(fig_avg, use_container_width=True)


# ───────────────────────────────────────────────
# TAB 6  피처 분석 (step_61 출력)
# ───────────────────────────────────────────────
with tab6:
    st.subheader("피처 상관계수 및 기술통계")

    if not _MODULES_OK:
        st.error(f"모듈 오류: {_MODULE_ERR}")
    else:
        today_token = dt.date.today().strftime("%Y-%m-%d")
        with st.spinner("step_61 자동 실행 및 DB 로딩 중..."):
            try:
                feat_payload = _run_step61_and_load_from_db(year_sel, today_token)
            except Exception as e:
                feat_payload = {}
                st.error(f"피처 분석 데이터 준비 실패: {e}")

        if not feat_payload:
            st.warning("피처 분석 데이터를 불러오지 못했습니다.")
        else:
            desc_stats = feat_payload.get("desc_stats", pd.DataFrame())
            corr_matrix = feat_payload.get("corr_matrix", pd.DataFrame())
            target_corr = feat_payload.get("target_corr", pd.DataFrame())
            vendor_corr = feat_payload.get("vendor_corr", pd.DataFrame())
            analysis_date = feat_payload.get("analysis_date")
            n_total = feat_payload.get("n_total", 0)

            st.caption(
                f"소스: MySQL 테이블 `특성_상관관계` | "
                f"분석일: {analysis_date} | 샘플수: {n_total:,}"
            )

            sub_tab1, sub_tab2, sub_tab3, sub_tab4 = st.tabs([
                "📐 기술통계", "🔥 피처 간 상관계수", "🎯 타겟 상관계수", "🏭 협력사별 요약"
            ])

            with sub_tab1:
                if desc_stats.empty:
                    st.warning("기술통계 데이터가 없습니다.")
                else:
                    df_desc = desc_stats.reset_index().rename(columns={"index": "피처명"})
                    st.dataframe(df_desc, use_container_width=True, height=520)

                    feat_col = "피처명"
                    if {"왜도(Skewness)", "첨도(Kurtosis)"} <= set(df_desc.columns):
                        st.markdown("---")
                        df_plot = df_desc[[feat_col, "왜도(Skewness)", "첨도(Kurtosis)"]].copy()
                        for c in ["왜도(Skewness)", "첨도(Kurtosis)"]:
                            df_plot[c] = pd.to_numeric(df_plot[c], errors="coerce")
                        df_plot = df_plot.dropna()

                        sc1, sc2 = st.columns(2)
                        fig_sk = px.bar(
                            df_plot.sort_values("왜도(Skewness)"),
                            x=feat_col, y="왜도(Skewness)",
                            color="왜도(Skewness)", color_continuous_scale="RdBu_r",
                            title="피처별 왜도(Skewness)",
                        )
                        fig_sk.add_hline(y=1, line_dash="dot", line_color="red")
                        fig_sk.add_hline(y=-1, line_dash="dot", line_color="blue")
                        fig_sk.update_layout(height=360, margin=dict(t=40, b=20), coloraxis_showscale=False)
                        sc1.plotly_chart(fig_sk, use_container_width=True)

                        fig_ku = px.bar(
                            df_plot.sort_values("첨도(Kurtosis)"),
                            x=feat_col, y="첨도(Kurtosis)",
                            color="첨도(Kurtosis)", color_continuous_scale="PuOr_r",
                            title="피처별 첨도(Kurtosis)",
                        )
                        fig_ku.add_hline(y=3, line_dash="dot", line_color="red")
                        fig_ku.add_hline(y=-3, line_dash="dot", line_color="blue")
                        fig_ku.update_layout(height=360, margin=dict(t=40, b=20), coloraxis_showscale=False)
                        sc2.plotly_chart(fig_ku, use_container_width=True)

            with sub_tab2:
                if corr_matrix.empty:
                    st.warning("피처 간 상관계수 데이터가 없습니다.")
                else:
                    cm = corr_matrix.apply(pd.to_numeric, errors="coerce").dropna(how="all")
                    fig_cm = px.imshow(
                        cm.astype(float),
                        text_auto=".2f",
                        color_continuous_scale="RdBu_r",
                        zmin=-1, zmax=1,
                        title="독립변수 간 피어슨 상관계수 히트맵",
                        aspect="auto",
                    )
                    fig_cm.update_layout(
                        height=max(500, len(cm) * 32 + 120),
                        margin=dict(t=50, b=20),
                        coloraxis_colorbar=dict(title="r"),
                    )
                    st.plotly_chart(fig_cm, use_container_width=True)

                    st.markdown("---")
                    st.markdown("**주의: |r| ≥ 0.4 피처 쌍 (다중공선성 위험)**")
                    pairs = []
                    for i, f1 in enumerate(cm.index):
                        for j, f2 in enumerate(cm.columns):
                            if i >= j:
                                continue
                            v = cm.loc[f1, f2]
                            if pd.notna(v) and abs(v) >= 0.4:
                                pairs.append({"피처1": f1, "피처2": f2, "r": round(v, 4), "|r|": round(abs(v), 4)})
                    if pairs:
                        st.dataframe(pd.DataFrame(pairs).sort_values("|r|", ascending=False), use_container_width=True, height=300)
                    else:
                        st.success("|r| ≥ 0.4 인 피처 쌍이 없습니다.")

            with sub_tab3:
                if target_corr.empty:
                    st.warning("타겟 상관계수 데이터가 없습니다.")
                else:
                    tc = target_corr.copy()
                    tc.index.name = "피처명"
                    tc = tc.reset_index()
                    if "corr" in tc.columns:
                        tc["corr"] = pd.to_numeric(tc["corr"], errors="coerce")
                        if "abs_corr" in tc.columns:
                            tc["abs_corr"] = pd.to_numeric(tc["abs_corr"], errors="coerce")
                            tc_plot = tc.dropna(subset=["corr", "abs_corr"]).sort_values("abs_corr")
                        else:
                            tc_plot = tc.dropna(subset=["corr"]).sort_values("corr", key=abs)

                        fig_tc = px.bar(
                            tc_plot,
                            x="corr",
                            y="피처명",
                            orientation="h",
                            color="corr",
                            color_continuous_scale="RdBu_r",
                            range_color=[-1, 1],
                            title="타겟(lag_days)과 독립변수 간 피어슨 상관계수",
                            text=tc_plot["corr"].round(4),
                        )
                        fig_tc.add_vline(x=0, line_color="gray", line_dash="dash")
                        fig_tc.update_traces(textposition="outside")
                        fig_tc.update_layout(
                            height=max(400, len(tc_plot) * 30 + 100),
                            margin=dict(t=50, l=200, b=20),
                            coloraxis_showscale=False,
                            xaxis_title="피어슨 r",
                        )
                        st.plotly_chart(fig_tc, use_container_width=True)

                    with st.expander("📋 타겟 상관계수 전체 테이블"):
                        st.dataframe(tc, use_container_width=True)

            with sub_tab4:
                if vendor_corr.empty:
                    st.warning("협력사별 요약 데이터가 없습니다.")
                else:
                    vs = vendor_corr.apply(pd.to_numeric, errors="coerce")
                    fig_vs = px.imshow(
                        vs.astype(float),
                        text_auto=".2f",
                        color_continuous_scale="RdBu_r",
                        zmin=-1, zmax=1,
                        title="협력사별 × 피처별 타겟 상관계수",
                        aspect="auto",
                    )
                    fig_vs.update_layout(
                        height=max(400, len(vs) * 36 + 120),
                        margin=dict(t=50, l=160, b=20),
                        coloraxis_colorbar=dict(title="r"),
                    )
                    st.plotly_chart(fig_vs, use_container_width=True)

                    with st.expander("📋 협력사별 상관계수 전체 테이블"):
                        st.dataframe(
                            vs.style.background_gradient(cmap="RdBu_r", vmin=-1, vmax=1).format("{:.3f}"),
                            use_container_width=True,
                        )
