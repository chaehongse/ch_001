from __future__ import annotations
"""
step_48_utils_logs_upload_DL.py

DL 로그 업로드 래퍼 (공통 유틸 사용)
"""

import pandas as pd

from step_48_utils_logs_upload_common import (
    ensure_table_exists as _ensure_table_exists,
    upload_log_df_to_db as _upload_log_df_to_db,
)

_LOG_COLUMNS = [
    ("timestamp", "DATETIME"),
    ("year", "INT"),
    ("협력사", "VARCHAR(100)"),
    ("tag", "VARCHAR(50)"),
    ("engine", "VARCHAR(50)"),
    ("R2_train", "DOUBLE"),
    ("R2_valid", "DOUBLE"),
    ("MAE_valid", "DOUBLE"),
    ("RMSE_valid", "DOUBLE"),
    ("val_loss", "DOUBLE"),
    ("split_ratio", "VARCHAR(20)"),
    ("train_range", "VARCHAR(50)"),
    ("valid_range", "VARCHAR(50)"),
]


def ensure_table_exists(db_url: str, table: str = "예측_모델_log_dl") -> None:
    _ensure_table_exists(db_url, table, _LOG_COLUMNS)


def upload_log_df_to_db(
    df: pd.DataFrame,
    db_url: str,
    table: str = "예측_모델_log_dl",
) -> None:
    _upload_log_df_to_db(df, db_url, table, _LOG_COLUMNS)
