from __future__ import annotations

"""
step_50_utils_best_model_common.py

Best 모델 선정 공통 유틸.
"""

from typing import Optional, Tuple

import pandas as pd
from sqlalchemy import create_engine, text


def _norm_str(x) -> str:
    return " ".join(str(x).split()) if x is not None else ""


def load_logs_from_db(db_url: str, table: str) -> pd.DataFrame:
    try:
        engine = create_engine(db_url, pool_pre_ping=True, future=True)
        with engine.connect() as conn:
            df = pd.read_sql(text(f"SELECT * FROM {table}"), conn)
        print(f"[DB] {table} 로드 완료: {len(df)} rows")
        return df
    except Exception as e:
        print(f"[DB-ERROR] 로그 로드 실패: {e}")
        return pd.DataFrame()


def filter_chosen(df: pd.DataFrame) -> pd.DataFrame:
    if "tag" not in df.columns:
        print("[WARN] tag 컬럼 없음 → 전체 데이터 사용")
        return df
    chosen = df[df["tag"].astype(str).str.upper() == "CHOSEN"].copy()
    if chosen.empty:
        print("[WARN] CHOSEN 없음 → 전체 데이터 사용")
        return df
    print(f"[INFO] CHOSEN 필터 적용: {len(chosen)} rows")
    return chosen


def filter_year_per_vendor_latest(
    df: pd.DataFrame, year: Optional[int], vendor_col: str = "협력사"
) -> Tuple[pd.DataFrame, Optional[int]]:
    if "year" not in df.columns:
        print("[WARN] year 컬럼 없음 → year 필터 스킵")
        return df, year
    if vendor_col not in df.columns:
        print("[WARN] 협력사 컬럼 없음 → year 필터 스킵")
        return df, year

    df = df.copy()
    df[vendor_col] = df[vendor_col].astype(str).map(_norm_str)
    df["year"] = pd.to_numeric(df["year"], errors="coerce").astype("Int64")
    df = df.dropna(subset=["year"])
    if df.empty:
        print("[WARN] year 변환 후 데이터 없음 → year 필터 스킵")
        return df, year

    if year is not None:
        sub = df[df["year"] == year].copy()
        if sub.empty:
            print(f"[WARN] year={year} 데이터 없음 → year 필터 무시(전체 사용)")
            return df, year
        return sub, year

    latest_year_by_vendor = (
        df.groupby(vendor_col)["year"].max().reset_index().rename(columns={"year": "latest_year"})
    )
    df = df.merge(latest_year_by_vendor, on=vendor_col, how="left")
    df = df[df["year"] == df["latest_year"]].drop(columns=["latest_year"])
    return df, None
