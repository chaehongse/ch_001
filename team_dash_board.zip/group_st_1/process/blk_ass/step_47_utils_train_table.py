from __future__ import annotations
"""
step_47_utils_train_table.py

역할 요약
-----------
협력사(벤더)별로 "실적_완료일 - 기준계획_완료일"을 타겟(lag_days)으로 하는
회귀 모델 학습용 테이블(X, y)을 만드는 유틸 함수 모듈.

주요 내용
---------
1) _weight_col(df)
   - 중량 컬럼명을 자동으로 선택하는 헬퍼
   - 우선순위: "고유_중량" > "중량_고유"

2) _build_vendor_table(df_all, vendor, include_realized_features=False)
   - 한 협력사(vendor)에 대해 다음을 수행:
     - 완료일/착수일 컬럼을 date로 변환
     - lag_days = (실적일 - 계획일).days (클리핑: [-90, 180])
     - 착수 기반 피처(옵션, 기본 비활성):
         · start_lag = (실적_착수 - 기준계획_착수) 일수
         · proc_days = (실적_완료 - 실적_착수) 일수
     - 계획일 기반 피처(순환 인코딩):
         · plan_month_sin / plan_month_cos  : 월 sin/cos (12주기)
         · plan_week_sin  / plan_week_cos   : 주차 sin/cos (53주기)
         · plan_quarter       : 분기 (1~4)
         · plan_dow           : 요일 (월=0 ~ 일=6)
         · plan_dom           : 일(day-of-month)
         · plan_days_to_month_end : 월말까지 남은 일수 (0=월말, 클수록 월초)
                                    ※ 기성 기준이 대조 완료 → 월말 집중 반영
     - 계획 기간 / 작업 강도 피처:
         · plan_duration  : 기준계획_완료 - 기준계획_착수 (일수, [0, 365])
         · weight_per_day : weight / plan_duration (일당 처리 중량, [0, 100])
     - 블록 기반 피처:
         · block_zone           : 첫 알파벳 → BLOCK_ZONE_MAP 구역 번호 (1~4, 5=미상)
         · block_num_last_digit : 중간 숫자 마지막 자리 (0=대조, 1~9=중조, -1=미상)
         · family_mid_count     : (프로젝트+패밀리) 내 중조 수
                                  ※ 블록 고유 식별 = 프로젝트 + 블록번호
                                  ※ 착수는 독립 가능, 완료만 의존
                                    (대조는 중조 전체 완료 후에만 완료 가능)
         · family_mid_plan_range: 패밀리 내 중조 계획 완료일 범위(일)
     - 구분 기반 피처:
         · is_mid   : "중조" 포함 여부 (0/1, 구분 컬럼 기반)
         · is_large : "대조" 포함 여부 (0/1, 구분 컬럼 기반)
     - 중량:
         · weight : 중량(ton) 숫자 컬럼
     - 협력사 실적 기반 피처:
         · vendor_rolling_lag : 직전 10건 평균 지연일 (shift(1)로 미래 누수 방지)
         · vendor_cumcount    : 협력사 누적 처리 블록 수 (시간순, 0-based)

   - 최종 반환:
       X     : (N, n_feats) float32 피처 행렬
       y     : (N,) float32 타겟(lag_days)
       feats : 피처 이름 리스트
       dates : pd.Series (계획일, 시계열 분할 등에 사용)
"""

import re
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd

from step_42_utils_calendar import _to_date, week_no_mon


# ─────────────────────────────────────────────
# 블록 구역(Zone) 그룹핑 테이블
# ─────────────────────────────────────────────
# 블록명 첫 알파벳 → 구역 번호 매핑
#   1: 선수부   (Fore)         F
#   2: 중앙부 (Mid)     H,B
#   3: 선미부   (Aft)          A,E
#   4: 상부구조/기타 (Upper)   M,W,C
#   5: 알 수 없음 (알파벳 없음)
#
# ※ 실제 선종/야드 블록 코드 체계에 따라 이 테이블만 수정하면
#    _alpha_to_zone() 및 이후 피처 생성 전체에 자동 반영됩니다.
BLOCK_ZONE_MAP: dict[str, int] = {
    # 1 선수부 (Fore)
    "F": 1,
    # 2 중앙부 (Mid)
    "H": 2, "B": 2,
    # 3 선미부 (Aft)
    "A": 3, "E": 3,
    # 4 상부구조 / 기타 (Upper / Special)
    "M": 4, "W": 4, "C": 4,
    # 맵에 없는 알파벳 또는 알파벳 없음 → _alpha_to_zone 에서 5 반환
}

# 순환 인코딩 주기 상수
_MONTH_PERIOD = 12
_WEEK_PERIOD  = 53


# 블록코드 파싱 정규식
# 형식: [zone 알파벳 1자][중간 숫자 2~3자리][접미 알파벳 1~2자] = 총 5자리
# 예)  E11AP → zone=E, nums=11, suffix=AP  (중조)
#      E111P → zone=E, nums=111, suffix=P   (중조)
#      E110P → zone=E, nums=110, suffix=P   (대조: 숫자 마지막 자리 = 0)
_BLOCK_CODE_RE = re.compile(r"^([A-Z])(\d{2,3})([A-Z]{1,2})$")


def _block_family_key(val) -> str:
    """
    블록코드에서 '블록 패밀리' 키를 추출.

    블록 제작 순서: 중조(E11AP, E111P) → 대조(E110P)
    세 블록 모두 같은 패밀리 "E11" 에 속한다.

    규칙: family = zone_letter + nums[:2]
      E11AP → E + 11  = "E11"
      E111P → E + 11  = "E11"   (3자리 중 앞 2자리)
      E110P → E + 11  = "E11"   (대조, 마지막 자리=0)

    파싱 실패(형식 불일치, 결측) 시 "" 반환.
    """
    if pd.isna(val):
        return ""
    m = _BLOCK_CODE_RE.match(str(val).strip().upper())
    if not m:
        return ""
    return m.group(1) + m.group(2)[:2]   # zone + 숫자 앞 2자리


def _block_num_last_digit(val) -> float:
    """
    블록코드에서 중간 숫자부의 마지막 자리를 추출.

    블록 제작 순서:  중조(E11AP, E111P) → 대조(E110P)
    대조 블록은 숫자 마지막 자리가 0 이므로,
    이 값을 피처로 사용하면 모델이 대조 완료 시점(월말 집중)을
    is_large 와 독립적으로 학습할 수 있습니다.

    반환
    ----
    0~9 : 파싱 성공 (0 = 대조, 1~9 = 중조)
    -1  : 파싱 실패 (블록코드 형식 불일치 또는 결측)
    """
    if pd.isna(val):
        return -1.0
    m = _BLOCK_CODE_RE.match(str(val).strip().upper())
    if not m:
        return -1.0
    return float(m.group(2)[-1])   # 숫자부 마지막 자리


def _alpha_to_zone(val) -> float:
    """
    블록명에서 첫 알파벳을 추출해 BLOCK_ZONE_MAP 기준 구역 번호를 반환.

    반환
    ----
    1~4 : 구역 번호 (BLOCK_ZONE_MAP 참조)
    5   : 맵에 없는 알파벳 또는 알파벳 없음(미상)
    """
    if pd.isna(val):
        return 5.0
    s = str(val).strip().upper()
    for ch in s:
        if "A" <= ch <= "Z":
            return float(BLOCK_ZONE_MAP.get(ch, 5))
    return 5.0


def _weight_col(df: pd.DataFrame) -> str:
    """
    중량 컬럼명 선택 유틸.

    우선순위
    --------
    1) "고유_중량"
    2) "중량_고유"

    두 컬럼 모두 없으면 KeyError 를 발생시켜 학습 파이프라인에서
    조기에 문제를 발견할 수 있도록 합니다.
    """
    if "고유_중량" in df.columns:
        return "고유_중량"
    if "중량_고유" in df.columns:
        return "중량_고유"
    raise KeyError("중량 컬럼 누락 ('고유_중량' 또는 '중량_고유').")


def _build_vendor_table(
    df_all: pd.DataFrame,
    vendor: str,
    include_realized_features: bool = False,
) -> Optional[Tuple[np.ndarray, np.ndarray, List[str], pd.Series]]:
    """
    특정 협력사(vendor)에 대한 학습용 테이블(X, y) 생성.

    타겟
    ----
    lag_days = (실적_완료일 - 기준계획_완료일).days
               → -90 ~ 180 범위로 클리핑

    생성 피처
    --------
    1) 계획일 기반 (순환 인코딩)
       - plan_month_sin / plan_month_cos : 월 sin/cos 인코딩 (1~12 → 12주기)
       - plan_week_sin  / plan_week_cos  : 주차 sin/cos 인코딩 (1~53 → 53주기)
       - plan_quarter              : 분기 (1~4)
       - plan_dow                  : 계획일 요일 (월=0 ~ 일=6)
       - plan_dom                  : 계획일 일(day-of-month)
       - plan_days_to_month_end    : 계획일~월말 잔여일 (0=월말, 클수록 월초)
                                     기성 기준(대조 완료) 월말 집중 경향 반영

    2) 계획 기간 / 작업 강도
       - plan_duration  : 기준계획_완료 - 기준계획_착수 일수
                          NaT 시 0.0, 클리핑: [0, 365]
       - weight_per_day : weight / plan_duration (일당 처리 중량)
                          plan_duration=0 시 0.0, 클리핑: [0, 100]

    3) 착수 기반(옵션)
       - start_lag  : (실적_착수일 - 계획_착수일).days    클리핑: [-90, 180]
       - proc_days  : (실적일 - 실적_착수일).days         클리핑: [0, 365]
         ※ include_realized_features=True 일 때만 사용
         ※ NaN 시 각 컬럼 중앙값으로 대체

    4) 블록/구분 기반
       - block_zone           : 블록명 첫 알파벳 → BLOCK_ZONE_MAP 기준 구역 번호
                                (1:선수부 / 2:중앙부 / 3:선미부 / 4:상부구조·기타 / 5:미상)
       - block_num_last_digit  : 블록코드 중간 숫자부 마지막 자리 (0~9, -1=미상)
                                 0 = 대조(grand assembly), 1~9 = 중조(sub-assembly)
       - family_mid_count      : (프로젝트+패밀리) 내 중조 수
                                 ※ 블록 고유 식별 = 프로젝트 + 블록번호
                                 ※ 착수(start)는 중조/대조 각각 독립 가능
                                   완료(completion)만 의존:
                                   대조는 동일 (프로젝트+패밀리)의 중조 전체
                                   완료 후에만 최종 완료 가능
                                   → 의존 중조 수가 많을수록 완료 지연 위험 ↑
       - family_mid_plan_range : (프로젝트+패밀리) 내 중조 계획 완료일 범위(일)
                                 범위가 넓을수록 마지막 중조 완료 시점 불확실성 ↑
       - is_mid      : "중조" 포함 여부 (1/0, 구분 컬럼 기반)
       - is_large    : "대조" 포함 여부 (1/0, 구분 컬럼 기반)

    5) 중량
       - weight      : 중량 톤 값 (숫자 변환 실패 시 0.0)

    6) 협력사 실적 기반
       - vendor_rolling_lag : 직전 10건 평균 lag_days
                              shift(1) 적용으로 미래 정보 누수 방지
                              초기(데이터 부족) 시 0.0
       - vendor_cumcount    : 협력사 누적 처리 블록 수 (시간순, 0-based)
                              협력사 학습 곡선(Learning Curve) 효과 반영

    반환값
    ------
    (X, y, feats, dates) or None

    - X     : np.ndarray, shape (N, len(feats)), dtype=float32
    - y     : np.ndarray, shape (N,), dtype=float32
    - feats : List[str]  (사용된 피처 이름 순서)
    - dates : pd.Series (계획일, 시계열 분할/로그용)

    ※ 필수 컬럼 누락/결측으로 인해 학습 가능한 행이 없으면 None 반환.
    """
    wcol = _weight_col(df_all)

    # ── 협력사 필터링
    df = df_all.copy()
    df["협력사"] = df["협력사"].astype(str).str.strip()
    df = df.loc[df["협력사"] == vendor].copy()

    # ── 완료일(계획/실적) 파싱
    df["계획일"] = pd.to_datetime(df["기준계획_완료"].apply(_to_date), errors="coerce")
    df["실적일"] = pd.to_datetime(df["실적_완료"].apply(_to_date), errors="coerce")

    # ── 착수일(없으면 NaT 유지)
    df["계획_착수일"] = (
        pd.to_datetime(df["기준계획_착수"].apply(_to_date), errors="coerce")
        if "기준계획_착수" in df.columns else pd.NaT
    )
    df["실적_착수일"] = (
        pd.to_datetime(df["실적_착수"].apply(_to_date), errors="coerce")
        if "실적_착수" in df.columns else pd.NaT
    )

    # ── 최소 조건: 계획일·실적일·중량 모두 있어야 학습 가능
    df = df.dropna(subset=["계획일", "실적일", wcol]).copy()
    if df.empty:
        return None

    # ── 타겟: lag_days
    df["lag_days"] = (df["실적일"] - df["계획일"]).dt.days.clip(-90, 180)

    # ── 시간순 정렬 (rolling/cumcount 계산 전에 반드시 선행)
    df = df.sort_values("계획일").reset_index(drop=True)

    # ──────────────────────────────────────────
    # 1) 계획일 기반 피처 (순환 인코딩)
    # ──────────────────────────────────────────
    plan_month = df["계획일"].dt.month          # 1~12
    plan_week  = df["계획일"].apply(lambda d: week_no_mon(d, d.year))  # 1~53

    # sin/cos 순환 인코딩 — 1월↔12월, 1주↔53주가 인접함을 모델에 전달
    df["plan_month_sin"] = np.sin(2 * np.pi * plan_month / _MONTH_PERIOD)
    df["plan_month_cos"] = np.cos(2 * np.pi * plan_month / _MONTH_PERIOD)
    df["plan_week_sin"]  = np.sin(2 * np.pi * plan_week  / _WEEK_PERIOD)
    df["plan_week_cos"]  = np.cos(2 * np.pi * plan_week  / _WEEK_PERIOD)

    df["plan_quarter"] = df["계획일"].dt.quarter           # 1~4
    df["plan_dow"]     = df["계획일"].dt.weekday           # 월=0 ~ 일=6
    df["plan_dom"]     = df["계획일"].dt.day               # 1~31

    # 월말까지 남은 일수: 0 = 월말 당일, 클수록 월초
    # 기성 기준이 대조 완료이므로 월말에 대조(is_large) 완료가 집중되는
    # 경향을 모델이 학습할 수 있도록 반영
    df["plan_days_to_month_end"] = df["계획일"].apply(
        lambda d: (
            d + pd.offsets.MonthEnd(0) - d
        ).days
    ).astype(float)

    # ──────────────────────────────────────────
    # 2) 계획 기간 / 작업 강도
    # ──────────────────────────────────────────
    df["plan_duration"] = (
        (df["계획일"] - df["계획_착수일"]).dt.days
        .clip(0, 365)
        .fillna(0.0)
    )
    df["weight"] = pd.to_numeric(df[wcol], errors="coerce").fillna(0.0)

    # plan_duration=0 인 행은 NaN → 0.0 으로 안전하게 대체
    df["weight_per_day"] = (
        df["weight"] / df["plan_duration"].replace(0, np.nan)
    ).fillna(0.0).clip(0, 100)

    # ──────────────────────────────────────────
    # 3) 착수 기반 파생 피처 (옵션)
    # ──────────────────────────────────────────
    if include_realized_features:
        # start_lag: 착수 지연일 (조기착수 음수 허용)
        df["start_lag"] = (df["실적_착수일"] - df["계획_착수일"]).dt.days

        # proc_days: 실제 작업 기간 (음수 불가)
        df["proc_days"] = (df["실적일"] - df["실적_착수일"]).dt.days

        # NaN → 중앙값, 컬럼별 클리핑 범위 적용
        _CLIP = {"start_lag": (-90, 180), "proc_days": (0, 365)}
        for col in ("start_lag", "proc_days"):
            vals = df[col]
            default = float(vals.median()) if vals.notna().any() else 0.0
            lo, hi = _CLIP[col]
            df[col] = vals.fillna(default).clip(lo, hi).astype(float)

    # ──────────────────────────────────────────
    # 4) 블록/구분 기반 피처
    # ──────────────────────────────────────────
    if "블록" in df.columns:
        # 블록 구역: 첫 알파벳 → BLOCK_ZONE_MAP (1:선수부/2:중앙부/3:선미부/4:상부·기타/5:미상)
        df["block_zone"] = df["블록"].apply(_alpha_to_zone).astype(float)

        # 중간 숫자 마지막 자리 (0=대조, 1~9=중조, -1=미상)
        df["block_num_last_digit"] = df["블록"].apply(_block_num_last_digit)

        # 패밀리 키 (E11AP/E111P/E110P → "E11")
        df["_block_family"] = df["블록"].apply(_block_family_key)
    else:
        df["block_zone"]           = 5.0
        df["block_num_last_digit"] = -1.0
        df["_block_family"]        = ""

    # 패밀리 기반 피처
    # ※ 블록 고유 식별 = 프로젝트 + 블록번호 (같은 블록코드도 프로젝트가 다르면 별개)
    # ※ 착수(start)는 중조/대조 각각 독립적으로 가능
    #   완료(completion)만 의존: 대조는 같은 (프로젝트+패밀리)의 중조 전체 완료 후에만 가능
    _proj_col = next(
        (c for c in ("프로젝트", "호선", "ship_no", "project") if c in df.columns),
        None,
    )
    if _proj_col:
        df["_proj_family"] = (
            df[_proj_col].astype(str).str.strip() + "_" + df["_block_family"]
        )
    else:
        df["_proj_family"] = df["_block_family"]   # 프로젝트 컬럼 없으면 패밀리만 사용

    #   중조 식별: block_num_last_digit ∈ 1~9 (파싱 성공 && 마지막 자리 ≠ 0)
    _is_mid_code = df["block_num_last_digit"].between(1, 9)

    # family_mid_count : (프로젝트+패밀리) 내 중조 블록 수
    #   대조 완료 전에 선행 완료돼야 하는 중조 수 → 클수록 완료 지연 위험 ↑
    _fam_mid_cnt = (
        df.loc[_is_mid_code]
        .groupby("_proj_family")
        .size()
        .rename("family_mid_count")
    )
    df["family_mid_count"] = (
        df["_proj_family"].map(_fam_mid_cnt).fillna(0.0)
    )

    # family_mid_plan_range : (프로젝트+패밀리) 내 중조 계획 완료일 범위(일)
    #   범위가 넓을수록 마지막 중조 완료 시점의 불확실성이 커져 대조 완료 지연 위험 ↑
    _fam_mid_plan = df.loc[_is_mid_code].groupby("_proj_family")["계획일"]
    _fam_mid_range = (
        (_fam_mid_plan.max() - _fam_mid_plan.min())
        .dt.days
        .fillna(0)
        .rename("family_mid_plan_range")
    )
    df["family_mid_plan_range"] = (
        df["_proj_family"].map(_fam_mid_range).fillna(0.0)
    )

    # 구분: 중조 / 대조 여부
    if "구분" in df.columns:
        g = df["구분"].astype(str)
        df["is_mid"]   = g.str.contains("중조", na=False).astype(float)
        df["is_large"] = g.str.contains("대조", na=False).astype(float)
    else:
        df["is_mid"]   = 0.0
        df["is_large"] = 0.0

    # ──────────────────────────────────────────
    # 5) 협력사 실적 기반 피처
    # ──────────────────────────────────────────
    # vendor_rolling_lag: 직전 10건 lag_days 이동평균
    #   shift(1) 필수 — 현재 행의 실적을 미래 정보로 누수시키지 않음
    df["vendor_rolling_lag"] = (
        df["lag_days"]
        .shift(1)
        .rolling(10, min_periods=1)
        .mean()
        .fillna(0.0)
    )

    # vendor_cumcount: 협력사 누적 처리 블록 수 (0-based, 협력사 학습 곡선 반영)
    df["vendor_cumcount"] = np.arange(len(df), dtype=float)

    # ──────────────────────────────────────────
    # 최종 피처 목록
    # ──────────────────────────────────────────
    feats: List[str] = [
        # 계획일 기반 (순환 인코딩)
        "plan_month_sin",    # 월 sin (12주기 순환)
        "plan_month_cos",    # 월 cos (12주기 순환)
        "plan_week_sin",     # 주차 sin (53주기 순환)
        "plan_week_cos",     # 주차 cos (53주기 순환)
        "plan_quarter",             # 분기 (1~4)
        "plan_dow",                 # 요일 (월=0 ~ 일=6)
        "plan_dom",                 # 일(day-of-month)
        "plan_days_to_month_end",   # 월말까지 잔여일 (기성/대조 완료 집중 반영)
        # 계획 기간 / 작업 강도
        "plan_duration",     # 계획 작업 기간 (일)
        "weight_per_day",    # 일당 처리 중량 (ton/일)
        # 착수 기반 (옵션)
        # → include_realized_features=True 시 아래에서 삽입
        # 블록/구분
        "block_zone",              # 블록 구역 (1~4, 5=미상)
        "block_num_last_digit",    # 중간 숫자 마지막 자리 (0=대조, 1~9=중조, -1=미상)
        "family_mid_count",        # 패밀리 내 중조 수 (대조 선행 의존성 수)
        "family_mid_plan_range",   # 패밀리 내 중조 계획일 범위 (일, 넓을수록 리스크 ↑)
        "is_mid",                  # 중조 여부 (구분 컬럼 기반)
        "is_large",                # 대조 여부 (구분 컬럼 기반)
        # 중량
        "weight",            # 중량 (ton)
        # 협력사 실적 기반
        "vendor_rolling_lag",  # 직전 10건 평균 지연일
        "vendor_cumcount",     # 누적 처리 블록 수
    ]

    if include_realized_features:
        # 착수 기반 피처를 plan_duration 바로 뒤에 삽입
        insert_at = feats.index("plan_duration") + 1
        feats.insert(insert_at,     "start_lag")  # 착수 지연일
        feats.insert(insert_at + 1, "proc_days")  # 실제 작업 기간

    X = df[feats].values.astype(np.float32)
    y = df["lag_days"].values.astype(np.float32)
    dates = pd.to_datetime(df["계획일"])

    return X, y, feats, dates
