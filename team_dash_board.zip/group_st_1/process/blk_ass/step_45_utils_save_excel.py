from __future__ import annotations
"""
step_45_utils_save_excel.py

역할 요약
-----------
KNN, AR, MA, ARIMA, Linear, Ridge, LightGBM, XGBoost, CatBoost 등
각 step_6~step_14 모델에서 공통으로 사용하는 **엑셀 저장 유틸** 모듈입니다.

1) write_section_default(...)
   - "한 섹션(전체/그룹/협력사 1개)"에 대한
     행렬표(능력/계획/실적/누계차/지연일수)를 엑셀 시트에 그려줍니다.
   - 조회일 이후 구간의 실적/누계차/지연일수는 짙은 회색(#666666),
     값이 음수이면 항상 빨간색(FF0000)로 표시합니다.

2) save_excel_with_title(...)
   - 전체/그룹/개별 협력사를 PRINT_ORDER 순서대로 돌면서,
     위 write_section_default를 반복 호출하여 **한 개의 엑셀 파일**을 완성 후 저장합니다.
   - 파일명 예시:
       {year}년도_사외_조립_계획실적_예측_현황(KNN)_251130.xlsx
   - 저장 위치:
       step_41_utils_save_to_folder.get_excel_save_dir(query_date) 가 돌려주는
       "OUT_DIR / yyyy-mm-dd" 폴더 아래에 저장됩니다.

※ 이 모듈은 "엑셀 출력 레이아웃"에만 집중하고,
   실제 예측·집계 로직(행렬 생성)은 각 step_xxx 파일에서
   matrix_vendor_with_pred / matrix_total_with_pred 로 넘겨줍니다.
"""

import datetime as dt
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Callable

import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, Border, Side
from openpyxl.utils import get_column_letter

# 자체 경로
from step_41_utils_save_to_folder import get_excel_save_dir
from step_42_utils_calendar import week_span, week_no_mon
from step_43_utils_label_group import ROW_LABELS, PRINT_ORDER, GROUP_DEFS, resolve_group_members
from step_44_utils_TPD import tpd_week


# ─────────────────────────────────────────────
# 공통 테두리 스타일
# ─────────────────────────────────────────────
_THIN = Side(border_style="thin", color="000000")
BORDER_THIN = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)


# ─────────────────────────────────────────────
# 섹션(한 협력사/그룹/전체 블록) 출력
# ─────────────────────────────────────────────
def write_section_default(
    ws,
    title: str,
    mat: pd.DataFrame,
    start_row: int,
    axis_meta: List[Tuple[str, dict]],
    year: int,
    query_date: dt.date,
) -> int:
    """
    엑셀 시트에 ‘한 섹션(전체/그룹/협력사)’을 출력하는 함수.

    ◎ 미래 구간 색상 규칙 (조회일 포함 이후)
        - 실적 / 누계차 / 지연일수 = 짙은 회색(FF666666)
        - 단, 값이 음수이면 항상 빨간색(FFFF0000)이 우선

    ◎ label_to_date 매핑
        - month  → 그 달의 말일
        - week   → 그 주의 마지막 날 (일요일)
        - day    → meta["date"]
    """

    cols = list(mat.columns)
    r = start_row
    c = 1

    # ───────────────────────────────────────────
    # 1) 타이틀
    # ───────────────────────────────────────────
    tcell = ws.cell(row=r, column=c, value=title)
    tcell.font = Font(bold=True, size=11)
    tcell.alignment = Alignment(horizontal="left")
    r += 1

    # ───────────────────────────────────────────
    # 2) 헤더
    # ───────────────────────────────────────────
    hcell = ws.cell(row=r, column=c, value="구분 (단위: ton)")
    hcell.font = Font(bold=True)
    hcell.border = BORDER_THIN
    hcell.alignment = Alignment(horizontal="center")

    for j, colname in enumerate(cols, start=c+1):
        ch = ws.cell(row=r, column=j, value=colname)
        ch.font = Font(bold=True)
        ch.alignment = Alignment(horizontal="center")
        ch.border = BORDER_THIN

    r += 1

    # ───────────────────────────────────────────
    # 3) label_to_date 생성
    # ───────────────────────────────────────────
    label_to_date = {}

    for lbl, meta in axis_meta:
        t = meta["type"]
        if t == "month":
            m = meta["month"]
            # 월의 마지막 날
            last_day = (dt.date(year, m, 1).replace(day=28) + dt.timedelta(days=4))
            last_day = last_day.replace(day=1) - dt.timedelta(days=1)
            label_to_date[lbl] = last_day
        elif t == "week":
            _, end = week_span(year, meta["week"])
            label_to_date[lbl] = end
        else:  # t == "day"
            label_to_date[lbl] = meta["date"]

    # ───────────────────────────────────────────
    # 4) 본문 데이터 출력
    # ───────────────────────────────────────────
    FUTURE_ROWS = {"실적", "누계차", "지연일수"}

    for rowname in mat.index:
        row = r
        ccell = ws.cell(row=row, column=c, value=rowname)
        ccell.border = BORDER_THIN
        ccell.font = Font(bold=(rowname == "지연일수"))

        for j, colname in enumerate(cols, start=c+1):
            val = mat.loc[rowname, colname]
            cell = ws.cell(row=row, column=j)
            cell.border = BORDER_THIN
            cell.alignment = Alignment(horizontal="right")

            # 숫자 포맷
            if isinstance(val, (int, float)):
                if rowname == "지연일수":
                    cell.value = round(float(val), 1)
                    cell.number_format = "0.0"
                else:
                    cell.value = val
                    cell.number_format = "#,##0"
            else:
                cell.value = val

            # 색상 처리 우선순위
            # 음수 → red
            if isinstance(val, (int, float)) and val < 0:
                cell.font = Font(color="FFFF0000")
                continue  # red가 최우선

            # 미래 구간 → gray (#666666)
            if rowname in FUTURE_ROWS:
                d = label_to_date[colname]
                if d >= query_date:
                    cell.font = Font(color="FF666666")

        r += 1

    return r + 1


# ─────────────────────────────────────────────
# 엑셀 전체 작성 + 저장 (엔진별 공통)
# ─────────────────────────────────────────────
def save_excel_with_title(
    year: int,
    axis_meta: List[Tuple[str, dict]],
    vendors_all: List[str],
    cap_df: pd.DataFrame,
    agg: dict,
    pred_daily: Optional[pd.DataFrame],
    query_date: dt.date,
    sheet_title: str,
    engine_tag: str,
    matrix_vendor_with_pred: Callable[..., pd.DataFrame],
    matrix_total_with_pred: Callable[..., pd.DataFrame],
) -> Path:
    """
    "한 예측 엔진(KNN, AR, MA, ...)"에 대한 월/주/일 하이브리드 행렬표를
    엑셀 파일 1개로 저장하는 함수.

    이 함수는 레이아웃/저장만 담당하고,
    실제 데이터(능력/계획/실적/누계차/지연일수) 계산은
    외부에서 넘겨주는 matrix_vendor_with_pred / matrix_total_with_pred 가 담당합니다.

    Parameters
    ----------
    year : int
        조회 연도
    axis_meta : List[Tuple[str, dict]]
        하이브리드 축 메타 정보 (step_42_utils_calendar.build_hybrid_axis 결과 등)
        - 예: [("1월", {"type":"month","month":1}), ("2월", ...), ... ,("46주", {"type":"week",...}), ...]
    vendors_all : List[str]
        당해년 데이터에 실제 존재하는 협력사 목록
    cap_df : pd.DataFrame
        load_capacity(year) 결과 (협력사별 월별 TPD)
    agg : dict
        build_aggregates(...) 결과 (plan_month/act_month/... 등 집계 데이터)
    pred_daily : Optional[pd.DataFrame]
        예측 결과 일자 단위 DataFrame (없으면 None)
        - 예: 컬럼 ["협력사","예측일","예측중량","engine",...]
    query_date : datetime.date
        조회일 (미래 구간 판단 및 파일명 suffix에 사용)
    sheet_title : str
        엑셀 시트 이름 (예: f"{year} 현황_KNN")
    engine_tag : str
        엔진 태그 (예: "KNN", "AR", "MA"...)
        - 타이틀/파일명에 들어감
    matrix_vendor_with_pred : Callable
        (vendor, cap_df, agg, axis_meta, year, query_date, pred_daily) → DataFrame
        개별 협력사 행렬 생성 함수 (step_6 등에서 정의)
    matrix_total_with_pred : Callable
        (vendors, cap_df, agg, axis_meta, year, query_date, pred_daily) → DataFrame
        여러 협력사를 합산한 행렬 생성 함수

    Returns
    -------
    Path
        저장된 엑셀 파일의 전체 경로 (Path 객체)
    """
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_title

    # ── 1) 조회주 기준 협력사별 TPD (타이틀 표시용) ────────────────────
    qw = week_no_mon(query_date, year) or 1
    vendor_title_tpd: Dict[str, float] = {
        v: (
            0.0
            if pd.isna(tpd_week(cap_df, v, year, qw))
            else float(tpd_week(cap_df, v, year, qw))
        )
        for v in vendors_all
    }

    def title_tpd(name: str) -> float:
        """
        타이틀에 넣을 TPD 값 계산.

        - 개별 협력사: 해당 협력사의 조회주 TPD 사용
        - 그룹/전체  : 하위 협력사들의 TPD 합을 사용
        """
        if name in vendor_title_tpd:
            return vendor_title_tpd[name]
        members = resolve_group_members(name, vendors_all)
        if not members:
            return 0.0
        return float(sum(vendor_title_tpd.get(v, 0.0) for v in members))

    row = 1

    # ── 2) PRINT_ORDER 순서대로 섹션 출력 ────────────────────────────
    for name in PRINT_ORDER:
        # (1) 전체/그룹 처리
        if name == "전체":
            members = resolve_group_members("전체", vendors_all)
            if members:
                mat = matrix_total_with_pred(
                    members, cap_df, agg, axis_meta, year, query_date, pred_daily
                )
            else:
                cols = [lbl for (lbl, _) in axis_meta]
                mat = pd.DataFrame(0, index=ROW_LABELS, columns=cols, dtype=object)

        elif name in GROUP_DEFS:
            members = resolve_group_members(name, vendors_all)
            if members:
                mat = matrix_total_with_pred(
                    members, cap_df, agg, axis_meta, year, query_date, pred_daily
                )
            else:
                cols = [lbl for (lbl, _) in axis_meta]
                mat = pd.DataFrame(0, index=ROW_LABELS, columns=cols, dtype=object)

        # (2) 개별 협력사 처리
        else:
            if name in vendors_all:
                mat = matrix_vendor_with_pred(
                    name, cap_df, agg, axis_meta, year, query_date, pred_daily
                )
            else:
                cols = [lbl for (lbl, _) in axis_meta]
                mat = pd.DataFrame(0, index=ROW_LABELS, columns=cols, dtype=object)

        # 섹션 타이틀 예:
        #  "기민_2.5톤/일_KNN"
        #  "전체_1335.0톤/일_KNN"
        tpd_val = title_tpd(name)
        title_str = f"{name}_{tpd_val:,.1f}톤/일_{engine_tag}"

        # 실제 섹션 그리기
        row = write_section_default(
            ws, title_str, mat, row, axis_meta, year, query_date
        )

    # ── 3) 열 너비 정리 ────────────────────────────────────────────
    for col in range(1, ws.max_column + 1):
        ws.column_dimensions[get_column_letter(col)].width = 12

    # ── 4) 날짜별 폴더에 엑셀 저장 ───────────────────────────────────
    #     step_41_utils_save_to_folder.get_excel_save_dir 사용
    excel_dir = get_excel_save_dir(query_date)
    excel_dir.mkdir(parents=True, exist_ok=True)

    date_suffix = query_date.strftime("%y%m%d")  # 예: 2025-11-30 → "251130"
    out_path = excel_dir / f"{year}년도_사외_조립_계획실적_예측_현황({engine_tag})_{date_suffix}.xlsx"

    try:
        Path(out_path).unlink(missing_ok=True)
    except Exception as e:
        print(f"[LOG] 기존 엑셀 삭제 실패: {e}")

    wb.save(out_path)
    print(f"[SAVE] Excel saved → {out_path}")

    return out_path
