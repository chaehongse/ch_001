from __future__ import annotations

"""
step_12_LightGBM.py

역할 요약
---------
1. step_2_BPA_Data 에서 전년도/당해년도 데이터를 로드한다.
2. 협력사별로 시계열 테이블(_build_vendor_table)을 만들고,
   - 8:2, 7:3 두 가지 시계열 분할 비율에 대해
   - LightGBM(LGBMRegressor) 하이퍼파라미터(leaf/learning_rate/n_estimators) 그리드를 탐색하면서
   - R2_valid, RMSE_valid 기준으로 best 모델을 선정한다.
3. 선정된 LightGBM 모델로
   - 기준계획_완료 기준 1/1 ~ 다음해 3/31까지의 계획분에 대해 lag(실적일-계획일)를 예측하고
   - next_working_day()로 휴무일을 건너뛴 '예측 실적일'을 만든 뒤
   - 협력사/예측일별 예측중량(ton)을 집계한다.
4. step_5_MWD 스타일의 하이브리드 축(월/주/일) 위에
   - 능력(조회일 이전: TPD, 조회일 이후: 직전 유효값 ffill)
   - 계획
   - 실적(조회일 이전: 실제 실적, 조회일 포함 이후: LightGBM 예측값)
   - 누계차(실적/예측 - 계획, 월↔주 경계 중복감산 포함)
   - 지연일수(누계차 / 능력)
   를 채워 행렬(matrix_vendor_with_pred, matrix_total_with_pred)을 생성한다.
5. step_45_utils_save_excel.save_excel_with_title 를 통해
   - 엑셀 시트/파일을 저장 (엔진 태그: "LightGBM")
6. step_46_utils_save_logcsv_ML.write_csv_log_ML 로
   - 로그 CSV + DB(예측_모델_log)까지 저장한다.
"""

import argparse
import datetime as dt
import json
from typing import Dict, List, Optional, Tuple, Callable

import numpy as np
import pandas as pd
import calendar

# ── 경고 억제(호환형) 
import warnings
from sklearn.exceptions import ConvergenceWarning

warnings.filterwarnings("ignore", category=ConvergenceWarning)
try:
    from numpy.exceptions import VisibleDeprecationWarning as _NP_VDW

    warnings.filterwarnings("ignore", category=_NP_VDW)
except Exception:
    warnings.filterwarnings("ignore", message=".*VisibleDeprecationWarning.*")
try:
    from numpy.linalg import LinAlgWarning as _NP_LAW

    warnings.filterwarnings("ignore", category=_NP_LAW)
except Exception:
    warnings.filterwarnings("ignore", message=".*[Ii]ll-conditioned.*")
    warnings.filterwarnings("ignore", message=".*[Ss]ingular matrix.*")
warnings.filterwarnings("ignore", category=RuntimeWarning)
np.seterr(all="ignore")

# LightGBM / Metrics
import lightgbm as _lightgbm
from lightgbm import LGBMRegressor
from sklearn.metrics import r2_score, mean_absolute_error, root_mean_squared_error

# 데이터/유틸 모듈
from step_2_BPA_Data import outside_df2
from step_40_utils_holiday import next_working_day, is_holiday
from step_42_utils_calendar import TODAY, DEFAULT_YEAR, _to_date, week_no_mon, week_span, dates_of_week, weeks_in_month
from step_43_utils_label_group import ROW_LABELS, BASE_VENDORS
from step_44_utils_TPD import load_capacity, tpd_month, tpd_week, tpd_day, DB_URL
from step_45_utils_save_excel import save_excel_with_title
from step_46_utils_save_logcsv_ML import write_csv_log_ML
from step_47_utils_train_table import _build_vendor_table


# ─────────────────────────────────────────────
# 집계 생성(월/주/일)
# ─────────────────────────────────────────────
def _weight_col(df: pd.DataFrame) -> str:
    """
    사용할 중량 컬럼명을 자동 판별.

    우선순위
    1) '고유_중량'
    2) '중량_고유'
    """
    if "고유_중량" in df.columns:
        return "고유_중량"
    if "중량_고유" in df.columns:
        return "중량_고유"
    raise KeyError("중량 컬럼 누락 ('고유_중량' 또는 '중량_고유').")


def build_aggregates(df_year: pd.DataFrame, year: int) -> dict:
    """
    연도별 원천 데이터를 월/주/일 단위로 집계.

    Returns
    -------
    dict
        {
          "plan_month", "act_month",
          "plan_week",  "act_week",
          "plan_day",   "act_day"
        }
    """
    wcol = _weight_col(df_year)
    df = df_year.copy()
    df["협력사"] = df["협력사"].astype(str).str.strip()

    if "기준계획_완료" not in df.columns:
        raise KeyError("기준계획_완료 누락")
    if "실적_완료" not in df.columns:
        raise KeyError("실적_완료 누락")

    df["계획일"] = pd.to_datetime(df["기준계획_완료"].apply(_to_date), errors="coerce")
    df["실적일"] = pd.to_datetime(df["실적_완료"].apply(_to_date), errors="coerce")

    df_plan = df[df["계획일"].dt.year.eq(year)].copy()
    df_act = df[df["실적일"].dt.year.eq(year)].copy()

    df_plan["월"] = df_plan["계획일"].dt.month
    df_plan["주"] = df_plan["계획일"].apply(lambda d: week_no_mon(d, year))
    df_plan["일자"] = df_plan["계획일"]

    df_act["월"] = df_act["실적일"].dt.month
    df_act["주"] = df_act["실적일"].apply(lambda d: week_no_mon(d, year))
    df_act["일자"] = df_act["실적일"]

    plan_month = (
        df_plan.groupby(["협력사", "월"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "계획"})
    )
    act_month = (
        df_act.groupby(["협력사", "월"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "실적"})
    )
    plan_week = (
        df_plan.dropna(subset=["주"])
        .groupby(["협력사", "주"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "계획"})
    )
    act_week = (
        df_act.dropna(subset=["주"])
        .groupby(["협력사", "주"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "실적"})
    )
    plan_day = (
        df_plan.groupby(["협력사", "일자"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "계획"})
    )
    act_day = (
        df_act.groupby(["협력사", "일자"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "실적"})
    )

    return {
        "plan_month": plan_month,
        "act_month": act_month,
        "plan_week": plan_week,
        "act_week": act_week,
        "plan_day": plan_day,
        "act_day": act_day,
    }


# ─────────────────────────────────────────────
# 하이브리드 축(meta)
# ─────────────────────────────────────────────
def build_hybrid_axis(year: int, query_date: dt.date) -> List[Tuple[str, dict]]:
    """
    조회일 기준 '하이브리드 축' 구성.

    규칙
    ----
    1) 조회월 이전  : 월 단위
    2) 조회월 내    : 조회주 이전 주단위
    3) 조회주       : 일 단위
    4) 조회주 이후 : 주 단위
    5) 조회월 이후 : 월 단위
    """
    qm = query_date.month
    qw = week_no_mon(query_date, year)
    labels: List[Tuple[str, dict]] = []

    # 조회월 이전 월
    for m in range(1, qm):
        labels.append((f"{m}월", {"type": "month", "month": m}))

    # 조회월 내 주 리스트
    wlist = weeks_in_month(year, qm)
    if qw not in wlist:
        wlist = sorted(set(wlist + ([qw] if qw else [])))

    # 조회주 이전 주
    for w in [x for x in wlist if x < qw]:
        labels.append((f"{w}주", {"type": "week", "week": w}))

    # 조회주 일자
    for d in dates_of_week(year, qw):
        if d.year == year and d.month == qm:
            labels.append((f"{d.month}/{d.day}", {"type": "day", "date": d}))

    # 조회주 이후 주
    for w in [x for x in wlist if x > qw]:
        labels.append((f"{w}주", {"type": "week", "week": w}))

    # 조회월 이후 월
    for m in range(qm + 1, 13):
        labels.append((f"{m}월", {"type": "month", "month": m}))
    return labels


# ─────────────────────────────────────────────
# 일자 딕셔너리(중복감산/일 단위용)
# ─────────────────────────────────────────────
def _daily_dicts_for_vendor(agg: dict, vendor: str):
    """
    해당 협력사의 일별 계획/실적을
    dict(date → float) 형태로 반환.
    """
    pdict, adict = {}, {}
    if not agg["plan_day"].empty:
        sub = agg["plan_day"].loc[agg["plan_day"]["협력사"] == vendor]
        pdict = {
            pd.to_datetime(r["일자"]).date(): float(r["계획"])
            for _, r in sub.iterrows()
        }
    if not agg["act_day"].empty:
        sub = agg["act_day"].loc[agg["act_day"]["협력사"] == vendor]
        adict = {
            pd.to_datetime(r["일자"]).date(): float(r["실적"])
            for _, r in sub.iterrows()
        }
    return pdict, adict


# ─────────────────────────────────────────────
# 시계열 train/valid 분할 유틸
# ─────────────────────────────────────────────
def _time_split_idx(
    n: int,
    valid_ratio: float = 0.2,
    min_valid: Optional[int] = None,
):
    """
    시계열용 인덱스 분할 (앞쪽 train, 뒤쪽 valid)

    - min_valid 가 주어지지 않으면 데이터 개수 기반으로 자동 설정:
      * 기본: max(20, int(n * 0.1))
    - 데이터가 너무 적으면 valid를 비워서 (0개) 반환
    """
    if min_valid is None:
        min_valid = max(20, int(n * 0.1))

    if n <= min_valid:
        return np.arange(0, n), np.array([], dtype=int)

    nv = max(int(n * valid_ratio), min_valid)
    if nv >= n:
        nv = max(1, n // 5)

    split = n - nv
    if split <= 0:
        return np.arange(0, n), np.array([], dtype=int)

    return np.arange(0, split), np.arange(split, n)


# ─────────────────────────────────────────────
# 협력사별 LightGBM 단일 학습
# ─────────────────────────────────────────────
def train_lgbm_per_vendor(
    df_prev: pd.DataFrame, df_curr: pd.DataFrame, vendors: List[str]
):
    """
    협력사별 LightGBM 단일 모델 선택.

    - split_ratio: 8:2 / 7:3 두 가지 모두 시도
    - 각 split 안에서 num_leaves / learning_rate / n_estimators 그리드 탐색
    - R2_valid 기준 베스트 조합 선택 (동률이면 RMSE_valid 작은 쪽)

    Returns
    -------
    predictors : Dict[str, Callable]
        협력사별 lag 예측 함수 (df_vendor_feats → np.ndarray)
    csv_rows : List[dict]
        로그 CSV 및 DB 저장용 row (CHOSEN만 기록)
    """
    split_candidates = [
        (0.2, "8:2"),
        (0.3, "7:3"),
    ]

    all_df = pd.concat([df_prev, df_curr], ignore_index=True)

    predictors: Dict[str, Callable] = {}
    csv_rows: List[dict] = []

    print("==== [협력사별 LightGBM 학습 — multi split ratios] ====")

    for v in vendors:
        packed = _build_vendor_table(all_df, v, include_realized_features=False)
        if packed is None:
            print(f"[WARN] '{v}' 협력사 데이터 부족/누락 → 학습 스킵")
            continue
        X, y, feats, dates = packed
        n = len(y)

        print(f"[INFO] '{v}' 학습 데이터 개수: {n}")

        if n < 30:
            print(f"[WARN] '{v}' 샘플 수 {n} (<30) → LightGBM 학습 스킵")
            continue

        best_global = None
        best_model_global = None
        best_split_ratio = None
        best_train_range = ""
        best_valid_range = ""

        # ── 8:2 / 7:3 각각 시도 ───────────────────
        for valid_ratio, ratio_label in split_candidates:
            tr_idx, va_idx = _time_split_idx(n, valid_ratio=valid_ratio)
            if len(tr_idx) == 0 or len(va_idx) == 0:
                continue

            X_tr, y_tr = X[tr_idx], y[tr_idx]
            X_va, y_va = X[va_idx], y[va_idx]

            train_range = (
                f"{pd.Timestamp(dates.iloc[tr_idx[0]]).strftime('%Y%m%d')}-"
                f"{pd.Timestamp(dates.iloc[tr_idx[-1]]).strftime('%Y%m%d')}"
            )
            valid_range = (
                f"{pd.Timestamp(dates.iloc[va_idx[0]]).strftime('%Y%m%d')}-"
                f"{pd.Timestamp(dates.iloc[va_idx[-1]]).strftime('%Y%m%d')}"
            )

            # 이 split에 대한 LightGBM 하이퍼파라미터 탐색
            for num_leaves in [31, 63, 127]:
                for lr in [0.03, 0.06, 0.1]:
                    for n_est in [400, 800, 1200]:
                        try:
                            lgb = LGBMRegressor(
                                num_leaves=int(num_leaves),
                                learning_rate=float(lr),
                                n_estimators=int(n_est),
                                subsample=0.9,
                                colsample_bytree=0.9,
                                reg_alpha=0.0,
                                reg_lambda=1.0,
                                objective="regression",
                                random_state=42,
                                n_jobs=0,
                            )
                            lgb.fit(
                                X_tr,
                                y_tr,
                                eval_set=[(X_va, y_va)],
                                eval_metric="rmse",
                                callbacks=[
                                    _lightgbm.early_stopping(
                                        stopping_rounds=100, verbose=False
                                    ),
                                    _lightgbm.log_evaluation(period=-1),
                                ],
                            )
                            # early stopping 후 실제 사용된 트리 수로 업데이트
                            actual_n_est = int(n_est)
                            if hasattr(lgb, "best_iteration_") and lgb.best_iteration_ > 0:
                                actual_n_est = lgb.best_iteration_
                            pred_va = lgb.predict(X_va)
                            cand = {
                                "engine": "lightgbm",
                                "model": lgb,
                                "params": {
                                    "num_leaves": int(num_leaves),
                                    "learning_rate": float(lr),
                                    "n_estimators": actual_n_est,
                                    "subsample": 0.9,
                                    "colsample_bytree": 0.9,
                                    "reg_alpha": 0.0,
                                    "reg_lambda": 1.0,
                                },
                                "R2_train": float(
                                    r2_score(y_tr, lgb.predict(X_tr))
                                )
                                if len(y_tr) > 1
                                else float("nan"),
                                "R2_valid": float(r2_score(y_va, pred_va))
                                if len(y_va) > 1
                                else float("nan"),
                                "MAE_valid": float(
                                    mean_absolute_error(y_va, pred_va)
                                ),
                                "RMSE_valid": float(
                                    root_mean_squared_error(y_va, pred_va)
                                ),
                                "split_ratio": ratio_label,
                                "train_range": train_range,
                                "valid_range": valid_range,
                            }

                            # 글로벌 best와 비교(스플릿/하이퍼 모두 포함)
                            if (
                                best_global is None
                                or cand["R2_valid"] > best_global["R2_valid"]
                                or (
                                    np.isclose(
                                        cand["R2_valid"], best_global["R2_valid"]
                                    )
                                    and cand["RMSE_valid"]
                                    < best_global["RMSE_valid"]
                                )
                            ):
                                best_global = cand
                                best_model_global = lgb
                                best_split_ratio = ratio_label
                                best_train_range = train_range
                                best_valid_range = valid_range
                        except Exception:
                            continue

        if best_global is None or best_model_global is None:
            print(f"[WARN] '{v}' LightGBM 유효한 하이퍼파라미터/스플릿 없음 → 학습 실패")
            continue

        # ── 최종 선택된 하이퍼파라미터로 전체 데이터 재학습 ──────────────
        model_all = LGBMRegressor(
            **{
                k: v
                for k, v in best_global["params"].items()
                if k
                in [
                    "num_leaves",
                    "learning_rate",
                    "n_estimators",
                    "subsample",
                    "colsample_bytree",
                    "reg_alpha",
                    "reg_lambda",
                ]
            },
            objective="regression",
            random_state=42,
            n_jobs=0,
        )
        model_all.fit(X, y)

        def predict_fn_factory(m=model_all, feats=feats):
            def _predict(df_vendor_feats: pd.DataFrame) -> np.ndarray:
                A = df_vendor_feats[feats].values.astype(np.float32)
                return m.predict(A)

            return _predict

        predictors[v] = predict_fn_factory()

        # 콘솔 요약
        print(
            f"[LGBM] {v} | best split={best_split_ratio} | "
            f"{json.dumps(best_global['params'], ensure_ascii=False)} | "
            f"R2_valid={best_global.get('R2_valid', float('nan')):.4f}  "
            f"RMSE_valid={best_global.get('RMSE_valid', float('nan')):.3f}  "
            f"MAE_valid={best_global.get('MAE_valid', float('nan')):.3f} | "
            f"train={best_train_range}  valid={best_valid_range}"
        )

        # 로그 행 (CHOSEN만)
        ts = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        def _clean(d):
            out = {}
            for k, val in d.items():
                if k == "model":
                    continue
                out[k] = (
                    float(val)
                    if isinstance(val, (np.floating, np.integer))
                    else val
                )
            return out

        row_ch = _clean(best_global)
        csv_rows.append(
            {
                "timestamp": ts,
                "year": dates.iloc[-1].year if len(dates) else dt.date.today().year,
                "협력사": v,
                "tag": "CHOSEN",
                "engine": row_ch.get("engine"),
                "params_json": row_ch.get("params"),
                "R2_train": row_ch.get("R2_train"),
                "R2_valid": row_ch.get("R2_valid"),
                "MAE_valid": row_ch.get("MAE_valid"),
                "RMSE_valid": row_ch.get("RMSE_valid"),
                "split_ratio": row_ch.get("split_ratio"),
                "train_range": row_ch.get("train_range"),
                "valid_range": row_ch.get("valid_range"),
            }
        )

    print("======================================= ")
    return predictors, csv_rows


# ─────────────────────────────────────────────
# 예측일 산출(협력사별 LightGBM)
# ─────────────────────────────────────────────
def predict_future_by_date_per_vendor(
    df_curr: pd.DataFrame,
    predictors: Dict[str, Callable],
    start_date: dt.date,
    end_date: dt.date
) -> pd.DataFrame:
    """
    계획일 피처 → 예측 lag → 예측일 = 계획일 + lag → 날짜별 예측중량 집계

    기본 규칙
       - step_40_holiday.next_working_day 을 사용해서
         주말/휴가/공휴일/명절 등 휴무일을 자동으로 건너뛰고
         '다음 영업일'을 예측일로 사용.

    월말 추가 규칙
       - 예측일이 월말 부근 휴무일이라서 next_working_day 결과가
         '다음 달로 넘어가면',
         → 해당 달의 "마지막 영업일"로 당겨서 실적이 발생한다고 가정.
       - 이유: 협력사가 월말 기성 맞추려고 생산을 당겨서
         다음 달로 넘기지 않으려는 패턴을 반영.
    """
    wcol = _weight_col(df_curr)
    df = df_curr.copy()
    df["협력사"] = df["협력사"].astype(str).str.strip()
    df["계획일"] = pd.to_datetime(df["기준계획_완료"].apply(_to_date), errors="coerce")

    plan_end = dt.date(start_date.year + 1, 3, 31)
    # 예측 범위: start_date ~ plan_end (계획 기준)
    mask = (
        df["계획일"].notna()
        & (df["계획일"] >= pd.Timestamp(start_date))
        & (df["계획일"] <= pd.Timestamp(plan_end))
    )
    df = df.loc[mask].copy()
    if df.empty:
        return pd.DataFrame(columns=["협력사", "예측일", "예측중량"])

    outs = []

    for v, fn in predictors.items():
        sub = df.loc[df["협력사"] == v].copy()
        if sub.empty:
            continue

        # ─────────────────────────────────────
        # 학습과 동일한 피처 구조 생성
        # ─────────────────────────────────────
        sub["plan_month"] = sub["계획일"].dt.month
        sub["plan_dow"]   = sub["계획일"].dt.weekday
        sub["plan_dom"]   = sub["계획일"].dt.day
        sub["plan_week"]  = sub["계획일"].apply(lambda d: week_no_mon(d, d.year))

        sub["start_lag"] = 0.0
        sub["proc_days"] = 0.0

        if "블록" in sub.columns:
            def _first_alpha_to_num(val):
                if pd.isna(val):
                    return 0.0
                s = str(val).strip().upper()
                for ch in s:
                    if "A" <= ch <= "Z":
                        return float(ord(ch) - ord("A") + 1)
                return 0.0
            sub["block_alpha"] = sub["블록"].apply(_first_alpha_to_num).astype(float)
        else:
            sub["block_alpha"] = 0.0

        if "구분" in sub.columns:
            g = sub["구분"].astype(str)
            sub["is_mid"]   = g.str.contains("중조", na=False).astype(float)
            sub["is_large"] = g.str.contains("대조", na=False).astype(float)
        else:
            sub["is_mid"] = 0.0
            sub["is_large"] = 0.0

        sub["weight"] = pd.to_numeric(sub[wcol], errors="coerce").fillna(0.0)

        # 1) lag 일수 예측
        A = sub  # feats는 모델 학습 시 _build_vendor_table에서 정의한 순서 사용
        lag_pred = np.round(fn(A)).astype(int).clip(-90, 180)

        # 2) 원시 예측일 (달력 기준)
        raw_pred = sub["계획일"] + pd.to_timedelta(lag_pred, unit="D")

        # 3) 휴무일 보정 + 월말 규칙 적용
        def _adjust_to_working_day(ts):
            """
            기본: next_working_day 로 다음 영업일 계산.
            예외: 결과가 다음 달로 넘어가면 → 해당 달 마지막 영업일로 당김.
            """
            if pd.isna(ts):
                return pd.NaT

            d_raw = pd.Timestamp(ts).date()
            d_next = next_working_day(d_raw)

            # ① 다음 영업일이 같은 달이면 그대로 사용
            if d_next.month == d_raw.month:
                return pd.Timestamp(d_next)

            # ② 다음달로 넘어가는 경우 → '이 달의 마지막 영업일'로 조정
            year = d_raw.year
            month = d_raw.month
            # 그 달의 마지막 날
            last_day = calendar.monthrange(year, month)[1]
            cur = dt.date(year, month, last_day)

            # 뒤로 가면서 휴무가 아닌 날 찾기
            for _ in range(40):  # 안전 상한
                if not is_holiday(cur):
                    return pd.Timestamp(cur)
                cur -= dt.timedelta(days=1)

            # 이론상 거의 도달하지 않지만, 방어적으로 마지막 값 반환
            return pd.Timestamp(cur)

        sub["예측일"] = raw_pred.apply(_adjust_to_working_day)

        # 4) 연도 범위 클리핑 (start_date ~ 연말)
        sub["예측일"] = sub["예측일"].clip(
            lower=pd.Timestamp(start_date),
            upper=pd.Timestamp(dt.date(start_date.year, 12, 31)),
        )

        # 5) 날짜별 예측중량 집계
        pred = (
            sub.groupby(["협력사", "예측일"], as_index=False)["weight"]
               .sum()
               .rename(columns={"weight": "예측중량"})
        )
        outs.append(pred)

    if not outs:
        return pd.DataFrame(columns=["협력사", "예측일", "예측중량"])

    out = pd.concat(outs, ignore_index=True)
    out["예측일"] = pd.to_datetime(out["예측일"])
    out = out.loc[out["예측일"].notna()].copy()
    out = out.sort_values(["협력사", "예측일"]).reset_index(drop=True)
    return out



# ─────────────────────────────────────────────
# 시리즈/행렬(벤더/전체) + 예측 포함
# ─────────────────────────────────────────────
def series_for_vendor_with_pred(
    vendor: str,
    cap_df: pd.DataFrame,
    agg: dict,
    axis_meta: List[Tuple[str, dict]],
    year: int,
    query_date: dt.date,
    pred_daily: Optional[pd.DataFrame],
):
    """
    단일 협력사에 대해,
    하이브리드 축 기준의 시계열(능력, 계획, 실적, 누계차, 지연일수)을 생성.

    - 조회일 이전 : 실제 실적 기준
    - 조회일 이후 : 예측중량(pred_daily) 기준
    - 능력        : 조회일 이전은 TPD, 조회일 이후는 직전 유효값 ffill
    - 예측행은 별도 row 없이, 실적/누계차/지연일수에 이미 반영된 상태로만 반환
    """
    pm = (
        agg["plan_month"]
        .loc[agg["plan_month"]["협력사"] == vendor]
        .set_index("월")["계획"]
        if not agg["plan_month"].empty
        else pd.Series(dtype=float)
    )
    am = (
        agg["act_month"]
        .loc[agg["act_month"]["협력사"] == vendor]
        .set_index("월")["실적"]
        if not agg["act_month"].empty
        else pd.Series(dtype=float)
    )
    pw = (
        agg["plan_week"]
        .loc[agg["plan_week"]["협력사"] == vendor]
        .set_index("주")["계획"]
        if not agg["plan_week"].empty
        else pd.Series(dtype=float)
    )
    aw = (
        agg["act_week"]
        .loc[agg["act_week"]["협력사"] == vendor]
        .set_index("주")["실적"]
        if not agg["act_week"].empty
        else pd.Series(dtype=float)
    )

    # 일별 dict (월/주↔일 중복 보정용)
    pdict, adict = _daily_dicts_for_vendor(agg, vendor)

    cap_calc_list: List[float] = []       # 지연일 분모용 능력(숫자)
    plan_list: List[float] = []
    act_list: List[float] = []
    overlap_delta_by_idx: Dict[int, float] = {}
    compare_dates: List[dt.date] = []

    # ── 축 메타 순회(능력/계획/실적/대표일자/중복보정 정보 생성) ─────────
    for idx, (_, meta) in enumerate(axis_meta):
        if meta["type"] == "month":
            m = meta["month"]
            cap_val = tpd_month(cap_df, vendor, m)
            cap_calc_list.append(np.nan if pd.isna(cap_val) else float(cap_val))

            # 해당 월 마지막 날
            last_day = (dt.date(year, m, 1).replace(day=28) + dt.timedelta(days=4))
            last_day = last_day.replace(day=1) - dt.timedelta(days=1)
            compare_dates.append(last_day)

            plan_list.append(float(pm.get(m, 0.0)))
            act_list.append(float(am.get(m, 0.0)))

        elif meta["type"] == "week":
            w = meta["week"]
            cap_val = tpd_week(cap_df, vendor, year, w)
            cap_calc_list.append(np.nan if pd.isna(cap_val) else float(cap_val))

            _, end = week_span(year, w)
            compare_dates.append(end)

            plan_list.append(float(pw.get(w, 0.0)))
            act_list.append(float(aw.get(w, 0.0)))

            # 주跨월 보정용 overlap delta (이전 월분)
            s, e = week_span(year, w)
            if s.month != e.month:
                prev_month_days = [
                    d
                    for d in dates_of_week(year, w)
                    if d.month == s.month and d.year == year
                ]
                plan_overlap = sum(pdict.get(d, 0.0) for d in prev_month_days)
                act_overlap = sum(adict.get(d, 0.0) for d in prev_month_days)
                overlap_delta_by_idx[idx] = act_overlap - plan_overlap

        else:  # "day"
            d = meta["date"]
            cap_val = tpd_day(cap_df, vendor, d)
            cap_calc_list.append(np.nan if pd.isna(cap_val) else float(cap_val))

            compare_dates.append(d)

            plan_list.append(float(pdict.get(d, 0.0)))
            act_list.append(float(adict.get(d, 0.0)))

    # ── numpy 배열 변환 ─────────────────────────
    cap_calc = np.array(cap_calc_list, dtype=float)
    plan_arr = np.array(plan_list, dtype=float)
    act_arr = np.array(act_list, dtype=float)

    # ── 축별 예측중량(월/주/일) 합계 계산 ──────────────
    pred_list: List[Optional[float]] = []
    for _, meta in axis_meta:
        if pred_daily is None or pred_daily.empty:
            pred_list.append(None)
            continue

        df_p = pred_daily[pred_daily["협력사"] == vendor]
        if df_p.empty:
            pred_list.append(None)
            continue

        if meta["type"] == "month":
            m = meta["month"]
            sel = df_p[df_p["예측일"].dt.month == m]
        elif meta["type"] == "week":
            w = meta["week"]
            sel = df_p[df_p["예측일"].dt.isocalendar().week.astype(int) == w]
        else:  # "day"
            d = meta["date"]
            sel = df_p[df_p["예측일"].dt.date == d]

        pred_list.append(float(sel["예측중량"].sum()) if not sel.empty else None)

    pred_arr = np.array(
        [
            np.nan
            if (v is None or (isinstance(v, float) and np.isnan(v)))
            else float(v)
            for v in pred_list
        ],
        dtype=float,
    )

    compare_dates_arr = np.array(compare_dates, dtype=object)

    # ── 능력행(표기용): 조회일 이전은 원래 값, 이후는 직전 유효값 ffill ─────
    cap_out = np.empty_like(compare_dates_arr, dtype=object)
    last_cap: Optional[float] = None
    for i, cd in enumerate(compare_dates):
        raw = cap_calc[i]
        val = None if np.isnan(raw) else float(raw)
        if cd < query_date:
            cap_out[i] = val
            if val is not None:
                last_cap = val
        else:
            cap_out[i] = last_cap

    # ── 실적/예측 numeric : 조회일 이전 → 실적, 이후 → 예측중량 ───────────
    actual_numeric = np.zeros_like(plan_arr, dtype=float)
    for i, cd in enumerate(compare_dates):
        if cd < query_date:
            actual_numeric[i] = act_arr[i]
        else:
            pv = pred_arr[i] if i < len(pred_arr) else np.nan
            actual_numeric[i] = 0.0 if np.isnan(pv) else pv

    # ── 누계차: (실적/예측 - 계획) 누적 + 월/주/일 중복보정 ────────────────
    diff = np.nan_to_num(actual_numeric) - np.nan_to_num(plan_arr)
    cumsum = np.cumsum(diff)

    for i, delta in overlap_delta_by_idx.items():
        if delta:
            cumsum[i:] -= delta

    act_out = actual_numeric.astype(object)
    cumsum_out = cumsum.astype(object)

    # ── 지연일수: 누계차 / 능력(분모는 cap_calc 그대로 사용) ─────────────
    delay_out = np.empty_like(cumsum, dtype=object)
    for i in range(len(delay_out)):
        denom = cap_calc[i]
        if (
            isinstance(denom, (int, float, np.floating))
            and not np.isnan(denom)
            and denom != 0
        ):
            delay_out[i] = cumsum[i] / denom
        else:
            delay_out[i] = None

    # 예측행은 별도 row 없이, 실적/누계차/지연일수에 이미 반영된 상태로만 반환
    return cap_out, plan_arr, act_out, cumsum_out, delay_out


def matrix_vendor_with_pred(
    vendor: str,
    cap_df: pd.DataFrame,
    agg: dict,
    axis_meta: List[Tuple[str, dict]],
    year: int,
    query_date: dt.date,
    pred_daily: Optional[pd.DataFrame],
) -> pd.DataFrame:
    """
    단일 협력사용 LightGBM 예측 포함 행렬 생성.
    """
    cap, plan, act, csum, delay = series_for_vendor_with_pred(
        vendor, cap_df, agg, axis_meta, year, query_date, pred_daily
    )
    cols = [lbl for (lbl, _) in axis_meta]
    return pd.DataFrame(
        [cap, plan, act, csum, delay],
        index=ROW_LABELS,
        columns=cols,
    )


def matrix_total_with_pred(
    vendors: List[str],
    cap_df: pd.DataFrame,
    agg: dict,
    axis_meta: List[Tuple[str, dict]],
    year: int,
    query_date: dt.date,
    pred_daily: Optional[pd.DataFrame],
) -> pd.DataFrame:
    """
    여러 협력사(그룹/전체)의 행렬 합산.

    - 능력 : 협력사별 능력행 합
    - 계획/실적/누계차 : 협력사별 행렬 합
    - 지연일수 : (누계차 합 / 능력합)
    """
    mats = [
        matrix_vendor_with_pred(
            v, cap_df, agg, axis_meta, year, query_date, pred_daily
        )
        for v in vendors
    ]
    cols = [lbl for (lbl, _) in axis_meta]
    if not mats:
        return pd.DataFrame(0, index=ROW_LABELS, columns=cols, dtype=object)

    # 능력 합
    cap_arrays_num = [
        [
            0.0
            if (val is None or (isinstance(val, float) and np.isnan(val)))
            else float(val)
            for val in m.loc["능력"].values
        ]
        for m in mats
    ]
    cap_sum_numeric = np.nansum(cap_arrays_num, axis=0)

    # 계획/실적/누계차 합 (None → 0)
    plan = np.nansum([m.loc["계획"].values.astype(float) for m in mats], axis=0)
    act_arrays = [
        [0.0 if v is None else float(v) for v in m.loc["실적"].values]
        for m in mats
    ]
    csum_arrays = [
        [0.0 if v is None else float(v) for v in m.loc["누계차"].values]
        for m in mats
    ]

    act_sum = np.nansum(act_arrays, axis=0)
    csum_sum = np.nansum(csum_arrays, axis=0)

    # 지연일수: 누계차 / 능력합
    delay_arr = np.empty_like(act_sum, dtype=object)
    for i in range(len(delay_arr)):
        denom = cap_sum_numeric[i]
        if (
            isinstance(denom, (int, float, np.floating))
            and not np.isnan(denom)
            and denom != 0
        ):
            delay_arr[i] = csum_sum[i] / denom
        else:
            delay_arr[i] = None

    cap_out = cap_sum_numeric.astype(object)
    plan_out = plan.astype(object)
    act_out = act_sum.astype(object)
    csum_out = csum_sum.astype(object)

    return pd.DataFrame(
        [cap_out, plan_out, act_out, csum_out, delay_arr],
        index=ROW_LABELS,
        columns=cols,
    )


# ─────────────────────────────────────────────
# 엑셀 저장 (타이틀에 "LightGBM")
# ─────────────────────────────────────────────
def save_excel(
    year: int,
    axis_meta: List[Tuple[str, dict]],
    vendors_all: List[str],
    cap_df: pd.DataFrame,
    agg: dict,
    pred_daily: Optional[pd.DataFrame],
    query_date: dt.date,
):
    """
    - 시트 이름과 엔진 태그만 여기서 결정하고
    - 실제 작성/저장은 step_45_utils_save_excel.save_excel_with_title 를 사용.
    """
    sheet_title = f"{year} 현황_LightGBM"  # 시트 이름
    engine_tag = "LightGBM"                # 타이틀/파일명에 붙을 엔진 태그

    return save_excel_with_title(
        year=year,
        axis_meta=axis_meta,
        vendors_all=vendors_all,
        cap_df=cap_df,
        agg=agg,
        pred_daily=pred_daily,
        query_date=query_date,
        sheet_title=sheet_title,
        engine_tag=engine_tag,
        matrix_vendor_with_pred=matrix_vendor_with_pred,
        matrix_total_with_pred=matrix_total_with_pred,
    )


# ─────────────────────────────────────────────
# 로그 CSV — LightGBM 전용 + DB 업로드(예측_모델_log)
# ─────────────────────────────────────────────
def write_csv_log(year: int, query_date: dt.date, rows: List[dict]) -> None:
    """
    공통 유틸(step_46_utils_save_logcsv_ML.write_csv_log_ML)을 호출해서
    LightGBM 엔진 로그 CSV 및 DB(예측_모델_log) 업로드까지 수행.
    """
    engine_tag = "LightGBM"
    write_csv_log_ML(
        year=year,
        query_date=query_date,
        rows=rows,
        engine_tag=engine_tag,
        db_url=DB_URL,
        table_name="예측_모델_log",
    )


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
def main(year: int, query_date: Optional[str] = None):
    """
    LightGBM 기반 lag 예측 →
    예측일별 실적/능력/누계차/지연일수 행렬 생성 및 엑셀/로그 저장 전체 파이프라인.
    """
    qdate = TODAY if query_date is None else pd.to_datetime(query_date).date()

    # 전/당해/내년 개별 로드 시도
    df_prev = outside_df2(year - 1)
    df_curr = outside_df2(year)
    df_next = outside_df2(year + 1)
    df_all = pd.concat([df_prev, df_curr, df_next], ignore_index=True)

    df_all = df_all.copy()
    df_all["협력사"] = df_all["협력사"].astype(str).str.strip()

    plan_dt = pd.to_datetime(df_all["기준계획_완료"].apply(_to_date), errors="coerce")
    act_dt = pd.to_datetime(df_all["실적_완료"].apply(_to_date), errors="coerce")

    prev_year = year - 1
    df_prev = df_all[
        (plan_dt.dt.year.eq(prev_year)) | (act_dt.dt.year.eq(prev_year))
    ].copy()
    df_curr = df_all[
        (plan_dt.dt.year.eq(year)) | (act_dt.dt.year.eq(year))
    ].copy()

    # 실제 데이터가 존재하는 협력사 목록
    if not df_curr.empty:
        available_vendors = (
            df_curr["협력사"].dropna().astype(str).str.strip().unique().tolist()
        )
    else:
        available_vendors = []

    vendors_all = sorted(available_vendors)

    vendors_ordered = [v for v in BASE_VENDORS if v in vendors_all] + [
        v for v in vendors_all if v not in BASE_VENDORS
    ]

    if not vendors_ordered:
        print("[WARN] 당해년 협력사 데이터가 없어 LightGBM 예측을 수행할 수 없습니다.")
        return

    # 학습 대상 협력사 (실제 데이터 있는 것만)
    vendors_for_train = [v for v in vendors_ordered if v in available_vendors]
    missing_vendors = [v for v in vendors_ordered if v not in available_vendors]
    if missing_vendors:
        print(
            "[WARN] 데이터가 없는 협력사 (학습 제외): "
            + ", ".join(missing_vendors)
        )

    cap_df = load_capacity(year)
    agg = build_aggregates(df_curr, year)
    axis_meta = build_hybrid_axis(year, qdate)

    # LightGBM 모델 학습
    predictors, rows_for_csv = train_lgbm_per_vendor(
        df_prev, df_curr, vendors_for_train
    )

    # 예측 (연초~연말)
    start_date = dt.date(year, 1, 1)
    end_date = dt.date(year, 12, 31)
    pred_daily = predict_future_by_date_per_vendor(
        df_curr, predictors, start_date, end_date
    )

    # 엑셀 저장
    save_excel(
        year=year,
        axis_meta=axis_meta,
        vendors_all=vendors_all,
        cap_df=cap_df,
        agg=agg,
        pred_daily=pred_daily,
        query_date=qdate,
    )

    # 로그 저장
    write_csv_log(year, qdate, rows_for_csv)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--year", type=int, default=DEFAULT_YEAR, help="조회 연도 (기본: 올해)")
    parser.add_argument(
        "--query_date",
        type=str,
        default=None,
        help="조회일 (YYYY-MM-DD, 기본: 오늘)",
    )
    args = parser.parse_args()
    main(args.year, args.query_date)

