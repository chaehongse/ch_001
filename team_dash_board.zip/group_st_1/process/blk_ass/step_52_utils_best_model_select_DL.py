from __future__ import annotations
"""
step_52_utils_best_model_select_DL.py (DB Only)

협력사별 최종 best engine 선정 — 정규화 복합 점수 방식
=======================================================

선정 방식: 순위 기반 정규화 복합 점수 (Normalized Composite Score)
  - val_loss (SmoothL1Loss, 낮을수록 좋음) — 기본 가중치 0.50
  - RMSE_valid (낮을수록 좋음)              — 기본 가중치 0.30
  - MAE_valid  (낮을수록 좋음)              — 기본 가중치 0.20

  composite_score = w_vl * VL_norm + w_rmse * RMSE_norm + w_mae * MAE_norm

  - 순위 정규화: (rank - 1) / (n - 1)  →  최고 모델=1.0, 최저 모델=0.0
  - val_loss NaN 모델: 정규화 점수 0.0 (최하위 취급)
  - R2_valid < 0 패널티: composite_score -= 0.1
  - 동률(1e-6 이하 차이): 최신 timestamp 우선

[MAPE 처리 방침]
  - MAPE는 모델 선정 기준에서 제외 (lag_days=0인 경우 분모=0 → undefined 위험)
  - DB 로그에 MAPE_valid 컬럼이 있을 경우 출력 로그·CSV에 참고 지표로만 포함

[출력]
- OUT_DIR / best_model_by_vendor_dl.json
- OUT_DIR / logs_dl / {year}_best_model_dl_YYYYMMDD.csv
  (year는 강제 year 지정 시 그 year, 미지정이면 현재연도 사용)
"""

import argparse
import datetime as dt
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import pymysql
from sqlalchemy import create_engine, text

pymysql.install_as_MySQLdb()

from step_0_MSF import OUT_DIR

# ─────────────────────────────────────────────
# DB 설정
# ─────────────────────────────────────────────
from db_config import DB_URL
from step_50_utils_best_model_common import (
    filter_chosen,
    filter_year_per_vendor_latest,
    load_logs_from_db,
)

# ─────────────────────────────────────────────
# Utils
# ─────────────────────────────────────────────

# ─────────────────────────────────────────────
# 1) DB 로그 로드
# ─────────────────────────────────────────────

# ─────────────────────────────────────────────
# 2) CHOSEN ??

# 3) year ?? (???? ?? year ?? ??)

# 4) 최근 N일 필터 (timestamp 기준)
# ─────────────────────────────────────────────
def filter_recent(df: pd.DataFrame, days: int) -> pd.DataFrame:
    if "timestamp" not in df.columns:
        print("[INFO] timestamp 없음 → 최근 N일 필터 스킵")
        return df

    df = df.copy()
    df["timestamp_dt"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df = df.dropna(subset=["timestamp_dt"])
    if df.empty:
        print("[WARN] timestamp 파싱 후 데이터 없음 → 기간 필터 미적용")
        return df

    cutoff = dt.datetime.now() - dt.timedelta(days=days)
    recent = df[df["timestamp_dt"] >= cutoff]
    if recent.empty:
        print(f"[WARN] 최근 {days}일 이내 로그 없음 → 기간 필터 미적용")
        return df

    print(f"[INFO] 최근 {days}일 필터 적용: {len(recent)} rows")
    return recent

# ─────────────────────────────────────────────
# 5) 순위 정규화 유틸
# ─────────────────────────────────────────────
def _rank_norm_lower_better(series: pd.Series) -> pd.Series:
    """낮을수록 좋은 지표: 최솟값 → 1.0, 최댓값 → 0.0"""
    n = len(series)
    if n <= 1:
        return pd.Series([1.0] * n, index=series.index)
    ranked = series.rank(method="average", ascending=False)
    return (ranked - 1) / (n - 1)

# ─────────────────────────────────────────────
# 5) 복합 점수 컬럼 생성
# ─────────────────────────────────────────────
def add_composite_scores_dl(
    df: pd.DataFrame,
    w_valloss: float = 0.50,
    w_rmse: float = 0.30,
    w_mae: float = 0.20,
) -> pd.DataFrame:
    """
    DL 선정용 정규화 복합 점수 계산.

    composite_score = w_vl * VL_norm + w_rmse * RMSE_norm + w_mae * MAE_norm

    - val_loss NaN 모델: VL_norm = 0.0 (최하위)
    - R2_valid < 0 패널티: composite_score -= 0.1
    - timestamp tie-break 컬럼(ts_f) 생성
    """
    df = df.copy()

    for col in ["val_loss", "RMSE_valid", "MAE_valid", "R2_valid"]:
        if col not in df.columns:
            df[col] = np.nan
        df[col] = pd.to_numeric(df[col], errors="coerce")

    n = len(df)

    # val_loss: NaN → 최댓값 * 10 으로 채워 worst 취급
    if df["val_loss"].notna().any():
        vl_fill = df["val_loss"].fillna(df["val_loss"].max() * 10 + 1e9)
        vl_norm = _rank_norm_lower_better(vl_fill)
    else:
        vl_norm = pd.Series([0.0] * n, index=df.index)

    # RMSE: NaN → worst 취급
    if df["RMSE_valid"].notna().any():
        rmse_fill = df["RMSE_valid"].fillna(df["RMSE_valid"].max() + 1e9)
        rmse_norm = _rank_norm_lower_better(rmse_fill)
    else:
        rmse_norm = pd.Series([0.0] * n, index=df.index)

    # MAE: NaN → worst 취급
    if df["MAE_valid"].notna().any():
        mae_fill = df["MAE_valid"].fillna(df["MAE_valid"].max() + 1e9)
        mae_norm = _rank_norm_lower_better(mae_fill)
    else:
        mae_norm = pd.Series([0.0] * n, index=df.index)

    df["composite_score"] = (
        w_valloss * vl_norm + w_rmse * rmse_norm + w_mae * mae_norm
    )

    # R2 < 0 패널티
    df["composite_score"] = df["composite_score"] - np.where(
        df["R2_valid"].fillna(0) < 0, 0.1, 0.0
    )

    # timestamp tie-break
    if "timestamp_dt" not in df.columns:
        if "timestamp" in df.columns:
            df["timestamp_dt"] = pd.to_datetime(df["timestamp"], errors="coerce")
        else:
            df["timestamp_dt"] = pd.NaT
    df["ts_f"] = df["timestamp_dt"].fillna(pd.Timestamp("1970-01-01"))

    return df

def _pick_best_row_by_score_dl(
    sub: pd.DataFrame,
    w_valloss: float = 0.50,
    w_rmse: float = 0.30,
    w_mae: float = 0.20,
) -> Tuple[pd.Series, str]:
    """복합 점수 기준으로 단일 그룹(sub)에서 최고 1건 선택. 동률은 최신 ts."""
    sub = add_composite_scores_dl(sub, w_valloss, w_rmse, w_mae)
    best = sub.sort_values(
        by=["composite_score", "ts_f"],
        ascending=[False, False],
    ).iloc[0]
    return best, f"composite(w_vl={w_valloss},w_rmse={w_rmse},w_mae={w_mae})"

# ─────────────────────────────────────────────
# 6) (협력사, engine)별 최고성능 1건 유지
# ─────────────────────────────────────────────
def keep_best_per_vendor_engine(
    df: pd.DataFrame,
    w_valloss: float = 0.50,
    w_rmse: float = 0.30,
    w_mae: float = 0.20,
) -> pd.DataFrame:
    if "협력사" not in df.columns or "engine" not in df.columns:
        print("[ERROR] '협력사' 또는 'engine' 컬럼 없음")
        return df

    df = df.copy()
    df["협력사"] = df["협력사"].astype(str).map(_norm_str)
    df["engine"] = df["engine"].astype(str).str.strip().str.lower()
    df = df[(df["협력사"] != "") & (df["engine"] != "")]
    if df.empty:
        print("[WARN] 협력사/engine 유효행 없음")
        return df

    rows = []
    for (vendor, engine), sub in df.groupby(["협력사", "engine"]):
        best_row, _ = _pick_best_row_by_score_dl(sub, w_valloss, w_rmse, w_mae)
        rows.append(best_row)

    out = pd.DataFrame(rows).reset_index(drop=True)
    print(f"[INFO] 협력사+engine별 최고성능 로그만 유지: {len(out)} rows")
    return out

# ─────────────────────────────────────────────
# 7) 협력사별 best engine 선정
# ─────────────────────────────────────────────
def select_best_engine_per_vendor(
    df: pd.DataFrame,
    w_valloss: float = 0.50,
    w_rmse: float = 0.30,
    w_mae: float = 0.20,
) -> Tuple[Dict[str, str], pd.DataFrame]:
    if df.empty:
        return {}, pd.DataFrame()

    df = df.copy()
    df["협력사"] = df["협력사"].astype(str).map(_norm_str)
    df["engine"] = df["engine"].astype(str).str.strip().str.lower()
    df = df[(df["협력사"] != "") & (df["engine"] != "")]
    if df.empty:
        print("[WARN] 협력사/engine 정보 유효한 행 없음")
        return {}, pd.DataFrame()

    best_map: Dict[str, str] = {}
    best_rows: List[pd.Series] = []

    for vendor, sub in df.groupby("협력사"):
        best, rule = _pick_best_row_by_score_dl(sub, w_valloss, w_rmse, w_mae)
        engine = str(best["engine"]).strip().lower()
        best_map[vendor] = engine
        best_rows.append(best)

        mape_str = (
            f", MAPE={best.get('MAPE_valid')}  ※참고용"
            if "MAPE_valid" in best.index and pd.notna(best.get("MAPE_valid"))
            else ""
        )
        print(
            f"[BEST] 협력사={vendor} / engine={engine} "
            f"(rule={rule}, score={best.get('composite_score', float('nan')):.4f}, "
            f"val_loss={best.get('val_loss')}, RMSE={best.get('RMSE_valid')}, "
            f"MAE={best.get('MAE_valid')}, R2={best.get('R2_valid')}"
            f"{mape_str})"
        )

    best_df = pd.DataFrame(best_rows).reset_index(drop=True) if best_rows else pd.DataFrame()
    return best_map, best_df

# ─────────────────────────────────────────────
# 8) JSON 저장
# ─────────────────────────────────────────────
def save_best_json(best_map: Dict[str, str]) -> Path:
    out_path = OUT_DIR / "best_model_by_vendor_dl.json"
    ordered = {k: best_map[k] for k in sorted(best_map.keys())}
    with open(out_path, "w", encoding="utf-8") as fp:
        json.dump(ordered, fp, ensure_ascii=False, indent=2)
    print(f"[SAVE] 협력사별 best DL 모델 JSON 저장: {out_path} (vendors={len(ordered)})")
    return out_path

# ─────────────────────────────────────────────
# 9) best 모델 로그 CSV 저장
# ─────────────────────────────────────────────
def save_best_log_csv(best_df: pd.DataFrame, year_for_filename: Optional[int]) -> Optional[Path]:
    if best_df is None or best_df.empty:
        print("[WARN] best_df 비어있음 → CSV 저장 스킵")
        return None

    logs_dir = OUT_DIR / "logs_dl"
    logs_dir.mkdir(parents=True, exist_ok=True)

    today = dt.date.today()
    y = year_for_filename if year_for_filename is not None else today.year
    fname = f"{y}_best_model_dl_{today.strftime('%Y%m%d')}.csv"

    out_path = logs_dir / fname

    drop_cols = ["composite_score", "ts_f", "timestamp_dt"]
    best_df_to_save = best_df.drop(columns=[c for c in drop_cols if c in best_df.columns], errors="ignore")
    best_df_to_save.to_csv(out_path, index=False, encoding="utf-8-sig")

    print(f"[SAVE] best DL 모델 로그 CSV 저장: {out_path} (rows={len(best_df_to_save)})")
    return out_path

# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
def main(
    year: Optional[int] = None,
    recent_days: int = 60,
    w_valloss: float = 0.50,
    w_rmse: float = 0.30,
    w_mae: float = 0.20,
):
    print(" ==== DL Best Model Selection (DB Only) ==== ")
    print(
        f"[CONFIG] recent_days={recent_days}, year={year}, "
        f"w_valloss={w_valloss}, w_rmse={w_rmse}, w_mae={w_mae}"
    )

    df = load_logs_from_db(DB_URL, "예측_모델_log_dl")
    if df.empty:
        print("[ABORT] DB 로그 없음 → 종료")
        return

    df = filter_chosen(df)

    # 협력사별 최신 year 자동 선택
    df_year, selected_year = filter_year_per_vendor_latest(df, year)

    if recent_days > 0:
        df_year = filter_recent(df_year, recent_days)

    if df_year.empty:
        print("[ABORT] 필터링 후 로그 없음 → 종료")
        return

    # (협력사, engine)별 최고성능 1건
    df_best_ve = keep_best_per_vendor_engine(df_year, w_valloss, w_rmse, w_mae)
    if df_best_ve.empty:
        print("[ABORT] 협력사+engine 최고성능 필터 후 로그 없음 → 종료")
        return

    # 협력사별 최종 best engine
    best_map, best_df = select_best_engine_per_vendor(df_best_ve, w_valloss, w_rmse, w_mae)
    if not best_map:
        print("[ABORT] best DL 모델 없음 → 종료")
        return

    save_best_json(best_map)

    # 파일명 year: 강제 year면 그 year, 미지정이면 현재연도(협력사별 year가 다를 수 있음)
    year_for_filename = selected_year if year is not None else None
    save_best_log_csv(best_df, year_for_filename)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--year", type=int, default=None, help="강제 year (미지정 시 협력사별 최신 year 자동 선택)")
    parser.add_argument("--recent_days", type=int, default=60, help="최근 N일 이내 로그만 사용 (0 이하이면 미적용)")
    parser.add_argument("--w_valloss", type=float, default=0.50, help="val_loss 가중치 (기본 0.50)")
    parser.add_argument("--w_rmse",    type=float, default=0.30, help="RMSE 가중치 (기본 0.30)")
    parser.add_argument("--w_mae",     type=float, default=0.20, help="MAE 가중치 (기본 0.20)")
    args = parser.parse_args()
    main(args.year, args.recent_days, args.w_valloss, args.w_rmse, args.w_mae)
