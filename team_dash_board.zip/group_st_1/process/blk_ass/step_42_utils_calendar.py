from __future__ import annotations

import datetime as dt
from typing import List, Optional, Tuple, Union

import numpy as np
import pandas as pd

# ─────────────────────────────────────────────
# 기본 날짜 설정
# ─────────────────────────────────────────────
TODAY = dt.date.today()
DEFAULT_YEAR = TODAY.year


def _to_date(val: Union[str, int, float, dt.date, dt.datetime, pd.Timestamp, None]) -> Optional[dt.date]:
    """
    여러 형태의 값을 dt.date 로 변환하는 유틸 함수.

    지원 형식
    ----------
    - ''(빈 문자열) 또는 NaN            → None
    - datetime / Timestamp / date      → date (그냥 날짜만 추출)
    - 숫자(정수/실수):
        · 8자리 정수:  YYYYMMDD 로 간주 (예: 20250131)
        · 6자리 정수:  YYYYMM 로 간주, 일자는 1일로 처리 (예: 202501 → 2025-01-01)
        · 그 외 길이  → 변환 실패 시 None
    - 문자열(str):
        · pandas.to_datetime 으로 파싱, 실패 시 None

    이 함수는 "이 값은 날짜 같아 보이는데…" 하는 모든 케이스를
    최대한 date 로 바꿔주고, 애매하면 None 으로 정리하는 역할입니다.
    """
    # 1) 빈 문자열
    if isinstance(val, str) and not val.strip():
        return None

    # 2) NaN 계열
    if pd.isna(val):
        return None

    # 3) date / datetime / Timestamp → date 로 통일
    if isinstance(val, (dt.date, dt.datetime, pd.Timestamp)):
        return pd.Timestamp(val).date()

    # 4) 숫자(엑셀에서 날짜를 20250101 같은 코드로 들고오거나,
    #    yyyymm 형식 숫자인 경우)
    if isinstance(val, (int, float, np.integer, np.floating)):
        s = str(int(val))
        if len(s) == 8:  # YYYYMMDD
            ts = pd.to_datetime(s, format="%Y%m%d", errors="coerce")
        elif len(s) == 6:  # YYYYMM → YYYYMM01
            ts = pd.to_datetime(s + "01", format="%Y%m%d", errors="coerce")
        else:
            ts = pd.NaT
        return None if pd.isna(ts) else ts.date()

    # 5) 일반 문자열 → pandas.to_datetime 에 일단 맡기기
    if isinstance(val, str):
        ts = pd.to_datetime(val, errors="coerce")
        return None if pd.isna(ts) else ts.date()

    # 그 외 타입은 전부 None 처리
    return None


def _monday(d: Union[dt.date, dt.datetime, pd.Timestamp]) -> dt.date:
    """
    주어진 날짜가 포함된 주의 '월요일' 날짜 반환.

    - 월요일 기준 주차 계산(week_no_mon)에서 사용하는 보조 함수
    - Monday=0 기준 (datetime.date.weekday())
    """
    if isinstance(d, (pd.Timestamp, dt.datetime)):
        d = pd.Timestamp(d).date()
    return d - dt.timedelta(days=d.weekday())  # Monday=0


def _first_monday(year: int) -> dt.date:
    """
    해당 연도 1월 1일이 속한 주의 월요일을 '기준 주차 시작점'으로 사용.

    예)
        2025-01-01 이 수요일이라면,
        이 날이 속한 주의 월요일(2024-12-30)을 기준으로
        week_no_mon 계산 시 1주차가 시작됩니다.
    """
    return _monday(dt.date(year, 1, 1))


def week_no_mon(d, year: int) -> Optional[int]:
    """
    월요일 기준 주차 번호 계산 함수.

    규칙
    ----
    - d.year != year 이면 None (해당 연도 외의 날짜는 관심 밖)
    - 기준: _first_monday(year) 로부터 몇 번째 주인지 계산
    - 반환 범위는 1 ~ 53 사이로 클리핑

    인자 예)
    --------
    d: datetime.date / datetime / Timestamp / 기타
    year: 기준 연도 (예: 2025)

    사용 예)
    --------
    >>> week_no_mon(date(2025, 1, 1), 2025)
    1  # (기준 주차 정의에 따라 달라질 수 있음)
    """
    if d is None or (isinstance(d, float) and np.isnan(d)):
        return None

    if isinstance(d, (pd.Timestamp, dt.datetime)):
        d = pd.Timestamp(d).date()

    if not isinstance(d, dt.date) or d.year != year:
        return None

    base = _first_monday(year)
    wn = 1 + ((_monday(d) - base).days // 7)

    # 주차 번호 클리핑 (1~53)
    if wn < 1:
        return 1
    if wn > 53:
        return 53
    return wn


def week_span(year: int, week_no: int) -> Tuple[dt.date, dt.date]:
    """
    (year, week_no)에 대한 '해당 주간의 시작일(월요일)과 종료일(일요일)'을 반환.

    예)
        >>> week_span(2025, 1)
        (2024-12-30, 2025-01-05)  # 기준 정의에 따라 1주차가 이렇게 잡힐 수 있음
    """
    start = _first_monday(year) + dt.timedelta(days=(week_no - 1) * 7)
    end = start + dt.timedelta(days=6)
    return start, end


def dates_of_week(year: int, week_no: int) -> List[dt.date]:
    """
    해당 연도, 주차에 포함되는 7일(월~일) 리스트를 반환.

    예)
        >>> dates_of_week(2025, 1)
        [2024-12-30, 2024-12-31, 2025-01-01, 2025-01-02, 2025-01-03, 2025-01-04, 2025-01-05]
    """
    s, _ = week_span(year, week_no)
    return [s + dt.timedelta(days=i) for i in range(7)]


def weeks_in_month(year: int, month: int) -> List[int]:
    """
    (year, month)에 속한 '모든 날짜'가 포함된
    월요일 기준 주차 번호 목록을 반환.

    로직
    ----
    - 해당 월의 1일부터 말일까지 하루씩 돌면서 week_no_mon 으로 주차 계산
    - None 이 아닌 주차 번호를 모두 set 에 넣고, 정렬해서 리스트로 반환

    예)
        2025년 11월에 걸쳐 있는 주차가 45, 46, 47 이라면:
        >>> weeks_in_month(2025, 11)
        [45, 46, 47]
    """
    first = dt.date(year, month, 1)
    # 말일 계산: 28일에 4일 더한 뒤 다음 달 1일에서 하루 빼기 패턴
    last = (first.replace(day=28) + dt.timedelta(days=4)).replace(day=1) - dt.timedelta(days=1)

    wset = set()
    for i in range((last - first).days + 1):
        d = first + dt.timedelta(days=i)
        wn = week_no_mon(d, year)
        if wn:
            wset.add(wn)
    return sorted(wset)
