from __future__ import annotations
"""
step_51_utils_best_predict_ML.py

- step_50_utils_best_model_select_ML.py 에서 선정된
  협력사별 Best(최적) ML 모델 정보를 읽어서
  → 그 엔진으로 예측을 수행하고
  → 월/주/일 하이브리드 축에 맞춰
     능력/계획/실적/누계차/지연일수 행렬을 만든 뒤
  → 엑셀과 로그 CSV(+DB)에 저장하는 모듈입니다.

주요 특징
---------
1) Best 모델 로딩
   - OUT_DIR / "best_model_by_vendor_ML.json" 에서 협력사별 최적 엔진을 로드
   - JSON이 없으면 협력사별로 Ridge 기본값 사용

2) 축/집계
   - 월/주/일을 섞은 하이브리드 축(axis_meta) 생성
   - 계획/실적은 집계 테이블에서 가져옴
   - 예측(pred_daily)은 일자 단위 예측을 월/주/일 단위로 다시 합산

3) 조회일 이후 처리
   - 조회일 포함 이후 구간의 실적행은 예측중량을 사용
   - 누계차(실적/예측 - 계획)는 예측까지 반영하여 계산
   - 능력은 조회일 "직전" 값으로 미래 구간에 ffill
   - 지연일수 = 누계차 / 능력 (과거+미래 전체)

4) 색상 규칙(엑셀)
   - 조회일 포함 이후의 능력/실적/누계차/지연일수: 짙은 회색(FF666666)
   - 값이 음수인 셀은 항상 빨간색(FFFF0000) 우선
"""

import argparse
import datetime as dt
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from openpyxl.styles import Alignment, Font, Border, Side
from openpyxl.utils import get_column_letter

# 공통 경로/상수
from step_0_MSF import OUT_DIR
from step_2_BPA_Data import outside_df2 
from step_42_utils_calendar import (
    TODAY,
    DEFAULT_YEAR,
    _to_date,
    week_no_mon,
    week_span,
    dates_of_week,
    weeks_in_month,
    _first_monday,
)
from step_43_utils_label_group import (
    ROW_LABELS,
    BASE_VENDORS,
    PRINT_ORDER,
    GROUP_DEFS,
    BORDER_THIN,
    resolve_group_members,
)
from step_44_utils_TPD import load_capacity, tpd_month, tpd_week, tpd_day, DB_URL
from step_49_utils_BPA_upload import upload_bpa_predict_ml

# ─────────────────────────────────────────────
# 각 단일 모델 모듈에서 학습/예측 함수 import
# ─────────────────────────────────────────────

from step_6_KNN import (
    train_knn_per_vendor,
    predict_future_by_date_per_vendor as predict_knn_future,
)
from step_7_AR import (
    train_ar_per_vendor,
    predict_future_by_date_per_vendor as predict_ar_future,
)
from step_8_MA import (
    train_ma_per_vendor,
    predict_future_by_date_per_vendor as predict_ma_future,
)
from step_9_ARIMA import (
    train_arima_per_vendor,
    predict_future_by_date_per_vendor as predict_arima_future,
)
from step_10_Linear import (
    train_linear_per_vendor,
    predict_future_by_date_per_vendor as predict_linear_future,
)
from step_11_Ridge import (
    train_ridge_per_vendor,
    predict_future_by_date_per_vendor as predict_ridge_future,
)
from step_12_LightGBM import (
    train_lgbm_per_vendor,
    predict_future_by_date_per_vendor as predict_lgbm_future,
)
from step_13_XGBoost import (
    train_xgb_per_vendor,
    predict_future_by_date_per_vendor as predict_xgb_future,
)
from step_14_Catboost import (
    train_catboost_per_vendor,
    predict_future_by_date_per_vendor as predict_catboost_future,
)


def _is_blank_actual(v) -> bool:
    if pd.isna(v):
        return True
    s = str(v).strip().lower()
    return s in ("", "nan", "none", "nat")


def apply_ml_predicted_dates_to_actual(
    base_df: pd.DataFrame, pred_daily: Optional[pd.DataFrame]
) -> pd.DataFrame:
    """
    step_2(outside_df2) 원본에 대해 '실적_완료' 빈칸을 ML 예측일로 채운다.

    배정 로직(협력사별):
      - 예측 결과를 예측일 단위로 합산(예측중량)
      - 원본의 실적_완료 빈 행(협력사별)을 기준계획_완료 순으로 정렬
      - 행 중량 누적값이 예측중량 누적을 처음 넘는 날짜를 해당 행 예측일로 배정
    """
    df = base_df.copy()
    if pred_daily is None or pred_daily.empty:
        return df
    if "협력사" not in df.columns or "실적_완료" not in df.columns:
        return df

    weight_col = "고유_중량" if "고유_중량" in df.columns else ("중량_고유" if "중량_고유" in df.columns else None)
    if weight_col is None:
        print("[WARN] 중량 컬럼(고유_중량/중량_고유)이 없어 예측일 매핑을 생략합니다.")
        return df

    pred = pred_daily.copy()
    if "협력사" not in pred.columns or "예측일" not in pred.columns or "예측중량" not in pred.columns:
        print("[WARN] pred_daily 필수 컬럼(협력사/예측일/예측중량) 누락으로 예측일 매핑을 생략합니다.")
        return df

    pred["협력사"] = pred["협력사"].astype(str).str.strip()
    pred["예측일"] = pd.to_datetime(pred["예측일"], errors="coerce")
    pred["예측중량"] = pd.to_numeric(pred["예측중량"], errors="coerce").fillna(0.0)
    pred = pred.dropna(subset=["예측일"])
    pred = pred[pred["예측중량"] > 0]
    if pred.empty:
        return df

    df["협력사"] = df["협력사"].astype(str).str.strip()
    empty_mask = df["실적_완료"].apply(_is_blank_actual)
    if not empty_mask.any():
        return df

    for vendor, sub_idx in df[empty_mask].groupby("협력사").groups.items():
        sub_rows = df.loc[sub_idx].copy()
        sub_rows["_plan_dt"] = pd.to_datetime(sub_rows.get("기준계획_완료"), errors="coerce")
        sub_rows = sub_rows.sort_values(["_plan_dt"], kind="stable")

        p = pred[pred["협력사"] == vendor]
        if p.empty:
            continue

        pday = (
            p.groupby(p["예측일"].dt.normalize(), as_index=False)["예측중량"]
            .sum()
            .rename(columns={"예측일": "예측일"})
            .sort_values("예측일")
        )
        if pday.empty:
            continue

        cum_pred = pday["예측중량"].cumsum().to_numpy()
        need = (
            pd.to_numeric(sub_rows[weight_col], errors="coerce")
            .fillna(0.0)
            .clip(lower=0.0)
            .cumsum()
            .to_numpy()
        )
        pos = np.searchsorted(cum_pred, need, side="left")
        pos = np.clip(pos, 0, len(pday) - 1)
        assigned = pday["예측일"].iloc[pos].dt.strftime("%Y%m%d").to_numpy()
        df.loc[sub_rows.index, "실적_완료"] = assigned

    return df


# ─────────────────────────────────────────────
# Best(최적) 모델 매핑 로더
# ─────────────────────────────────────────────

# 외부에서 불러올 때 들어올 수 있는 엔진명 alias 정리용
ENGINE_ALIASES: Dict[str, str] = {
    "ridge": "ridge",
    "knn": "knn",
    "ar": "ar",
    "ma": "ma",
    "arima": "arima",
    "lightgbm": "lightgbm",
    "xgboost": "xgboost",
    "catboost": "catboost",
    "linear": "linear",
}

# 타이틀에 들어갈 표시용 모델명
ENGINE_TITLE: Dict[str, str] = {
    "ridge": "Ridge",
    "knn": "KNN",
    "ar": "AR",
    "ma": "MA",
    "arima": "ARIMA",
    "lightgbm": "LightGBM",
    "xgboost": "XGBoost",
    "catboost": "CatBoost",
    "linear": "Linear",
}


def normalize_engine_name(name: str) -> str:
    """
    JSON/로그에서 읽어온 엔진명을
    내부에서 사용하는 키(ridge/knn/...)로 정규화.
    """
    key = str(name).strip().lower()
    return ENGINE_ALIASES.get(key, "ridge")  # 모르면 Ridge로 기본값


def load_best_model_map(year: int) -> Dict[str, str]:
    """
    협력사별 Best 모델 매핑 로드.

    - step_50_utils_best_model_select_ML 에서 생성한
      OUT_DIR / "best_model_by_vendor_ML.json" 을 읽는다.
    - JSON 구조 예:
        {
          "기민": "ridge",
          "디케이(건화)": "lightgbm",
          ...
        }
    - 파일이 없거나 문제가 있으면 빈 dict 반환
      → 이후 로직에서 Ridge 기본값 사용.
    """
    json_path = OUT_DIR / "best_model_by_vendor_ML.json"
    mapping: Dict[str, str] = {}

    if json_path.is_file():
        try:
            with open(json_path, encoding="utf-8") as fp:
                raw = json.load(fp)
            for k, v in raw.items():
                vendor = str(k).strip()
                eng = normalize_engine_name(str(v))
                mapping[vendor] = eng
            print(f"[INFO] JSON best 모델 매핑 로드: {json_path} (rows={len(mapping)})")
            return mapping
        except Exception as e:
            print(f"[WARN] JSON best 모델 매핑 로드 실패: {e}")

    print(
        "[WARN] best_model_by_vendor_ML.json 을 찾지 못했습니다. "
        "모든 협력사는 Ridge 모델을 기본값으로 사용합니다."
    )
    return mapping  # 비어있으면 이후 로직에서 Ridge로 처리


# ─────────────────────────────────────────────
# 집계 생성(월/주/일)
# ─────────────────────────────────────────────

def _weight_col(df: pd.DataFrame) -> str:
    """중량 컬럼 이름 자동 판별."""
    if "고유_중량" in df.columns:
        return "고유_중량"
    if "중량_고유" in df.columns:
        return "중량_고유"
    raise KeyError("중량 컬럼 누락 ('고유_중량' 또는 '중량_고유').")


def build_aggregates(df_year: pd.DataFrame, year: int):
    """
    연도별 DataFrame(df_year)에 대해
    협력사별 월/주/일 단위 계획/실적 집계를 생성한다.
    """
    wcol = _weight_col(df_year)
    df = df_year.copy()
    df["협력사"] = df["협력사"].astype(str).str.strip()

    if "기준계획_완료" not in df.columns:
        raise KeyError("기준계획_완료 누락")
    if "실적_완료" not in df.columns:
        raise KeyError("실적_완료 누락")

    df["계획일"] = pd.to_datetime(df["기준계획_완료"].apply(_to_date), errors="coerce")
    df["실적일"] = pd.to_datetime(df["실적_완료"].apply(_to_date), errors="coerce")

    # 계획/실적 중 해당 연도에 속하는 것만 사용
    df_plan = df[df["계획일"].dt.year.eq(year)].copy()
    df_act = df[df["실적일"].dt.year.eq(year)].copy()

    # 월/주/일자 생성
    df_plan["월"] = df_plan["계획일"].dt.month
    df_plan["주"] = df_plan["계획일"].apply(lambda d: week_no_mon(d, year))
    df_plan["일자"] = df_plan["계획일"]

    df_act["월"] = df_act["실적일"].dt.month
    df_act["주"] = df_act["실적일"].apply(lambda d: week_no_mon(d, year))
    df_act["일자"] = df_act["실적일"]

    # 집계
    plan_month = (
        df_plan.groupby(["협력사", "월"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "계획"})
    )
    act_month = (
        df_act.groupby(["협력사", "월"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "실적"})
    )
    plan_week = (
        df_plan.dropna(subset=["주"])
        .groupby(["협력사", "주"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "계획"})
    )
    act_week = (
        df_act.dropna(subset=["주"])
        .groupby(["협력사", "주"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "실적"})
    )
    plan_day = (
        df_plan.groupby(["협력사", "일자"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "계획"})
    )
    act_day = (
        df_act.groupby(["협력사", "일자"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "실적"})
    )

    return {
        "plan_month": plan_month,
        "act_month": act_month,
        "plan_week": plan_week,
        "act_week": act_week,
        "plan_day": plan_day,
        "act_day": act_day,
    }


# ─────────────────────────────────────────────
# 하이브리드 축(meta) 생성
# ─────────────────────────────────────────────

def build_hybrid_axis(year: int, query_date: dt.date) -> List[Tuple[str, dict]]:
    """
    월/주/일을 섞은 축 meta 생성.

    예: 11월 18일 기준
        [ "1월", "2월", ..., "10월",
          "45주", "46주",  # 조회월 내 과거 주
          "11/17", "11/18", "11/19", ...  # 조회주 일자
          "47주", "48주",  # 조회주 이후 주
          "12월" ]
    """
    qm = query_date.month
    qw = week_no_mon(query_date, year)
    labels: List[Tuple[str, dict]] = []

    # 조회월 이전 월
    for m in range(1, qm):
        labels.append((f"{m}월", {"type": "month", "month": m}))

    # 조회월 내 주 리스트
    wlist = weeks_in_month(year, qm)
    if qw not in wlist:
        wlist = sorted(set(wlist + ([qw] if qw else [])))

    # 조회주 이전 주
    for w in [x for x in wlist if x < qw]:
        labels.append((f"{w}주", {"type": "week", "week": w}))

    # 조회주 일자
    for d in dates_of_week(year, qw):
        if d.year == year and d.month == qm:
            labels.append((f"{d.month}/{d.day}", {"type": "day", "date": d}))

    # 조회주 이후 주
    for w in [x for x in wlist if x > qw]:
        labels.append((f"{w}주", {"type": "week", "week": w}))

    # 조회월 이후 월
    for m in range(qm + 1, 13):
        labels.append((f"{m}월", {"type": "month", "month": m}))

    return labels


# ─────────────────────────────────────────────
# 하이브리드 축의 "미래/예측구간" 라벨 계산
# ─────────────────────────────────────────────

def _week_span(year: int, week_no: int) -> Tuple[dt.date, dt.date]:
    """(월요일 시작) 주차의 시작/끝 날짜."""
    start = _first_monday(year) + dt.timedelta(days=(week_no - 1) * 7)
    end = start + dt.timedelta(days=6)
    return start, end


def build_future_label_set(
    axis_meta: List[Tuple[str, dict]], year: int, query_date: dt.date
) -> set:
    """
    하이브리드 축 meta를 이용해
    '조회일 포함 이후'에 해당하는 라벨 집합을 만든다.

    - month : 그 달의 말일이 조회일 이상
    - week  : 그 주의 마지막 날짜가 조회일 이상
    - day   : 해당 일자가 조회일 이상
    """
    future = set()
    for label, meta in axis_meta:
        if meta["type"] == "month":
            m = meta["month"]
            first = dt.date(year, m, 1)
            last = (first.replace(day=28) + dt.timedelta(days=4)).replace(day=1) - dt.timedelta(days=1)
            compare_date = last
        elif meta["type"] == "week":
            _, end = _week_span(year, meta["week"])
            compare_date = end
        else:  # day
            compare_date = meta["date"]
        if compare_date >= query_date:
            future.add(label)
    return future


# ─────────────────────────────────────────────
# 일자 딕셔너리(중복감산/일 단위용)
# ─────────────────────────────────────────────

def _daily_dicts_for_vendor(agg: dict, vendor: str):
    """
    특정 협력사의 일자별 계획/실적 딕셔너리 생성.
    - {일자(date): 중량(float)} 형태
    """
    pdict, adict = {}, {}
    if not agg["plan_day"].empty:
        sub = agg["plan_day"].loc[agg["plan_day"]["협력사"] == vendor]
        pdict = {
            pd.to_datetime(r["일자"]).date(): float(r["계획"])
            for _, r in sub.iterrows()
        }
    if not agg["act_day"].empty:
        sub = agg["act_day"].loc[agg["act_day"]["협력사"] == vendor]
        adict = {
            pd.to_datetime(r["일자"]).date(): float(r["실적"])
            for _, r in sub.iterrows()
        }
    return pdict, adict


# ─────────────────────────────────────────────
# 시리즈/행렬(벤더/전체) + 예측 포함
# ─────────────────────────────────────────────

def series_for_vendor_with_pred(
    vendor: str,
    cap_df: pd.DataFrame,
    agg: dict,
    axis_meta: List[Tuple[str, dict]],
    year: int,
    query_date: dt.date,
    pred_daily: Optional[pd.DataFrame],
):
    """
    한 협력사에 대해
    [능력, 계획, 실적, 누계차, 지연일수] 를 축(axis_meta)에 맞춰 계산한다.

    - 실적행:
        · 조회일 이전: 실제 실적
        · 조회일 포함 이후: 예측중량(pred_daily) 합계
    - 누계차행:
        · 위 실적/예측 - 계획 의 누적합
    - 지연일수행:
        · 누계차 / 능력 (능력은 분모용 cap_calc 사용)
    """
    # 월/주 단위 집계 시리즈
    pm = (
        agg["plan_month"]
        .loc[agg["plan_month"]["협력사"] == vendor]
        .set_index("월")["계획"]
        if not agg["plan_month"].empty
        else pd.Series(dtype=float)
    )
    am = (
        agg["act_month"]
        .loc[agg["act_month"]["협력사"] == vendor]
        .set_index("월")["실적"]
        if not agg["act_month"].empty
        else pd.Series(dtype=float)
    )
    pw = (
        agg["plan_week"]
        .loc[agg["plan_week"]["협력사"] == vendor]
        .set_index("주")["계획"]
        if not agg["plan_week"].empty
        else pd.Series(dtype=float)
    )
    aw = (
        agg["act_week"]
        .loc[agg["act_week"]["협력사"] == vendor]
        .set_index("주")["실적"]
        if not agg["act_week"].empty
        else pd.Series(dtype=float)
    )

    pdict, adict = _daily_dicts_for_vendor(agg, vendor)

    cap_calc_list, cap_out_list = [], []
    plan_list, act_list = [], []
    compare_dates: List[dt.date] = []
    overlap_delta_by_idx: Dict[int, float] = {}

    # 1차 루프: 각 축(label)에 대해 계획/실적/능력/비교일 계산
    for idx, (_, meta) in enumerate(axis_meta):
        if meta["type"] == "month":
            m = meta["month"]

            # 능력: 월간 TPD
            cap_val = tpd_month(cap_df, vendor, m)
            cap_calc_list.append(np.nan if pd.isna(cap_val) else float(cap_val))

            # 이 달의 말일 (비교 기준)
            last_day = (dt.date(year, m, 1).replace(day=28) + dt.timedelta(days=4))
            last_day = last_day.replace(day=1) - dt.timedelta(days=1)
            compare_dates.append(last_day)

            # 엑셀 표 출력용 능력 값 (조회일 이전만 바로 채우고, 이후는 나중에 ffill)
            cap_out_list.append(
                None if last_day >= query_date else (None if pd.isna(cap_val) else float(cap_val))
            )

            # 계획/실적 집계
            plan_list.append(float(pm.get(m, 0.0)))
            act_list.append(float(am.get(m, 0.0)))

        elif meta["type"] == "week":
            w = meta["week"]

            # 능력: 주간 TPD
            cap_val = tpd_week(cap_df, vendor, year, w)
            cap_calc_list.append(np.nan if pd.isna(cap_val) else float(cap_val))

            # 이 주의 마지막 날짜 (비교 기준)
            _, end = week_span(year, w)
            compare_dates.append(end)
            cap_out_list.append(
                None if end >= query_date else (None if pd.isna(cap_val) else float(cap_val))
            )

            # 계획/실적 집계
            plan_list.append(float(pw.get(w, 0.0)))
            act_list.append(float(aw.get(w, 0.0)))

            # 월/주 중복 구간(예: 주가 월을 걸쳐 있는 경우) 보정용
            s, e = week_span(year, w)
            if s.month != e.month:
                prev_month_days = [
                    d for d in dates_of_week(year, w)
                    if d.month == s.month and d.year == year
                ]
                plan_overlap = sum(pdict.get(d, 0.0) for d in prev_month_days)
                act_overlap = sum(adict.get(d, 0.0) for d in prev_month_days)
                overlap_delta_by_idx[idx] = act_overlap - plan_overlap

        else:  # day
            d = meta["date"]

            # 능력: 일간 TPD
            cap_val = tpd_day(cap_df, vendor, d)
            cap_calc_list.append(np.nan if pd.isna(cap_val) else float(cap_val))
            compare_dates.append(d)
            cap_out_list.append(
                None if d >= query_date else (None if pd.isna(cap_val) else float(cap_val))
            )

            # 계획/실적 집계(일 단위)
            plan_list.append(float(pdict.get(d, 0.0)))
            act_list.append(float(adict.get(d, 0.0)))

    cap_calc = np.array(cap_calc_list, dtype=float)  # 지연일 분모용
    plan_arr = np.array(plan_list, dtype=float)
    act_arr = np.array(act_list, dtype=float)

    # 축별 예측중량(월/주/일) 합계 계산
    pred_list: List[Optional[float]] = []
    for _, meta in axis_meta:
        if pred_daily is None or pred_daily.empty:
            pred_list.append(None)
            continue

        if meta["type"] == "month":
            m = meta["month"]
            sel = pred_daily[
                (pred_daily["협력사"] == vendor)
                & (pred_daily["예측일"].dt.month == m)
            ]
        elif meta["type"] == "week":
            w = meta["week"]
            sel = pred_daily[
                (pred_daily["협력사"] == vendor)
                & (pred_daily["예측일"].dt.isocalendar().week.astype(int) == w)
            ]
        else:  # day
            d = meta["date"]
            sel = pred_daily[
                (pred_daily["협력사"] == vendor)
                & (pred_daily["예측일"].dt.date == d)
            ]

        pred_list.append(float(sel["예측중량"].sum()) if not sel.empty else None)

    pred_arr = np.array(
        [
            np.nan if (v is None or (isinstance(v, float) and np.isnan(v))) else float(v)
            for v in pred_list
        ],
        dtype=float,
    )

    # 조회일 기준 미래 구간 마스크
    compare_dates_arr = np.array(compare_dates, dtype=object)
    mask_future = np.array([cd >= query_date for cd in compare_dates_arr], dtype=bool)

    # 능력행: 조회일 이전은 원래 값, 이후는 직전 유효값으로 ffill
    cap_out = np.empty_like(compare_dates_arr, dtype=object)
    last_cap: Optional[float] = None
    for i, cd in enumerate(compare_dates_arr):
        raw = cap_calc[i]
        val = None if np.isnan(raw) else float(raw)
        if cd < query_date:
            cap_out[i] = val
            if val is not None:
                last_cap = val
        else:
            cap_out[i] = last_cap

    # 실적행용 numeric 값: 조회일 이전 → 실적, 이후 → 예측중량
    actual_numeric = np.zeros_like(plan_arr, dtype=float)
    for i, cd in enumerate(compare_dates_arr):
        if cd < query_date:
            actual_numeric[i] = act_arr[i]
        else:
            pv = pred_arr[i] if i < len(pred_arr) else np.nan
            actual_numeric[i] = 0.0 if np.isnan(pv) else pv

    # 누계차: (실적/예측 - 계획) 누적 + 월/주/일 중복보정
    diff = np.nan_to_num(actual_numeric) - np.nan_to_num(plan_arr)
    cumsum = np.cumsum(diff)
    for i, delta in overlap_delta_by_idx.items():
        if delta:
            cumsum[i:] -= delta

    act_out = actual_numeric.astype(object)
    cumsum_out = cumsum.astype(object)

    # 지연일수: 누계차 / 능력 (분모는 cap_calc 그대로 사용)
    delay_out = np.empty_like(cumsum, dtype=object)
    for i in range(len(delay_out)):
        denom = cap_calc[i]
        if (
            isinstance(denom, (int, float, np.floating))
            and not np.isnan(denom)
            and denom != 0
        ):
            delay_out[i] = cumsum[i] / denom
        else:
            delay_out[i] = None

    # 예측행은 제거: (능력, 계획, 실적, 누계차, 지연일수만 반환)
    return cap_out, plan_arr, act_out, cumsum_out, delay_out


def matrix_vendor_with_pred(
    vendor: str,
    cap_df: pd.DataFrame,
    agg: dict,
    axis_meta: List[Tuple[str, dict]],
    year: int,
    query_date: dt.date,
    pred_daily: Optional[pd.DataFrame],
) -> pd.DataFrame:
    """
    한 협력사의 [능력/계획/실적/누계차/지연일수] 행렬 생성.
    """
    cap, plan, act, csum, delay = series_for_vendor_with_pred(
        vendor, cap_df, agg, axis_meta, year, query_date, pred_daily
    )
    cols = [lbl for (lbl, _) in axis_meta]
    return pd.DataFrame(
        [cap, plan, act, csum, delay],
        index=ROW_LABELS,
        columns=cols,
    )


def matrix_total_with_pred(
    vendors: List[str],
    cap_df: pd.DataFrame,
    agg: dict,
    axis_meta: List[Tuple[str, dict]],
    year: int,
    query_date: dt.date,
    pred_daily: Optional[pd.DataFrame],
) -> pd.DataFrame:
    """
    여러 협력사를 합산한 [능력/계획/실적/누계차/지연일수] 행렬 생성.
    """
    mats = [
        matrix_vendor_with_pred(v, cap_df, agg, axis_meta, year, query_date, pred_daily)
        for v in vendors
    ]
    cols = [lbl for (lbl, _) in axis_meta]
    if not mats:
        return pd.DataFrame(0, index=ROW_LABELS, columns=cols, dtype=object)

    # 능력 합산
    cap_arrays_num = [
        [
            0.0 if (val is None or (isinstance(val, float) and np.isnan(val))) else float(val)
            for val in m.loc["능력"].values
        ]
        for m in mats
    ]
    cap_sum_numeric = np.nansum(cap_arrays_num, axis=0)

    # 계획/실적/누계차 합산
    plan = np.nansum([m.loc["계획"].values.astype(float) for m in mats], axis=0)

    act_arrays = [
        [0.0 if v is None else float(v) for v in m.loc["실적"].values]
        for m in mats
    ]
    csum_arrays = [
        [0.0 if v is None else float(v) for v in m.loc["누계차"].values]
        for m in mats
    ]
    act_sum = np.nansum(act_arrays, axis=0)
    csum_sum = np.nansum(csum_arrays, axis=0)

    # 전체 기준 지연일수: 누계차 / 능력
    delay_arr = np.empty_like(act_sum, dtype=object)
    for i in range(len(delay_arr)):
        denom = cap_sum_numeric[i]
        if (
            isinstance(denom, (int, float, np.floating))
            and not np.isnan(denom)
            and denom != 0
        ):
            delay_arr[i] = csum_sum[i] / denom
        else:
            delay_arr[i] = None

    cap_out = cap_sum_numeric.astype(object)
    plan_out = plan.astype(object)
    act_out = act_sum.astype(object)
    csum_out = csum_sum.astype(object)

    return pd.DataFrame(
        [cap_out, plan_out, act_out, csum_out, delay_arr],
        index=ROW_LABELS,
        columns=cols,
    )


# ─────────────────────────────────────────────
# 엑셀 작성(스타일 포함) — 조회일 이후 회색/음수 red
# ─────────────────────────────────────────────

thin = Side(style="thin", color="000000")
BORDER_THIN = Border(left=thin, right=thin, top=thin, bottom=thin)


def _write_section_optimal(
    ws,
    title: str,
    mat: pd.DataFrame,
    start_row: int,
    future_labels: set,
) -> int:
    """
    하나의 섹션(협력사 or 그룹 or 전체)을 엑셀에 쓰는 함수.

    - 타이틀: title (예: "기민_2.5톤/일_Ridge")
    - 행: ROW_LABELS (능력/계획/실적/누계차/지연일수)
    - 열: axis_meta 기준 하이브리드 라벨

    색상 규칙
    --------
    - 조회일 포함 이후(future_labels)의
      '능력' / '실적' / '누계차' / '지연일수' 셀:
        · 기본 글자색: 짙은 회색(#666666)
        · 음수값이면 항상 빨간색(FF0000) 우선
    """
    r = start_row
    c = 1

    # 제목
    tcell = ws.cell(row=r, column=c, value=title)
    tcell.font = Font(bold=True, size=11)
    tcell.alignment = Alignment(horizontal="left", vertical="center")
    r += 1

    cols = mat.columns.tolist()

    # 헤더 행
    hcell = ws.cell(row=r, column=c, value="구분 (단위: ton)")
    hcell.font = Font(bold=True)
    hcell.alignment = Alignment(horizontal="center", vertical="center")
    hcell.border = BORDER_THIN

    for j, colname in enumerate(cols, start=c + 1):
        ch = ws.cell(row=r, column=j, value=colname)
        ch.alignment = Alignment(horizontal="center", vertical="center")
        ch.font = Font(bold=True)
        ch.border = BORDER_THIN
    r += 1

    # 데이터 행
    for i, rowname in enumerate(mat.index, start=r):
        ccell = ws.cell(row=i, column=c, value=rowname)
        ccell.border = BORDER_THIN
        ccell.font = Font(bold=(rowname == "지연일수"))

        for j, colname in enumerate(cols, start=c + 1):
            val = mat.loc[rowname, colname]
            cell = ws.cell(row=i, column=j, value=val)
            cell.border = BORDER_THIN
            cell.alignment = Alignment(horizontal="right", vertical="center")

            # 숫자 포맷
            if rowname == "지연일수" and isinstance(val, (int, float)):
                cell.value = round(float(val), 1)
                cell.number_format = "0.0"
            elif isinstance(val, (int, float)):
                cell.number_format = "#,##0"

            # 색상 로직
            color = None

            # 1) 조회일 이후 구간의 능력/실적/누계차/지연일수 → 기본 회색
            if (
                rowname in ("능력", "실적", "누계차", "지연일수")
                and colname in future_labels
                and val is not None
            ):
                color = "0B07FF"  # blue

            # 2) 값이 음수이면 항상 red 우선
            if isinstance(val, (int, float)) and val < 0:
                color = "FF0000"

            if color:
                cell.font = Font(
                    bold=(rowname == "지연일수"),
                    color=color,
                )

    last_data_row = r + len(mat.index) - 1
    return last_data_row + 2


# ─────────────────────────────────────────────
# 누계차/지연일수 + 능력(미래구간) 재계산
# ─────────────────────────────────────────────

def adjust_cumsum_and_delay_with_prediction(
    mat: pd.DataFrame,
    future_labels: set,
) -> pd.DataFrame:
    """
    matrix_vendor_with_pred / matrix_total_with_pred 가 만들어 준 mat을 기반으로,

    - 행 구성: ["능력", "계획", "실적", "누계차", "지연일수"]
      · '실적' 행은 이미 과거구간=실적, 미래구간=예측중량이 반영된 상태
      · '누계차' 행도 위 실적/예측 기준 누계값이 계산된 상태

    여기서는:
      1) '능력' 행에서 조회일 포함 이후(future_labels)의 값들을
         조회일 직전 마지막 유효 능력값으로 채워 넣고(ffill)
      2) 이 (조정된) 능력값을 분모로 사용해 '지연일수'를 다시 계산한다.

    ※ 누계차 값 자체는 series_for_vendor_with_pred 에서 이미
       예측을 반영해 계산했으므로, 여기서 다시 수정하지 않는다.
    """
    # 필수 행 체크
    if "누계차" not in mat.index or "계획" not in mat.index or "실적" not in mat.index:
        return mat

    cols = list(mat.columns)

    # 미래 구간 플래그
    is_future = [col in future_labels for col in cols]

    # ---- 능력값 로드 ----
    cap_vals = []
    if "능력" in mat.index:
        for col in cols:
            v = mat.at["능력", col]
            if v is None or (isinstance(v, float) and pd.isna(v)):
                cap_vals.append(None)
            else:
                cap_vals.append(float(v))
    else:
        cap_vals = [None] * len(cols)

    # ---- 미래 구간 인덱스 ----
    future_indices = [idx for idx, f in enumerate(is_future) if f]

    # 1) 미래 구간 능력: 조회일 "전날" 마지막 유효 능력값으로 ffill
    if future_indices:
        past_indices = [
            i for i in range(len(cols))
            if not is_future[i] and cap_vals[i] is not None
        ]
        if past_indices:
            last_past_idx = max(past_indices)
            base_cap = float(cap_vals[last_past_idx])
            for j in future_indices:
                cap_vals[j] = base_cap

    # 2) 누계차는 그대로 사용 (이미 예측 반영된 값)
    orig_csum_vals = []
    for col in cols:
        v = mat.at["누계차", col]
        if v is None or (isinstance(v, float) and pd.isna(v)):
            orig_csum_vals.append(0.0)
        else:
            orig_csum_vals.append(float(v))
    new_csum = orig_csum_vals  # 그대로 유지

    # 3) 지연일수 재계산: 누계차 / 능력 (과거+미래 전체)
    new_delay = []
    for j in range(len(cols)):
        csum_val = new_csum[j]
        cap_val = cap_vals[j]
        if cap_val is None or isinstance(cap_val, str):
            new_delay.append(None)
        else:
            try:
                if pd.isna(cap_val) or cap_val == 0:
                    new_delay.append(None)
                else:
                    new_delay.append(csum_val / float(cap_val))
            except Exception:
                new_delay.append(None)

    # 4) 결과 반영
    mat2 = mat.copy()
    mat2.loc["누계차"] = new_csum
    if "지연일수" in mat2.index:
        mat2.loc["지연일수"] = new_delay
    if "능력" in mat2.index:
        mat2.loc["능력"] = cap_vals

    return mat2


# ─────────────────────────────────────────────
# 엑셀 저장 — (최적) 규칙 + 예측 반영 누계차/지연일수/능력
# ─────────────────────────────────────────────

def save_excel_optimal(
    year: int,
    query_date: dt.date,
    cap_df: pd.DataFrame,
    agg: dict,
    axis_meta: List[Tuple[str, dict]],
    pred_daily: Optional[pd.DataFrame],
    vendors_all: List[str],
    vendor_engine: Dict[str, str],
) -> Path:
    """
    - 섹션 타이틀: "{이름}_{TPD:.1f}톤/일_{선정모델명}"
      * 개별 협력사: 선정모델명 = ENGINE_TITLE[엔진키]
      * 전체/그룹: 선정모델명 = "최적"
    - 엑셀 파일명:
        {year}년도_사외_조립_계획실적_예측_현황(ML_최적)_{yyMMdd}.xlsx

    - 추가 로직:
      · 조회일 포함 이후 구간의 누계차/지연일수에 예측(예측-계획) 반영
      · 능력은 조회일 전날 값을 미래 구간에 ffill 후
        지연일수 계산에 사용
      · 해당 셀(능력/실적/누계차/지연일수)은 짙은 회색, 음수는 빨간색
    """
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = f"{year} 현황_최적"

    # 조회일이 속한 주의 TPD 사용 (타이틀용)
    qw = week_no_mon(query_date, year) or 1
    vendor_title_tpd: Dict[str, float] = {
        v: (
            0.0
            if pd.isna(tpd_week(cap_df, v, year, qw))
            else float(tpd_week(cap_df, v, year, qw))
        )
        for v in vendors_all
    }

    def title_tpd(name: str) -> float:
        """타이틀에 들어갈 TPD(톤/일) 값 계산."""
        if name in vendor_title_tpd:
            return vendor_title_tpd[name]
        members = resolve_group_members(name, vendors_all)
        if not members:
            return 0.0
        return float(sum(vendor_title_tpd.get(v, 0.0) for v in members))

    def title_model(name: str) -> str:
        """타이틀에 들어갈 선정모델명."""
        if name in vendor_engine:
            eng = vendor_engine.get(name, "ridge")
            return ENGINE_TITLE.get(eng, eng)
        # 전체/그룹 등은 '최적'으로 표기
        return "최적"

    # 조회일 포함 이후에 해당하는 라벨 집합
    future_labels = build_future_label_set(axis_meta, year, query_date)

    row = 1

    for name in PRINT_ORDER:
        # 1) 전체/그룹 행렬 생성
        if name == "전체":
            members = resolve_group_members("전체", vendors_all)
            if members:
                mat_raw = matrix_total_with_pred(
                    members, cap_df, agg, axis_meta, year, query_date, pred_daily
                )
            else:
                cols = [lbl for (lbl, _) in axis_meta]
                mat_raw = pd.DataFrame(0, index=ROW_LABELS, columns=cols, dtype=object)
        elif name in GROUP_DEFS:
            members = resolve_group_members(name, vendors_all)
            if members:
                mat_raw = matrix_total_with_pred(
                    members, cap_df, agg, axis_meta, year, query_date, pred_daily
                )
            else:
                cols = [lbl for (lbl, _) in axis_meta]
                mat_raw = pd.DataFrame(0, index=ROW_LABELS, columns=cols, dtype=object)
        # 2) 개별 협력사 행렬 생성
        else:
            if name in vendors_all:
                mat_raw = matrix_vendor_with_pred(
                    name, cap_df, agg, axis_meta, year, query_date, pred_daily
                )
            else:
                cols = [lbl for (lbl, _) in axis_meta]
                mat_raw = pd.DataFrame(0, index=ROW_LABELS, columns=cols, dtype=object)

        # 조회일 이후 구간에 예측 + 능력 반영하여 누계차/지연일수 재계산
        mat = adjust_cumsum_and_delay_with_prediction(mat_raw, future_labels)

        # 타이틀 문자열
        tpd_val = title_tpd(name)
        model_name = title_model(name)
        # 예) "기민_2.5톤/일_Ridge", "전체_1335.0톤/일_최적"
        title_str = f"{name}_{tpd_val:,.1f}톤/일_{model_name}"

        # 섹션 쓰기 (색상/서식 포함)
        row = _write_section_optimal(ws, title_str, mat, row, future_labels)

    # 열 너비 정리
    for col in range(1, ws.max_column + 1):
        ws.column_dimensions[get_column_letter(col)].width = 12

    date_folder = query_date.strftime("%Y-%m-%d")
    target_dir = Path(__file__).resolve().parent / "save_folder" / date_folder
    target_dir.mkdir(parents=True, exist_ok=True)
    date_suffix = query_date.strftime("%y%m%d")  # 예: 2025-11-18 -> "251118"
    file_name = f"{year}년도_사외_조립_계획실적_예측_현황(ML_최적)_{date_suffix}.xlsx"
    out_path = target_dir / file_name
    
    try:
        Path(out_path).unlink(missing_ok=True)
    except Exception as e:
        print(f"[LOG] 기존 엑셀 삭제 실패: {e}")
    wb.save(out_path)
    print(f"[SAVE] Excel saved → {out_path}")
    return out_path


# ─────────────────────────────────────────────
# 로그 CSV — '최적' 요약용 
# ─────────────────────────────────────────────

def write_csv_log_optimal(year: int, query_date: dt.date, rows: List[dict]):
    """
    - 파일명: {year}_model_selection_log_ML_최적_{yyMMdd}.csv
    - 내용/정렬: 단일 모델 step들(write_csv_log)과 동일한 스타일
    - 저장 후 DB 테이블 '예측_모델_log' 에 append 업로드
    """
    if not rows:
        print("[LOG] 기록할 행이 없습니다. (빈 로그)")
        return

    logs_dir = OUT_DIR / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    date_suffix = query_date.strftime("%y%m%d")
    csv_path = logs_dir / f"{year}_model_selection_log_ML_최적_{date_suffix}.csv"

    try:
        csv_path.unlink(missing_ok=True)
    except Exception as e:
        print(f"[LOG] 기존 최적 로그 삭제 실패: {e}")

    df = pd.DataFrame(rows)

    def _ensure_dict(v):
        """params_json 컬럼을 dict 형태로 정리."""
        if isinstance(v, dict):
            return v
        if isinstance(v, (str, bytes)):
            try:
                return json.loads(v)
            except Exception:
                return {"_raw": str(v)}
        return {"_raw": None}

    # params_json 펼치기
    if "params_json" in df.columns:
        params_df = pd.json_normalize(df["params_json"].apply(_ensure_dict)).add_prefix(
            "param_"
        )
        df = pd.concat([df.drop(columns=["params_json"]), params_df], axis=1)

    priority_cols = [
        "timestamp",
        "year",
        "협력사",
        "tag",
        "engine",
        "R2_train",
        "R2_valid",
        "MAE_valid",
        "RMSE_valid",
        "split_ratio",
        "train_range",
        "valid_range",
    ]
    param_cols = sorted([c for c in df.columns if c.startswith("param_")])
    other_cols = [c for c in df.columns if c not in priority_cols + param_cols]
    ordered_cols = [c for c in priority_cols if c in df.columns] + param_cols + other_cols
    df = df[ordered_cols]

    # 1) CSV 저장
    df.to_csv(csv_path, mode="w", header=True, index=False, encoding="utf-8-sig")
    print(
        f"[LOG] 최적 모델선정 CSV 저장: {csv_path} "
        f"(rows={len(df)}, cols={len(df.columns)})"
    )

    # 2) DB 테이블 '예측_모델_log' 에 append 업로드
    #from step_48_utils_logs_upload_ML import upload_log_df_to_db
    #upload_log_df_to_db(df, DB_URL, table="예측_모델_log")


# ─────────────────────────────────────────────
# MAIN 로직
# ─────────────────────────────────────────────

def main(year: int, query_date: Optional[str] = None):
    """
    - year, query_date 기준으로 데이터를 불러오고
    - Best 모델 매핑(JSON)을 읽어서
    - 엔진별로 학습/예측 수행 후
    - 엑셀 + 로그 CSV(+DB)를 생성한다.
    """
    # 조회일 처리
    qdate = TODAY if query_date is None else pd.to_datetime(query_date).date()

    # 전/당해년 개별 로드 시도
    df_prev_raw = outside_df2(year - 1)
    df_curr_raw = outside_df2(year)
    df_all = pd.concat([df_prev_raw, df_curr_raw], ignore_index=True)

    df_all = df_all.copy()
    df_all["협력사"] = df_all["협력사"].astype(str).str.strip()

    plan_dt = pd.to_datetime(df_all["기준계획_완료"].apply(_to_date), errors="coerce")
    act_dt = pd.to_datetime(df_all["실적_완료"].apply(_to_date), errors="coerce")

    prev_year = year - 1
    df_prev = df_all[
        (plan_dt.dt.year.eq(prev_year)) | (act_dt.dt.year.eq(prev_year))
    ].copy()
    df_curr = df_all[
        (plan_dt.dt.year.eq(year)) | (act_dt.dt.year.eq(year))
    ].copy()

    vendors_all = (
        sorted(
            df_curr["협력사"].dropna().astype(str).str.strip().unique().tolist()
        )
        if not df_curr.empty
        else []
    )
    vendors_ordered = [v for v in BASE_VENDORS if v in vendors_all] + [
        v for v in vendors_all if v not in BASE_VENDORS
    ]

    if not vendors_ordered:
        print("[WARN] 당해년 데이터가 없어 예측/엑셀 생성이 불가합니다.")
        return

    # 집계/축/TPD 등 공통 부분
    cap_df = load_capacity(year)
    agg = build_aggregates(df_curr, year)
    axis_meta = build_hybrid_axis(year, qdate)

    # 협력사별 best(최적) 모델 매핑 로드
    best_map_raw = load_best_model_map(year)

    # 협력사 → 엔진키(ridge/knn/...)
    vendor_engine: Dict[str, str] = {}
    for v in vendors_ordered:
        eng = best_map_raw.get(v, "ridge")  # 매핑 없으면 Ridge
        vendor_engine[v] = normalize_engine_name(eng)

    # 엔진별 협력사 리스트로 그룹핑
    engine_to_vendors: Dict[str, List[str]] = {}
    for v, eng in vendor_engine.items():
        engine_to_vendors.setdefault(eng, []).append(v)

    # 모델별 train/predict 함수 매핑
    TRAIN_FUNCS = {
        "ridge": train_ridge_per_vendor,
        "knn": train_knn_per_vendor,
        "ar": train_ar_per_vendor,
        "ma": train_ma_per_vendor,
        "arima": train_arima_per_vendor,
        "lightgbm": train_lgbm_per_vendor,
        "xgboost": train_xgb_per_vendor,
        "catboost": train_catboost_per_vendor,
        "linear": train_linear_per_vendor,
    }

    PRED_FUNCS = {
        "ridge": predict_ridge_future,
        "knn": predict_knn_future,
        "ar": predict_ar_future,
        "ma": predict_ma_future,
        "arima": predict_arima_future,
        "lightgbm": predict_lgbm_future,
        "xgboost": predict_xgb_future,
        "catboost": predict_catboost_future,
        "linear": predict_linear_future,
    }

    # 예측 기간: 연초~연말 전구간
    start_date = dt.date(year, 1, 1)
    end_date = dt.date(year, 12, 31)

    # 각 엔진별로 학습/예측 수행 후 pred_daily 를 결합
    pred_list: List[pd.DataFrame] = []
    rows_for_csv_all: List[dict] = []

    for eng, vlist in engine_to_vendors.items():
        if not vlist:
            continue
        train_fn = TRAIN_FUNCS.get(eng)
        pred_fn = PRED_FUNCS.get(eng)
        if train_fn is None or pred_fn is None:
            print(f"[WARN] 지원하지 않는 엔진 '{eng}' 입니다. 협력사 {vlist} 는 스킵합니다.")
            continue

        print(f"[INFO] Engine={eng}, vendors={len(vlist)} → {vlist}")

        # 각 엔진 모듈의 train_xxx_per_vendor 호출
        predictors, rows_for_csv = train_fn(df_prev, df_curr, vlist)
        rows_for_csv_all.extend(rows_for_csv)

        # 각 엔진 모듈의 predict_future_by_date_per_vendor 호출
        pred_df = pred_fn(df_curr, predictors, start_date, end_date)
        if pred_df is not None and not pred_df.empty:
            pred_df = pred_df.copy()
            if "engine" not in pred_df.columns:
                pred_df["engine"] = eng
            pred_list.append(pred_df)

    if pred_list:
        pred_daily = pd.concat(pred_list, ignore_index=True)
    else:
        print("[WARN] 예측 결과가 비어 있습니다. (pred_daily 없음)")
        pred_daily = None

    # 엑셀 저장 — (최적) 규칙 / 타이틀 규칙 + 예측 반영 누계차/지연일수/능력 적용
    out_xlsx = save_excel_optimal(
        year, qdate, cap_df, agg, axis_meta, pred_daily, vendors_all, vendor_engine
    )

    # step_2(outside_df2) 조회년도 원본 기준으로
    # 실적_완료 빈칸에 ML 예측일 반영
    base_df = outside_df2(year)
    df_ml = apply_ml_predicted_dates_to_actual(base_df, pred_daily)

    # MySQL 업로드 (사외_조립_계획_실적_예측_ml)
    # - table 없으면 자동 생성
    # - 있으면 replace 업로드
    upload_bpa_predict_ml(df_ml)

    print(f"[DONE] step_51_utils_best_predict_ML(최적) 완료. Excel: {out_xlsx}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--year", type=int, default=DEFAULT_YEAR, help="조회 연도 (기본: 올해)")
    parser.add_argument(
        "--query_date",
        type=str,
        default=None,
        help="조회일 (YYYY-MM-DD, 기본: 오늘)",
    )
    args = parser.parse_args()
    main(args.year, args.query_date)
