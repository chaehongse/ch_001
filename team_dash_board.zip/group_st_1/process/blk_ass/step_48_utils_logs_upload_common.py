from __future__ import annotations

"""
step_48_utils_logs_upload_common.py

ML/DL 로그 업로드 공통 유틸.
"""

from typing import List, Tuple

import pandas as pd
from sqlalchemy import create_engine, text


def _build_create_sql(table: str, columns: List[Tuple[str, str]]) -> str:
    cols_sql = ",\n        ".join([f"`{name}` {ctype} NULL" for name, ctype in columns])
    return f"""
    CREATE TABLE IF NOT EXISTS `{table}` (
        {cols_sql}
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """


def ensure_table_exists(db_url: str, table: str, columns: List[Tuple[str, str]]) -> None:
    engine = create_engine(db_url, pool_pre_ping=True, future=True)
    create_sql = _build_create_sql(table, columns)
    try:
        with engine.begin() as conn:
            conn.execute(text(create_sql))
        print(f"[DB] '{table}' 테이블 존재 확인 완료 (없으면 자동 생성)")
    except Exception as e:
        print(f"[DB-WARN] 테이블 생성 실패: {e}")


def upload_log_df_to_db(
    df: pd.DataFrame,
    db_url: str,
    table: str,
    columns: List[Tuple[str, str]],
) -> None:
    if df.empty:
        print("[DB] 업로드할 로그가 없습니다. (빈 DataFrame)")
        return

    ensure_table_exists(db_url, table, columns)

    try:
        engine = create_engine(db_url, pool_pre_ping=True, future=True)
        with engine.begin() as conn:
            result = conn.execute(text(f"SELECT * FROM `{table}` LIMIT 0"))
            db_cols = list(result.keys())

        df_for_db = df.copy()
        if "timestamp" in df_for_db.columns:
            df_for_db["timestamp"] = pd.to_datetime(df_for_db["timestamp"], errors="coerce")

        use_cols = [c for c in df_for_db.columns if c in db_cols]
        if not use_cols:
            print(f"[DB-WARN] '{table}' 테이블과 공통 컬럼이 없어 업로드를 건너뜁니다.")
            return

        dropped_cols = [c for c in df_for_db.columns if c not in db_cols]
        if dropped_cols:
            print(f"[DB-WARN] '{table}' 테이블에 없는 컬럼이 무시됩니다: {dropped_cols}")

        df_for_db = df_for_db[use_cols]
        with engine.begin() as conn:
            df_for_db.to_sql(table, con=conn, if_exists="append", index=False)

        print(f"[DB] {table} 테이블에 로그 {len(df_for_db)}건 append 완료 (columns={use_cols})")

    except Exception as e:
        print(f"[DB-WARN] 로그 업로드 실패: {e}")
        raise
