from __future__ import annotations
"""
step_60_predict_accuracy.py

예측 정확도 분석
-----------------
step_51(Best ML) / step_53(Best DL) 이 OUT_DIR/yyyy-mm-dd/ 폴더에
저장한 예측 엑셀 파일들을 순회하여,

  1) 코드 실행일 기준 가장 최신 날짜 폴더의 엑셀에서 '실적' 행을
     "실제 실적(actual)" 기준값으로 사용합니다.

  2) 나머지 각 파일의 '실적' 행 중 해당 파일의 조회일(query_date)
     이후 구간(예측 구간)의 월별 값을 예측값으로 추출합니다.

  3) 실제 실적 vs 예측값을 협력사별/월별로 비교하여 MAE·RMSE·MAPE
     지표를 계산합니다.

출력 엑셀
----------
  - 파일명: {year}년도_예측정확도_분석_{YYMMDD}.xlsx
  - 저장위치: OUT_DIR (날짜 폴더 없이 루트에 바로 저장)
  - 구성
      · 시트 1 (요약):   전체 협력사 × 파일별 MAPE 요약 매트릭스
      · 시트 2~N (협력사별):
            [월별 비교표] 실적(최신) vs 각 예측파일의 예측값/오차/오차율
            [정확도 요약] 파일별 MAE / RMSE / MAPE

사용 방법
---------
  python step_60_predict_accuracy.py          # 자동: OUT_DIR 탐색
  python step_60_predict_accuracy.py --year 2025   # 연도 고정
"""

import argparse
import datetime as dt
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from step_0_MSF import OUT_DIR
from utils_drm import decrypt_fasoo_file

# ─────────────────────────────────────────────
# 상수
# ─────────────────────────────────────────────
TODAY = dt.date.today()
MONTHS = [f"{m}월" for m in range(1, 13)]           # "1월" ~ "12월"
ROW_LABEL_ACTUAL = "실적"
PREDICT_EXCEL_DIR = Path(__file__).resolve().parent / "predict_excel"

# 저장 엑셀 파일명 패턴 (step_45_utils_save_excel 의 규칙)
#   {year}년도_사외_조립_계획실적_예측_현황({engine_tag})_{YYMMDD}.xlsx
FILE_PATTERN = re.compile(
    r"(\d{4})년도_사외_조립_계획실적_예측_현황\((.+?)\)_(\d{6})\.xlsx",
    re.IGNORECASE,
)

# ─────────────────────────────────────────────
# 스타일 상수
# ─────────────────────────────────────────────
_THIN = Side(border_style="thin", color="000000")
BORDER_THIN = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

FILL_HEADER  = PatternFill("solid", fgColor="4472C4")   # 파란색 (헤더)
FILL_ACTUAL  = PatternFill("solid", fgColor="E2EFDA")   # 연초록 (실제 실적)
FILL_PREDICT = PatternFill("solid", fgColor="FFF2CC")   # 연노랑 (예측값)
FILL_ERROR   = PatternFill("solid", fgColor="FCE4D6")   # 연주황 (오차)
FILL_SUMMARY = PatternFill("solid", fgColor="D9E1F2")   # 연보라 (요약 헤더)
FILL_TITLE   = PatternFill("solid", fgColor="BDD7EE")   # 연파랑 (섹션 타이틀)

FONT_WHITE_BOLD = Font(color="FFFFFF", bold=True)
FONT_BOLD       = Font(bold=True)
FONT_RED        = Font(color="FF0000")


# ═══════════════════════════════════════════════
# 1. 예측 엑셀 파일 탐색
# ═══════════════════════════════════════════════

def scan_predict_excels(root_dir: Path, year: Optional[int] = None) -> List[Dict]:
    """
    predict_excel ?? ???? ?? ?? ??? ????.

    Parameters
    ----------
    root_dir : Path
        ?? ?? (predict_excel)
    year : int, optional
        ?? ??? ???, None?? ??.

    Returns
    -------
    List[Dict]  ? ?? ?? ??
        {
          "path"       : Path,
          "query_date" : dt.date,
          "year"       : int,
          "engine"     : str,
        }
    """
    results: List[Dict] = []

    if not root_dir.exists():
        print(f"[WARN] predict_excel ?? ??: {root_dir}")
        return results

    for fpath in sorted(root_dir.rglob("*.xlsx")):
        m = FILE_PATTERN.match(fpath.name)
        if not m:
            continue
        file_year = int(m.group(1))
        if year is not None and file_year != year:
            continue
        engine = m.group(2)
        try:
            suffix = m.group(3)
            month = int(suffix[2:4])
            day = int(suffix[4:6])
            query_date = dt.date(file_year, month, day)
        except Exception:
            query_date = dt.date.fromtimestamp(fpath.stat().st_mtime)

        results.append({
            "path"       : fpath,
            "query_date" : query_date,
            "year"       : file_year,
            "engine"     : engine,
        })

    return results

    for folder in sorted(out_dir.iterdir()):
        if not folder.is_dir():
            continue
        # yyyy-mm-dd 폴더만 처리
        try:
            folder_date = dt.date.fromisoformat(folder.name)
        except ValueError:
            continue

        for fpath in sorted(folder.glob("*.xlsx")):
            m = FILE_PATTERN.match(fpath.name)
            if not m:
                continue
            file_year = int(m.group(1))
            if year is not None and file_year != year:
                continue
            engine = m.group(2)
            results.append({
                "path"       : fpath,
                "query_date" : folder_date,
                "year"       : file_year,
                "engine"     : engine,
            })

    return results


# ═══════════════════════════════════════════════
# 2. 엑셀 파싱 – 협력사별 월별 실적 값 추출
# ═══════════════════════════════════════════════

def parse_excel_vendor_monthly(
    excel_path: Path,
) -> Dict[str, Dict[str, float]]:
    """
    예측 엑셀 파일에서 협력사별 '실적' 행의 월별(1월~12월) 값을 추출한다.

    엑셀 레이아웃 (step_45_utils_save_excel 기준)
    -----------------------------------------------
    Row N  : 타이틀  "협력사명_TPD_ENGINE"
    Row N+1: 헤더    "구분 (단위: ton)" | 1월 | 2월 | ...
    Row N+2: 능력    숫자들...
    Row N+3: 계획    숫자들...
    Row N+4: 실적    숫자들...  ← 이 행을 추출
    Row N+5: 누계차  숫자들...
    Row N+6: 지연일수 숫자들...
    (blank gap)

    Returns
    -------
    Dict[vendor_name, Dict[month_label, float]]
    예: {"기민": {"1월": 1234.0, "3월": 567.0}, ...}
    """
    # Fasoo DRM 활성화 (열기 전 호출)
    decrypt_fasoo_file(str(excel_path))

    try:
        wb = load_workbook(excel_path, read_only=True, data_only=True)
    except Exception as e:
        print(f"[WARN] 엑셀 열기 실패: {excel_path.name} → {e}")
        return {}

    result: Dict[str, Dict[str, float]] = {}

    try:
        ws = wb.active
        all_rows = list(ws.iter_rows(values_only=True))
    except Exception as e:
        print(f"[WARN] 시트 읽기 실패: {excel_path.name} → {e}")
        wb.close()
        return {}

    n = len(all_rows)
    i = 0
    while i < n:
        row = all_rows[i]
        first_val = str(row[0]).strip() if row[0] is not None else ""

        # 헤더 행 감지: "구분" 과 "단위" 가 모두 포함된 셀
        if "구분" in first_val and "단위" in first_val:
            # 바로 앞 행 = 타이틀 행
            title_str = ""
            if i > 0 and all_rows[i - 1][0] is not None:
                title_str = str(all_rows[i - 1][0]).strip()

            # 협력사명: "기민_2.5톤/일_Best_ML" → "기민"
            vendor_name = title_str.split("_")[0].strip() if title_str else ""

            # 컬럼 레이블 (헤더 행의 2번째 셀부터)
            col_labels: List[str] = [
                str(c).strip() if c is not None else ""
                for c in row[1:]
            ]

            # 이후 최대 6행에서 "실적" 행 탐색
            found = False
            for j in range(i + 1, min(i + 7, n)):
                data_row = all_rows[j]
                row_label = str(data_row[0]).strip() if data_row[0] is not None else ""
                if row_label == ROW_LABEL_ACTUAL:
                    monthly: Dict[str, float] = {}
                    for k, lbl in enumerate(col_labels):
                        if lbl in MONTHS:
                            raw = data_row[k + 1] if (k + 1) < len(data_row) else None
                            if raw is None:
                                continue
                            if isinstance(raw, float) and np.isnan(raw):
                                continue
                            try:
                                monthly[lbl] = float(raw)
                            except (TypeError, ValueError):
                                pass
                    if vendor_name:
                        result[vendor_name] = monthly
                    found = True
                    break

            if found:
                i += 7   # 타이틀+헤더+5데이터행 건너뜀
                continue

        i += 1

    wb.close()
    return result


# ═══════════════════════════════════════════════
# 3. 예측 구간(미래 월) 판별
# ═══════════════════════════════════════════════

def future_months(query_date: dt.date) -> List[str]:
    """
    query_date 기준으로 월간 정확도 비교 대상 월 목록 반환.

    월간 분석 조건
    --------------
    step_51/53 의 하이브리드 축은 조회월(query month) 자체를 주/일 단위로
    쪼개므로 "N월" 컬럼이 생성되지 않는다.
    따라서 월간 실적 vs 예측 비교는 조회월보다 **엄격히 이후** 월만 가능하다.
    """
    return [f"{m}월" for m in range(query_date.month + 1, 13)]


# ═══════════════════════════════════════════════
# 4. 정확도 지표 계산
# ═══════════════════════════════════════════════

def calc_metrics(
    actual: List[float],
    predicted: List[float],
) -> Dict[str, float]:
    """
    MAE, RMSE, MAPE(%) 계산.

    actual·predicted 리스트 길이가 0 이거나 불일치이면
    모든 지표를 nan 으로 반환합니다.
    """
    if not actual or not predicted or len(actual) != len(predicted):
        return {"MAE": np.nan, "RMSE": np.nan, "MAPE": np.nan}

    a = np.array(actual, dtype=float)
    p = np.array(predicted, dtype=float)

    mae  = float(np.mean(np.abs(a - p)))
    rmse = float(np.sqrt(np.mean((a - p) ** 2)))

    mask = a != 0
    mape = float(np.mean(np.abs((a[mask] - p[mask]) / a[mask]) * 100)) if mask.any() else np.nan

    return {
        "MAE" : round(mae,  1),
        "RMSE": round(rmse, 1),
        "MAPE": round(mape, 1),
    }


# ═══════════════════════════════════════════════
# 5. 엑셀 출력 – 협력사별 시트
# ═══════════════════════════════════════════════

def _hdr_cell(ws, row: int, col: int, value, fill=None, font=None, fmt=None) -> None:
    """헤더/타이틀 셀을 한 번에 설정하는 헬퍼."""
    c = ws.cell(row=row, column=col, value=value)
    c.border    = BORDER_THIN
    c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    if fill : c.fill = fill
    if font : c.font = font
    if fmt  : c.number_format = fmt


def _data_cell(ws, row: int, col: int, value, fill=None, fmt=None, red_neg=False) -> None:
    """데이터 셀을 설정하는 헬퍼."""
    c = ws.cell(row=row, column=col, value=value)
    c.border    = BORDER_THIN
    c.alignment = Alignment(horizontal="right" if isinstance(value, (int, float)) else "center")
    if fill: c.fill = fill
    if fmt and isinstance(value, (int, float)): c.number_format = fmt
    if red_neg and isinstance(value, (int, float)) and value < 0:
        c.font = FONT_RED


def _write_vendor_sheet(
    wb: Workbook,
    vendor: str,
    actual_monthly: Dict[str, float],
    predict_records: List[Dict],
    year: int,
) -> Optional[Dict]:
    """
    협력사 1개에 대한 시트를 작성한다.

    predict_records 원소 구조
    -------------------------
    {
      "query_date" : dt.date,
      "engine"     : str,
      "monthly"    : Dict[str, float],  # 해당 파일의 월별 실적(예측포함) 값
      "pred_months": List[str],          # 예측 구간 월 라벨
    }

    Returns
    -------
    Dict  – 요약 시트용 데이터 (vendor, {file_label: MAPE})
    """
    # 시트명: 31자 제한, 특수문자 금지
    safe_name = re.sub(r'[\\/*?:\[\]]', '_', vendor)[:31]
    ws = wb.create_sheet(title=safe_name)

    r = 1

    # ─── 섹션 타이틀 ────────────────────────────────────────────────
    tc = ws.cell(row=r, column=1, value=f"【{vendor}】  월별 예측 vs 실적 비교  ({year}년도)")
    tc.font = Font(bold=True, size=12)
    tc.fill = FILL_TITLE
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=len(MONTHS) + 1)
    r += 2

    # ─── 월별 비교 테이블 헤더 ──────────────────────────────────────
    _hdr_cell(ws, r, 1, "구분", fill=FILL_HEADER, font=FONT_WHITE_BOLD)
    for j, m in enumerate(MONTHS, start=2):
        _hdr_cell(ws, r, j, m, fill=FILL_HEADER, font=FONT_WHITE_BOLD)
    r += 1

    # ─── 실적(최신) 행 ──────────────────────────────────────────────
    _hdr_cell(ws, r, 1, "실적(최신)", fill=FILL_ACTUAL, font=FONT_BOLD)
    for j, m in enumerate(MONTHS, start=2):
        val = actual_monthly.get(m)
        _data_cell(ws, r, j, val, fill=FILL_ACTUAL, fmt="#,##0")
    r += 1

    # ─── 각 예측 파일별 3개 행(예측/오차/오차율%) ───────────────────
    summary_by_file: Dict[str, float] = {}   # {file_label: MAPE}
    summary_rows: List[Dict] = []

    for rec in predict_records:
        qd          = rec["query_date"]
        engine      = rec["engine"]
        monthly     = rec["monthly"]
        pred_months = set(rec["pred_months"])
        date_lbl    = qd.strftime("%y/%m/%d")
        file_label  = f"{date_lbl}({engine})"

        actual_vals:    List[float] = []
        predicted_vals: List[float] = []

        # ── 예측값 행
        _hdr_cell(ws, r, 1, f"예측  {file_label}", fill=FILL_PREDICT, font=FONT_BOLD)
        for j, m in enumerate(MONTHS, start=2):
            if m in pred_months:
                val = monthly.get(m)
                _data_cell(ws, r, j, val, fill=FILL_PREDICT, fmt="#,##0")
                if val is not None:
                    av = actual_monthly.get(m)
                    if av is not None:
                        actual_vals.append(av)
                        predicted_vals.append(val)
            else:
                _data_cell(ws, r, j, "—", fill=FILL_PREDICT)
        r += 1

        # ── 오차 행 (실적 - 예측)
        _hdr_cell(ws, r, 1, f"오차  {date_lbl}", fill=FILL_ERROR)
        for j, m in enumerate(MONTHS, start=2):
            if m in pred_months:
                av = actual_monthly.get(m)
                pv = monthly.get(m)
                if av is not None and pv is not None:
                    err = av - pv
                    _data_cell(ws, r, j, err, fill=FILL_ERROR, fmt="#,##0", red_neg=True)
                else:
                    _data_cell(ws, r, j, "—", fill=FILL_ERROR)
            else:
                _data_cell(ws, r, j, "—", fill=FILL_ERROR)
        r += 1

        # ── 오차율(%) 행
        _hdr_cell(ws, r, 1, f"오차율%  {date_lbl}", fill=FILL_ERROR)
        for j, m in enumerate(MONTHS, start=2):
            if m in pred_months:
                av = actual_monthly.get(m)
                pv = monthly.get(m)
                if av is not None and pv is not None and av != 0:
                    pct = round((av - pv) / av * 100, 1)
                    _data_cell(ws, r, j, pct, fill=FILL_ERROR, fmt="0.0", red_neg=True)
                else:
                    _data_cell(ws, r, j, "—", fill=FILL_ERROR)
            else:
                _data_cell(ws, r, j, "—", fill=FILL_ERROR)
        r += 2   # gap

        # 지표 계산
        metrics = calc_metrics(actual_vals, predicted_vals)
        summary_rows.append({
            "조회일"     : qd.strftime("%Y-%m-%d"),
            "모델"       : engine,
            "예측월수"   : len(pred_months),
            "비교가능월수": len(actual_vals),
            "MAE"        : metrics["MAE"],
            "RMSE"       : metrics["RMSE"],
            "MAPE(%)"    : metrics["MAPE"],
        })
        summary_by_file[file_label] = metrics["MAPE"]

    # ─── 정확도 요약 테이블 ─────────────────────────────────────────
    r += 1
    tc2 = ws.cell(row=r, column=1, value="【정확도 요약】")
    tc2.font = Font(bold=True, size=11)
    tc2.fill = FILL_TITLE
    r += 1

    sum_hdrs = ["조회일", "모델", "예측월수", "비교가능월수", "MAE", "RMSE", "MAPE(%)"]
    for j, h in enumerate(sum_hdrs, start=1):
        _hdr_cell(ws, r, j, h, fill=FILL_SUMMARY, font=FONT_BOLD)
    r += 1

    for srec in summary_rows:
        for j, h in enumerate(sum_hdrs, start=1):
            val = srec[h]
            c = ws.cell(row=r, column=j, value=val)
            c.border    = BORDER_THIN
            c.alignment = Alignment(
                horizontal="center" if isinstance(val, str) else "right"
            )
            if isinstance(val, float) and not np.isnan(val):
                c.number_format = "0.0"
        r += 1

    # ─── 열 너비 ────────────────────────────────────────────────────
    ws.column_dimensions["A"].width = 28
    for col in range(2, len(MONTHS) + 2):
        ws.column_dimensions[get_column_letter(col)].width = 11

    return {"vendor": vendor, "mape_by_file": summary_by_file}


# ═══════════════════════════════════════════════
# 6. 요약 시트 작성
# ═══════════════════════════════════════════════

def _write_summary_sheet(
    wb: Workbook,
    vendor_summaries: List[Dict],
    all_file_labels: List[str],
    year: int,
    latest_date: dt.date,
) -> None:
    """
    '요약' 시트 작성.

    레이아웃
    ---------
    행: 협력사
    열: 파일별 MAPE(%)
        - NaN 이면 "—" 표시
    """
    ws = wb.active
    ws.title = "요약"

    r = 1
    tc = ws.cell(row=r, column=1,
                 value=f"{year}년도 예측 정확도 분석 요약  "
                       f"(기준 실적일: {latest_date.strftime('%Y-%m-%d')}  "
                       f"분석일: {TODAY.strftime('%Y-%m-%d')})")
    tc.font = Font(bold=True, size=13)
    tc.fill = FILL_TITLE
    n_cols = len(all_file_labels) + 2
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=n_cols)
    r += 2

    # 헤더: 협력사 | 파일1_MAPE | 파일2_MAPE | ...
    _hdr_cell(ws, r, 1, "협력사", fill=FILL_HEADER, font=FONT_WHITE_BOLD)
    for j, lbl in enumerate(all_file_labels, start=2):
        _hdr_cell(ws, r, j, f"MAPE(%)\n{lbl}", fill=FILL_HEADER, font=FONT_WHITE_BOLD)
    # 마지막 열: 평균 MAPE
    _hdr_cell(ws, r, len(all_file_labels) + 2, "평균\nMAPE(%)",
              fill=FILL_HEADER, font=FONT_WHITE_BOLD)
    r += 1

    # 데이터 행
    for vs in vendor_summaries:
        vendor = vs["vendor"]
        mape_map = vs["mape_by_file"]

        ws.cell(row=r, column=1, value=vendor).border    = BORDER_THIN
        ws.cell(row=r, column=1).font                    = FONT_BOLD
        ws.cell(row=r, column=1).alignment               = Alignment(horizontal="center")

        valid_mapes: List[float] = []
        for j, lbl in enumerate(all_file_labels, start=2):
            mape = mape_map.get(lbl)
            if mape is not None and not np.isnan(mape):
                c = ws.cell(row=r, column=j, value=mape)
                c.number_format = "0.0"
                # 색상: MAPE 기준
                if mape <= 10:
                    c.fill = PatternFill("solid", fgColor="E2EFDA")   # 연초록: 양호
                elif mape <= 20:
                    c.fill = PatternFill("solid", fgColor="FFF2CC")   # 연노랑: 보통
                else:
                    c.fill = PatternFill("solid", fgColor="FCE4D6")   # 연주황: 불량
                valid_mapes.append(mape)
            else:
                c = ws.cell(row=r, column=j, value="—")
            c.border    = BORDER_THIN
            c.alignment = Alignment(horizontal="center")

        # 평균 MAPE
        last_col = len(all_file_labels) + 2
        if valid_mapes:
            avg = round(sum(valid_mapes) / len(valid_mapes), 1)
            ca = ws.cell(row=r, column=last_col, value=avg)
            ca.number_format = "0.0"
            ca.font = FONT_BOLD
            if avg <= 10:
                ca.fill = PatternFill("solid", fgColor="E2EFDA")
            elif avg <= 20:
                ca.fill = PatternFill("solid", fgColor="FFF2CC")
            else:
                ca.fill = PatternFill("solid", fgColor="FCE4D6")
        else:
            ca = ws.cell(row=r, column=last_col, value="—")
        ca.border    = BORDER_THIN
        ca.alignment = Alignment(horizontal="center")

        r += 1

    # 범례
    r += 1
    legend_items = [
        ("MAPE ≤ 10%", "E2EFDA", "양호"),
        ("10% < MAPE ≤ 20%", "FFF2CC", "보통"),
        ("MAPE > 20%", "FCE4D6", "불량"),
    ]
    ws.cell(row=r, column=1, value="※ 색상 범례").font = FONT_BOLD
    r += 1
    for label, color, desc in legend_items:
        c1 = ws.cell(row=r, column=1, value=f"  {label}  ({desc})")
        c1.fill = PatternFill("solid", fgColor=color)
        c1.border = BORDER_THIN
        r += 1

    # 열 너비
    ws.column_dimensions["A"].width = 22
    for col in range(2, len(all_file_labels) + 3):
        ws.column_dimensions[get_column_letter(col)].width = 18


# ═══════════════════════════════════════════════
# 7. 메인 진입점
# ═══════════════════════════════════════════════

def run(year: Optional[int] = None) -> Optional[Path]:
    """
    예측 정확도 분석을 실행하고 결과 엑셀을 저장한다.

    Parameters
    ----------
    year : int, optional
        분석 연도. None 이면 탐색된 파일에서 가장 많은 연도 자동 선택.

    Returns
    -------
    Path | None  저장된 엑셀 경로
    """
    # ── 1) 파일 탐색 ────────────────────────────────────────────────
    print(f"[INFO] 예측 엑셀 탐색 중... (predict_excel: {PREDICT_EXCEL_DIR})")
    all_files = scan_predict_excels(PREDICT_EXCEL_DIR, year=year)

    if not all_files:
        print("[WARN] 분석 대상 예측 엑셀 파일이 없습니다.")
        return None

    # 연도 결정
    if year is None:
        from collections import Counter
        year = Counter(f["year"] for f in all_files).most_common(1)[0][0]
        all_files = [f for f in all_files if f["year"] == year]

    print(f"[INFO] 대상 연도: {year}년  파일 수: {len(all_files)}")

    # ── 2) 최신 파일 결정 ───────────────────────────────────────────
    all_files_sorted = sorted(all_files, key=lambda x: x["query_date"])
    latest_info = all_files_sorted[-1]
    latest_date = latest_info["query_date"]

    print(f"[INFO] 최신 파일(기준 실적): {latest_info['path'].name}  (조회일: {latest_date})")

    # ── 3) 최신 파일에서 실제 실적 추출 ─────────────────────────────
    print(f"[INFO] 최신 실적 파싱 중...")
    actual_data = parse_excel_vendor_monthly(latest_info["path"])
    if not actual_data:
        print(f"[ERROR] 최신 파일 파싱 실패 → 분석 중단")
        return None

    vendors_found = sorted(actual_data.keys())
    print(f"[INFO] 발견된 협력사: {vendors_found}")

    # ── 4) 각 파일 파싱 + 예측 구간 정보 수집 ──────────────────────
    # 최신 파일 제외 → 예측값 비교 대상
    older_files = [f for f in all_files_sorted if f["query_date"] < latest_date]

    if not older_files:
        print("[WARN] 최신 파일 외에 비교할 이전 파일이 없습니다. 최신 파일만 포함하여 분석합니다.")
        # 최신 파일 자체의 예측 구간도 분석 가능하므로 포함
        older_files = all_files_sorted  # 모든 파일 비교

    all_predict_records_by_vendor: Dict[str, List[Dict]] = {v: [] for v in vendors_found}
    all_file_labels: List[str] = []

    for finfo in older_files:
        qd     = finfo["query_date"]
        engine = finfo["engine"]
        path   = finfo["path"]

        print(f"  파싱: {path.name}  (조회일: {qd})")
        monthly_data = parse_excel_vendor_monthly(path)

        pred_m = future_months(qd)
        date_lbl = qd.strftime("%y/%m/%d")
        file_label = f"{date_lbl}({engine})"

        if file_label not in all_file_labels:
            all_file_labels.append(file_label)

        for vendor in vendors_found:
            monthly = monthly_data.get(vendor, {})
            all_predict_records_by_vendor[vendor].append({
                "query_date" : qd,
                "engine"     : engine,
                "monthly"    : monthly,
                "pred_months": pred_m,
            })

    # ── 5) 엑셀 작성 ────────────────────────────────────────────────
    print(f"[INFO] 결과 엑셀 작성 중...")
    wb = Workbook()

    # 먼저 요약 시트(첫 번째)를 위해 active sheet 유지
    vendor_summaries: List[Dict] = []

    # PRINT_ORDER 순서로 협력사 정렬 (그룹명 제외, 개별 협력사만)
    from step_43_utils_label_group import BASE_VENDORS
    ordered_vendors = [v for v in BASE_VENDORS if v in vendors_found]
    remaining = [v for v in vendors_found if v not in ordered_vendors]
    ordered_vendors += remaining

    for vendor in ordered_vendors:
        rec = _write_vendor_sheet(
            wb,
            vendor=vendor,
            actual_monthly=actual_data.get(vendor, {}),
            predict_records=all_predict_records_by_vendor[vendor],
            year=year,
        )
        if rec:
            vendor_summaries.append(rec)

    # 요약 시트 (가장 앞으로)
    _write_summary_sheet(wb, vendor_summaries, all_file_labels, year, latest_date)

    # 요약 시트를 맨 앞으로 이동
    wb.move_sheet("요약", offset=-len(wb.worksheets) + 1)

    # ── 6) 파일 저장 ────────────────────────────────────────────────
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    date_suffix = TODAY.strftime("%y%m%d")
    out_path = OUT_DIR / f"{year}년도_예측정확도_분석_{date_suffix}.xlsx"

    try:
        out_path.unlink(missing_ok=True)
    except Exception:
        pass

    wb.save(out_path)
    print(f"\n[SAVE] 결과 저장 완료 → {out_path}")

    # Fasoo DRM 활성화
    decrypt_fasoo_file(str(out_path))

    return out_path


# ═══════════════════════════════════════════════
# CLI 진입점
# ═══════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="step_51/53 예측 엑셀과 실제 실적을 비교하여 정확도 분석 결과를 출력합니다."
    )
    parser.add_argument(
        "--year", type=int, default=None,
        help="분석 연도 (생략 시 탐색된 파일에서 자동 선택)"
    )
    args = parser.parse_args()

    result_path = run(year=args.year)
    if result_path:
        print(f"\n✅  분석 완료: {result_path}")
    else:
        print("\n❌  분석 실패 또는 대상 파일 없음")
