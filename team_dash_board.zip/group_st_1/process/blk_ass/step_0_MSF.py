from __future__ import annotations

import os
import subprocess
from pathlib import Path

"""
step_0_MSF.py (Mount Shared Folder)

- Windows `net use` 명령으로 공유 폴더를 연결하고
- 그 아래에 작업용 OUT_DIR 폴더(예: baechaehong)를 생성한 뒤
- Path 객체로 경로를 반환하는 모듈입니다.

다른 모듈에서는 다음처럼 사용합니다.
    from step_0_MSF import connect_and_prepare_outdir, OUT_DIR
"""

# ─────────────────────────────────────────────
# 환경 설정: 공유 계정 정보 (환경변수)
#   - SHARE_USER, SHARE_PWD 를 통해서만 자격증명 주입
#   - 코드 내 하드코딩 비밀번호는 사용하지 않음
# ─────────────────────────────────────────────
USER = os.getenv("SHARE_USER", "").strip()
PWD  = os.getenv("SHARE_PWD",  "").strip()

# ─────────────────────────────────────────────
# 공유 폴더 루트 및 산출물 경로
#   REMOTE_PATH : 공유 폴더(또는 네트워크 드라이브) 루트
#   WORK_DIR    : 작업 기준 폴더
#   OUT_DIR     : 실제 산출물 저장 폴더 (예: D:\...\BLK_ASS_PREDICT_4\baechaehong)
#                 → 다른 모듈에서 import 하여 사용
# ─────────────────────────────────────────────
REMOTE_PATH = r"\\60.100.164.182\d\001_python_source\021_team_dash_board_r1\group_st_1\process\blk_ass"
WORK_DIR = Path(REMOTE_PATH)
OUT_DIR  = WORK_DIR / "save_folder"   # 모듈 외부에서 import 해 사용


def connect_and_prepare_outdir(persistent: bool = False) -> Path:
    """
    공유 폴더 연결 후 OUT_DIR(작업 산출 폴더)을 생성하고, 그 경로(Path)를 반환합니다.

    Parameters
    ----------
    persistent : bool, optional
        - True  : Windows 재부팅 후에도 연결 유지(/persistent:yes)
        - False : 한 번 연결만 시도(기본값)

    Returns
    -------
    Path
        OUT_DIR 경로 (예: D:\\08_Python_uv\\BLK_ASS_PREDICT_4\\baechaehong)
    """
    # 이미 공유 경로 접근 가능하면 재연결 시도 없이 바로 사용
    if WORK_DIR.exists():
        OUT_DIR.mkdir(parents=True, exist_ok=True)
        return OUT_DIR

    # /persistent 옵션 구성
    persistent_opt = "/persistent:yes" if persistent else ""

    # 접근이 안 되는 상태에서 자격증명이 없으면 명시적으로 실패
    if not USER or not PWD:
        raise EnvironmentError(
            "공유 폴더 접근을 위한 환경변수 SHARE_USER / SHARE_PWD 가 필요합니다. "
            "이미 OS 자격증명으로 접근 가능한 경우에는 별도 설정 없이 동작합니다."
        )

    # Windows net use 명령어 구성
    #   예) net use "\\server\share" "비밀번호" /user:"계정" /persistent:yes
    cmd = ["net", "use", REMOTE_PATH, PWD, f"/user:{USER}"]
    if persistent_opt:
        cmd.append(persistent_opt)

    try:
        # 공유 폴더 연결 시도
        subprocess.run(
            cmd,
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as e:
        # 연결 명령 실패 시에도 실제 접근 가능하면 진행
        if not WORK_DIR.exists():
            stderr = (e.stderr or "").strip()
            raise RuntimeError(
                f"공유 폴더 연결 실패: {REMOTE_PATH}"
                + (f" | stderr: {stderr}" if stderr else "")
            ) from e

    # OUT_DIR(산출 폴더) 생성
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    return OUT_DIR


if __name__ == "__main__":
    # 단독 실행 시, 연결 + OUT_DIR 경로를 출력해 간단히 확인
    out = connect_and_prepare_outdir(persistent=False)
    print(f"[OK] OUT_DIR: {out}")
