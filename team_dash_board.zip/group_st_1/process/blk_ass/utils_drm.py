from __future__ import annotations

"""
drm_utils.py
------------------------------------------------------------
Fasoo DRM 권한 활성화 유틸.
엑셀을 열기 전에 호출하면 DRM 환경에서 열림 실패를 줄일 수 있습니다.
------------------------------------------------------------
"""

from ctypes import CDLL


def decrypt_fasoo_file(excel_path: str) -> None:
    """
    Fasoo DRM 권한을 활성화합니다.
    실제 복호화는 OS/Fasoo 클라이언트가 파일 I/O 시 투명하게 처리하는 구조인 경우가 많습니다.

    ※ 파일 경로 인자는 호출부 통일을 위해 받지만 내부에서 사용하지 않습니다.
    """
    try:
        fasoo = CDLL("C:/Windows/System32/f_nxldr.dll")
        ret = fasoo.EnableDRM()
        if not ret:
            print("[WARN] Fasoo EnableDRM 리턴값 확인 필요")
    except Exception as e:
        # DRM 환경이 아니거나 DLL이 없는 경우에도 앱은 동작하도록 경고만 출력
        print(f"[WARN] DRM 모듈 로드 오류 (무시하고 진행): {e}")
