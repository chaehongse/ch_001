from __future__ import annotations

"""
step_3_Monthly.py

역할 요약
---------
1. step_2_BPA_Data.outside_df2() 로 조회년도(year) 사외조립 데이터 로딩
2. 협력사별 월간 계획/실적 피벗 (1~12월, ton)
3. 협력사/그룹/전체 단위로
   - 능력(일일조립생산능력 → 월환산)
   - 월별 계획
   - 월별 실적
   - 월별 누계차(실적-계획 누적)
   - 월별 지연일수(누계차 / 월간능력)
4. 조회월(query_month) 이후 구간은 실적/누계차/지연일수를 엑셀에서 공란 처리
5. step_4 스타일과 동일하게 엑셀로 저장
"""

import argparse
import datetime as dt
from typing import List

import numpy as np
import pandas as pd

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font
from openpyxl.formatting.rule import CellIsRule
from openpyxl.utils import get_column_letter

# 자체 모듈
from step_0_MSF import OUT_DIR
from step_2_BPA_Data import outside_df2
from step_42_utils_calendar import _to_date
from step_43_utils_label_group import (
    ROW_LABELS,
    BASE_VENDORS,
    PRINT_ORDER,
    GROUP_DEFS,
    BORDER_THIN,
    resolve_group_members,
)
from step_44_utils_TPD import load_capacity, tpd_month

# ─────────────────────────────────────────────
# 전역/상수
# ─────────────────────────────────────────────
TODAY = dt.date.today()
DEFAULT_YEAR = TODAY.year
DEFAULT_QUERY_MONTH = TODAY.month   # 조회 기준 월
TITLE_MONTH = TODAY.month           # 타이틀에 표시할 TPD 기준 월

MONTH_COLS = [f"{m}월" for m in range(1, 13)]

FIRST_MONTH_COL = 2  # B열
LAST_MONTH_COL = FIRST_MONTH_COL + len(MONTH_COLS) - 1  # 2 + 12 - 1 = 13 (M열)


# ─────────────────────────────────────────────
# 계획/실적 월간 피벗 생성
# ─────────────────────────────────────────────
def _weight_col(df: pd.DataFrame) -> str:
    """
    중량 컬럼명 자동 판별.

    - '고유_중량' 우선
    - 없으면 '중량_고유' 사용
    """
    if "고유_중량" in df.columns:
        return "고유_중량"
    if "중량_고유" in df.columns:
        return "중량_고유"
    raise KeyError("중량 컬럼 누락('고유_중량' 또는 '중량_고유').")


def build_monthly_plan_actual(df_year: pd.DataFrame, year: int):
    """
    협력사별 1~12월 계획/실적 피벗 생성.

    - 기준: 기준계획_완료, 실적_완료
    - 해당 연도(year)에 속하는 날짜만 집계
    """
    wcol = _weight_col(df_year)
    df = df_year.copy()

    # ── 계획 (기준계획_완료 기준) ─────────────────────
    if "기준계획_완료" not in df.columns:
        raise KeyError("기준계획_완료 컬럼이 없습니다.")

    df["계획일"] = df["기준계획_완료"].apply(_to_date)
    df["계획월"] = df["계획일"].apply(
        lambda d: d.month if (d is not None and d.year == year) else None
    )

    plan = (
        df.dropna(subset=["계획월"])
        .groupby(["협력사", "계획월"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "계획", "계획월": "월"})
    )

    # ── 실적 (실적_완료 기준) ───────────────────────
    if "실적_완료" not in df.columns:
        raise KeyError("실적_완료 컬럼이 없습니다.")

    df["실적일"] = df["실적_완료"].apply(_to_date)
    df["실적월"] = df["실적일"].apply(
        lambda d: d.month if (d is not None and d.year == year) else None
    )

    actual = (
        df.dropna(subset=["실적월"])
        .groupby(["협력사", "실적월"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "실적", "실적월": "월"})
    )

    # ── 피벗: index=협력사, columns=월(1~12) ─────────
    plan_pv = plan.pivot_table(
        index="협력사",
        columns="월",
        values="계획",
        aggfunc="sum",
        fill_value=0.0,
    )
    actual_pv = actual.pivot_table(
        index="협력사",
        columns="월",
        values="실적",
        aggfunc="sum",
        fill_value=0.0,
    )

    # 1~12월 컬럼 강제 생성
    for m in range(1, 13):
        if m not in plan_pv.columns:
            plan_pv[m] = 0.0
        if m not in actual_pv.columns:
            actual_pv[m] = 0.0

    plan_pv = plan_pv[[m for m in range(1, 13)]].sort_index()
    actual_pv = actual_pv[[m for m in range(1, 13)]].sort_index()

    # 컬럼명을 "1월" ~ "12월"로 변경
    plan_pv.columns = [f"{m}월" for m in plan_pv.columns]
    actual_pv.columns = [f"{m}월" for m in actual_pv.columns]

    return plan_pv, actual_pv

# ─────────────────────────────────────────────
# 조회월 TPD가 없을 경우 최근 TPD 반환
# ─────────────────────────────────────────────
def _recent_tpd(cap_df: pd.DataFrame, vendor: str, month: int):
        """
        조회월(month)의 TPD가 없으면
        → 과거 월 중 가장 최근의 유효한 TPD를 반환.
        """
        # 1) 조회월 값 우선 확인
        v = tpd_month(cap_df, vendor, month)
        if not pd.isna(v):
            return float(v)

        # 2) 조회월 이전에서 최근값 탐색
        for m in range(month - 1, 0, -1):
            prev = tpd_month(cap_df, vendor, m)
            if not pd.isna(prev):
                return float(prev)

        # 3) 전부 없으면 None
        return None  

# ─────────────────────────────────────────────
# 조회월 이후 공백 처리 (엑셀 표기용)
# ─────────────────────────────────────────────
def _mask_after_query(arr_like, q_month: int):
    """
    조회월(q_month) 이후(미래 구간)는 None 처리 → 엑셀에서 공란으로 표시.

    Parameters
    ----------
    arr_like : array-like (월별 12개 값)
    q_month  : 1~12 (예: 5 → 5월 이후 구간 공란)
    """
    masked = list(pd.Series(arr_like).astype(object))
    # 인덱스 0→1월, ..., 11→12월
    for i in range(q_month, 12):  # q_month=5(5월)이면 index 0~4 유지, index 5~11 None
        masked[i] = None
    return masked


# ─────────────────────────────────────────────
# 행렬 생성 (개별 협력사 / 전체·그룹)
# ─────────────────────────────────────────────
def matrix_vendor(
    cap_df: pd.DataFrame,
    plan_pv: pd.DataFrame,
    actual_pv: pd.DataFrame,
    vendor: str,
    query_month: int,
) -> pd.DataFrame:
    """
    단일 협력사에 대한 월별 행렬 생성.

    행: ROW_LABELS (능력, 계획, 실적, 누계차, 지연일수)
    열: MONTH_COLS ("1월" ~ "12월")
    """
    # 능력: 해당 월 TPD 없으면 과거 최근값 사용
    cap_full = []
    for m in range(1, 13):
        v = _recent_tpd(cap_df, vendor, m)
        cap_full.append(v)
    cap_full = np.array(cap_full, dtype=object)

    plan = plan_pv.loc[vendor].values if vendor in plan_pv.index else np.zeros(12)
    actual = actual_pv.loc[vendor].values if vendor in actual_pv.index else np.zeros(12)

    diff = np.nan_to_num(actual) - np.nan_to_num(plan)
    cumsum = np.cumsum(diff)

    cap_for_delay = np.array(
        [float(x) if isinstance(x, (int, float, np.floating)) else 0.0 for x in cap_full],
        dtype=float,
    )
    delay_all = []
    for i in range(12):
        denom = cap_for_delay[i]
        delay_all.append(cumsum[i] / denom if denom != 0 else None)

    cap_masked = _mask_after_query(cap_full, query_month)
    actual_masked = _mask_after_query(actual, query_month)
    cumsum_masked = _mask_after_query(cumsum, query_month)
    delay_masked = _mask_after_query(delay_all, query_month)

    return pd.DataFrame(
        [cap_masked, plan, actual_masked, cumsum_masked, delay_masked],
        index=ROW_LABELS,
        columns=MONTH_COLS,
    )


def matrix_total(
    cap_df: pd.DataFrame,
    plan_pv: pd.DataFrame,
    actual_pv: pd.DataFrame,
    vendors: List[str],
    query_month: int,
) -> pd.DataFrame:
    """
    여러 협력사(그룹/전체)의 월별 합산 행렬 생성.

    - 능력: 협력사별 월능력(해당 월 TPD 없으면 과거 최근값) 합계
    - 계획/실적: 협력사별 월계획·실적 합계
    """
    vendors = list(vendors)

    # 능력 합계: 모든 값이 None/NaN이면 None
    cap_full = []
    for m in range(1, 13):
        vals = [_recent_tpd(cap_df, v, m) for v in vendors]
        nums = [x for x in vals if x is not None and not pd.isna(x)]
        cap_full.append(sum(nums) if nums else None)
    cap_full = np.array(cap_full, dtype=object)

    plan_rows = [
        plan_pv.loc[v].values if v in plan_pv.index else np.zeros(12)
        for v in vendors
    ]
    actual_rows = [
        actual_pv.loc[v].values if v in actual_pv.index else np.zeros(12)
        for v in vendors
    ]

    plan = np.nansum(np.vstack(plan_rows), axis=0) if plan_rows else np.zeros(12)
    actual = np.nansum(np.vstack(actual_rows), axis=0) if actual_rows else np.zeros(12)

    diff = np.nan_to_num(actual) - np.nan_to_num(plan)
    cumsum = np.cumsum(diff)

    cap_for_delay = np.array(
        [float(x) if isinstance(x, (int, float, np.floating)) else 0.0 for x in cap_full],
        dtype=float,
    )
    delay_all = [
        (cumsum[i] / cap_for_delay[i]) if cap_for_delay[i] != 0 else None
        for i in range(12)
    ]

    cap_masked = _mask_after_query(cap_full, query_month)
    actual_masked = _mask_after_query(actual, query_month)
    cumsum_masked = _mask_after_query(cumsum, query_month)
    delay_masked = _mask_after_query(delay_all, query_month)

    return pd.DataFrame(
        [cap_masked, plan, actual_masked, cumsum_masked, delay_masked],
        index=ROW_LABELS,
        columns=MONTH_COLS,
    )

# ─────────────────────────────────────────────
# Excel 출력
# ─────────────────────────────────────────────
def borders(ws, r1, r2, c1: int = 1, c2: int = LAST_MONTH_COL) -> None:
    """지정 영역에 얇은 테두리(BORDER_THIN) 일괄 적용."""
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            ws.cell(row=r, column=c).border = BORDER_THIN


def write_header_row(ws, row: int) -> None:
    """행렬 상단 헤더(구분/월)를 그린다."""
    # A열: "구분 (단위: ton)"
    ca = ws.cell(row=row, column=1, value="구분 (단위: ton)")
    ca.font = Font(bold=True)
    ca.alignment = Alignment(horizontal="center", vertical="center")

    # B~M열: "1월"~"12월"
    for idx, mlab in enumerate(MONTH_COLS, start=FIRST_MONTH_COL):
        cell = ws.cell(row=row, column=idx, value=mlab)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.column_dimensions[get_column_letter(idx)].width = 10

    borders(ws, row, row, 1, LAST_MONTH_COL)


def write_block(ws, start_row: int, title: str, mat: pd.DataFrame) -> int:
    """
    타이틀 + 헤더 + 데이터 블록 1개를 작성.

    Parameters
    ----------
    ws        : Worksheet
    start_row : 블록 시작 행 (타이틀 위치)
    title     : "협력사명_TPD톤/일" 형식의 타이틀 문자열
    mat       : matrix_vendor / matrix_total 결과 DataFrame

    Returns
    -------
    int
        다음 블록이 시작될 행 번호
    """
    # ── 타이틀 라인 ─────────────────────────────
    t = ws.cell(row=start_row, column=1, value=title)
    t.font = Font(bold=True, size=12)
    t.alignment = Alignment(horizontal="left", vertical="center")

    # ── 헤더 행 ────────────────────────────────
    hdr = start_row + 1
    write_header_row(ws, hdr)

    # ── 데이터 영역 ────────────────────────────
    data_start = hdr + 1
    for i, rname in enumerate(ROW_LABELS):
        r = data_start + i
        # 좌측 행 라벨 (능력, 계획, 실적, 누계차, 지연일수)
        ws.cell(row=r, column=1, value=rname).alignment = Alignment(
            horizontal="left", vertical="center"
        )
        # 월별 값
        for j, mlab in enumerate(MONTH_COLS, start=FIRST_MONTH_COL):
            val = mat.loc[rname, mlab]
            cell = ws.cell(row=r, column=j, value=val)
            cell.alignment = Alignment(horizontal="right", vertical="center")
            # 지연일수만 소수 1자리, 나머지는 정수형(천단위 콤마)
            cell.number_format = "0.0" if rname == "지연일수" else "#,##0"

    # ── 음수값 빨간색 (조건부 서식) ───────────────
    rng = (
        f"{get_column_letter(FIRST_MONTH_COL)}{data_start}:"
        f"{get_column_letter(LAST_MONTH_COL)}{data_start + len(ROW_LABELS) - 1}"
    )
    ws.conditional_formatting.add(
        rng,
        CellIsRule(
            operator="lessThan",
            formula=["0"],
            stopIfTrue=False,
            font=Font(color="FF0000"),
        ),
    )

    # ── 테두리, 다음 블록 시작행 반환 ────────────
    borders(ws, data_start, data_start + len(ROW_LABELS) - 1, 1, LAST_MONTH_COL)
    return data_start + len(ROW_LABELS) + 1


def autosize_left(ws) -> None:
    """A열(구분) 너비 자동(고정폭) 설정."""
    ws.column_dimensions["A"].width = 16


# ─────────────────────────────────────────────
# 메인
# ─────────────────────────────────────────────
def main(year: int = DEFAULT_YEAR, query_month: int = DEFAULT_QUERY_MONTH):
    """
    월별 조립 계획/실적 현황 엑셀 생성.

    - year        : 조회 기준 연도
    - query_month : 조회 기준 월 (이후 월은 실적/누계차/지연일수 공란)
    """
    # 1) 원천 데이터(해당 연도) — step_2_BPA_Data.outside_df2 사용
    df_year = outside_df2(year)
    if df_year.empty:
        raise ValueError(f"[step_2] {year}년 데이터가 비어 있습니다.")

    if "협력사" not in df_year.columns:
        raise KeyError("[step_2] 협력사 컬럼이 없습니다.")

    vendors_all = df_year["협력사"].astype(str).unique().tolist()

    # 실제 존재하는 협력사만 사용 (step_43의 BASE_VENDORS 교차)
    base_vendors = [v for v in BASE_VENDORS if v in vendors_all]

    # 2) TPD/능력 정보
    cap_df = load_capacity(year)

    # 3) 월별 계획/실적 피벗
    plan_pv, actual_pv = build_monthly_plan_actual(df_year, year)

    # 4) 타이틀용 TPD (개별 협력사 기준)
    vendor_title_tpd = {}
    for v in base_vendors:
        val = tpd_month(cap_df, v, TITLE_MONTH)
        vendor_title_tpd[v] = 0.0 if pd.isna(val) else float(val)
 

    def title_tpd(name: str) -> float:
        """
        타이틀(이름_XX.X톤/일)에 들어갈 TPD 값 계산.

        - 개별 협력사: vendor_title_tpd 사용
        - 그룹/전체: 구성원 협력사들의 TPD 합계
        """
        # 개별 협력사
        if name in vendor_title_tpd:
            val = _recent_tpd(cap_df, name, TITLE_MONTH)
            return 0.0 if val is None else float(val)

        # 그룹/전체 (예: 일반, 전문화, 해양, 전체 등)
        members = resolve_group_members(name, vendors_all)
        if not members:
            return 0.0

        total = 0.0
        for v in members:
            val = tpd_month(cap_df, v, TITLE_MONTH)
            if not pd.isna(val):
                total += float(val)
        return total

    # 5) 엑셀 워크북 구성
    wb = Workbook()
    ws = wb.active
    ws.title = "월별_조립_계획실적"

    row = 1

    # PRINT_ORDER 순서대로 블록 출력
    for name in PRINT_ORDER:
        # 1) 전체/그룹(합산)
        if name == "전체":
            members = resolve_group_members("전체", vendors_all)
            if members:
                mat = matrix_total(cap_df, plan_pv, actual_pv, members, query_month)
            else:
                mat = pd.DataFrame(0, index=ROW_LABELS, columns=MONTH_COLS, dtype=object)

        elif name in GROUP_DEFS:
            members = resolve_group_members(name, vendors_all)
            if members:
                mat = matrix_total(cap_df, plan_pv, actual_pv, members, query_month)
            else:
                mat = pd.DataFrame(0, index=ROW_LABELS, columns=MONTH_COLS, dtype=object)

        # 2) 개별 협력사
        else:
            mat = matrix_vendor(cap_df, plan_pv, actual_pv, name, query_month)

        tpd_val = title_tpd(name)
        row = write_block(ws, row, f"{name}_{tpd_val:,.1f}톤/일", mat)

    autosize_left(ws)

    # 6) 파일 저장
    query_date = dt.date.today()
    date_folder = query_date.strftime("%Y-%m-%d")  
    target_dir = OUT_DIR / date_folder
    target_dir.mkdir(parents=True, exist_ok=True)
    date_suffix = query_date.strftime("%y%m%d")
    file_name = f"{year}년도_사외_월별_조립_계획실적_현황_{date_suffix}.xlsx"
    out_path = target_dir / file_name
    wb.save(out_path)
    print(f"[OK] 저장 완료: {out_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="월별 조립 계획/실적")
    parser.add_argument("-y", "--year", type=int, default=DEFAULT_YEAR)
    parser.add_argument(
        "-m",
        "--month",
        type=int,
        default=DEFAULT_QUERY_MONTH,
        help="조회 기준 월(이후 월은 실적/누계차/지연일수 공란)",
    )
    args = parser.parse_args()
    main(year=args.year, query_month=args.month)
