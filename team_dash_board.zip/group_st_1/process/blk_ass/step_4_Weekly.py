from __future__ import annotations

"""
step_4_Weekly.py

역할 요약
---------
1. step_2_BPA_Data.outside_df2() 로 조회년도(year) 사외조립 데이터 로딩
2. 협력사별 주간(1~53주) 계획/실적 피벗 생성
   - 기준: 기준계획_완료(계획), 실적_완료(실적)
   - 연도 경계는 해당 연도에 속하는 날짜만 집계
3. 협력사/그룹/전체 단위로
   - 능력(일일조립생산능력 → 주간환산)
   - 주간 계획
   - 주간 실적
   - 주간 누계차(실적-계획 누적)
   - 주간 지연일수(누계차 / 주간능력)
4. 조회주(query_week, 월요일 시작) 이후 구간은
   - 능력, 실적, 누계차, 지연일수를 엑셀에서 공란으로 표시
   - 계획은 미래주도 그대로 표시
5. step_3_Monthly와 동일한 스타일의 엑셀로 저장
"""

import datetime as dt
from typing import List
import argparse

import numpy as np
import pandas as pd

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font
from openpyxl.formatting.rule import CellIsRule
from openpyxl.utils import get_column_letter

#  자체 경로
from step_0_MSF import OUT_DIR
from step_2_BPA_Data import outside_df2
from step_42_utils_calendar import (
    _to_date,
    week_no_mon as week_number_mon_start,  # 월요일 시작 주차
)
from step_43_utils_label_group import (
    ROW_LABELS,
    BASE_VENDORS,
    PRINT_ORDER,
    GROUP_DEFS,
    BORDER_THIN,
    resolve_group_members,
)
from step_44_utils_TPD import load_capacity, tpd_month, tpd_week

# ─────────────────────────────────────────────
# 전역/상수
# ─────────────────────────────────────────────
TODAY = dt.date.today()
DEFAULT_YEAR = TODAY.year

TITLE_MONTH = TODAY.month  # 타이틀에 쓸 '오늘 기준 월'
WEEK_COLS = [f"{w}주" for w in range(1, 53 + 1)]  # 1..53

FIRST_WEEK_COL = 2  # B열
LAST_WEEK_COL = 1 + len(WEEK_COLS)  # A=1, ... BB=54


# ─────────────────────────────────────────────
# 계획/실적 주간 피벗 생성
# ─────────────────────────────────────────────
def _weight_col(df: pd.DataFrame) -> str:
    """
    중량 컬럼명 자동 판별.

    - '고유_중량' 우선
    - 없으면 '중량_고유' 사용
    """
    if "고유_중량" in df.columns:
        return "고유_중량"
    if "중량_고유" in df.columns:
        return "중량_고유"
    raise KeyError("중량 컬럼 누락('고유_중량' 또는 '중량_고유').")


def build_weekly_plan_actual(df_year: pd.DataFrame, year: int):
    """
    협력사별 1~53주 계획/실적 피벗 생성.

    - 계획 기준: 기준계획_완료
    - 실적 기준: 실적_완료
    - 연도 경계: 해당 연도(year)에 속하는 날짜만 집계
    """
    wcol = _weight_col(df_year)
    df = df_year.copy()

    # ── 계획 (기준계획_완료 기준) ─────────────────────
    if "기준계획_완료" not in df.columns:
        raise KeyError("기준계획_완료 누락")

    df["계획일"] = df["기준계획_완료"].apply(_to_date)
    df["계획주"] = df["계획일"].apply(lambda d: week_number_mon_start(d, year))

    plan = (
        df.dropna(subset=["계획주"])
        .groupby(["협력사", "계획주"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "계획", "계획주": "주"})
    )

    # ── 실적 (실적_완료 기준) ───────────────────────
    if "실적_완료" not in df.columns:
        raise KeyError("실적_완료 누락")

    df["실적일"] = df["실적_완료"].apply(_to_date)
    df["실적주"] = df["실적일"].apply(lambda d: week_number_mon_start(d, year))

    actual = (
        df.dropna(subset=["실적주"])
        .groupby(["협력사", "실적주"], as_index=False)[wcol]
        .sum()
        .rename(columns={wcol: "실적", "실적주": "주"})
    )

    # ── 피벗: index=협력사, columns=주(1~53) ─────────
    plan_pv = plan.pivot_table(
        index="협력사",
        columns="주",
        values="계획",
        aggfunc="sum",
        fill_value=0.0,
    )
    actual_pv = actual.pivot_table(
        index="협력사",
        columns="주",
        values="실적",
        aggfunc="sum",
        fill_value=0.0,
    )

    # 1~53주 컬럼 강제 생성
    for w in range(1, 54):
        if w not in plan_pv.columns:
            plan_pv[w] = 0.0
        if w not in actual_pv.columns:
            actual_pv[w] = 0.0

    plan_pv = plan_pv[[w for w in range(1, 54)]].sort_index()
    actual_pv = actual_pv[[w for w in range(1, 54)]].sort_index()

    return plan_pv, actual_pv

def _recent_tpd_month(cap_df: pd.DataFrame, vendor: str, month: int):
    """
    월별 TPD:
    - 해당 월(month)에 값이 있으면 그 값
    - 없으면 과거 월 중 가장 최근 값
    - 전부 없으면 None
    """
    v = tpd_month(cap_df, vendor, month)
    if not pd.isna(v):
        return float(v)

    for m in range(month - 1, 0, -1):
        prev = tpd_month(cap_df, vendor, m)
        if not pd.isna(prev):
            return float(prev)

    return None


def _recent_tpd_week(cap_df: pd.DataFrame, vendor: str, year: int, week: int):
    """
    주간 TPD:
    - 해당 주(week)에 값이 있으면 그 값
    - 없으면 과거 주 중 가장 최근 값
    - 전부 없으면 None
    """
    v = tpd_week(cap_df, vendor, year, week)
    if not pd.isna(v):
        return float(v)

    for w in range(week - 1, 0, -1):
        prev = tpd_week(cap_df, vendor, year, w)
        if not pd.isna(prev):
            return float(prev)

    return None

# ─────────────────────────────────────────────
# 조회주 이후 공백 처리 (엑셀 공란용)
# ─────────────────────────────────────────────
def _mask_after_query(arr_like, q_week: int):
    """
    조회주(q_week) 이후(미래 구간)를 None으로 마스킹.

    예)
        q_week = 10이면
        - index 0~8  : 1~9주 → 값 유지
        - index 9    : 10주   → 값 유지
        - index 10~: 11주~   → None 처리
    """
    masked = list(pd.Series(arr_like).astype(object))
    # 0-based index, q_week 이후(> q_week) 구간을 None 처리하고 싶으면 range(q_week, 53)
    for i in range(q_week, 53):
        masked[i] = None
    return masked


# ─────────────────────────────────────────────
# 행렬 생성 (협력사 / 그룹·전체)
# ─────────────────────────────────────────────
def matrix_vendor(
    cap_df: pd.DataFrame,
    plan_pv: pd.DataFrame,
    actual_pv: pd.DataFrame,
    vendor: str,
    year: int,
    query_week: int,
) -> pd.DataFrame:
    """
    단일 협력사에 대한 주간 행렬 생성.

    행: ROW_LABELS (능력, 계획, 실적, 누계차, 지연일수)
    열: WEEK_COLS ("1주" ~ "53주")
    """
    # 능력: 해당 주 TPD 없으면 과거 최근 주 TPD 사용
    cap_list = []
    for w in range(1, 54):
        v = _recent_tpd_week(cap_df, vendor, year, w)
        cap_list.append(v)
    cap_full = np.array(cap_list, dtype=object)

    plan = plan_pv.loc[vendor].values if vendor in plan_pv.index else np.zeros(53)
    actual = actual_pv.loc[vendor].values if vendor in actual_pv.index else np.zeros(53)

    diff = np.nan_to_num(actual) - np.nan_to_num(plan)
    cumsum = np.cumsum(diff)

    # 지연일수 계산용: 능력 0 또는 None → 0으로 처리 후, 0이면 None 반환
    cap_for_delay = np.array(
        [float(x) if isinstance(x, (int, float, np.floating)) else 0.0 for x in cap_full],
        dtype=float,
    )
    delay_all = []
    for i in range(53):
        denom = cap_for_delay[i]
        delay_all.append(cumsum[i] / denom if denom != 0 else None)

    # 조회주 이후 공란 처리 (능력/실적/누계차/지연일수)
    cap_masked = _mask_after_query(cap_full, query_week)
    actual_masked = _mask_after_query(actual, query_week)
    cumsum_masked = _mask_after_query(cumsum, query_week)
    delay_masked = _mask_after_query(delay_all, query_week)

    return pd.DataFrame(
        [cap_masked, plan, actual_masked, cumsum_masked, delay_masked],
        index=ROW_LABELS,
        columns=WEEK_COLS,
    )


def matrix_total(
    cap_df: pd.DataFrame,
    plan_pv: pd.DataFrame,
    actual_pv: pd.DataFrame,
    vendors: List[str],
    year: int,
    query_week: int,
) -> pd.DataFrame:
    """
    여러 협력사(그룹/전체)의 주간 합산 행렬 생성.

    - 능력: 협력사별 주간 능력 합계
    - 계획/실적: 협력사별 주간 계획·실적 합계
    """
    vendors = list(vendors)

    # 능력 합계: 각 협력사의 최근 주간 TPD를 합산, 전부 없으면 None
    cap_list = []
    for w in range(1, 54):
        vals = [_recent_tpd_week(cap_df, v, year, w) for v in vendors]
        nums = [x for x in vals if x is not None and not pd.isna(x)]
        cap_list.append(sum(nums) if nums else None)
    cap_full = np.array(cap_list, dtype=object)

    plan_rows = [
        plan_pv.loc[v].values if v in plan_pv.index else np.zeros(53) for v in vendors
    ]
    actual_rows = [
        actual_pv.loc[v].values if v in actual_pv.index else np.zeros(53) for v in vendors
    ]
    plan = np.nansum(np.vstack(plan_rows), axis=0) if plan_rows else np.zeros(53)
    actual = np.nansum(np.vstack(actual_rows), axis=0) if actual_rows else np.zeros(53)

    diff = np.nan_to_num(actual) - np.nan_to_num(plan)
    cumsum = np.cumsum(diff)

    cap_for_delay = np.array(
        [float(x) if isinstance(x, (int, float, np.floating)) else 0.0 for x in cap_full],
        dtype=float,
    )
    delay_all = [
        (cumsum[i] / cap_for_delay[i]) if cap_for_delay[i] != 0 else None
        for i in range(53)
    ]

    cap_masked = _mask_after_query(cap_full, query_week)
    actual_masked = _mask_after_query(actual, query_week)
    cumsum_masked = _mask_after_query(cumsum, query_week)
    delay_masked = _mask_after_query(delay_all, query_week)

    return pd.DataFrame(
        [cap_masked, plan, actual_masked, cumsum_masked, delay_masked],
        index=ROW_LABELS,
        columns=WEEK_COLS,
    )


# ─────────────────────────────────────────────
# Excel 출력 유틸
# ─────────────────────────────────────────────
def borders(ws, r1: int, r2: int, c1: int = 1, c2: int = LAST_WEEK_COL) -> None:
    """지정 영역에 얇은 테두리(BORDER_THIN) 일괄 적용."""
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            ws.cell(row=r, column=c).border = BORDER_THIN


def write_header_row(ws, row: int) -> None:
    """행렬 상단 헤더(구분/주차)를 그린다."""
    # A열: "구분 (단위: ton)"
    ca = ws.cell(row=row, column=1, value="구분 (단위: ton)")
    ca.font = Font(bold=True)
    ca.alignment = Alignment(horizontal="center", vertical="center")

    # B~BB열: "1주"~"53주"
    for idx, wlab in enumerate(WEEK_COLS, start=FIRST_WEEK_COL):
        cell = ws.cell(row=row, column=idx, value=wlab)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.column_dimensions[get_column_letter(idx)].width = 10

    borders(ws, row, row, 1, LAST_WEEK_COL)


def write_block(ws, start_row: int, title: str, mat: pd.DataFrame) -> int:
    """
    타이틀 + 헤더 + 데이터 블록 1개를 작성.

    Parameters
    ----------
    ws        : Worksheet
    start_row : 블록 시작 행 (타이틀 위치)
    title     : "협력사명_TPD톤/일" 형식의 타이틀 문자열
    mat       : matrix_vendor / matrix_total 결과 DataFrame

    Returns
    -------
    int
        다음 블록이 시작될 행 번호
    """
    # ── 타이틀 라인 ─────────────────────────────
    t = ws.cell(row=start_row, column=1, value=title)
    t.font = Font(bold=True, size=12)
    t.alignment = Alignment(horizontal="left", vertical="center")

    # ── 헤더 행 ────────────────────────────────
    hdr = start_row + 1
    write_header_row(ws, hdr)

    # ── 데이터 영역 ────────────────────────────
    data_start = hdr + 1
    for i, rname in enumerate(ROW_LABELS):
        r = data_start + i
        # 좌측 행 라벨 (능력, 계획, 실적, 누계차, 지연일수)
        ws.cell(row=r, column=1, value=rname).alignment = Alignment(
            horizontal="left", vertical="center"
        )
        # 주차별 값
        for j, wlab in enumerate(WEEK_COLS, start=FIRST_WEEK_COL):
            val = mat.loc[rname, wlab]
            cell = ws.cell(row=r, column=j, value=val)
            cell.alignment = Alignment(horizontal="right", vertical="center")
            # 지연일수만 소수 1자리, 나머지는 정수형(천단위 콤마)
            cell.number_format = "0.0" if rname == "지연일수" else "#,##0"

    # ── 음수값 빨간색 (조건부 서식) ───────────────
    rng = (
        f"{get_column_letter(FIRST_WEEK_COL)}{data_start}:"
        f"{get_column_letter(LAST_WEEK_COL)}{data_start + len(ROW_LABELS) - 1}"
    )
    ws.conditional_formatting.add(
        rng,
        CellIsRule(
            operator="lessThan",
            formula=["0"],
            stopIfTrue=False,
            font=Font(color="FF0000"),
        ),
    )

    # ── 테두리, 다음 블록 시작행 반환 ────────────
    borders(ws, data_start, data_start + len(ROW_LABELS) - 1, 1, LAST_WEEK_COL)
    return data_start + len(ROW_LABELS) + 1


def autosize_left(ws) -> None:
    """A열(구분) 너비 자동(고정폭) 설정."""
    ws.column_dimensions["A"].width = 16


# ─────────────────────────────────────────────
# 메인
# ─────────────────────────────────────────────
def main(year: int = DEFAULT_YEAR) -> None:
    """
    주간 조립 계획/실적 현황 엑셀 생성.

    - year : 조회 기준 연도
    """
    # 1) 원천 데이터(해당 연도) — step_2_BPA_Data.outside_df2 사용
    df_year = outside_df2(year)
    if df_year.empty:
        raise ValueError(f"[step_2] {year}년 데이터가 비어 있습니다.")

    if "협력사" not in df_year.columns:
        raise KeyError("[step_2] 협력사 컬럼이 없습니다.")

    vendors_all = df_year["협력사"].astype(str).unique().tolist()

    # 실제 존재하는 협력사만 사용
    base_vendors = [v for v in BASE_VENDORS if v in vendors_all]

    # 2) 능력(TPD) 정보
    cap_df = load_capacity(year)
    if cap_df.empty:
        raise ValueError(f"[능력] {year}년 데이터 없음")

    # 3) 주간 계획/실적 피벗
    plan_pv, actual_pv = build_weekly_plan_actual(df_year, year)

    # 4) 조회주(월요일 시작, 오늘 기준)
    query_week = week_number_mon_start(TODAY, year) or 1

    # 5) 타이틀용 TPD (개별 협력사 기준)
    vendor_title_tpd = {}
    for v in base_vendors:
        val = _recent_tpd_month(cap_df, v, TITLE_MONTH)
        vendor_title_tpd[v] = 0.0 if val is None else float(val)

    def title_tpd(name: str) -> float:
        """
        타이틀(이름_XX.X톤/일)에 들어갈 TPD 값 계산.

        - 개별 협력사: 조회월 TPD 없으면 과거 월의 최근 TPD 사용
        - 그룹/전체: 구성원 협력사들의 '최근 월 TPD' 합계
        """
        # 개별 협력사
        if name in vendor_title_tpd:
            return float(vendor_title_tpd[name])

        # 그룹/전체 (예: 일반, 전문화, 해양, 전체 등)
        members = resolve_group_members(name, vendors_all)
        if not members:
            return 0.0

        total = 0.0
        for v in members:
            rv = _recent_tpd_month(cap_df, v, TITLE_MONTH)
            if rv is not None:
                total += rv
        return total

    # 6) 엑셀 워크북 구성
    wb = Workbook()
    ws = wb.active
    ws.title = "주간_조립_계획실적"

    row = 1

    # PRINT_ORDER 순서대로 블록 출력
    for name in PRINT_ORDER:
        # 1) 전체/그룹(합산)
        if name == "전체":
            members = resolve_group_members("전체", vendors_all)
            if members:
                mat = matrix_total(cap_df, plan_pv, actual_pv, members, year, query_week)
            else:
                mat = pd.DataFrame(0, index=ROW_LABELS, columns=WEEK_COLS, dtype=object)

        elif name in GROUP_DEFS:
            members = resolve_group_members(name, vendors_all)
            if members:
                mat = matrix_total(cap_df, plan_pv, actual_pv, members, year, query_week)
            else:
                mat = pd.DataFrame(0, index=ROW_LABELS, columns=WEEK_COLS, dtype=object)

        # 2) 개별 협력사
        else:
            mat = matrix_vendor(cap_df, plan_pv, actual_pv, name, year, query_week)

        tpd_val = title_tpd(name)
        row = write_block(ws, row, f"{name}_{tpd_val:,.1f}톤/일", mat)

    autosize_left(ws)

    # 7) 파일 저장
    query_date = dt.date.today()
    date_folder = query_date.strftime("%Y-%m-%d")  
    target_dir = OUT_DIR / date_folder
    target_dir.mkdir(parents=True, exist_ok=True)
    date_suffix = query_date.strftime("%y%m%d")
    file_name = f"{year}년도_사외_주간_조립_계획실적_현황_{date_suffix}.xlsx"
    out_path = target_dir / file_name
    wb.save(out_path)
    print(f"[OK] 저장 완료: {out_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="주간 조립 계획/실적")
    parser.add_argument("-y", "--year", type=int, default=DEFAULT_YEAR)
    args = parser.parse_args()
    main(year=args.year)
