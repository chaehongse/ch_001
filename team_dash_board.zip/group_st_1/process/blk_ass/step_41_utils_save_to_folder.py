from __future__ import annotations
"""
step_41_utils_save_to_folder.py

엑셀 파일과 로그 파일을 "조회일 기준 날짜 폴더"에 저장하기 위한 공용 유틸리티.

폴더 구조 예시
--------------
OUT_DIR/
    2025-11-26/          ← get_excel_save_dir(2025-11-26) 반환
        ...엑셀 파일들
    logs/
        2025-11-26/      ← get_log_save_dir(2025-11-26) 반환
            ...로그 파일들

주요 사용 패턴
--------------
from step_41_utils_save_to_folder import get_excel_save_dir, get_log_save_dir

excel_dir = get_excel_save_dir(query_date)
excel_path = excel_dir / "파일이름.xlsx"

log_dir = get_log_save_dir(query_date)
log_path = log_dir / "로그이름.csv"

※ query_date 는 datetime.date 타입을 사용합니다.
"""

from pathlib import Path
import datetime as dt

from step_0_MSF import OUT_DIR  # 프로젝트 공통 출력 루트 디렉터리


# ─────────────────────────────────────────────
# 기본 루트 폴더 설정
# ─────────────────────────────────────────────
# 엑셀 저장 루트: OUT_DIR 바로 아래 날짜 폴더
EXCEL_ROOT = OUT_DIR

# 로그 저장 루트: OUT_DIR/logs 아래 날짜 폴더
LOG_ROOT = OUT_DIR / "logs"


# ─────────────────────────────────────────────
# 내부 유틸
# ─────────────────────────────────────────────
def _ensure_date_folder(root: Path, query_date: dt.date) -> Path:
    """
    주어진 root 하위에 'yyyy-mm-dd' 이름의 날짜 폴더를 생성(또는 재사용)하고 Path를 반환합니다.

    예)
        root      = OUT_DIR
        query_date = date(2025, 11, 26)

        반환값: OUT_DIR / '2025-11-26'
    """
    if not isinstance(query_date, dt.date):
        raise TypeError("query_date 는 datetime.date 타입이어야 합니다.")

    dname = query_date.strftime("%Y-%m-%d")
    folder = root / dname
    folder.mkdir(parents=True, exist_ok=True)
    return folder


# ─────────────────────────────────────────────
# 공개 함수: 엑셀 / 로그 저장 경로
# ─────────────────────────────────────────────
def get_excel_save_dir(query_date: dt.date) -> Path:
    """
    엑셀 저장용 날짜 폴더 Path 반환.

    예)
        query_date = date(2025, 11, 26)
        → OUT_DIR / '2025-11-26'
    """
    return _ensure_date_folder(EXCEL_ROOT, query_date)


def get_log_save_dir(query_date: dt.date) -> Path:
    """
    로그 저장용 날짜 폴더 Path 반환.

    예)
        query_date = date(2025, 11, 26)
        → OUT_DIR / 'logs' / '2025-11-26'
    """
    return _ensure_date_folder(LOG_ROOT, query_date)


# ─────────────────────────────────────────────
# 단독 실행용 간단 테스트
# ─────────────────────────────────────────────
if __name__ == "__main__":
    today = dt.date.today()
    excel_dir = get_excel_save_dir(today)
    log_dir = get_log_save_dir(today)
    print("Excel dir:", excel_dir)
    print("Log dir  :", log_dir)
