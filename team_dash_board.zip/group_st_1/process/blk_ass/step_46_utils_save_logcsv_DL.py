from __future__ import annotations
"""
step_46_utils_save_logcsv_DL.py

DL 로그 CSV 저장 래퍼 (공통 유틸 사용)
"""

import datetime as dt
from pathlib import Path
from typing import List

from step_0_MSF import OUT_DIR
from step_46_utils_save_logcsv_common import write_csv_log_common
from step_48_utils_logs_upload_DL import upload_log_df_to_db


def write_csv_log_DL(
    year: int,
    query_date: dt.date,
    rows: List[dict],
    engine_tag: str,
    db_url: str,
    table_name: str = "예측_모델_log_dl",
) -> None:
    priority_cols = [
        "timestamp",
        "year",
        "협력사",
        "tag",
        "engine",
        "R2_train",
        "R2_valid",
        "MAE_valid",
        "RMSE_valid",
        "val_loss",
        "split_ratio",
        "train_range",
        "valid_range",
    ]

    def _upload(df, db_url_inner):
        upload_log_df_to_db(df, db_url_inner, table=table_name)

    logs_dir = Path(OUT_DIR) / "logs_dl"
    write_csv_log_common(
        year=year,
        query_date=query_date,
        rows=rows,
        engine_tag=engine_tag,
        db_url=db_url,
        table_name=table_name,
        logs_dir=logs_dir,
        priority_cols=priority_cols,
        upload_func=_upload,
    )
