# -*- coding: utf-8 -*-
"""
step_5.py — 조립 P/R 미발행 목록 산출(주석 확장/안정성 강화판)
──────────────────────────────────────────────────────────────────────────────
목적
  • 실행 시점(한국시간, KST)을 '조회일'로 간주하여, 조립 P/R 미발행 대상 목록을 생성/저장.
  • 조건:
      1) '조립P/R확정일'이 비어있음(결측/빈칸/NaT)
      2) '관리납품일' ≤ (조회일 + 30일)
      3) (옵션) '관리납품일' ≥ MIN_DATE (데이터 노이즈 컷오프)
      4) '협력사명'이 step_3_1.EXCLUDE_SUPPLIERS(소문자 완전일치) 목록에 없는 행만 포함
  • 출력 컬럼(가능한 한 유지): ['프로젝트','블록','관리납품일','협력사명','납품처']
  • 저장: step_1.OUT_DIR / 셀가이드_조립PR_미발행_YYYYMMDD.xlsx

포인트
  • 컬럼명 정규화(개행/공백 제거) → 원천 스키마 변동/개행 문제 대응
  • 결측/빈 문자열/NaT 를 '미발행'으로 일괄 판단
  • 협력사 제외는 소문자·공백트림 후 완전 일치로 비교(데이터 표기 흔들림 방지)
  • 누락 컬럼은 친절히 에러/경고 출력 후 최대한 진행(특히 '납품처'가 없을 수도 있음)
  • 엑셀 저장 시 오토필터/헤더 고정/열 너비 자동화

주의
  • step_2.main()이 실제 데이터를 반환해야 정상 동작.
  • 네트워크 공유 OUT_DIR 권한/연결은 step_1.py에서 준비되어 있어야 함.
──────────────────────────────────────────────────────────────────────────────
"""


from datetime import datetime, timedelta, timezone, date
from typing import Iterable, Optional

import os
import pandas as pd
import openpyxl  # noqa: F401  (엑셀 writer 엔진 의존성용)

from step_1 import OUT_DIR              # 저장 경로
import step_2                           # 데이터 로더: step_2.main()
import step_3_1                         # 협력사 제외 상수: step_3_1.EXCLUDE_SUPPLIERS

# ── 모듈 메타 (main_app 등에서 제목으로 사용할 수 있게) ────────────────
title = "조립 PR 미발행"  # main_app에서 step_5.title 참조 가능

# ── 타임존(KST) ────────────────────────────────────────────────────────
KST = timezone(timedelta(hours=9))

# ── 옵션: 최소 관리납품일 컷오프(노이즈/구데이터 배제용) ────────────────
ENFORCE_MIN_DATE = True
MIN_DATE: date = date(2025, 1, 1)  # 필요 시 False 또는 다른 날짜로 조정


# ── 유틸 ───────────────────────────────────────────────────────────────
def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """컬럼명의 개행/캐리지리턴 제거 + 좌우 공백 제거."""
    out = df.copy()
    out.columns = [str(c).replace("\n", "").replace("\r", "").strip() for c in out.columns]
    return out


def _to_date_inplace(df: pd.DataFrame, col: str) -> None:
    """지정 열을 pandas datetime.date로 변환(문자열/숫자 허용, 파싱 실패→NaT→NaN)."""
    if col in df.columns:
        df[col] = pd.to_datetime(df[col], errors="coerce").dt.date


def _is_blank_series(s: pd.Series) -> pd.Series:
    """결측 판정 헬퍼: NaN/NaT/빈문자열(''/'NaT' 문자열 포함)을 True로.

    - datetime dtype → isna()로 충분
    - object/str dtype → 공백트림 후 ''/NaT/None 도 결측으로 처리
    """
    if s.dtype.kind == "M":  # datetime64[ns]
        return s.isna()
    # 문자열/객체
    return s.isna() | (s.astype(str).str.strip().isin(["", "NaT", "None"]))


def _get_exclude_suppliers_from_step3() -> list[str]:
    """step_3_1.EXCLUDE_SUPPLIERS(소문자/트림) 읽기. 없으면 빈 리스트."""
    if hasattr(step_3_1, "EXCLUDE_SUPPLIERS"):
        raw = getattr(step_3_1, "EXCLUDE_SUPPLIERS")
        if isinstance(raw, (list, tuple, set)):
            return [str(x).strip().lower() for x in raw if str(x).strip()]
    return []


# ── 핵심 로직 ─────────────────────────────────────────────────────────
def build_unissued_pr_list(df_master: pd.DataFrame, query_dt: datetime) -> pd.DataFrame:
    """
    입력:
      df_master: step_2.main() 결과 전체 DF
      query_dt : 조회일(한국시간 KST 권장)

    필터 조건:
      • 조립P/R확정일 결측(미발행)
      • 관리납품일 ≤ 조회일+30일
      • (옵션) 관리납품일 ≥ MIN_DATE
      • 협력사명 not in step_3_1.EXCLUDE_SUPPLIERS

    출력 컬럼(있는 범위에서 최대한 유지):
      ['프로젝트','블록','관리납품일','협력사명','납품처']
    """
    df = _normalize_columns(df_master)

    # (1) 날짜 컬럼 변환
    _to_date_inplace(df, "관리납품일")

    # (2) 결측 판단을 위한 시리즈 준비
    pr_col = "조립P/R확정일"
    if pr_col not in df.columns:
        raise KeyError(f"필수 컬럼 누락: '{pr_col}'")

    # 문자열/혼합 타입에서도 공백/NaT 문자열 등을 결측으로 인식
    pr_blank = _is_blank_series(df[pr_col])

    # (3) 날짜 조건
    cutoff = (query_dt + timedelta(days=30)).date()
    cond_due30 = df["관리납품일"].notna() & (df["관리납품일"] <= cutoff)

    cond_min_date = True
    if ENFORCE_MIN_DATE:
        cond_min_date = df["관리납품일"].notna() & (df["관리납품일"] >= MIN_DATE)

    # (4) 협력사 제외(소문자/트림 후 완전 일치)
    exclude_lower = _get_exclude_suppliers_from_step3()
    if "협력사명" in df.columns and exclude_lower:
        cond_exclude = ~df["협력사명"].astype(str).str.strip().str.lower().isin(exclude_lower)
    else:
        cond_exclude = pd.Series(True, index=df.index)

    # (5) 최종 필터링
    mask = pr_blank & cond_due30 & cond_min_date & cond_exclude
    filtered = df.loc[mask].copy()

    # (6) 결과 컬럼 구성 — 없는 컬럼은 무시(최대한 유지)
    want_cols: list[str] = ["프로젝트", "블록", "관리납품일", "협력사명", "납품처"]
    have_cols = [c for c in want_cols if c in filtered.columns]
    out = filtered.loc[:, have_cols].copy()

    # (7) 정렬: 관리납품일 → 프로젝트 → 블록(있는 것만)
    sort_cols = [c for c in ["관리납품일", "프로젝트", "블록"] if c in out.columns]
    if sort_cols:
        out = out.sort_values(by=sort_cols, kind="stable")

    # (8) index reset
    out = out.reset_index(drop=True)
    return out


def save_to_excel(df_out: pd.DataFrame, query_dt: datetime) -> str:
    """
    결과를 엑셀로 저장.
      • 파일명: 셀가이드_조립PR_미발행_YYYYMMDD.xlsx
      • Sheet1: 데이터 + 오토필터 + 헤더 고정 + 기본 열 너비
    """
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    # 동일 접두어 파일 정리(선택사항: 필요 없으면 주석)
    for file in os.listdir(OUT_DIR):
        if file.startswith("셀가이드_조립PR_미발행_") and file.endswith(".xlsx"):
            try:
                os.remove(os.path.join(OUT_DIR, file))
            except OSError:
                pass

    ymd = query_dt.strftime("%Y%m%d")
    xlsx_path = OUT_DIR / f"셀가이드_조립PR_미발행_{ymd}.xlsx"

    with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
        sheet = "PR_미발행_조회+30"
        df_out.to_excel(writer, index=False, sheet_name=sheet)

        wb = writer.book
        ws = wb[sheet]

        # 오토필터 & 헤더 고정
        ws.auto_filter.ref = ws.dimensions
        ws.freeze_panes = "A2"

        # 간단 열 너비(최대 60자 제한)
        for j, col in enumerate(df_out.columns, start=1):
            max_len = max([len(str(col))] + [len(str(v)) for v in df_out[col].fillna("")])
            ws.column_dimensions[ws.cell(row=1, column=j).column_letter].width = min(max_len + 2, 60)

    return str(xlsx_path.resolve())


def run(query_dt: Optional[datetime] = None) -> None:
    """
    전체 파이프라인 실행:
      1) 조회일 결정(기본: 지금 KST)
      2) step_2.main()으로 원본 로드
      3) 미발행 목록 필터링
      4) 엑셀 저장
    """
    if query_dt is None:
        query_dt = datetime.now(KST)

    print(f"[info] 조회일(KST): {query_dt.strftime('%Y-%m-%d')}")

    # 1) 데이터 로드
    df_master = step_2.main()
    if df_master is None or df_master.empty:
        raise RuntimeError("step_2.main() 결과가 비어 있습니다. DB/권한/쿼리를 확인하세요.")
    print(f"[info] 원본 DF: {df_master.shape}")

    # 2) 목록 생성
    df_out = build_unissued_pr_list(df_master, query_dt)
    print(f"[info] 최종 행 수: {len(df_out)}")

    # 3) 미리보기(상위 20행)
    print("\n[preview] 상위 20행:")
    if df_out.empty:
        print("(비어있음)")
    else:
        for i, row in enumerate(df_out.head(20).to_dict(orient="records"), 1):
            print(f"  {i:02d}. {row}")

    # 4) 저장
    saved_path = save_to_excel(df_out, query_dt)
    print(f"\n[done] 엑셀 저장 완료: {saved_path}")


if __name__ == "__main__":
    run()
