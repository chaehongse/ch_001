# -*- coding: utf-8 -*-
"""
step_3_1.py — 데이터 처리 및 분석(생산): 월별 '계획/실적/누계차' 산출 + 엑셀 저장 (주석 확장판)
──────────────────────────────────────────────────────────────────────────────
목적
  • step_2.main()의 표준 DataFrame을 입력 받아, 생산(조립) 관점 월별 지표(계획/실적/누계/누계차)를 산출합니다.
  • 시각화/대시보드/보고서에서 바로 쓰도록 '행렬표(matrix)'와 '피벗(pivot)'을 함께 제공합니다.
  • 보고용 엑셀(OUT_DIR/월별_생산_계획_실적.xlsx)로도 저장합니다.

핵심 로직
  1) 협력사 제외 필터(EXCLUDE_SUPPLIERS)
  2) 타입 정규화: 날짜(관리납품일/조립완료(실적)), 수치(중량합계(A))
  3) 월 키(YY-MM) 생성 후 월별 합계(kg) 집계 → 톤 단위 변환(kg/1000)
  4) 기준월(오늘, KST) 이후의 실적/누계는 그래프 시 '끊김' 효과를 위해 NaN 유지
  5) 과거/현재월 실적 결측은 0으로 보정(actual_disp) — 보고 시 빈칸 방지
  6) 누계(계획/실적) 및 누계차(실적-계획) 계산
  7) 미래월에 실적이 들어온 경우 '누계차(표시)="이상"'으로 마킹(데이터 검증 신호)
  8) 엑셀 저장(숫자/문자 혼재 대응, 서식/열너비/스크롤 고정)

출력
  • matrix(DataFrame; 가로형): index=["계획","실적","누계차","누계차(표시)"], columns=["YY-MM", ...]
  • pivot (DataFrame; 세로형): columns=["계획","실적","누계차","누계차(표시)"], index=["YY-MM", ...]
  • OUT_DIR/월별_생산_계획_실적.xlsx (Sheet1=matrix, Sheet2=pivot)

주의/팁
  • 단위: 원천은 kg → 내부 계산은 톤(kg/1000). 보고서는 소수 1자리(0.1톤) 포맷.
  • 미래월 실적 입력 시 이상치로 간주하여 로그 출력 + 표시값 "이상"으로 명시.
  • sort_yy_mm는 'YY-MM' 기준 정렬(세기 20XX 고정) — 연도 넘어가도 안정 작동.
  • 다운스트림(대시보드)와의 호환을 위해 반환 구조/컬럼명은 변경하지 않습니다.
──────────────────────────────────────────────────────────────────────────────
"""

import math
from datetime import datetime, timezone, timedelta
from typing import List, Tuple, Optional

import numpy as np
import pandas as pd

import openpyxl  # noqa: F401  # 엑셀 저장 엔진(openpyxl/xlsxwriter) 의존성 유지 목적
import xlsxwriter

from step_1 import OUT_DIR
import step_2  # 원천 로더(표준 컬럼으로 변환까지 수행)


# 제외할 협력사명: 필요 시 자유롭게 수정/추가하세요.
#  - 비교는 "소문자 완전 일치" 기준(공백 트리밍 포함).
EXCLUDE_SUPPLIERS: List[str] = [
    "영성법인1공장",
    "한화오션(산동)",
]

# 운영 시간대: 한국 표준시
KST = timezone(timedelta(hours=9))


# ──────────────────────────────────────────────────────────────────────────────
# Helper: 월 키/정렬/엑셀 열너비
# ──────────────────────────────────────────────────────────────────────────────
def sort_yy_mm(cols: List[str]) -> List[str]:
    """'YY-MM' 문자열 리스트를 시간순으로 정렬.

    구현 디테일
      • '20' 접두를 붙여 'YYYY-MM'로 확장 → PeriodIndex(freq='M')로 정렬.
      • 입력이 비어있다면 그대로 반환.
    """
    if not cols:
        return cols
    periods = pd.PeriodIndex(["20" + c for c in cols], freq="M")
    order = periods.argsort()
    return [cols[i] for i in order]


def _autoset_col_widths(
    worksheet,
    df: pd.DataFrame,
    start_row: int = 0,
    start_col: int = 0,
    min_w: int = 7,
    max_w: int = 18,
) -> None:
    """엑셀 시트의 열 너비를 데이터 길이에 맞춰 대략 자동 조정.

    포인트
      • 숫자열은 가독성을 위해 약간 작게(0.85 배) 반영.
      • 0열(인덱스 헤더)은 외부에서 별도 set_column 했으므로 1열부터 조정.
    """
    for j, col in enumerate(df.columns):
        series = df[col].astype(str).fillna("")
        max_len = max([len(col)] + [len(s) for s in series])
        if pd.api.types.is_numeric_dtype(df[col].dtype):
            max_len = max(6, math.ceil(max_len * 0.85))
        width = max(min_w, min(max_w, max_len + 1))
        worksheet.set_column(start_col + 1 + j, start_col + 1 + j, width)


def _yy_mm_period(yy_mm: str) -> pd.Period:
    """'YY-MM' → Period('20YY-MM','M') 변환(월 단위 비교/연산용)."""
    return pd.Period("20" + yy_mm, freq="M")


# ──────────────────────────────────────────────────────────────────────────────
# 요약 통계(보고서 KPI용)
# ──────────────────────────────────────────────────────────────────────────────
def calculate_summary(matrix: pd.DataFrame) -> dict:
    """행렬표(계획/실적/누계차/…)에서 요약 통계(합계, 잔여, 완료률)를 계산.

    반환 예
      {
        "계획_총합계": "1,234톤",
        "실적_총합계": "987톤",
        "잔여조립량": "247톤",
        "조립완료률": "80%",
      }
    """
    # matrix는 dtype=object(문자 혼재)라 숫자합 시 pandas가 자동 캐스팅합니다.
    plan_total = matrix.loc["계획"].sum()
    actual_total = matrix.loc["실적"].sum()
    remain_assembly = plan_total - actual_total
    assembly_rate = (actual_total / plan_total) * 100 if plan_total != 0 else 0

    return {
        "계획_총합계": f"{round(plan_total):,}톤",   # 톤 단위 정수 표기
        "실적_총합계": f"{round(actual_total):,}톤",
        "잔여조립량": f"{round(remain_assembly):,}톤",
        "조립완료률": f"{int(assembly_rate)}%",     # %는 정수로 깔끔하게
    }


# ──────────────────────────────────────────────────────────────────────────────
# 메인 파이프라인
# ──────────────────────────────────────────────────────────────────────────────
def main() -> Optional[Tuple[pd.DataFrame, pd.DataFrame]]:
    """데이터 로드 → 가공 → 지표 산출 → 엑셀 저장.

    반환
      (matrix, pivot)
        - matrix: 가로형(계획/실적/누계차/누계차(표시))
        - pivot : 세로형(동일 지표 컬럼)
      실패/무데이터 시 None
    """
    # 1) 원천 로드(표준 컬럼/형식 보장). 실패 시 종료.
    df = step_2.main()
    if df is None or df.empty:
        print("[ERROR] step_2.main() 결과가 없습니다.")
        return None

    # (안전) 필수 컬럼 존재 여부 빠르게 점검
    required_cols = {"관리납품일", "조립완료(실적)", "중량합계(A)"}
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        print(f"[ERROR] 필수 컬럼 누락: {missing} — step_2 스키마 확인 필요")
        return None

    # 1-1) 협력사 제외 필터(옵션): EXCLUDE_SUPPLIERS 목록과 소문자 완전 일치
    if "협력사명" in df.columns:
        before = len(df)
        excludes_lower = {s.strip().lower() for s in EXCLUDE_SUPPLIERS if s and isinstance(s, str)}
        if excludes_lower:
            df = df[~df["협력사명"].astype(str).str.lower().isin(excludes_lower)].copy()
        after = len(df)
        print(f"[INFO] 협력사 제외 적용: {before - after}건 제거됨 (잔여 {after}건)")
    else:
        print("[WARN] '협력사명' 컬럼이 없어 제외 필터를 적용하지 않았습니다.")

    # 2) 타입 변환(날짜/수치) — 파싱 실패는 NaT/NaN으로 통일
    df["관리납품일"] = pd.to_datetime(df["관리납품일"], errors="coerce")
    df["조립완료(실적)"] = pd.to_datetime(df["조립완료(실적)"], errors="coerce")
    df["중량합계(A)"] = pd.to_numeric(df["중량합계(A)"], errors="coerce").astype(float)

    # 3) 월 키 생성('YY-MM')
    #    - 계획 기준: '관리납품일' (계획 월)
    #    - 실적 기준: '조립완료(실적)' (실적 월)
    df["계획_년월"] = df["관리납품일"].dt.strftime("%y-%m")
    df["실적_년월"] = df["조립완료(실적)"].dt.strftime("%y-%m")

    # 4) 월별 합계(kg) → 계획/실적 (NaT는 dropna로 제거)
    plan_kg = (
        df.dropna(subset=["계획_년월"])
          .groupby("계획_년월")["중량합계(A)"]
          .sum()
          .astype(float)
    )
    actual_kg = (
        df.dropna(subset=["실적_년월"])
          .groupby("실적_년월")["중량합계(A)"]
          .sum()
          .astype(float)
    )

    # 5) 컬럼(월) 구성: 계획 ∪ 실적(합집합) → 시간순 정렬
    months = sort_yy_mm(sorted(set(plan_kg.index).union(set(actual_kg.index))))

    #    톤 단위 변환(kg/1000), 소수 1자리로 반올림(보고서 표기 일관)
    plan = (plan_kg / 1000.0).round(1).reindex(months).astype(float)
    actual = (actual_kg / 1000.0).round(1).reindex(months).astype(float)

    # 6) 기준월(오늘, 한국시간)
    기준P = _yy_mm_period(datetime.now(KST).strftime("%y-%m"))

    # 7) 표시용 실적(actual_disp): 과거/현재 결측 → 0, 미래월은 결측(빈칸 유지를 위한 NaN)
    actual_disp = actual.copy()
    for m in months:
        if _yy_mm_period(m) <= 기준P and pd.isna(actual_disp[m]):
            actual_disp[m] = 0.0      # 과거/현재월 결측은 0으로 치환
        # 미래월은 NaN 유지 → 그래프에서 끊김/테이블 빈칸 효과

    # 8) 누계 계산
    #    - 계획 누계: 결측 0 치환 → cumsum
    #    - 실적 누계: 과거/현재 결측 0 보정 → cumsum (미래 결측은 그래프용으로 유지)
    plan_cum = plan.fillna(0.0).astype(float).cumsum()
    actual_cum = actual.copy()
    for m in months:
        if _yy_mm_period(m) <= 기준P and pd.isna(actual_cum[m]):
            actual_cum[m] = 0.0
    actual_cum = actual_cum.astype(float).cumsum()

    # 9) 누계차(수치) = 실적누계 - 계획누계
    #    - 미래월은 그래프 끊김을 위해 NaN으로 비워둡니다.
    diff_cum = (actual_cum - plan_cum).astype(float).round(1)
    for m in months:
        if _yy_mm_period(m) > 기준P:
            diff_cum[m] = np.nan

    # 10) 누계차(표시): 미래 실적이 미리 들어오면 "이상" 마킹, 없으면 빈칸
    diff_display = diff_cum.copy()
    for m in months:
        if _yy_mm_period(m) > 기준P:
            if pd.isna(actual[m]):
                diff_display[m] = pd.NA        # 정상: 미래 실적 없음 → 공란
            else:
                diff_display[m] = "이상"        # 비정상: 미래 실적 존재
                print("미래 실적이 입력되었습니다. 실적 점검 바랍니다. →", m)

    # 11) 행렬표(그래프/보고 공용). 숫자+문자 혼재 → dtype='object'
    matrix = pd.DataFrame(
        [plan, actual_disp, diff_cum, diff_display],
        index=["계획", "실적", "누계차", "누계차(표시)"],
        columns=months,
        dtype="object",
    )

    # 12) 피벗(세로형 참고용): 동일 지표 컬럼 구성
    pivot = pd.DataFrame(
        {
            "계획": plan,
            "실적": actual_disp,
            "누계차": diff_cum,
            "누계차(표시)": diff_display,
        }
    ).reindex(index=months)

    # (옵션) 요약 통계 콘솔 출력 — 대시보드/로거에서 수집 시 유용
    summary = calculate_summary(matrix)
    print("[요약 통계]")
    for k, v in summary.items():
        print(f"  - {k}: {v}")

    # 13) 엑셀 저장(보고서용)
    out_path = OUT_DIR / "월별_생산_계획_실적.xlsx"
    with pd.ExcelWriter(out_path, engine="xlsxwriter") as writer:
        # (1) Sheet1: 행렬표
        matrix.to_excel(writer, sheet_name="Sheet1", startrow=0, startcol=0)
        wb = writer.book
        ws = writer.sheets["Sheet1"]

        # 서식
        fmt_header = wb.add_format({
            "bold": True, "align": "center", "valign": "vcenter",
            "bg_color": "F2F2F2", "border": 1,
        })
        fmt_index = wb.add_format({"bold": True, "border": 1, "align": "center"})
        fmt_num = wb.add_format({"num_format": "#,##0.0", "border": 1})
        fmt_txt = wb.add_format({"border": 1})
        fmt_cell = wb.add_format({"border": 1})

        # 헤더(인덱스 공란 + 월 컬럼)
        for j, col in enumerate([""] + months):
            ws.write(0, j, col, fmt_header)

        # 데이터(행 라벨 + 값)
        for i, idx in enumerate(matrix.index, start=1):
            ws.write(i, 0, idx, fmt_index)  # 행 라벨: "계획", "실적", "누계차", "누계차(표시)"
            for j, col in enumerate(months, start=1):
                val = matrix.loc[idx, col]
                if pd.isna(val):
                    ws.write(i, j, "", fmt_cell)
                elif isinstance(val, (int, float, np.integer, np.floating)):
                    ws.write_number(i, j, float(val), fmt_num)
                else:
                    ws.write(i, j, str(val), fmt_txt)

        # 편의 옵션
        ws.freeze_panes(1, 1)
        ws.set_column(0, 0, 12)  # 인덱스 열
        _autoset_col_widths(ws, pd.DataFrame(columns=months))

        # (2) Sheet2: 피벗(세로형)
        pivot.to_excel(writer, sheet_name="Sheet2", startrow=0, startcol=0)

    print(f"[저장 완료] {out_path}")

    # 후속 모듈(step_4/대시보드)에서 재사용할 수 있도록 반환
    return matrix, pivot


if __name__ == "__main__":
    main()
