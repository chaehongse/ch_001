﻿# -*- coding: utf-8 -*-
"""
step_8.py — 월별 예측(생산 톤 / 납품 SET) + 히스토리 기반 보정
───────────────────────────────────────────────────────────────────────────────
목적
  1) 월별 실적 시계열 생성
      - 생산(prod_ton): '조립완료(실적)' 월 기준 합(중량합계(A) kg → 톤)
      - 납품(deli_set): '납품/선적일' 값 존재 건수(SET)
        (옵션: '관리납품일' 기준 라벨 가능)
  2) 선형회귀로 미래 월 예측
  3) 예측 히스토리 CSV 저장 → 다음 실행 시 최근 실적과 비교해
     스케일(보정계수) 산출/적용
  4) main.py 연동 포맷 반환: ["series", "yyyymm", "pred_raw", "pred_adj"]
      - series ∈ {"prod_ton", "deli_set"}
      - yyyymm: 'yy_mm' (예: '25_01')
      - pred_adj: 보정 적용 최종 예측치(그래프에는 이 값을 사용 권장)

튜닝 포인트
  • run_forecast_on_df(...):
      - train_months       : 선형회귀 학습 개월 수
      - horizons_days      : [30, 60, ...] → ceil(max/30)개월 예측
      - use_history_scale  : 과거 예측 기반 보정 사용 여부
      - scale_lookback_m   : 보정계수 산정 시 사용할 과거 개월 수(기본 6)
      - scale_min / max    : 보정계수 클램프(기본 0.6~1.4)
      - deli_month_basis   : "ship"(납품/선적일 기준) | "manage"(관리납품일 기준)
───────────────────────────────────────────────────────────────────────────────
"""


from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import List, Optional
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

# 저장 경로 (없으면 동작은 하지만 기록 기능은 비활성)
try:
    from step_1 import OUT_DIR  # Path
except Exception:
    OUT_DIR = None

KST = timezone(timedelta(hours=9))
HISTORY_FILENAME = "forecast_history.csv"  # OUT_DIR 하위에 저장


# 유틸
def _to_yy_mm_label_from_period(p: pd.Period) -> str:
    """Period('YYYY-MM') -> 'yy_mm' 라벨."""
    return f"{p.year % 100:02d}_{p.month:02d}"


def _safe_to_period_month(s: pd.Series) -> pd.Series:
    """날짜 시리즈를 월 Period로 변환(파싱 실패는 NaT)."""
    dts = pd.to_datetime(s, errors="coerce")
    try:
        if getattr(dts.dt, "tz", None) is not None:
            dts = dts.dt.tz_localize(None)
    except AttributeError:
            if getattr(dts, "tz", None) is not None:
                dts =dts.tz_localize(None)
    return dts.dt.to_period("M")


def _month_range_after(last_period: pd.Period, n: int) -> List[pd.Period]:
    """마지막 월 이후 n개월 Period 리스트 생성."""
    return [last_period + i for i in range(1, n + 1)]


def _ensure_series(s: pd.Series) -> pd.Series:
    """
    시계열을 PeriodIndex/float로 정규화하고 NaN 제거/정렬.
    """
    if not isinstance(s.index, pd.PeriodIndex):
        idx = pd.to_datetime(s.index, errors="coerce")
        if getattr(idx, "tz", None) is  not None:
            idx = idx.tz_localize(None)
        s.index = idx.to_period("M")
    s = s.sort_index()
    s = s.sort_index()
    return pd.to_numeric(s, errors="coerce").dropna()


def _signature_from_filtered(df: pd.DataFrame) -> str:
    """
    히스토리 구분용 컨텍스트 시그니처 생성.
      - 협력사 리스트 + 포함 연도 조합 기반
    """
    try:
        supp = sorted(set(str(x).strip() for x in df.get("협력사명", pd.Series(dtype=str)).dropna()))
        yrs = (
            pd.to_datetime(df.get("관리납품일"), errors="coerce")
            .dt.year.dropna().astype(int).unique().tolist()
        )
        yrs.sort()
        supp_tag = ",".join(supp)[:200] if supp else "ALL"
        year_tag = ",".join(map(str, yrs)) if yrs else "ALL"
        return f"supp={supp_tag}|years={year_tag}"
    except Exception:
        return "unknown"


# 월별 실적 시계열(메인 그래프와 동일 기준)
def _build_prod_actual_series(filtered: pd.DataFrame) -> pd.Series:
    """
    생산 실적(톤):
      - 기준: 조립완료(실적) 월
      - 값: 중량합계(A) kg 합 → 톤
    """
    kg = pd.to_numeric(filtered.get("중량합계(A)"), errors="coerce")
    done_p = _safe_to_period_month(filtered.get("조립완료(실적)")).dropna()
    vals = kg.loc[done_p.index]
    s = vals.groupby(done_p).sum(min_count=1) / 1000.0  # kg → ton
    return _ensure_series(s)


def _build_deli_actual_series(filtered: pd.DataFrame, month_basis: str = "ship") -> pd.Series:
    """
    납품 실적(SET):
      - 기본(month_basis="ship"): 납품/선적일 존재 건수 카운트
      - 옵션(month_basis="manage"): 관리납품일 기준 라벨 생성
    """
    if month_basis == "manage":
        base_dt = pd.to_datetime(filtered.get("관리납품일"), errors="coerce")
        mask = pd.to_datetime(filtered.get("납품/선적일"), errors="coerce").notna()
    else:  # "ship"
        base_dt = pd.to_datetime(filtered.get("납품/선적일"), errors="coerce")
        mask = base_dt.notna()

    key = base_dt[mask].dt.to_period("M").dropna()
    ones = pd.Series(1.0, index=key.index)
    s = ones.groupby(key).sum(min_count=1)  # SET 카운트
    return _ensure_series(s)


# 선형회귀 예측
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class ForecastConfig:
    train_months: int = 24  # 학습에 사용할 최근 개월 수 (0이면 전체)
    min_points: int = 3     # 선형회귀 최소 데이터 개수


def _forecast_series(s: pd.Series, steps: int, cfg: ForecastConfig) -> np.ndarray:
    """
    시계열 s를 선형회귀로 steps개월 예측.
    - 최근 train_months만 사용(0이면 전체)
    - 데이터가 부족하면 최근 평균으로 대체
    """
    y = _ensure_series(s)
    if len(y) == 0:
        return np.zeros(steps, dtype=float)

    if cfg.train_months and len(y) > cfg.train_months:
        y = y.tail(cfg.train_months)

    if len(y) < cfg.min_points:
        base = float(np.nanmean(y.values))
        return np.full(steps, max(base, 0.0), dtype=float)

    X = np.arange(len(y), dtype=float).reshape(-1, 1)
    model = LinearRegression()
    model.fit(X, y.values.astype(float))

    X_future = np.arange(len(y), len(y) + steps, dtype=float).reshape(-1, 1)
    preds = model.predict(X_future)
    preds = np.clip(preds, 0.0, None)
    return preds.astype(float)


def _history_path() -> Optional[Path]:
    """히스토리 CSV 경로(Path 또는 None)."""
    return None if OUT_DIR is None else (OUT_DIR / HISTORY_FILENAME)


def _load_history() -> pd.DataFrame:
    """히스토리 CSV 로드(없으면 빈 DF)."""
    path = _history_path()
    if path is None or not path.exists():
        return pd.DataFrame(columns=[
            "created_at", "series", "yyyymm", "pred_raw", "context", "train_last_ym", "horizon_m"
        ])
    try:
        return pd.read_csv(path, encoding="utf-8-sig")
    except Exception:
        return pd.read_csv(path)  # 인코딩 이슈 fallback


def _save_history_append(df_rows: pd.DataFrame) -> None:
    """새 예측 묶음을 히스토리에 append."""
    path = _history_path()
    if path is None:
        return
    try:
        OUT_DIR.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            df_rows.to_csv(path, index=False, encoding="utf-8-sig")
        else:
            df_hist = _load_history()
            df_all = pd.concat([df_hist, df_rows], ignore_index=True)
            df_all.to_csv(path, index=False, encoding="utf-8-sig")
    except Exception:
        pass


def _robust_scale_from_history(
    history: pd.DataFrame,
    actual: pd.Series,
    series_name: str,
    context: str,
    lookback_months: int = 6,
    clamp_min: float = 0.6,
    clamp_max: float = 1.4,
) -> float:
    """
    과거 동일 컨텍스트의 예측 vs 실적을 매칭해 보정계수 산정:
      - 보정계수 = median(actual / pred_raw)
      - 최근 lookback_months 개월만 사용
      - 0/NaN/Inf 제거
      - 과도한 보정 방지: [clamp_min, clamp_max]로 클램프
    """
    if history.empty or actual.empty:
        return 1.0

    # 동일 시리즈/컨텍스트만 사용
    now_p = pd.Timestamp.now(tz=KST).tz_localize(None).to_period("M")
    h = history[(history["series"] == series_name) & (history["context"] == context)].copy()
    if h.empty:
        return 1.0

    # 'yy_mm' → Period
    try:
        h["p"] = pd.PeriodIndex(["20" + y.replace("_", "-") for y in h["yyyymm"].astype(str)], freq="M")
    except Exception:
        return 1.0
    h = h[h["p"] < now_p]

    if h.empty:
        return 1.0

    # 동일 월 중복 예측이 있으면 최신(created_at)만 사용
    if "created_at" in h.columns:
        h["created_at"] = pd.to_datetime(h["created_at"], errors="coerce")
        h = h.sort_values(["p", "created_at"]).groupby("p", as_index=False).tail(1)

    # ?ㅼ젣媛?議곗씤
    act = _ensure_series(actual).rename("actual")
    df = h.set_index("p").join(act, how="inner")
    if df.empty:
        return 1.0

    # 최근 N개월만 사용, 0/NaN 제거
    df = df.sort_index().tail(lookback_months)
    df = df[pd.to_numeric(df["pred_raw"], errors="coerce") > 0]
    if df.empty:
        return 1.0

    ratio = df["actual"].astype(float) / df["pred_raw"].astype(float)
    ratio = ratio.replace([np.inf, -np.inf], np.nan).dropna()
    if ratio.empty:
        return 1.0

    scale = float(np.median(ratio.values))
    return float(np.clip(scale, clamp_min, clamp_max))


# 공개 API (main.py에서 호출)
def run_forecast_on_df(
    filtered: pd.DataFrame,
    horizons_days: List[int],
    train_months: int = 24,
    save: bool = True,
    # 보정 관련 파라미터
    use_history_scale: bool = True,
    scale_lookback_m: int = 6,
    scale_min: float = 0.6,
    scale_max: float = 1.4,
    deli_month_basis: str = "ship",  # "ship"(납품/선적일 기준) | "manage"(관리납품일 기준)
) -> pd.DataFrame:
    """
    필터된 DF에 대해 월 단위 예측을 수행하고 결과를 반환/기록.

    Args:
        filtered          : 조회/협력사 필터가 적용된 DataFrame
        horizons_days     : [30, 60, ...] → ceil(max/30)개월 예측
        train_months      : 선형회귀 학습에 사용할 최근 개월 수
        save              : 히스토리에 예측 묶음 저장 여부
        use_history_scale : 과거 예측 기반 보정 사용 여부
        scale_lookback_m  : 보정계수 산정 시 사용할 과거 개월 수
        scale_min/max     : 보정계수 클램프 범위
        deli_month_basis  : 납품 월 라벨 기준("ship" | "manage")
    Returns:
        DataFrame["series","yyyymm","pred_raw","pred_adj"]
    """
    # 방어: 입력 없음
    if filtered is None or filtered.empty:
        return pd.DataFrame(columns=["series", "yyyymm", "pred_raw", "pred_adj"])

    # 예측 step 수 산정(최대 일수 기준 → 월 단위 반올림)
    max_days = max(int(d) for d in horizons_days) if horizons_days else 30
    steps = max(1, int(np.ceil(max_days / 30.0)))

    cfg = ForecastConfig(train_months=train_months)
    context = _signature_from_filtered(filtered)
    created_at = datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S")

    # 1) 월별 실적 시계열
    prod_actual = _build_prod_actual_series(filtered)                 # 톤
    deli_actual = _build_deli_actual_series(filtered, deli_month_basis)  # SET

    # 2) 원시 예측(선형회귀)
    out_rows = []

    if len(prod_actual) > 0:
        last_p = prod_actual.index.max()
        future_p = _month_range_after(last_p, steps)
        yhat_raw = _forecast_series(prod_actual, steps, cfg)
        train_last_ym = _to_yy_mm_label_from_period(last_p)
        for i, (p, y) in enumerate(zip(future_p, yhat_raw), start=1):
            out_rows.append(dict(
                created_at=created_at, series="prod_ton",
                yyyymm=_to_yy_mm_label_from_period(p), pred_raw=float(y),
                context=context, train_last_ym=train_last_ym, horizon_m=i
            ))

    if len(deli_actual) > 0:
        last_p = deli_actual.index.max()
        future_p = _month_range_after(last_p, steps)
        yhat_raw = _forecast_series(deli_actual, steps, cfg)
        train_last_ym = _to_yy_mm_label_from_period(last_p)
        for i, (p, y) in enumerate(zip(future_p, yhat_raw), start=1):
            out_rows.append(dict(
                created_at=created_at, series="deli_set",
                yyyymm=_to_yy_mm_label_from_period(p), pred_raw=float(y),
                context=context, train_last_ym=train_last_ym, horizon_m=i
            ))

    # 예측 결과가 없으면 빈 DF 반환
    if not out_rows:
        return pd.DataFrame(columns=["series", "yyyymm", "pred_raw", "pred_adj"])

    df_new = pd.DataFrame(out_rows)

    # 3) 히스토리 로드 → 스케일(보정계수) 산정
    hist = _load_history()
    if use_history_scale:
        scale_prod = _robust_scale_from_history(
            hist, prod_actual, "prod_ton", context,
            lookback_months=scale_lookback_m, clamp_min=scale_min, clamp_max=scale_max
        ) if len(prod_actual) else 1.0

        scale_deli = _robust_scale_from_history(
            hist, deli_actual, "deli_set", context,
            lookback_months=scale_lookback_m, clamp_min=scale_min, clamp_max=scale_max
        ) if len(deli_actual) else 1.0
    else:
        scale_prod = 1.0
        scale_deli = 1.0

    def _apply_scale(row):
        s = row["series"]
        raw = float(row["pred_raw"])
        sc = scale_prod if s == "prod_ton" else scale_deli
        return max(raw * sc, 0.0)

    df_new["pred_adj"] = df_new.apply(_apply_scale, axis=1)

    if save:
        _save_history_append(df_new[[
            "created_at", "series", "yyyymm", "pred_raw", "context", "train_last_ym", "horizon_m"
        ]])

    # 5) main.py 연동 스키마 반환
    return df_new[["series", "yyyymm", "pred_raw", "pred_adj"]].reset_index(drop=True)

