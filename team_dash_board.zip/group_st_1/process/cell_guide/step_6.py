# -*- coding: utf-8 -*-
"""
step_6.py — 도장 P/R 미발행 목록 산출(주석 확장/안정성 강화판)
──────────────────────────────────────────────────────────────────────────────
목적
  • 실행 시점(한국시간, KST)을 '조회일'로 간주하여, 도장 P/R 미발행 대상 목록을 생성/저장.
  • 조건:
      1) 도장여부 == 1  (정수/문자 어느 형식이든 1로 해석되면 참)
      2) 도장P/R확정일1 결측(빈칸/NaT 포함)
      3) 관리납품일 ≤ (조회일 + 30일)
      4) (옵션) 관리납품일 ≥ MIN_DATE (노이즈 컷오프)
      5) 협력사명 not in step_3_1.EXCLUDE_SUPPLIERS (소문자/공백트림 완전일치)
  • 출력 컬럼(가능한 한 유지): ['프로젝트','블록','관리납품일','협력사명','납품처']
  • 저장: step_1.OUT_DIR / 셀가이드_도장PR_미발행_YYYYMMDD.xlsx

특징/보강
  • 컬럼명 정규화(개행/공백 제거) → 원천 스키마 흔들림 대응
  • 결측 정의 강화: NaN/NaT/''/'NaT'/'None' → 모두 결측으로 간주
  • '도장여부'가 없고 '도장'만 있는 경우 자동 대체
  • 협력사 제외는 소문자·트림 후 완전 일치 비교
  • 누락 컬럼은 친절 에러/경고 후 가능한 범위에서 계속 진행
  • 엑셀 저장 시 오토필터/헤더 고정/열 너비 자동화

주의
  • step_2.main()이 실제 데이터를 반환해야 정상 동작
  • OUT_DIR 권한/연결은 step_1.py에서 선행 준비 필요
──────────────────────────────────────────────────────────────────────────────
"""


from datetime import datetime, timedelta, timezone, date
from typing import Optional, List

import os
import pandas as pd
import openpyxl  # noqa: F401  # pandas ExcelWriter(engine="openpyxl") 의존성

from step_1 import OUT_DIR
import step_2
import step_3_1

# main_app 등에서 표시용으로 쓸 수 있게 모듈 레벨 타이틀 제공
title = "도장 PR 미발행"

# 한국 시간대
KST = timezone(timedelta(hours=9))

# (옵션) 관리납품일 최소 컷오프 — 구데이터/노이즈 제거용
ENFORCE_MIN_DATE = True
MIN_DATE: date = date(2025, 1, 1)


# ──────────────────────────────────────────────────────────────────────
# 유틸리티
# ──────────────────────────────────────────────────────────────────────
def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """컬럼명 개행/캐리지리턴 제거 + 양끝 공백 제거."""
    out = df.copy()
    out.columns = [str(c).replace("\n", "").replace("\r", "").strip() for c in out.columns]
    return out


def _to_date_inplace(df: pd.DataFrame, col: str) -> None:
    """열을 pandas datetime.date 로 변환(파싱 실패→NaT→NaN)."""
    if col in df.columns:
        df[col] = pd.to_datetime(df[col], errors="coerce").dt.date


def _is_blank_series(s: pd.Series) -> pd.Series:
    """결측 판단(문자/날짜 혼재 안전):
    - datetime dtype: isna()
    - object/str: 공백트림 후 '' / 'NaT' / 'None' → 결측으로 처리
    """
    if s.dtype.kind == "M":  # datetime64[ns]
        return s.isna()
    return s.isna() | (s.astype(str).str.strip().isin(["", "NaT", "None"]))


def _get_exclude_list_lower() -> List[str]:
    """step_3_1.EXCLUDE_SUPPLIERS → 소문자/트림 리스트. 없으면 []."""
    if hasattr(step_3_1, "EXCLUDE_SUPPLIERS"):
        raw = getattr(step_3_1, "EXCLUDE_SUPPLIERS")
        if isinstance(raw, (list, tuple, set)):
            return [str(x).strip().lower() for x in raw if str(x).strip()]
    return []


def _pick_paint_flag_col(df: pd.DataFrame) -> str:
    """도장여부 플래그 컬럼명 선택:
       - 우선 '도장여부' 사용
       - 없으면 '도장' 사용
       - 둘 다 없으면 KeyError
    """
    if "도장여부" in df.columns:
        return "도장여부"
    if "도장" in df.columns:
        return "도장"
    raise KeyError("도장여부/도장 컬럼이 모두 없습니다.")


# ──────────────────────────────────────────────────────────────────────
# 핵심 로직
# ──────────────────────────────────────────────────────────────────────
def build_paint_unissued_list(df_master: pd.DataFrame, query_dt: datetime) -> pd.DataFrame:
    """
    도장 PR 미발행 리스트를 생성.

    조건:
      1) 도장여부 == 1  (정수/문자 어느 형식이든 1로 해석되면 참)
      2) 도장P/R확정일1 결측
      3) 관리납품일 ≤ 조회일 + 30
      4) (옵션) 관리납품일 ≥ MIN_DATE
      5) 협력사명 not in step_3_1.EXCLUDE_SUPPLIERS

    반환: 표시용 컬럼 위주 DataFrame
    """
    df = _normalize_columns(df_master)

    # (1) 필수/중요 컬럼 존재 확인(최소한의 검증)
    must_have_any = ["도장여부", "도장", "도장P/R확정일1", "관리납품일"]
    if not any(col in df.columns for col in must_have_any[:2]):  # 도장여부/도장 둘 다 없음
        raise KeyError("도장여부/도장 컬럼 둘 다 없습니다.")
    if "도장P/R확정일1" not in df.columns:
        raise KeyError("필수 컬럼 누락: '도장P/R확정일1'")
    if "관리납품일" not in df.columns:
        raise KeyError("필수 컬럼 누락: '관리납품일'")

    # (2) 날짜 변환
    _to_date_inplace(df, "관리납품일")

    # (3) 도장PR 확정일 결측 처리 강화(문자열 공백/NaT/None 등)
    pr1_blank = _is_blank_series(df["도장P/R확정일1"])

    # (4) 도장여부 플래그 추출 및 숫자화(문자 '1', '1.0' 등도 1로 인식)
    paint_flag_col = _pick_paint_flag_col(df)
    paint_flag = pd.to_numeric(df[paint_flag_col], errors="coerce")  # 실패→NaN
    cond_paint_yes = paint_flag.eq(1)

    # (5) 날짜 조건
    cutoff = (query_dt + timedelta(days=30)).date()
    cond_due30 = df["관리납품일"].notna() & (df["관리납품일"] <= cutoff)

    cond_min_date = True
    if ENFORCE_MIN_DATE:
        cond_min_date = df["관리납품일"].notna() & (df["관리납품일"] >= MIN_DATE)

    # (6) 협력사 제외(소문자·트림 완전일치)
    exclude_lower = _get_exclude_list_lower()
    if "협력사명" in df.columns and exclude_lower:
        cond_exclude = ~df["협력사명"].astype(str).str.strip().str.lower().isin(exclude_lower)
    else:
        cond_exclude = pd.Series(True, index=df.index)

    # (7) 최종 필터링
    mask = cond_paint_yes & pr1_blank & cond_due30 & cond_min_date & cond_exclude
    filtered = df.loc[mask].copy()

    # (8) 결과 컬럼 구성(있는 것만 유지)
    want_cols = ["프로젝트", "블록", "관리납품일", "협력사명", "납품처"]
    have_cols = [c for c in want_cols if c in filtered.columns]
    out = filtered.loc[:, have_cols].copy()

    # (9) 정렬: 관리납품일 → 프로젝트 → 블록(있는 범위 내)
    sort_cols = [c for c in ["관리납품일", "프로젝트", "블록"] if c in out.columns]
    if sort_cols:
        out = out.sort_values(by=sort_cols, kind="stable")

    return out.reset_index(drop=True)


def save_to_excel(df_out: pd.DataFrame, query_dt: datetime) -> str:
    """
    결과를 엑셀로 저장.
      • 파일명: 셀가이드_도장PR_미발행_YYYYMMDD.xlsx
      • Sheet: '도장PR_미발행_조회+30'
      • 오토필터/헤더 고정/열 너비 자동 조정
    """
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    # 동일 접두어 이전 파일 정리(선택사항)
    for file in os.listdir(OUT_DIR):
        if file.startswith("셀가이드_도장PR_미발행_") and file.endswith(".xlsx"):
            try:
                os.remove(os.path.join(OUT_DIR, file))
            except OSError:
                pass

    ymd = query_dt.strftime("%Y%m%d")
    xlsx_path = OUT_DIR / f"셀가이드_도장PR_미발행_{ymd}.xlsx"

    with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
        sheet = "도장PR_미발행_조회+30"
        df_out.to_excel(writer, index=False, sheet_name=sheet)

        wb = writer.book
        ws = wb[sheet]

        # 오토필터 & 헤더 고정
        ws.auto_filter.ref = ws.dimensions
        ws.freeze_panes = "A2"

        # 간단 열 너비 조정(최대 60자 제한)
        for j, col in enumerate(df_out.columns, start=1):
            max_len = max([len(str(col))] + [len(str(v)) for v in df_out[col].fillna("")])
            ws.column_dimensions[ws.cell(row=1, column=j).column_letter].width = min(max_len + 2, 60)

    return str(xlsx_path.resolve())


def run(query_dt: Optional[datetime] = None) -> None:
    """
    전체 파이프라인 실행:
      1) 조회일 결정(기본: 지금 KST)
      2) step_2.main()으로 원본 로드
      3) 도장 PR 미발행 목록 필터링
      4) 엑셀 저장
    """
    if query_dt is None:
        query_dt = datetime.now(KST)

    print(f"[info] 조회일(KST): {query_dt.strftime('%Y-%m-%d')}")

    # 1) 데이터 로드
    df_master = step_2.main()
    if df_master is None or df_master.empty:
        raise RuntimeError("step_2.main() 결과가 비어 있습니다. DB/권한/쿼리를 확인하세요.")
    print(f"[info] 원본 DF: {df_master.shape}")

    # 2) 목록 생성
    df_out = build_paint_unissued_list(df_master, query_dt)
    print(f"[info] 최종 행 수: {len(df_out)}")

    # 3) 미리보기(상위 20행)
    print("\n[preview] 상위 20행:")
    if df_out.empty:
        print("(비어있음)")
    else:
        for i, row in enumerate(df_out.head(20).to_dict(orient="records"), 1):
            print(f"  {i:02d}. {row}")

    # 4) 저장
    saved_path = save_to_excel(df_out, query_dt)
    print(f"\n[done] 엑셀 저장 완료: {saved_path}")


if __name__ == "__main__":
    run()
