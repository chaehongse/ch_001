# -*- coding: utf-8 -*-
"""
step_1.py
- cell_guide 실행 결과 저장 경로를 로컬 work_dir/파일_저장 으로 통일합니다.
- 네트워크 공유(UNC, net use) 로직은 사용하지 않습니다.
"""

from pathlib import Path


# 현재 파일 기준 work_dir
WORK_DIR = Path(__file__).resolve().parent
OUT_DIR_NAME = "파일_저장"
OUT_DIR = WORK_DIR / OUT_DIR_NAME


def connect_and_prepare_outdir(*_, **__) -> None:
    """호환용 함수: 기존 호출부를 깨지 않게 유지하고 폴더만 생성."""
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print(f"[OK] OUT_DIR 준비 완료: {OUT_DIR}")


if __name__ == "__main__":
    connect_and_prepare_outdir()
    print("[DONE] 로컬 저장 폴더 준비를 완료했습니다.")
