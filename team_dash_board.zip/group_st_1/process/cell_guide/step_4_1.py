# -*- coding: utf-8 -*-
"""
step_4_1.py — 생산 데이터 시각화 (막대 + 선) : 주석 확장/안정성 강화판
──────────────────────────────────────────────────────────────────────────────
목적
  • step_3_1.main()에서 산출한 행렬표(matrix)를 이용해 월별 '계획/실적 막대', '누계차 라인'을 1장 PNG로 저장.
  • 좌측 Y축: 계획/실적(톤), 우측 Y축: 누계차(톤). 눈금/라벨은 천 단위 콤마 처리.

입력
  • step_3_1.main() → (matrix, pivot)
      - matrix.index: ["계획", "실적", "누계차", "누계차(표시)"]
      - matrix.columns: 'YY-MM' 같은 월 라벨(문자열). 일부 NaN 가능.
      - 값: 숫자(float)/NaN 혼재 가능(특히 미래월에는 NaN이 의도됨)

출력
  • OUT_DIR / "셀가이드_월별_생산현황.png"

핵심 처리
  1) 월 라벨 정규화/정렬 유틸(to_yy_mm_label, month_sort_key, sort_yy_mm)
  2) matrix에서 '계획/실적/누계차' 3개 행 추출(필수 점검)
  3) 숫자 변환을 to_numeric(errors='coerce')로 강제 → NaN은 그대로 두어 '미래월 끊김' 표현 유지
  4) 막대 위/누계차 점 위 값 라벨(정수 반올림 + 천 단위 콤마)
  5) 한글 폰트 설정(Windows: 맑은 고딕 → 실패시 기본 폰트)

안정성 보완
  • 빈 데이터/필수 행 누락 시 명확한 에러 메시지
  • OUT_DIR 존재 보장
  • to_numeric 강제 변환으로 dtype 혼재 오류 방지(행렬표 dtype=object 대비)
──────────────────────────────────────────────────────────────────────────────
"""

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker  # y축 천 단위/콤마 포맷
from step_1 import OUT_DIR
import step_3_1  # step_3_1.main()이 (matrix, pivot)을 반환

TITLE = "[셀가이드 월별 생산현황]"
OUTFILE = OUT_DIR / "셀가이드_월별_생산현황.png"


# ── x축 라벨 포맷/정렬 유틸 ────────────────────────────────────────────────
def to_yy_mm_label(x) -> str:
    """입력(문자열 'YY-MM'/'YYYY-MM'/'YY_MM'/Timestamp 등)을 통일된 'yy_mm' 포맷으로.

    • 다양한 구분자("_", "/", "-") 허용
    • 문자열이면 앞 2자리 연도(yy), 2자리 월(mm)로 정리
    • Timestamp/날짜도 허용
    • 실패 시 원문 문자열 반환(에러로 죽지 않도록)
    """
    try:
        if isinstance(x, str):
            s = x.replace("_", "-").replace("/", "-").strip()
            parts = s.split("-")
            if len(parts) >= 2 and parts[0].isdigit() and parts[1].isdigit():
                yy = parts[0][-2:]
                mm = parts[1].zfill(2)
                return f"{yy}_{mm}"
        ts = pd.to_datetime(x, errors="raise")
        return ts.strftime("%y_%m")
    except Exception:
        return str(x)


def month_sort_key(x):
    """정렬키: 'yy-mm', 'yyyy-mm', 'yy_mm', timestamp 등 → (yy, mm) 튜플

    • 예외/파싱 실패 시 가장 뒤로 가도록 (999, 99) 반환
    """
    try:
        if isinstance(x, str):
            s = x.replace("_", "-").replace("/", "-").strip()
            parts = s.split("-")
            if len(parts) >= 2 and parts[0].isdigit() and parts[1].isdigit():
                yy = int(parts[0][-2:])
                mm = int(parts[1])
                return (yy, mm)
        ts = pd.to_datetime(x, errors="raise")
        return (int(ts.strftime("%y")), int(ts.strftime("%m")))
    except Exception:
        return (999, 99)


def sort_yy_mm(cols):
    """월 라벨 리스트를 시간 순으로 정렬."""
    if not cols:
        return cols
    return sorted(cols, key=month_sort_key)


def set_korean_font():
    """윈도우/맥/리눅스에서 한글이 깨지지 않도록 우선순위 적용.

    • Windows: 맑은 고딕
    • macOS: AppleGothic
    • Linux 계열: NanumGothic(설치되어 있다면)
    실패 시 기본 폰트 유지(에러로 중단하지 않음).
    """
    try:
        plt.rcParams["axes.unicode_minus"] = False  # 마이너스 깨짐 방지
        # 선호 순서대로 시도
        for fam in ["Malgun Gothic", "AppleGothic", "NanumGothic"]:
            try:
                plt.rcParams["font.family"] = fam
                return
            except Exception:
                continue
    except Exception:
        pass


# ── 메인 ────────────────────────────────────────────────────────────────────
def main():
    # 0) 출력 경로 보장(네트워크 공유 등일 수 있으므로 존재 확인)
    Path(OUT_DIR).mkdir(parents=True, exist_ok=True)

    # 1) step_3_1에서 행렬표 가져오기
    res = step_3_1.main()
    if not res or res[0] is None:
        print("[ERROR] step_3_1.main()에서 행렬표를 가져오지 못했습니다.")
        return
    matrix, _ = res
    if matrix is None or matrix.empty:
        print("[ERROR] step_3_1.main() 결과가 비어 있습니다.")
        return

    # 2) 필요한 행 존재 점검(운영 중 스키마 변경 대비)
    for row in ["계획", "실적", "누계차"]:
        if row not in matrix.index:
            raise KeyError(f"'{row}' 행이 필요합니다. step_3_1.py 결과 스키마를 확인하세요.")

    # 3) 월 정렬/재배치(라벨 혼재 대비)
    months = sort_yy_mm(matrix.columns.tolist())
    matrix = matrix.reindex(columns=months)

    # 4) 시리즈 추출 + 숫자 강제 변환(에러=NaN) — dtype=object 대비
    #    • NaN은 그대로 두면 막대/라인이 '비어' 보이므로 미래월 끊김 표현에 적합
    plan = pd.to_numeric(matrix.loc["계획"], errors="coerce")
    actual = pd.to_numeric(matrix.loc["실적"], errors="coerce")
    diff_cum = pd.to_numeric(matrix.loc["누계차"], errors="coerce")

    # 방어: 모두 NaN이면 의미 있는 그래프가 나오지 않으므로 조기 종료
    if plan.isna().all() and actual.isna().all() and diff_cum.isna().all():
        print("[WARN] 모든 값이 NaN입니다. 그래프를 생성하지 않습니다.")
        return

    # 5) 그래프 설정(폰트/사이즈)
    set_korean_font()
    fig, ax1 = plt.subplots(figsize=(20, 8), dpi=120)

    x = np.arange(len(months))
    width = 0.36  # 계획/실적 막대 간격

    # 6) 계획/실적 막대 (좌측 y축)
    bars_plan = ax1.bar(
        x - width / 2,
        plan.values,  # NaN이면 막대가 그려지지 않아 '빈칸' 효과
        width,
        label="계획",
        color="#499195",
        zorder=2,
    )
    bars_actual = ax1.bar(
        x + width / 2,
        actual.values,
        width,
        label="실적",
        color="#00ACFC",
        zorder=2,
    )

    ax1.set_xlabel("년_월")
    ax1.set_ylabel("톤")
    ax1.set_xticks(x)
    ax1.set_xticklabels([to_yy_mm_label(m) for m in months])
    ax1.grid(axis="y", linestyle="--", linewidth=0.8, alpha=0.6, zorder=1)

    # 좌측 y축 눈금: 천 단위 콤마
    ax1.yaxis.set_major_formatter(ticker.FuncFormatter(lambda v, p: format(int(v), ",")))

    # 6-1) 막대 위 값 라벨(정수 반올림 + 콤마) — 0/NaN은 생략
    def _annotate_bars(bars, color: str):
        for bar in bars:
            h = bar.get_height()
            if h is None or np.isnan(h) or h == 0:
                continue
            ax1.text(
                bar.get_x() + bar.get_width() / 2,
                h,
                format(int(round(h)), ","),
                ha="center",
                va="bottom",
                fontsize=9,
                color=color,
            )

    _annotate_bars(bars_plan, "#499195")
    _annotate_bars(bars_actual, "#00ACFC")

    # 7) 누계차 선 (우측 y축)
    ax2 = ax1.twinx()
    diff_vals = diff_cum.values
    # 점 색상: 양수(blue) / 음수(red)
    colors = ["blue" if (not np.isnan(v) and v >= 0) else "red" for v in diff_vals]

    # 선 + 점
    ax2.plot(x, diff_vals, marker="o", linewidth=2.5, color="#F15757", label="누계차", zorder=3)
    ax2.scatter(x, diff_vals, c=colors, s=80, zorder=4)
    ax2.set_ylabel("누계차(톤)")

    # 우측 y축 눈금: 천 단위 콤마
    ax2.yaxis.set_major_formatter(ticker.FuncFormatter(lambda v, p: format(int(v), ",")))

    # 0 기준선(누계차가 ±영역인지 직관)
    ax2.axhline(0, color="gray", linewidth=1.2, linestyle="--", alpha=0.8, zorder=2)

    # 누계차 값 라벨: 위/아래 정렬(부호에 따라) + 천 단위 콤마
    for xi, yi, c in zip(x, diff_vals, colors):
        if np.isnan(yi):
            continue
        ax2.text(
            xi,
            yi,
            format(int(round(yi)), ","),
            ha="center",
            va="bottom" if yi >= 0 else "top",
            fontsize=10,
            fontweight="bold",
            color=c,
        )

    # 8) 제목/범례/레이아웃
    fig.suptitle(TITLE, fontsize=20, fontweight="bold", y=1)
    ax1.legend(loc="upper left")
    ax2.legend(loc="upper right")

    fig.tight_layout()

    # 9) 저장
    fig.savefig(OUTFILE, bbox_inches="tight")
    plt.close(fig)
    print(f"[저장 완료] {OUTFILE}")


if __name__ == "__main__":
    main()
