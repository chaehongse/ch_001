# -*- coding: utf-8 -*-
"""
step_3_2.py — 데이터 처리 및 분석(납품): 월별 '계획/실적/누계차' 산출 + 엑셀 저장 (주석 확장판)
──────────────────────────────────────────────────────────────────────────────
목적
  • step_2.main()이 반환한 표준 DataFrame을 받아, '납품 관점' 월별 지표(SET)를 계산합니다.
  • 지표(계획, 실적, 누계차, 누계차(표시))를 행렬/피벗 형태로 만들고, 보고용 엑셀을 저장합니다.

핵심 규칙
  • 계획(plan):  "조립P/R확정일" 값이 존재하는 행만 대상으로, "관리납품일"의 월(YY-MM)에 귀속하여 개수를 카운트
  • 실적(actual): "조립P/R확정일" 값이 존재하는 행만 대상으로, "납품/선적일"의 월(YY-MM)에 귀속하여 개수를 카운트
  • 기준월(오늘, 한국시간) 이후의 '실적/누계차'는 NaN으로 두어 그래프에서 '끊김' 표현
  • 과거/현재월의 실적 결측은 0으로 보정하여 표/보고서에서 빈칸 방지
  • 미래월에 실적이 들어오면 '누계차(표시)="이상"'으로 마킹(데이터 입력 이상 신호)

출력
  • OUT_DIR/월별_납품_계획_실적.xlsx
    - Sheet1: 행렬표(계획/실적/누계차/누계차(표시); 가로형)
    - Sheet2: 피벗(세로형; 월별 한 줄)

주의/팁
  • 단위: SET(개수). 엑셀 기록은 #,##0 정수 포맷으로 강제합니다.
  • sort_yy_mm는 'YY-MM'을 Period로 변환해 안전 정렬(세기 20XX 고정)합니다.
  • 반환 형식/컬럼명은 대시보드와의 호환을 위해 변경하지 마세요.
──────────────────────────────────────────────────────────────────────────────
"""

import math
from datetime import datetime, timezone, timedelta
from typing import Optional, Tuple, List

import numpy as np
import pandas as pd

import openpyxl  # noqa: F401  # (참고) pandas.ExcelWriter(openpyxl/xlsxwriter) 의존성 유지 목적
import xlsxwriter

from step_1 import OUT_DIR
import step_2


# 제외할 협력사명 목록 (필요 시 수정/추가)
#  - 비교는 소문자 완전 일치(공백 트리밍 포함) 기준
EXCLUDE_SUPPLIERS: List[str] = [
    "영성법인1공장",
    "한화오션(산동)",
]

# 한국 표준시
KST = timezone(timedelta(hours=9))


# ──────────────────────────────────────────────────────────────────────────────
# 유틸: 월 정렬/엑셀 기록/요약지표
# ──────────────────────────────────────────────────────────────────────────────
def sort_yy_mm(cols: list[str]) -> list[str]:
    """'YY-MM' 문자열 리스트를 시간순으로 정렬.

    구현 포인트
      • '20' 접두를 붙여 'YYYY-MM'로 만든 후 PeriodIndex(freq='M') 정렬.
      • 입력이 비어있으면 그대로 반환.
    """
    if not cols:
        return cols
    periods = pd.PeriodIndex(["20" + c for c in cols], freq="M")
    order = periods.argsort()
    return [cols[i] for i in order]


def _autoset_col_widths(
    worksheet,
    df: pd.DataFrame,
    start_row: int = 0,
    start_col: int = 0,
    min_w: int = 7,
    max_w: int = 18,
) -> None:
    """엑셀 시트 열 너비를 데이터 길이에 맞춰 대략 자동 조정.

    포인트
      • 숫자열은 가독성을 위해 약간 축소(0.85배) 반영.
      • 0열(인덱스 헤더)은 외부에서 별도 set_column을 했으므로 1열부터 조정.
    """
    for j, col in enumerate(df.columns):
        series = df[col].astype(str).fillna("")
        max_len = max([len(col)] + [len(s) for s in series])
        if pd.api.types.is_numeric_dtype(df[col].dtype):
            max_len = max(6, math.ceil(max_len * 0.85))
        width = max(min_w, min(max_w, max_len + 1))
        worksheet.set_column(start_col + 1 + j, start_col + 1 + j, width)


def _yy_mm_period(yy_mm: str) -> pd.Period:
    """'YY-MM' → Period('20YY-MM','M') 변환(월 단위 비교/연산용)."""
    return pd.Period("20" + yy_mm, freq="M")


def calculate_summary(matrix: pd.DataFrame) -> dict:
    """행렬표에서 요약 통계(합계, 잔여, 완료률)를 계산(SET 단위).

    안전 장치
      • 문자열이 섞일 수 있으므로 to_numeric(errors='coerce')로 숫자만 합산
      • 모두 NaN이면 0으로 간주
    """
    plan_total = pd.to_numeric(matrix.loc["계획"], errors="coerce").sum(min_count=1)
    actual_total = pd.to_numeric(matrix.loc["실적"], errors="coerce").sum(min_count=1)
    plan_total = 0 if pd.isna(plan_total) else plan_total
    actual_total = 0 if pd.isna(actual_total) else actual_total

    remain_delivery = plan_total - actual_total
    deliver_rate = (actual_total / plan_total) * 100 if plan_total != 0 else 0

    return {
        "계획_납품합계": f"{round(plan_total):,}SET",
        "실적_납품합계": f"{round(actual_total):,}SET",
        "잔여납품량": f"{round(remain_delivery):,}SET",
        "납품완료률": f"{int(deliver_rate)}%",
    }


def _write_value(ws, row: int, col: int, val, fmt_num, fmt_txt, fmt_cell) -> None:
    """엑셀 수동 기록 헬퍼.

    규칙
      • NaN/NA → 빈칸
      • 숫자(float 포함) → 반올림 후 정수 포맷(#,##0)
      • 그 외     → 문자열 그대로
    """
    if pd.isna(val):
        ws.write_blank(row, col, None, fmt_cell)
        return
    if isinstance(val, (int, np.integer)):
        ws.write_number(row, col, int(val), fmt_num)
    elif isinstance(val, (float, np.floating)):
        ws.write_number(row, col, int(round(float(val))), fmt_num)
    else:
        ws.write(row, col, str(val), fmt_txt)


# ──────────────────────────────────────────────────────────────────────────────
# 메인 파이프라인
# ──────────────────────────────────────────────────────────────────────────────
def main() -> Optional[Tuple[pd.DataFrame, pd.DataFrame]]:
    """DB 원천 로드 → 가공 → 월별 계획/실적/누계/누계차 산출 → 엑셀 저장.

    반환
      (matrix, pivot)
        - matrix: 가로형(계획/실적/누계차/누계차(표시))
        - pivot : 세로형(동일 지표 컬럼)
      실패/무데이터 시 None
    """
    # 1) 원천 로드(표준 스키마) — 실패 시 즉시 종료
    df = step_2.main()
    if df is None or df.empty:
        print("[ERROR] step_2.main() 결과가 없습니다.")
        return None

    # 1-1) 필수 컬럼 빠른 점검(운영 중 스키마 변동 대비)
    required_cols = {"관리납품일", "납품/선적일", "조립P/R확정일"}
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        print(f"[ERROR] 필수 컬럼 누락: {missing} — step_2 스키마 확인 필요")
        return None

    # 1-2) 협력사 제외 필터(옵션): EXCLUDE_SUPPLIERS 목록과 소문자 완전 일치 비교
    if "협력사명" in df.columns:
        before = len(df)
        excludes_lower = {s.strip().lower() for s in EXCLUDE_SUPPLIERS if s and isinstance(s, str)}
        if excludes_lower:
            df = df[~df["협력사명"].astype(str).str.lower().isin(excludes_lower)].copy()
        after = len(df)
        print(f"[INFO] 협력사명 제외 적용: {before - after}건 제거됨 (잔여 {after}건)")
    else:
        print("[WARN] '협력사명' 컬럼이 없어 제외 필터를 적용하지 않았습니다.")

    # 2) 타입 변환(날짜) — 파싱 실패는 NaT로 통일
    df["관리납품일"] = pd.to_datetime(df["관리납품일"], errors="coerce")
    df["납품/선적일"] = pd.to_datetime(df["납품/선적일"], errors="coerce")
    df["조립P/R확정일"] = pd.to_datetime(df["조립P/R확정일"], errors="coerce")

    # 3) 월 키 생성('YY-MM')
    #    - 계획_년월: 관리납품일
    #    - 실적_년월: 납품/선적일
    df["계획_년월"] = df["관리납품일"].dt.strftime("%y-%m")
    df["실적_년월"] = df["납품/선적일"].dt.strftime("%y-%m")

    # 4) 월별 개수 산출(SET)
    #    - 계획(plan): 관리납품일 기준 월로 그룹. 단, 조립P/R확정일이 존재하는 건만 카운트.
    plan_count = (
        df.dropna(subset=["조립P/R확정일"])  # 확정된 건만 대상
          .groupby("계획_년월")["조립P/R확정일"]
          .count()
    )
    #    - 실적(actual): 납품/선적일 기준 월로 그룹. 단, 조립P/R확정일이 존재하는 건만 카운트.
    actual_count = (
        df.dropna(subset=["조립P/R확정일"])  # 확정된 건만 대상
          .groupby("실적_년월")["조립P/R확정일"]
          .count()
    )

    # 5) 열(월) 구성: 계획 ∪ 실적(합집합) → 시간순 정렬
    months = sort_yy_mm(sorted(set(plan_count.index).union(set(actual_count.index))))

    #    NaN 존재 가능 → float로 승격될 수 있으나, 엑셀 기록 시 정수 포맷으로 강제
    plan = plan_count.reindex(months)
    actual = actual_count.reindex(months)

    # (보조 로그) 총합 체크 — 대시보드 KPI 검증 시 유용
    print(f"[CHECK] 계획 합계={int(plan.fillna(0).sum())} SET,  "
          f"실적 합계={int(actual.fillna(0).sum())} SET")

    # 6) 기준월(오늘, 한국시간)
    기준P = _yy_mm_period(datetime.now(KST).strftime("%y-%m"))

    # 7) 표시용 실적(actual_disp): 과거/현재 결측 → 0, 미래월은 결측 유지(그래프 끊김/표 빈칸)
    actual_disp = actual.copy()
    for m in months:
        if _yy_mm_period(m) <= 기준P and pd.isna(actual_disp[m]):
            actual_disp[m] = 0  # 과거/현재월 결측은 0

    # 8) 누계(계획/실적) — 미래 결측은 유지
    plan_cum = plan.fillna(0).cumsum()
    actual_cum = actual.copy()
    for m in months:
        if _yy_mm_period(m) <= 기준P and pd.isna(actual_cum[m]):
            actual_cum[m] = 0
    actual_cum = actual_cum.cumsum()

    # 9) 누계차(수치) = 실적누계 - 계획누계
    diff_cum = (actual_cum - plan_cum)

    #    그래프용: 기준월 이후는 NaN으로 비워 끊김 표현
    for m in months:
        if _yy_mm_period(m) > 기준P:
            diff_cum[m] = np.nan

    # 10) 누계차(표시)
    #     - 미래월에 실적이 있으면 "이상"(데이터 입력 이상 신호)
    #     - 없으면 빈칸
    diff_display = diff_cum.copy()
    for m in months:
        if _yy_mm_period(m) > 기준P:
            if pd.isna(actual[m]):
                diff_display[m] = pd.NA
            else:
                diff_display[m] = "이상"
                print("미래 실적이 입력되었습니다. 실적 점검바랍니다. →", m)

    # 11) 행렬표(그래프/보고 공용). 숫자+문자 혼재 → dtype='object'
    matrix = pd.DataFrame(
        [plan, actual_disp, diff_cum, diff_display],
        index=["계획", "실적", "누계차", "누계차(표시)"],
        columns=months,
        dtype="object",
    )

    #    요약 통계(콘솔 출력) — 대시보드 KPI 검증 시 참고
    summary = calculate_summary(matrix)
    print("[요약 통계]")
    for k, v in summary.items():
        print(f"  - {k}: {v}")

    # 12) 피벗(세로형 참고용)
    pivot = pd.DataFrame({
        "계획": plan,
        "실적": actual_disp,
        "누계차": diff_cum,
        "누계차(표시)": diff_display,
    }).reindex(index=months)

    # 13) 엑셀 저장(서식 포함, 수동 기록으로 정수 포맷 보장)
    out_path = OUT_DIR / "월별_납품_계획_실적.xlsx"
    with pd.ExcelWriter(out_path, engine="xlsxwriter") as writer:
        wb = writer.book

        # 공통 포맷
        fmt_header = wb.add_format({
            "bold": True, "align": "center", "valign": "vcenter",
            "bg_color": "F2F2F2", "border": 1,
        })
        fmt_index = wb.add_format({"bold": True, "border": 1, "align": "center"})
        fmt_num = wb.add_format({"num_format": "#,##0", "border": 1})  # 정수 표시
        fmt_txt = wb.add_format({"border": 1})
        fmt_cell = wb.add_format({"border": 1})

        # (1) Sheet1: 행렬표 — 헤더/값 모두 수동 기록
        ws1 = wb.add_worksheet("Sheet1")

        # 헤더(인덱스 공란 + 월 컬럼)
        ws1.write(0, 0, "", fmt_header)
        for j, col in enumerate(months, start=1):
            ws1.write(0, j, col, fmt_header)

        # 데이터(행 라벨 + 값)
        for i, idx in enumerate(matrix.index, start=1):
            ws1.write(i, 0, idx, fmt_index)
            for j, col in enumerate(months, start=1):
                val = matrix.loc[idx, col]
                _write_value(ws1, i, j, val, fmt_num, fmt_txt, fmt_cell)

        # 보기 편의: 스크롤 고정/열 너비
        ws1.freeze_panes(1, 1)
        ws1.set_column(0, 0, 12)  # 인덱스 열
        _autoset_col_widths(ws1, pd.DataFrame(columns=months))

        # (2) Sheet2: 피벗(세로형) — 헤더/값 수동 기록
        ws2 = wb.add_worksheet("Sheet2")

        headers2 = ["월", "계획", "실적", "누계차", "누계차(표시)"]
        for j, h in enumerate(headers2):
            ws2.write(0, j, h, fmt_header)

        for i, m in enumerate(months, start=1):
            ws2.write(i, 0, m, fmt_index)
            _write_value(ws2, i, 1, pivot.at[m, "계획"], fmt_num, fmt_txt, fmt_cell)
            _write_value(ws2, i, 2, pivot.at[m, "실적"], fmt_num, fmt_txt, fmt_cell)
            _write_value(ws2, i, 3, pivot.at[m, "누계차"], fmt_num, fmt_txt, fmt_cell)
            _write_value(ws2, i, 4, pivot.at[m, "누계차(표시)"], fmt_num, fmt_txt, fmt_cell)

        ws2.freeze_panes(1, 1)
        ws2.set_column(0, 0, 10)  # "월"
        ws2.set_column(1, 3, 12)  # 숫자열
        ws2.set_column(4, 4, 12)  # 표시열

    print(f"[저장 완료] {out_path}")

    # 후속 모듈(step_4/대시보드)에서 지표/그래프로 재사용할 수 있도록 반환
    return matrix, pivot


if __name__ == "__main__":
    main()
