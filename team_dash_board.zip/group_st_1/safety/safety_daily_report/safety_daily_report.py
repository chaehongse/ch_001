# -*- coding: utf-8 -*-
"""
safety_daily_report.py
현장 점검 및 조치 사항 - Streamlit 시각화 대시보드 (MySQL 연동)

실행: streamlit run safety_daily_report.py
비밀번호 환경변수: set AS_DB_PASSWORD=<password>  (Windows)
                   export AS_DB_PASSWORD=<password> (Linux/Mac)
"""

import base64
import html as html_mod
import io
import os
import re
from datetime import datetime

import pandas as pd
import pymysql
import streamlit as st
import streamlit.components.v1 as components
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from PIL import Image
import matplotlib.pyplot as plt
from matplotlib import font_manager, rcParams
from matplotlib.backends.backend_pdf import PdfPages

# ─── DB 연결 설정 ─────────────────────────────────────────────

DB_HOST = "localhost"
DB_USER = "root"
DB_NAME = "구조조달1_db"
TABLE_NAME = "협력사_점검_현황"
DB_PASSWORD_ENV = os.environ.get("AS_DB_PASSWORD", "").strip()   # 환경변수 우선

# ─── 상수 ────────────────────────────────────────────────────

CMP_MARK = "#cmp="

# MySQL 컬럼명(공백 포함) → 앱 표준 키(공백 없음)
MYSQL_COL_MAP = {
    "점검 내용": "점검내용",
    "점검 사진": "점검사진",
    "조치 내용": "조치내용",
    "조치 사진": "조치사진",
}

MOJIBAKE_COL_MAP = {
    "漠径紫": "협력사",
    "硲識": "호선",
    "鷺系": "블록",
    "姥歳": "구분",
    "繊伊切": "점검자",
    "繊伊析": "점검일",
    "是鋼政莫": "위반유형",
    "繊伊鎧遂": "점검내용",
    "繊伊紫遭": "점검사진",
    "繕帖析": "조치일",
    "繕帖鎧遂": "조치내용",
    "繕帖紫遭": "조치사진",
}

EXPECTED_DATA_COLS = [
    "협력사", "호선", "블록", "구분", "점검자", "점검일",
    "위반유형", "점검내용", "점검사진", "조치일", "조치내용", "조치사진",
]

DISPLAY_COLS = [
    "NO", "협력사", "호선", "블록", "구분", "점검자",
    "점검일", "위반유형", "점검내용", "조치일", "조치내용", "조치완료",
]

FILTER_PLACEHOLDER_TOKENS = {
    "", "none", "null", "nan",
    "협력사", "구분", "위반유형", "점검자", "호선", "블록",
}

# ─── 디자인 시스템 ───────────────────────────────────────────

# 색상 토큰
C_PRIMARY  = "#1A2F5A"   # 딥 네이비
C_ACCENT   = "#2563EB"   # 로얄 블루
C_GOLD     = "#C9A040"   # 골드
C_SUCCESS  = "#059669"   # 에메랄드
C_WARNING  = "#D97706"   # 앰버
C_DANGER   = "#DC2626"   # 레드
C_DANGER_HI= "#7F1D1D"   # 다크 레드
C_BG       = "#F1F5F9"   # 페이지 배경
C_CARD     = "#FFFFFF"
C_TEXT     = "#0F172A"
C_MUTED    = "#64748B"
C_GRID     = "#E2E8F0"
C_BORDER   = "#CBD5E1"

# Plotly 공통 폰트
_CHART_FONT = dict(
    family="Malgun Gothic, AppleGothic, Noto Sans KR, sans-serif",
    size=13, color=C_TEXT,
)
_AXIS_STYLE = dict(
    gridcolor=C_GRID, linecolor=C_BORDER, zeroline=False,
    tickfont=dict(size=12, color=C_MUTED),
    title_font=dict(size=13, color=C_MUTED, family="Malgun Gothic, AppleGothic, sans-serif"),
)
_LEGEND_STYLE = dict(
    orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1,
    bgcolor="rgba(255,255,255,0.85)", bordercolor=C_BORDER, borderwidth=1,
    font=dict(size=12, color=C_TEXT),
)


def _base_layout(**overrides) -> dict:
    """모든 차트에 공통 적용할 layout dict 반환"""
    base = dict(
        paper_bgcolor=C_CARD,
        plot_bgcolor=C_CARD,
        font=_CHART_FONT,
        margin=dict(l=10, r=10, t=44, b=10),
        hoverlabel=dict(
            bgcolor=C_PRIMARY, font_color="#FFFFFF",
            font_size=13,
            font_family="Malgun Gothic, AppleGothic, sans-serif",
        ),
    )
    base.update(overrides)
    return base


def _style_axes(fig) -> None:
    """figure의 모든 x/y 축에 공통 스타일 적용"""
    fig.update_xaxes(**_AXIS_STYLE)
    fig.update_yaxes(**_AXIS_STYLE)


def _section(title: str) -> None:
    """세련된 섹션 헤더 렌더링"""
    st.markdown(
        f"<h3 style='"
        f"color:{C_PRIMARY};font-weight:700;font-size:1.1rem;"
        f"border-left:4px solid {C_GOLD};padding-left:10px;"
        f"margin-top:1.6rem;margin-bottom:0.4rem;"
        f"font-family:Malgun Gothic,AppleGothic,sans-serif;"
        f"'>{title}</h3>",
        unsafe_allow_html=True,
    )


# ─── 유틸 ────────────────────────────────────────────────────


def _setup_matplotlib_font() -> None:
    """한글 폰트가 있으면 우선 적용"""
    try:
        preferred = [
            "Malgun Gothic", "AppleGothic", "NanumGothic",
            "Noto Sans CJK KR", "Noto Sans KR", "DejaVu Sans",
        ]
        available = {f.name for f in font_manager.fontManager.ttflist}
        for name in preferred:
            if name in available:
                rcParams["font.family"] = name
                break
        rcParams["axes.unicode_minus"] = False
    except Exception:
        pass


_setup_matplotlib_font()


def strip_cmp_marker(s: str) -> str:
    """data URL 뒤에 붙은 압축 마커(#cmp=...) 제거"""
    idx = s.find(CMP_MARK)
    return s[:idx] if idx >= 0 else s


def bytes_to_data_url(val) -> str:
    """MySQL LONGBLOB(bytes) → data:image/jpeg;base64,... 변환"""
    if not val:
        return ""
    try:
        b = bytes(val) if not isinstance(val, (bytes, bytearray)) else val
        return "data:image/jpeg;base64," + base64.b64encode(b).decode("ascii")
    except Exception:
        return ""


def data_url_to_pil(data_url: str) -> "Image.Image | None":
    """data URL → PIL Image. 실패 또는 빈 값이면 None 반환."""
    clean = strip_cmp_marker(str(data_url or ""))
    if not clean.startswith("data:image"):
        return None
    try:
        _, b64 = clean.split(",", 1)
        return Image.open(io.BytesIO(base64.b64decode(b64)))
    except Exception:
        return None


def fmt_date_col(series: pd.Series) -> pd.Series:
    return series.dt.strftime("%Y-%m-%d").where(series.notna(), "")


def clean_violation_type_label(val) -> str:
    """위반유형 앞의 '숫자.' 접두어 제거 (예: '12. 낙하위험' -> '낙하위험')."""
    s = str(val or "").strip()
    s = re.sub(r"^\d+\.\s*", "", s)
    return s.strip()


def _save_fig(pdf: PdfPages, fig) -> None:
    fig.tight_layout()
    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


def render_dashboard_pdf_capture_button() -> None:
    """현재 보이는 대시보드 화면을 그대로 PDF로 저장하는 버튼 렌더링."""
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    html = f"""
    <div style="margin-top:8px;display:flex;justify-content:flex-start;">
      <button id="save-dashboard-pdf" style="
        width:auto;min-width:220px;padding:11px 22px;
        border-radius:8px;border:none;
        background:linear-gradient(135deg,{C_PRIMARY},{C_ACCENT});
        color:#ffffff;font-weight:700;cursor:pointer;
        font-size:14px;line-height:1.3;
        box-shadow:0 2px 8px rgba(37,99,235,0.30);
        letter-spacing:0.3px;
        transition:opacity 0.15s;">
        ⬇ PDF 파일 저장
      </button>
    </div>
    <div id="pdf-status" style="margin-top:6px;color:{C_MUTED};font-size:12px;"></div>
    <script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js"></script>
    <script>
      const btn = document.getElementById("save-dashboard-pdf");
      const status = document.getElementById("pdf-status");

      async function savePdfFromDashboard() {{
        try {{
          status.textContent = "PDF 생성 중입니다...";
          btn.disabled = true;
          btn.style.opacity = "0.6";

          let parentDoc = null;
          try {{
            parentDoc = window.parent && window.parent.document ? window.parent.document : document;
          }} catch (_) {{
            parentDoc = document;
          }}

          const selectors = [
            '[data-testid="stMain"]',
            '[data-testid="stMainBlockContainer"]',
            '[data-testid="stAppViewContainer"] main',
            'section.main',
            'main',
          ];
          let mainArea = null;
          for (const sel of selectors) {{
            mainArea = parentDoc.querySelector(sel);
            if (mainArea) break;
          }}
          if (!mainArea) mainArea = parentDoc.body;
          if (!mainArea) throw new Error("대시보드 영역을 찾을 수 없습니다.");

          const fullWidth = Math.max(
            mainArea.scrollWidth || 0,
            mainArea.clientWidth || 0,
            parentDoc.documentElement.scrollWidth || 0
          );
          const fullHeight = Math.max(
            mainArea.scrollHeight || 0,
            mainArea.clientHeight || 0,
            parentDoc.documentElement.scrollHeight || 0
          );
          const captureId = "dash-capture-" + Date.now();
          mainArea.setAttribute("data-capture-id", captureId);

          const canvas = await html2canvas(mainArea, {{
            scale: 2,
            useCORS: true,
            backgroundColor: "#ffffff",
            scrollX: 0,
            scrollY: -(window.parent?.scrollY || window.scrollY || 0),
            width: fullWidth,
            height: fullHeight,
            windowWidth: fullWidth,
            windowHeight: fullHeight,
            onclone: (clonedDoc) => {{
              const clonedArea = clonedDoc.querySelector(`[data-capture-id="${{captureId}}"]`);
              if (clonedArea) {{
                clonedArea.style.maxHeight = "none";
                clonedArea.style.height = "auto";
                clonedArea.style.overflow = "visible";
              }}
            }}
          }});
          mainArea.removeAttribute("data-capture-id");

          const imgData = canvas.toDataURL("image/jpeg", 0.95);
          const {{ jsPDF }} = window.jspdf;
          const pdf = new jsPDF("p", "mm", "a4");
          const pageW = pdf.internal.pageSize.getWidth();
          const pageH = pdf.internal.pageSize.getHeight();
          const imgW = pageW;
          const imgH = (canvas.height * pageW) / canvas.width;
          const fileName = "현장점검_대시보드화면_{ts}.pdf";

          let y = 0;
          let remain = imgH;
          pdf.addImage(imgData, "JPEG", 0, y, imgW, imgH);
          remain -= pageH;

          while (remain > 0) {{
            y = remain - imgH;
            pdf.addPage();
            pdf.addImage(imgData, "JPEG", 0, y, imgW, imgH);
            remain -= pageH;
          }}

          pdf.save(fileName);
          status.textContent = "PDF 저장이 완료되었습니다.";
        }} catch (err) {{
          status.textContent = "PDF 저장에 실패했습니다: " + (err?.message || err);
        }} finally {{
          btn.disabled = false;
          btn.style.opacity = "1";
        }}
      }}

      btn.addEventListener("click", savePdfFromDashboard);
    </script>
    """
    components.html(html, height=76)


def _draw_gallery_image(ax, img: "Image.Image | None", title: str) -> None:
    ax.set_title(title)
    ax.axis("off")
    if img is None:
        ax.text(0.5, 0.5, "사진 없음", ha="center", va="center", fontsize=12)
        return
    try:
        ax.imshow(img.convert("RGB"))
    except Exception:
        ax.text(0.5, 0.5, "이미지 로드 실패", ha="center", va="center", fontsize=12)


def build_gallery_pdf(img_df: pd.DataFrame, has_img1: bool, has_img2: bool) -> bytes:
    """이미지 갤러리(필터 반영)를 PDF로 생성 (1페이지 4건 배치)"""
    def _short(val, max_len: int = 28) -> str:
        s = str(val or "").strip()
        return s if len(s) <= max_len else s[: max_len - 1] + "…"

    buf = io.BytesIO()
    with PdfPages(buf) as pdf:
        for start in range(0, len(img_df), 4):
            chunk = img_df.iloc[start:start + 4]
            fig = plt.figure(figsize=(11.69, 8.27))  # A4 landscape
            outer = fig.add_gridspec(2, 2, hspace=0.35, wspace=0.18)

            for slot, (_, row) in enumerate(chunk.iterrows()):
                r, c = divmod(slot, 2)
                card = outer[r, c].subgridspec(2, 2, height_ratios=[1.2, 2.2], hspace=0.12, wspace=0.08)

                ax_info = fig.add_subplot(card[0, :])
                ax_info.axis("off")

                점검일_str = (
                    row["점검일"].strftime("%Y-%m-%d")
                    if "점검일" in row and pd.notna(row["점검일"]) else ""
                )
                조치일_str = (
                    row["조치일"].strftime("%Y-%m-%d")
                    if "조치일" in row and pd.notna(row["조치일"]) else "미조치"
                )

                info_line1 = (
                    f"NO {row.get('NO', '-')} | {_short(row.get('협력사', ''), 10)} | "
                    f"{_short(row.get('호선', ''), 8)} {_short(row.get('블록', ''), 8)}"
                )
                info_line2 = (
                    f"{_short(row.get('위반유형', ''), 18)} | 점검:{점검일_str} | 조치:{조치일_str}"
                )
                ax_info.text(0.0, 0.95, info_line1, va="top", ha="left", fontsize=8.8, fontweight="bold")
                ax_info.text(0.0, 0.45, info_line2, va="top", ha="left", fontsize=8.4)

                ax_l = fig.add_subplot(card[1, 0])
                ax_r = fig.add_subplot(card[1, 1])
                img1 = data_url_to_pil(row.get("점검사진", "")) if has_img1 else None
                img2 = data_url_to_pil(row.get("조치사진", "")) if has_img2 else None
                _draw_gallery_image(ax_l, img1, "점검")
                _draw_gallery_image(ax_r, img2, "조치")

            _save_fig(pdf, fig)

    return buf.getvalue()


def _build_filter_options(df: pd.DataFrame, col: str) -> list[str]:
    """필터 옵션에서 빈값/헤더문자열/NaN 문자열 제거"""
    if col not in df.columns:
        return []
    opts = set()
    for v in df[col].dropna().tolist():
        s = str(v).strip()
        if not s:
            continue
        if s.casefold() in FILTER_PLACEHOLDER_TOKENS:
            continue
        opts.add(s)
    return sorted(opts)


def _normalize_schema_columns(df: pd.DataFrame) -> pd.DataFrame:
    """컬럼명 깨짐/이형 컬럼을 앱 표준 컬럼명으로 정규화"""
    if df.empty:
        return df

    rename_map = {}
    rename_map.update({k: v for k, v in MYSQL_COL_MAP.items() if k in df.columns})
    rename_map.update({k: v for k, v in MOJIBAKE_COL_MAP.items() if k in df.columns})
    if rename_map:
        df = df.rename(columns=rename_map)

    # 컬럼명이 완전히 깨진 경우 대비: 데이터 컬럼 12개를 표준 순서로 보정
    present_expected = [c for c in EXPECTED_DATA_COLS if c in df.columns]
    if len(present_expected) < 6:
        candidate_cols = [c for c in df.columns if c not in {"id", "NO"}]
        if len(candidate_cols) >= len(EXPECTED_DATA_COLS):
            fallback_map = {}
            for src, target in zip(candidate_cols[:len(EXPECTED_DATA_COLS)], EXPECTED_DATA_COLS):
                if target not in df.columns:
                    fallback_map[src] = target
            if fallback_map:
                df = df.rename(columns=fallback_map)

    return df


def _finalize_df(df: pd.DataFrame) -> pd.DataFrame:
    """날짜 변환 · 조치완료 컬럼 · 문자열 공백 정리 공통 처리"""
    if df.empty:
        return df

    # MySQL 컬럼명 정규화 (공백/깨짐 컬럼명 대응)
    df = _normalize_schema_columns(df)

    # LONGBLOB bytes → data URL (MySQL에서 온 경우)
    for col in ("점검사진", "조치사진"):
        if col in df.columns:
            df[col] = df[col].apply(
                lambda v: bytes_to_data_url(v) if isinstance(v, (bytes, bytearray, memoryview))
                else (str(v) if v else "")
            )

    # 날짜 변환
    for col in ("점검일", "조치일"):
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")

    # 조치완료 여부
    if "조치일" in df.columns:
        df["조치완료"] = df["조치일"].notna()
    else:
        df["조치완료"] = False

    # pandas 2.x/3.x 호환: object + string 계열 컬럼을 안전하게 수집
    obj_cols = set(df.select_dtypes(include=["object"]).columns)
    str_cols = set(df.select_dtypes(include=["string"]).columns)
    for c in sorted(obj_cols | str_cols):
        df[c] = df[c].apply(lambda v: v.strip() if isinstance(v, str) else v)

    # 헤더 문자열이 데이터로 들어간 행 제거 (예: 협력사=협력사, 구분=구분 ...)
    header_cols = [c for c in ("협력사", "구분", "위반유형", "점검자", "호선", "블록") if c in df.columns]
    if header_cols:
        header_like_cnt = pd.Series(0, index=df.index, dtype="int64")
        for c in header_cols:
            col_s = df[c].astype(str).str.strip()
            header_like_cnt = header_like_cnt + (col_s == c).astype("int64")
        df = df[header_like_cnt < 2].copy()

    return df


@st.cache_data(show_spinner=False, ttl=300)   # 5분마다 자동 갱신
def load_from_mysql(host: str, user: str, password: str,
                    database: str, table: str) -> pd.DataFrame:
    """MySQL에서 전체 데이터를 읽어 DataFrame으로 반환 (5분 캐시)"""
    conn = pymysql.connect(
        host=host, user=user, password=password,
        database=database, charset="utf8mb4",
    )
    try:
        df = pd.read_sql(f"SELECT * FROM `{table}`", conn)
    finally:
        conn.close()
    return _finalize_df(df)


# ─── 페이지 설정 ──────────────────────────────────────────────

st.set_page_config(
    page_title="현장 점검 대시보드",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── 전역 CSS 주입 ────────────────────────────────────────────

st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;700&display=swap');

html, body, [class*="css"] {{
    font-family: 'Noto Sans KR', 'Malgun Gothic', 'AppleGothic', sans-serif !important;
}}

/* 페이지 배경 */
[data-testid="stAppViewContainer"] > .main {{
    background-color: {C_BG};
}}
[data-testid="stAppViewContainer"] {{
    background-color: {C_BG};
}}

/* 상단 Streamlit UI(Deploy/Toolbar/Menu) 숨김 */
header[data-testid="stHeader"] {{
    display: none !important;
}}
[data-testid="stToolbar"] {{
    display: none !important;
}}
[data-testid="stDecoration"] {{
    display: none !important;
}}
[data-testid="stStatusWidget"] {{
    display: none !important;
}}
#MainMenu, footer {{
    display: none !important;
}}

/* 내용 영역 전체폭 */
.main .block-container {{
    max-width: 100% !important;
    padding-left: 1.5rem !important;
    padding-right: 1.5rem !important;
    padding-top: 0.2rem !important;
}}

/* 사이드바 */
[data-testid="stSidebar"] {{
    background: linear-gradient(180deg, {C_PRIMARY} 0%, #22386E 100%) !important;
    border-right: none !important;
}}
[data-testid="stSidebar"] * {{
    color: #E2E8F0 !important;
}}
[data-testid="stSidebar"] .stButton button {{
    background: rgba(255,255,255,0.12) !important;
    border: 1px solid rgba(255,255,255,0.25) !important;
    color: #ffffff !important;
    border-radius: 8px !important;
    font-weight: 600 !important;
    transition: background 0.15s !important;
}}
[data-testid="stSidebar"] .stButton button:hover {{
    background: rgba(255,255,255,0.22) !important;
}}
[data-testid="stSidebar"] hr {{
    border-color: rgba(255,255,255,0.15) !important;
}}
[data-testid="stSidebar"] [data-testid="stSelectbox"] div,
[data-testid="stSidebar"] [data-testid="stDateInput"] input {{
    background: rgba(255,255,255,0.08) !important;
    border-color: rgba(255,255,255,0.2) !important;
    color: #E2E8F0 !important;
    border-radius: 6px !important;
}}

/* 메트릭 카드 */
[data-testid="stMetric"] {{
    background: {C_CARD};
    border-radius: 12px;
    padding: 18px 22px 14px 22px !important;
    border-left: 4px solid {C_ACCENT};
    box-shadow: 0 1px 8px rgba(15,23,42,0.08);
}}
[data-testid="stMetricLabel"] {{
    font-size: 0.78rem !important;
    font-weight: 600 !important;
    color: {C_MUTED} !important;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}}
[data-testid="stMetricValue"] {{
    font-size: 1.7rem !important;
    font-weight: 700 !important;
    color: {C_PRIMARY} !important;
}}

/* 탭 스타일 */
[data-testid="stTabs"] [role="tablist"] {{
    border-bottom: 2px solid {C_BORDER};
    gap: 0;
}}
[data-testid="stTabs"] [role="tab"] {{
    font-weight: 600 !important;
    font-size: 0.9rem !important;
    color: {C_MUTED} !important;
    padding: 10px 20px !important;
    border-radius: 0 !important;
    border-bottom: 2px solid transparent !important;
    margin-bottom: -2px !important;
    transition: color 0.15s, border-color 0.15s !important;
}}
[data-testid="stTabs"] [role="tab"][aria-selected="true"] {{
    color: {C_PRIMARY} !important;
    border-bottom-color: {C_GOLD} !important;
    background: transparent !important;
}}

/* dataframe */
[data-testid="stDataFrame"] {{
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 1px 6px rgba(15,23,42,0.07);
}}

/* 다운로드 버튼 */
[data-testid="stDownloadButton"] button {{
    background: linear-gradient(135deg, {C_PRIMARY}, {C_ACCENT}) !important;
    color: #ffffff !important;
    border: none !important;
    border-radius: 8px !important;
    font-weight: 600 !important;
    padding: 8px 18px !important;
    box-shadow: 0 2px 6px rgba(37,99,235,0.25) !important;
    transition: opacity 0.15s !important;
}}
[data-testid="stDownloadButton"] button:hover {{
    opacity: 0.88 !important;
}}

/* expander */
[data-testid="stExpander"] {{
    border-radius: 10px !important;
    border: 1px solid {C_BORDER} !important;
    box-shadow: 0 1px 4px rgba(15,23,42,0.05) !important;
    background: {C_CARD} !important;
}}

/* divider */
hr {{
    border-color: {C_BORDER} !important;
    margin: 1.2rem 0 !important;
}}
</style>
""", unsafe_allow_html=True)

title_placeholder = st.empty()

# ─── 사이드바 ─────────────────────────────────────────────────

with st.sidebar:
    if st.button("🔄 새로고침", use_container_width=True):
        load_from_mysql.clear()
        st.rerun()

    st.divider()

    # ── 필터 ─────────────────────────────────────────────────
    st.markdown(
        "<p style='font-size:0.85rem;font-weight:700;letter-spacing:1px;"
        "text-transform:uppercase;color:#94A3B8;margin-bottom:8px;'>필터</p>",
        unsafe_allow_html=True,
    )

    # (필터는 데이터 로드 후 아래에서 채워짐 — placeholder)
    filter_placeholder = st.empty()

# ─── MySQL 자동 로드 ──────────────────────────────────────────

if not DB_PASSWORD_ENV:
    st.warning("환경변수 `AS_DB_PASSWORD`를 설정하세요.")
    st.stop()

with st.spinner("MySQL에서 데이터 로드 중..."):
    try:
        df_raw = load_from_mysql(DB_HOST, DB_USER, DB_PASSWORD_ENV, DB_NAME, TABLE_NAME)
    except Exception as e:
        st.error(f"MySQL 연결 실패: {e}")
        st.stop()

if df_raw.empty:
    st.warning("테이블에 데이터가 없습니다.")
    st.stop()

# ─── 필터 위젯 (데이터 로드 후 동적 생성) ────────────────────

with filter_placeholder.container():
    # 날짜 범위
    date_range = None
    if "점검일" in df_raw.columns and df_raw["점검일"].notna().any():
        valid_d = df_raw["점검일"].dropna()
        min_d, max_d = valid_d.min().date(), valid_d.max().date()
        date_range = st.date_input(
            "점검일 범위", value=(min_d, max_d), min_value=min_d, max_value=max_d
        )

    partners  = _build_filter_options(df_raw, "협력사")
    vtypes    = _build_filter_options(df_raw, "위반유형")

    sel_partner   = st.selectbox("협력사", options=["전체"] + partners, index=0)
    sel_vtype     = st.selectbox("위반유형", options=["전체"] + vtypes, index=0)
    sel_status    = st.radio("조치 여부", ["전체", "완료", "미완료"], horizontal=True)

    st.divider()
    st.success(f"총 **{len(df_raw):,}건** 로드 완료")

partner_title = "사외" if sel_partner == "전체" else sel_partner
title_placeholder.markdown(
    f"<h1 style='color:{C_PRIMARY};font-weight:800;font-size:2.08rem;"
    f"font-family:Noto Sans KR,Malgun Gothic,sans-serif;"
    f"border-bottom:3px solid {C_GOLD};padding-bottom:10px;margin-bottom:0.2rem;'>"
    f"{partner_title} 현장 점검 및 조치 사항 대시보드</h1>",
    unsafe_allow_html=True,
)

# ─── 필터 적용 ────────────────────────────────────────────────

df = df_raw.copy()

if date_range and len(date_range) == 2 and "점검일" in df.columns:
    s, e = pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1])
    df = df[df["점검일"].isna() | df["점검일"].between(s, e)]

if sel_partner != "전체" and "협력사" in df.columns:
    df = df[df["협력사"] == sel_partner]
if sel_vtype != "전체" and "위반유형" in df.columns:
    df = df[df["위반유형"] == sel_vtype]

if sel_status == "완료":
    df = df[df["조치완료"]]
elif sel_status == "미완료":
    df = df[~df["조치완료"]]

if df.empty:
    st.warning("필터 조건에 맞는 데이터가 없습니다.")
    st.stop()

# ─── 탭 ──────────────────────────────────────────────────────

tab1, tab2, tab3 = st.tabs(["📊 대시보드", "📋 상세 목록", "🖼️ 이미지 갤러리"])

# ════════════════════════════════════════════════════════════
# TAB 1 — 대시보드
# ════════════════════════════════════════════════════════════
with tab1:
    total     = len(df)
    completed = int(df["조치완료"].sum())
    pending   = total - completed
    rate      = round(completed / total * 100) if total > 0 else 0
    wow = None
    pending_wow_text = "(전주대비 -)"
    if "점검일" in df.columns and df["점검일"].notna().any():
        week_base = df[df["점검일"].notna()].copy()
        iso_curr = week_base["점검일"].max().isocalendar()
        prev_ref = week_base["점검일"].max() - pd.Timedelta(days=7)
        iso_prev = prev_ref.isocalendar()

        curr_week_pending = int(
            week_base[
                (week_base["점검일"].dt.isocalendar().year == iso_curr.year)
                & (week_base["점검일"].dt.isocalendar().week == iso_curr.week)
                & (~week_base["조치완료"])
            ].shape[0]
        )
        prev_week_pending = int(
            week_base[
                (week_base["점검일"].dt.isocalendar().year == iso_prev.year)
                & (week_base["점검일"].dt.isocalendar().week == iso_prev.week)
                & (~week_base["조치완료"])
            ].shape[0]
        )
        wow = curr_week_pending - prev_week_pending
        pending_wow_text = f"(전주대비 {wow:+,}건)"

    if wow is None:
        wow_color = C_TEXT
    elif wow > 0:
        wow_color = C_DANGER
    elif wow < 0:
        wow_color = C_ACCENT
    else:
        wow_color = "#000000"

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("총 점검 건수", f"{total:,}건")
    k2.metric("조치 완료",   f"{completed:,}건")
    wow_len = len(pending_wow_text)
    wow_font_size = max(8, min(12, 15 - (wow_len // 3)))
    with k3:
        k3.metric("미조치", f"{pending:,}건")
        st.markdown(
            f"<div style='margin-top:-0.2rem;margin-left:0.6rem;font-size:{wow_font_size}px;"
            f"color:{wow_color};font-weight:600;'>{pending_wow_text}</div>",
            unsafe_allow_html=True,
        )
    k4.metric("조치 완료율", f"{rate}%")

    st.divider()

    # ── 협력사별 건수 / 위반유형별 건수 ─────────────────────
    c_l, c_r = st.columns(2)

    with c_l:
        _section("협력사별 건수")
        if "협력사" in df.columns:
            pc = df["협력사"].value_counts().reset_index()
            pc.columns = ["협력사", "건수"]
            fig2 = px.bar(
                pc, x="협력사", y="건수",
                color="건수",
                color_continuous_scale=[[0, "#93C5FD"], [1, C_PRIMARY]],
                text="건수",
            )
            fig2.update_traces(
                textposition="outside",
                textfont=dict(size=12, color=C_TEXT, family="Malgun Gothic,sans-serif"),
                marker_line_width=0,
            )
            fig2.update_layout(**_base_layout(
                height=360, showlegend=False, coloraxis_showscale=False,
            ))
            _style_axes(fig2)
            st.plotly_chart(fig2, use_container_width=True)

    with c_r:
        _section("위반유형별 건수")
        if "위반유형" in df.columns:
            vtype_series = (
                df["위반유형"]
                .dropna()
                .map(clean_violation_type_label)
            )
            vtype_series = vtype_series[vtype_series != ""]
            vt = vtype_series.value_counts().reset_index()
            vt.columns = ["위반유형", "건수"]
            fig = px.bar(
                vt, x="건수", y="위반유형", orientation="h",
                color="건수",
                color_continuous_scale=[[0, "#BAE6FD"], [1, C_ACCENT]],
                text="건수",
            )
            fig.update_traces(
                textposition="outside",
                textfont=dict(size=12, color=C_TEXT),
                marker_line_width=0,
            )
            fig.update_layout(**_base_layout(
                height=360,
                yaxis={"categoryorder": "total ascending"},
                showlegend=False, coloraxis_showscale=False,
                margin=dict(l=10, r=40, t=44, b=10),
            ))
            _style_axes(fig)
            st.plotly_chart(fig, use_container_width=True)

    # ── 협력사 × 위반유형 히트맵 ─────────────────────────────
    if "협력사" in df.columns and "위반유형" in df.columns:
        _section("협력사 × 위반유형 히트맵")
        heat_df = df.copy()
        heat_df["위반유형_표시"] = heat_df["위반유형"].map(clean_violation_type_label)
        heat_df = heat_df[heat_df["위반유형_표시"] != ""]
        if not heat_df.empty:
            pivot = (
                heat_df.groupby(["협력사", "위반유형_표시"]).size()
                .reset_index(name="건수")
                .pivot(index="협력사", columns="위반유형_표시", values="건수")
                .fillna(0).astype(int)
            )
            fig5 = px.imshow(
                pivot, text_auto=True, aspect="auto",
                color_continuous_scale=[[0, "#F0F9FF"], [0.5, "#3B82F6"], [1, C_PRIMARY]],
            )
            fig5.update_traces(
                textfont=dict(size=12, color=C_TEXT, family="Malgun Gothic,sans-serif"),
            )
            fig5.update_layout(**_base_layout(
                height=max(200, len(pivot) * 52 + 80),
                coloraxis_showscale=False,
            ))
            _style_axes(fig5)
            st.plotly_chart(fig5, use_container_width=True)
        else:
            st.caption("히트맵 표시 대상 데이터가 없습니다.")

        # ── 위반유형 파레토 그래프 ────────────────────────────
        _section("위반유형 파레토 분석")
        vt_pareto = (
            df["위반유형"]
            .dropna()
            .map(clean_violation_type_label)
            .loc[lambda s: s != ""]
            .value_counts()
            .reset_index()
        )
        vt_pareto.columns = ["위반유형", "건수"]
        if vt_pareto.empty:
            st.caption("파레토 표시 대상 데이터가 없습니다.")
        else:
            vt_pareto["누적건수"] = vt_pareto["건수"].cumsum()
            total_v = vt_pareto["건수"].sum()
            vt_pareto["누적비율"] = (vt_pareto["누적건수"] / total_v * 100).round(1)

            fig_p = make_subplots(specs=[[{"secondary_y": True}]])
            fig_p.add_trace(
                go.Bar(
                    x=vt_pareto["위반유형"], y=vt_pareto["건수"],
                    name="건수",
                    marker=dict(
                        color=vt_pareto["건수"],
                        colorscale=[[0, "#93C5FD"], [1, C_PRIMARY]],
                        showscale=False, line_width=0,
                    ),
                ),
                secondary_y=False,
            )
            fig_p.add_trace(
                go.Scatter(
                    x=vt_pareto["위반유형"], y=vt_pareto["누적비율"],
                    name="누적비율",
                    mode="lines+markers+text",
                    text=[f"{v}%" for v in vt_pareto["누적비율"]],
                    textposition="top center",
                    textfont=dict(size=11, color=C_DANGER, family="Malgun Gothic,sans-serif"),
                    line=dict(color=C_GOLD, width=3),
                    marker=dict(size=7, color=C_GOLD, line=dict(width=2, color=C_CARD)),
                    cliponaxis=False,
                ),
                secondary_y=True,
            )
            fig_p.update_layout(**_base_layout(
                height=460,
                margin=dict(l=10, r=10, t=60, b=10),
                legend=_LEGEND_STYLE,
            ))
            fig_p.update_yaxes(**_AXIS_STYLE, title_text="건수", secondary_y=False)
            fig_p.update_yaxes(**_AXIS_STYLE, title_text="누적비율(%)", range=[0, 115], secondary_y=True)
            fig_p.update_xaxes(**_AXIS_STYLE, title_text="위반유형", tickangle=-20)
            st.plotly_chart(fig_p, use_container_width=True)

    # ── 점검 / 조치 추이 (주간/월별) ───────────────────────────
    if "점검일" in df.columns and df["점검일"].notna().any():
        h_l, h_r = st.columns([7, 3])
        with h_r:
            trend_mode = st.radio(
                "집계 단위",
                ["주간", "월별"],
                index=1,
                horizontal=True,
                label_visibility="collapsed",
                key="trend_mode_toggle",
            )
        with h_l:
            if trend_mode == "주간":
                _section("주간점검 조치추이")
            else:
                _section("월별점검 조치 추이")

        trend_df = df.copy()
        if trend_mode == "주간":
            iso = trend_df["점검일"].dt.isocalendar()
            trend_df["기간라벨"] = (
                iso["year"].astype(str).str[-2:]
                + "년_"
                + iso["week"].astype(str)
                + "주차"
            )
        else:
            trend_df["기간라벨"] = (
                trend_df["점검일"].dt.strftime("%y")
                + "년_"
                + trend_df["점검일"].dt.month.astype(str)
                + "월"
            )

        trend_group = (
            trend_df.groupby("기간라벨")
            .agg(
                정렬키=("점검일", "min"),
                점검건수=("점검일", "count"),
                조치건수=("조치완료", "sum"),
            )
            .reset_index()
            .sort_values("정렬키")
        )
        trend_group["조치건수"] = trend_group["조치건수"].astype(int)

        fig_trend = make_subplots(specs=[[{"secondary_y": True}]])
        fig_trend.add_trace(
            go.Bar(
                x=trend_group["기간라벨"], y=trend_group["점검건수"], name="점검건수",
                marker=dict(color=C_ACCENT, opacity=0.85, line_width=0),
                hovertemplate="구간: %{x}<br>점검건수: %{y}<extra></extra>",
            ),
            secondary_y=False,
        )
        fig_trend.add_trace(
            go.Scatter(
                x=trend_group["기간라벨"], y=trend_group["조치건수"], name="조치건수",
                mode="lines+markers",
                line=dict(color=C_GOLD, width=3),
                marker=dict(size=7, color=C_GOLD, line=dict(width=2, color=C_CARD)),
                hovertemplate="구간: %{x}<br>조치건수: %{y}<extra></extra>",
            ),
            secondary_y=True,
        )
        fig_trend.update_layout(**_base_layout(
            height=360,
            margin=dict(l=10, r=10, t=60, b=10),
            legend=_LEGEND_STYLE,
        ))
        fig_trend.update_xaxes(**_AXIS_STYLE, title_text="", type="category")
        fig_trend.update_yaxes(**_AXIS_STYLE, title_text="점검건수", secondary_y=False)
        fig_trend.update_yaxes(**_AXIS_STYLE, title_text="조치건수", secondary_y=True)
        st.plotly_chart(fig_trend, use_container_width=True)

    # ── 협력사별 조치완료율 ───────────────────────────────────
    if "협력사" in df.columns:
        _section("협력사별 조치완료율")
        cmp_rate = (
            df.groupby("협력사")["조치완료"]
            .agg(총건수="count", 완료건수="sum")
            .reset_index()
        )
        cmp_rate["미완료건수"] = cmp_rate["총건수"] - cmp_rate["완료건수"]
        cmp_rate["완료율(%)"] = (cmp_rate["완료건수"] / cmp_rate["총건수"] * 100).round(1)
        cmp_rate = cmp_rate.sort_values("완료율(%)", ascending=True)
        rate_text_pos = [
            "middle right" if v < 95 else "middle left"
            for v in cmp_rate["완료율(%)"]
        ]

        fig_rate = make_subplots(specs=[[{"secondary_y": True}]])
        fig_rate.add_trace(
            go.Bar(
                y=cmp_rate["협력사"], x=cmp_rate["완료건수"],
                name="완료", orientation="h",
                marker=dict(color=C_SUCCESS, line_width=0),
                text=cmp_rate["완료건수"], textposition="inside",
                textfont=dict(size=12, color="#FFFFFF"),
            ),
            secondary_y=False,
        )
        fig_rate.add_trace(
            go.Bar(
                y=cmp_rate["협력사"], x=cmp_rate["미완료건수"],
                name="미완료", orientation="h",
                marker=dict(color=C_DANGER, opacity=0.80, line_width=0),
                text=cmp_rate["미완료건수"], textposition="inside",
                textfont=dict(size=12, color="#FFFFFF"),
            ),
            secondary_y=False,
        )
        fig_rate.add_trace(
            go.Scatter(
                y=cmp_rate["협력사"], x=cmp_rate["완료율(%)"],
                name="완료율(%)", mode="markers+text",
                text=[f"{v}%" for v in cmp_rate["완료율(%)"]],
                textposition=rate_text_pos,
                textfont=dict(size=12, color=C_PRIMARY, family="Malgun Gothic,sans-serif"),
                marker=dict(size=11, color=C_GOLD, symbol="diamond",
                            line=dict(width=2, color=C_CARD)),
                cliponaxis=False,
            ),
            secondary_y=True,
        )
        fig_rate.update_layout(**_base_layout(
            barmode="stack",
            height=max(280, len(cmp_rate) * 44 + 80),
            margin=dict(l=10, r=90, t=60, b=10),
            legend=_LEGEND_STYLE,
        ))
        fig_rate.update_xaxes(**_AXIS_STYLE, title_text="건수", range=[-5, 110])
        fig_rate.update_yaxes(**_AXIS_STYLE, title_text="완료율(%)", range=[0, 120], secondary_y=True)
        st.plotly_chart(fig_rate, use_container_width=True)

    # ── 조치 소요일 분포 (Box Plot) ──────────────────────────
    if "점검일" in df.columns and "조치일" in df.columns:
        done_df = df[df["조치완료"]].copy()
        if not done_df.empty:
            done_df["소요일"] = (done_df["조치일"] - done_df["점검일"]).dt.days
            done_df = done_df[done_df["소요일"] >= 0]
        if not done_df.empty:
            _section("조치 소요일 분포 (협력사별)")
            if "협력사" in done_df.columns:
                median_order = (
                    done_df.groupby("협력사")["소요일"].median()
                    .sort_values().index.tolist()
                )
                # 협력사 수에 따라 팔레트 생성
                n_cmp = len(median_order)
                palette = px.colors.sample_colorscale(
                    [[0, "#93C5FD"], [0.5, C_ACCENT], [1, C_PRIMARY]], n_cmp
                )
                color_map = dict(zip(median_order, palette))
                fig_box = px.box(
                    done_df, x="협력사", y="소요일",
                    category_orders={"협력사": median_order},
                    color="협력사", color_discrete_map=color_map,
                    points="outliers",
                    labels={"소요일": "조치 소요일(일)"},
                )
                fig_box.update_traces(
                    marker=dict(size=5, opacity=0.6),
                    line_width=2,
                )
                fig_box.update_layout(**_base_layout(
                    height=380, showlegend=False,
                ))
                _style_axes(fig_box)
                fig_box.add_hline(
                    y=done_df["소요일"].median(),
                    line_dash="dash", line_color=C_GOLD, line_width=2,
                    annotation_text=f"전체 중앙값 {done_df['소요일'].median():.0f}일",
                    annotation_position="top right",
                    annotation_font=dict(color=C_GOLD, size=12),
                )
                st.plotly_chart(fig_box, use_container_width=True)

    # ── 미조치 경과기간 분석 ─────────────────────────────────
    if "점검일" in df.columns:
        aging_df = df[~df["조치완료"]].copy()
        if not aging_df.empty:
            today = pd.Timestamp(datetime.now().date())
            aging_df["경과일"] = (today - aging_df["점검일"]).dt.days
            aging_df = aging_df[aging_df["경과일"] >= 0]

        if not aging_df.empty:
            _section("미조치 경과기간 분석 (구간별)")
            bins   = [-1, 7, 14, 30, 60, float("inf")]
            labels = ["7일 이하", "8~14일", "15~30일", "31~60일", "60일 초과"]
            aging_df["경과구간"] = pd.cut(aging_df["경과일"], bins=bins, labels=labels)

            aging_cnt = aging_df["경과구간"].value_counts().reindex(labels, fill_value=0).reset_index()
            aging_cnt.columns = ["경과구간", "건수"]

            color_map = {
                "7일 이하":  C_SUCCESS,
                "8~14일":    C_WARNING,
                "15~30일":   "#F97316",
                "31~60일":   C_DANGER,
                "60일 초과": C_DANGER_HI,
            }
            fig_aging = px.bar(
                aging_cnt, x="경과구간", y="건수",
                color="경과구간", color_discrete_map=color_map,
                text="건수",
            )
            fig_aging.update_traces(
                textposition="outside",
                textfont=dict(size=13, color=C_TEXT),
                marker_line_width=0,
            )
            fig_aging.update_layout(**_base_layout(
                height=340, showlegend=False,
                xaxis_title="미조치 경과기간", yaxis_title="건수",
            ))
            _style_axes(fig_aging)
            st.plotly_chart(fig_aging, use_container_width=True)

            # 60일 초과 건 경고 테이블
            critical = aging_df[aging_df["경과구간"] == "60일 초과"]
            if not critical.empty:
                with st.expander(f"⚠️ 60일 초과 미조치 건 ({len(critical)}건)", expanded=True):
                    warn_cols = [c for c in ["NO", "협력사", "호선", "블록", "위반유형", "점검자", "점검일", "경과일"] if c in critical.columns]
                    warn_disp = critical[warn_cols].copy()
                    if "점검일" in warn_disp.columns:
                        warn_disp["점검일"] = warn_disp["점검일"].dt.strftime("%Y-%m-%d")
                    st.dataframe(warn_disp, use_container_width=True,
                                 column_config={"경과일": st.column_config.NumberColumn("경과일(일)", width="small")})

    st.divider()
    render_dashboard_pdf_capture_button()

# ════════════════════════════════════════════════════════════
# TAB 2 — 상세 목록
# ════════════════════════════════════════════════════════════
with tab2:
    _section(f"점검 목록 ({len(df):,}건)")

    show_cols = [c for c in DISPLAY_COLS if c in df.columns]
    df_disp = df[show_cols].copy()
    for col in ("점검일", "조치일"):
        if col in df_disp.columns:
            df_disp[col] = fmt_date_col(df_disp[col])

    st.dataframe(
        df_disp,
        use_container_width=True,
        height=520,
        column_config={
            "NO":    st.column_config.NumberColumn("NO", width="small"),
            "조치완료": st.column_config.CheckboxColumn("조치완료", width="small"),
        },
    )

    csv = df_disp.to_csv(index=False, encoding="utf-8-sig")
    st.download_button(
        "⬇ CSV 다운로드", data=csv,
        file_name=f"현장점검_{datetime.now().strftime('%Y%m%d')}.csv",
        mime="text/csv",
    )

# ════════════════════════════════════════════════════════════
# TAB 3 — 이미지 갤러리
# ════════════════════════════════════════════════════════════
with tab3:
    _section("점검 / 조치 사진 갤러리")

    HAS_IMG1 = "점검사진" in df.columns
    HAS_IMG2 = "조치사진" in df.columns
    img_df = pd.DataFrame()

    if not HAS_IMG1 and not HAS_IMG2:
        st.info("이미지 컬럼이 없습니다.")
    else:
        def _has_img(val):
            return isinstance(val, str) and val.startswith("data:image")

        mask = pd.Series(False, index=df.index)
        if HAS_IMG1: mask |= df["점검사진"].apply(_has_img)
        if HAS_IMG2: mask |= df["조치사진"].apply(_has_img)
        img_df = df[mask]

        if img_df.empty:
            st.info("표시할 이미지가 없습니다.")
        else:
            st.caption(f"사진 포함 건수: {len(img_df):,}건")

            _NO_IMG_HTML = (
                f"<div style='height:130px;display:flex;align-items:center;"
                f"justify-content:center;border:1.5px dashed {C_BORDER};"
                f"border-radius:10px;color:{C_MUTED};font-size:13px;"
                f"background:{C_BG};font-family:Malgun Gothic,sans-serif;'>사진 없음</div>"
            )

            for _, row in img_df.iterrows():
                점검일_str = (
                    row["점검일"].strftime("%Y-%m-%d")
                    if "점검일" in row and pd.notna(row["점검일"]) else ""
                )
                조치일_str = (
                    row["조치일"].strftime("%Y-%m-%d")
                    if "조치일" in row and pd.notna(row["조치일"]) else "미조치"
                )
                label = (
                    f"NO {row.get('NO', '-')} │ {row.get('협력사', '')} │ "
                    f"{row.get('호선', '')} {row.get('블록', '')} │ "
                    f"{row.get('위반유형', '')} │ 점검일: {점검일_str}"
                )

                with st.expander(label, expanded=False):
                    col_info, col_img1, col_img2 = st.columns([2, 3, 3])

                    with col_info:
                        def _e(v) -> str:
                            return html_mod.escape(str(v or ""))
                        st.markdown(
                            f"<div style='font-family:Malgun Gothic,AppleGothic,sans-serif;"
                            f"font-size:13px;line-height:1.8;color:{C_TEXT};'>"
                            f"<b style='color:{C_MUTED};'>구분</b>&nbsp;&nbsp;{_e(row.get('구분'))}<br>"
                            f"<b style='color:{C_MUTED};'>점검자</b>&nbsp;{_e(row.get('점검자'))}<br>"
                            f"<b style='color:{C_MUTED};'>점검일</b>&nbsp;{_e(점검일_str)}<br>"
                            f"<b style='color:{C_MUTED};'>점검내용</b><br>"
                            f"<span style='color:{C_TEXT};'>{_e(row.get('점검내용'))}</span>"
                            f"<hr style='border-color:{C_BORDER};margin:8px 0;'>"
                            f"<b style='color:{C_MUTED};'>조치일</b>&nbsp;&nbsp;{_e(조치일_str)}<br>"
                            f"<b style='color:{C_MUTED};'>조치내용</b><br>"
                            f"<span style='color:{C_TEXT};'>{_e(row.get('조치내용'))}</span>"
                            f"</div>",
                            unsafe_allow_html=True,
                        )

                    with col_img1:
                        st.markdown(
                            f"<p style='font-size:12px;font-weight:600;color:{C_MUTED};"
                            f"letter-spacing:0.5px;margin-bottom:4px;'>🔍 점검 사진</p>",
                            unsafe_allow_html=True,
                        )
                        img1 = data_url_to_pil(row.get("점검사진", "")) if HAS_IMG1 else None
                        if img1: st.image(img1, use_container_width=True)
                        else: st.markdown(_NO_IMG_HTML, unsafe_allow_html=True)

                    with col_img2:
                        st.markdown(
                            f"<p style='font-size:12px;font-weight:600;color:{C_MUTED};"
                            f"letter-spacing:0.5px;margin-bottom:4px;'>✅ 조치 사진</p>",
                            unsafe_allow_html=True,
                        )
                        img2 = data_url_to_pil(row.get("조치사진", "")) if HAS_IMG2 else None
                        if img2: st.image(img2, use_container_width=True)
                        else: st.markdown(_NO_IMG_HTML, unsafe_allow_html=True)

    st.divider()
    if not img_df.empty:
        gallery_pdf = build_gallery_pdf(img_df, HAS_IMG1, HAS_IMG2)
        st.download_button(
            "⬇ 이미지 갤러리 PDF 저장",
            data=gallery_pdf,
            file_name=f"현장점검_갤러리_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf",
            mime="application/pdf",
        )
    else:
        st.caption("PDF 저장 대상 이미지가 없습니다.")
