from __future__ import annotations
"""
step_48_utils_logs_upload_ML.py

역할 요약
-----------
머신러닝 계열 로그(예측_모델_log)를 DB에 안전하게 업로드하기 위한 공용 유틸.

1) ensure_table_exists(db_url, table)
   - 지정한 테이블(기본: 예측_모델_log)이 없으면 기본 스키마로 자동 생성

2) upload_log_df_to_db(df, db_url, table)
   - CSV 등에서 만든 로그 DataFrame(df)을
     → DB 테이블에 append (INSERT)하는 함수
   - df에는 param_* 같은 추가 컬럼이 있어도 되고,
     실제 DB에 존재하는 컬럼만 골라서 업로드 (안전)

이 모듈은 보통 step_46_utils_save_logcsv_ML.write_csv_log_ML(...) 에서
CSV 저장 이후 DB 업로드 단계에서 호출됩니다.
"""

import pandas as pd
from sqlalchemy import create_engine, text


def ensure_table_exists(db_url: str, table: str = "예측_모델_log") -> None:
    """
    예측_모델_log 테이블이 없으면 자동으로 생성하는 함수.

    Parameters
    ----------
    db_url : str
        SQLAlchemy 스타일 DB URL
        예) "mysql+pymysql://user:pw@host:3306/dbname?charset=utf8mb4"
    table : str, default "예측_모델_log"
        존재 여부를 확인하고, 없으면 생성할 테이블명

    Notes
    -----
    - 기본 스키마(컬럼)는 ML 로그에 공통으로 쓰는 최소 컬럼만 정의
      (timestamp, year, 협력사, tag, engine, R2_train, R2_valid,
       MAE_valid, RMSE_valid, split_ratio, train_range, valid_range)
    - 하이퍼파라미터들은 CSV에서 param_* 컬럼로 관리하고,
      DB에는 별도 컬럼을 만들지 않는 설계입니다.
    """
    engine = create_engine(db_url, pool_pre_ping=True, future=True)

    create_sql = f"""
    CREATE TABLE IF NOT EXISTS `{table}` (
        `timestamp` DATETIME NULL,
        `year` INT NULL,
        `협력사` VARCHAR(100) NULL,
        `tag` VARCHAR(50) NULL,
        `engine` VARCHAR(50) NULL,
        `R2_train` DOUBLE NULL,
        `R2_valid` DOUBLE NULL,
        `MAE_valid` DOUBLE NULL,
        `RMSE_valid` DOUBLE NULL,
        `split_ratio` VARCHAR(20) NULL,
        `train_range` VARCHAR(50) NULL,
        `valid_range` VARCHAR(50) NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """

    try:
        with engine.begin() as conn:
            conn.execute(text(create_sql))
        print(f"[DB] '{table}' 테이블 존재 확인 완료 (없으면 자동 생성됨)")
    except Exception as e:
        # 테이블 생성 실패해도 전체 파이프라인이 바로 죽지 않도록 경고만 출력
        print(f"[DB-WARN] 테이블 생성 실패: {e}")


def upload_log_df_to_db(
    df: pd.DataFrame,
    db_url: str,
    table: str = "예측_모델_log",
) -> None:
    """
    모델선정 로그 DataFrame을 DB 테이블에 append 하는 공통 함수.

    사용 시나리오
    -------------
    - step_46_utils_save_logcsv_ML.write_csv_log_ML(...) 에서
      로그 CSV 저장 후, 같은 df 를 DB 에도 쌓기 위해 호출.

    동작 개요
    ---------
    1) df가 비어 있으면 업로드 스킵
    2) ensure_table_exists(...) 로 테이블이 없으면 생성
    3) DB에서 실제 컬럼 목록(db_cols)을 가져옴
    4) df 컬럼 중 db_cols에 있는 컬럼만 추려서 INSERT (param_* 등은 자동 제외)
    5) timestamp 컬럼은 datetime으로 형 변환 후 업로드

    Parameters
    ----------
    df : pd.DataFrame
        업로드할 로그 데이터.
        - CSV 기준으로는 모든 컬럼(param_* 포함)을 담고 있어도 괜찮고,
          여기서 DB 테이블에 실제로 존재하는 컬럼만 골라서 INSERT 합니다.
    db_url : str
        SQLAlchemy 스타일 DB URL
    table : str, default "예측_모델_log"
        append 업로드 대상 테이블명
    """
    if df.empty:
        print("[DB] 업로드할 로그가 없습니다. (빈 DataFrame)")
        return

    # 1) 테이블 없으면 기본 스키마로 자동 생성
    ensure_table_exists(db_url, table)

    try:
        engine = create_engine(db_url, pool_pre_ping=True, future=True)

        # 2) DB 컬럼 목록 조회 (SELECT * FROM table LIMIT 0 → 헤더만 가져오는 트릭)
        with engine.begin() as conn:
            result = conn.execute(text(f"SELECT * FROM `{table}` LIMIT 0"))
            db_cols = list(result.keys())

        # 3) DataFrame 복사 후 timestamp 형 변환
        df_for_db = df.copy()

        if "timestamp" in df_for_db.columns:
            df_for_db["timestamp"] = pd.to_datetime(
                df_for_db["timestamp"], errors="coerce"
            )

        # 4) DB에 실제 존재하는 컬럼만 필터링 (param_* 등은 자동 제외)
        use_cols = [c for c in df_for_db.columns if c in db_cols]

        if not use_cols:
            print(f"[DB-WARN] '{table}' 테이블과 공통 컬럼이 없어 업로드 스킵됨.")
            return

        df_for_db = df_for_db[use_cols]

        # 5) DB INSERT (append)
        with engine.begin() as conn:
            df_for_db.to_sql(
                table,
                con=conn,
                if_exists="append",
                index=False,
            )

        print(
            f"[DB] {table} 테이블에 로그 {len(df_for_db)}건 append 완료 "
            f"(columns={use_cols})"
        )

    except Exception as e:
        # 여기서 실패해도 전체 학습/예측 파이프라인까지 죽지 않도록 경고만 출력
        print(f"[DB-WARN] 로그 업로드 실패: {e}")
