from __future__ import annotations

import datetime as dt
from typing import List, Dict, Set


# ─────────────────────────────────────────────
# CONFIG: 회사 달력에 맞게 수정하는 영역
# ─────────────────────────────────────────────

# 1) 고정 양력 공휴일 (월, 일)
#    - 실제 사용하는 공휴일만 남기거나 추가해서 사용하세요.
FIXED_SOLAR_HOLIDAYS: List[tuple[int, int]] = [
    (1, 1),   # 신정
    (3, 1),   # 삼일절
    (5, 5),   # 어린이날
    (6, 6),   # 현충일
    (8, 15),  # 광복절
    (10, 3),  # 개천절
    (10, 9),  # 한글날
    (12, 25), # 성탄절
]

# 2) 명절 등 양력으로 변환된 휴일 날짜 (연도별로 관리)
#    - 실제 회사/국가 달력에 맞게 "양력 기준 (월, 일)" 값으로 채워 넣으시면 됩니다.
#    - 예시: 2025년 설/추석 연휴 (임의 날짜 예시, 실제와 다를 수 있음)
LUNAR_HOLIDAYS_BY_YEAR: Dict[int, List[tuple[int, int]]] = {
    2025: [
        # 설날 연휴 예시
        (1, 27), (1, 28), (1, 29), (1, 30),
        # 추석 연휴 예시
        (10, 5), (10, 6), (10, 7), (10, 9), (10, 10),
    ],
    2026: [
        # 설날 연휴 예시
        (2, 16), (2, 17), (2, 18),
        # 추석 연휴 예시
        (9, 24), (9, 25),
        # 회사 연중 휴무
        (1, 2), (2, 19), (9, 28),
        # 부처님 오신날/광복절/개천절 대체휴일
        (5, 25), (8, 17), (10, 5),
    ],
}

# 3) 회사 휴가/창립기념일 등 "기간" 단위 휴무 (start ~ end, 양끝 포함, 양력 기준)
#    - 실제 연도/기간에 맞게 수정하세요.
COMPANY_VACATION_RANGES: List[dict] = [
    # 예시) 2025년 여름휴가: 8/4 ~ 8/8
    {
        "name": "2025년 하계휴가",
        "start": dt.date(2025, 8, 4),
        "end": dt.date(2025, 8, 8),
    },
    {
        "name": "2026년 하계휴가",
        "start": dt.date(2026, 8, 3),
        "end": dt.date(2026, 8, 7),
    },
]

# 4) 주말을 휴무로 볼지 여부 (True: 토/일을 자동 휴무로 처리)
WEEKEND_IS_HOLIDAY: bool = True


# ─────────────────────────────────────────────
# 내부 유틸
# ─────────────────────────────────────────────

def _iter_dates(start: dt.date, end: dt.date):
    """
    start ~ end (양끝 포함) 날짜를 하루 단위로 생성하는 제너레이터.
    예) 2025-01-01 ~ 2025-01-03 → 1, 2, 3일 세 날짜를 순서대로 yield
    """
    cur = start
    while cur <= end:
        yield cur
        cur += dt.timedelta(days=1)


def _fixed_solar_holidays(year: int) -> Set[dt.date]:
    """
    고정 양력 공휴일을 해당 연도의 date 집합으로 변환.
    예) (3, 1) → 2025-03-01
    """
    return {dt.date(year, m, d) for (m, d) in FIXED_SOLAR_HOLIDAYS}


def _lunar_holidays_to_solar(year: int) -> Set[dt.date]:
    """
    명절(설날/추석 등) 휴일 (양력 기준)을 date 집합으로 변환.

    LUNAR_HOLIDAYS_BY_YEAR 에는 이미 "양력 (월, 일)" 이 들어있다고 가정합니다.
    실제 사용 시에는 각 연도별 설/추석 양력 날짜를 LUNAR_HOLIDAYS_BY_YEAR 에 등록하세요.
    """
    md_list = LUNAR_HOLIDAYS_BY_YEAR.get(year, [])
    return {dt.date(year, m, d) for (m, d) in md_list}


def _company_vacation_days(year: int) -> Set[dt.date]:
    """
    회사 휴가/창립기념일 등의 기간 휴무일을 date 집합으로 생성.
    - COMPANY_VACATION_RANGES 각 항목의 start~end 범위 중
      지정한 year에 해당하는 날짜만 포함합니다.
    """
    days: Set[dt.date] = set()
    for item in COMPANY_VACATION_RANGES:
        start: dt.date = item["start"]
        end: dt.date = item["end"]
        # 다른 연도와 걸쳐 있을 수 있으므로 year에 해당하는 날짜만 포함
        for d in _iter_dates(start, end):
            if d.year == year:
                days.add(d)
    return days


def _weekend_days(year: int) -> Set[dt.date]:
    """
    해당 연도의 모든 토/일 날짜 집합.
    - WEEKEND_IS_HOLIDAY=True 일 때만 build_holiday_set 에서 사용됩니다.
    """
    first = dt.date(year, 1, 1)
    last = dt.date(year, 12, 31)
    days: Set[dt.date] = set()
    for d in _iter_dates(first, last):
        if d.weekday() >= 5:  # 5=토요일, 6=일요일
            days.add(d)
    return days


# ─────────────────────────────────────────────
# 공개 함수
# ─────────────────────────────────────────────

def build_holiday_set(year: int) -> Set[dt.date]:
    """
    주말, 고정 공휴일, 명절, 회사 휴가일을 모두 포함한
    '해당 연도의 휴무일(date) 집합'을 생성합니다.

    사용 예)
        holidays_2025 = build_holiday_set(2025)
        if dt.date(2025, 3, 1) in holidays_2025:
            ...
    """
    holiday_days: Set[dt.date] = set()

    # 1) 주말
    if WEEKEND_IS_HOLIDAY:
        holiday_days |= _weekend_days(year)

    # 2) 고정 양력 공휴일
    holiday_days |= _fixed_solar_holidays(year)

    # 3) 명절(양력 기준 날짜)
    holiday_days |= _lunar_holidays_to_solar(year)

    # 4) 회사 휴가 등 기간 휴무
    holiday_days |= _company_vacation_days(year)

    return holiday_days


def is_holiday(d: dt.date) -> bool:
    """
    해당 날짜가 휴무일이면 True, 아니면 False 를 반환.
    - 주말/고정 공휴일/명절/회사 휴가 모두 포함.

    인자 타입이 date 가 아니면 TypeError 를 발생시켜
    잘못된 사용을 조기에 발견합니다.
    """
    if not isinstance(d, dt.date):
        raise TypeError("is_holiday()는 datetime.date 객체를 인자로 받습니다.")
    holidays = build_holiday_set(d.year)
    return d in holidays


def next_working_day(d: dt.date) -> dt.date:
    """
    d가 휴무일이면, 휴무일이 아닌 날짜가 나올 때까지 하루씩(+1일) 이동해서 반환.
    d가 이미 영업일이면 그대로 d를 반환합니다.

    무한 루프 방지를 위해 최대 400일까지만 탐색하도록 되어 있습니다.
    (실제 상황에서 이 한계에 도달할 일은 거의 없습니다.)
    """
    if not isinstance(d, dt.date):
        raise TypeError("next_working_day()는 datetime.date 객체를 인자로 받습니다.")

    cur = d
    for _ in range(400):
        if not is_holiday(cur):
            return cur
        cur += dt.timedelta(days=1)

    # 이론상 도달하지 않지만, 방어적으로 마지막 값을 반환
    return cur


if __name__ == "__main__":
    # 간단 동작 테스트
    today = dt.date.today()
    year = today.year

    hset = build_holiday_set(year)
    print(f"[DEBUG] {year}년 휴무일 개수: {len(hset)}")
    print("오늘:", today, "휴무일 여부:", is_holiday(today))
    print("다음 영업일:", next_working_day(today))
