from __future__ import annotations
"""
step_15_best_model_select_ML.py (DB Only)


[선정 규칙 — 복합 점수(Composite Score) 방식]
1) (협력사, engine)별 "최고 성능 1건" 유지
2) 협력사별 최적 engine 1개 선정

각 단계에서 아래 복합 점수가 가장 높은 후보를 선택한다.

  composite_score = w_r2 * R2_norm + w_rmse * RMSE_norm + w_mae * MAE_norm

  - R2_norm  : 그룹 내 R2 순위 정규화  (클수록 → 1)
  - RMSE_norm: 그룹 내 RMSE 순위 정규화 (작을수록 → 1)
  - MAE_norm : 그룹 내 MAE 순위 정규화  (작을수록 → 1)
  - 기본 가중치: w_r2=0.20 / w_rmse=0.35 / w_mae=0.45
    (lag_days 예측 도메인에서 MAE가 "평균 N일 오차"로 가장 직관적이므로 최고 가중)
  - R2 < 0 모델: 복합 점수에 -0.1 패널티 (평균 예측보다 나쁜 모델)
  - 동률 시: 최신 timestamp 우선

[MAPE 처리 방침]
  - MAPE는 모델 선정 기준에서 제외 (lag_days=0인 경우 분모=0 → undefined 위험)
  - DB 로그에 MAPE_valid 컬럼이 있을 경우 출력 로그·CSV에 참고 지표로만 포함

[출력]
- OUT_DIR / best_model_by_vendor_ML.json
- OUT_DIR / logs / {year}_best_model_ML_YYYYMMDD.csv
"""

import argparse
import datetime as dt
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import pymysql
from sqlalchemy import create_engine, text

pymysql.install_as_MySQLdb()

from step_0_MSF import OUT_DIR

# ─────────────────────────────────────────────
# DB 연결 정보
# ─────────────────────────────────────────────
from db_config import DB_URL


# ─────────────────────────────────────────────
# Utils
# ─────────────────────────────────────────────
def _norm_str(x) -> str:
    return " ".join(str(x).split()) if x is not None else ""


# ─────────────────────────────────────────────
# 1) DB 로그 로딩
# ─────────────────────────────────────────────
def load_logs_from_db() -> pd.DataFrame:
    try:
        engine = create_engine(DB_URL, pool_pre_ping=True, future=True)
        with engine.connect() as conn:
            df = pd.read_sql(text("SELECT * FROM 예측_모델_log"), conn)
        print(f"[DB] 예측_모델_log 로드 완료: {len(df)} rows")
        return df
    except Exception as e:
        print(f"[DB-ERROR] 로그 로딩 실패: {e}")
        return pd.DataFrame()


# ─────────────────────────────────────────────
# 2) CHOSEN 필터
# ─────────────────────────────────────────────
def filter_chosen(df: pd.DataFrame) -> pd.DataFrame:
    if "tag" not in df.columns:
        print("[WARN] tag 컬럼 없음 → 전체 데이터 사용")
        return df
    chosen = df[df["tag"].astype(str).str.upper() == "CHOSEN"].copy()
    if chosen.empty:
        print("[WARN] CHOSEN 행 없음 → 전체 데이터 사용")
        return df
    print(f"[INFO] CHOSEN 필터 적용: {len(chosen)} rows")
    return chosen


# ─────────────────────────────────────────────
# 3) year 필터 (협력사별 최신 year 자동 선택)
# ─────────────────────────────────────────────
def filter_year_per_vendor_latest(df: pd.DataFrame, year: Optional[int]) -> Tuple[pd.DataFrame, Optional[int]]:
    """
    - year 지정 시: 해당 year만 사용
    - year 미지정(None) 시: 협력사별 최신 year 자동 선택

    반환값 (df_filtered, selected_year)
    - selected_year는 강제 year 지정 시 그 값을 반환, 미지정이면 None (협력사별로 다를 수 있으므로)
    """
    if "year" not in df.columns:
        print("[WARN] year 컬럼 없음 → year 필터 스킵")
        return df, year

    if "협력사" not in df.columns:
        print("[WARN] 협력사 컬럼 없음 → year 필터 스킵")
        return df, year

    df = df.copy()
    df["협력사"] = df["협력사"].astype(str).map(_norm_str)
    df["year"] = pd.to_numeric(df["year"], errors="coerce").astype("Int64")
    df = df.dropna(subset=["year"])
    if df.empty:
        print("[WARN] year 파싱 후 데이터 없음 → year 필터 스킵")
        return df, year

    if year is not None:
        sub = df[df["year"] == year].copy()
        if sub.empty:
            print(f"[WARN] year={year} 데이터 없음 → year 필터 무시(전체 사용)")
            return df, year
        print(f"[INFO] year 강제 지정: {year} (rows={len(sub)})")
        return sub, year

    # 협력사별 최신 year 자동 선택
    idx = df.groupby("협력사")["year"].transform("max") == df["year"]
    sub = df[idx].copy()

    # 같은 협력사에 year 최신이 여러 행이면 그대로 두고, 다음 단계에서 성능으로 정리
    vendors = sub["협력사"].nunique()
    years_info = sub.groupby("협력사")["year"].max().value_counts().to_dict()
    print(f"[INFO] year 미지정 → 협력사별 최신 year 자동 선택: vendors={vendors}, year_dist={years_info}")
    return sub, None


# ─────────────────────────────────────────────
# 4) 최근 N일 필터 (timestamp 기준)
# ─────────────────────────────────────────────
def filter_recent(df: pd.DataFrame, days: int) -> pd.DataFrame:
    if "timestamp" not in df.columns:
        print("[INFO] timestamp 없음 → 최근 N일 필터 스킵")
        return df

    df = df.copy()
    df["timestamp_dt"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df = df.dropna(subset=["timestamp_dt"])
    if df.empty:
        print("[WARN] timestamp 파싱 후 데이터 없음 → 기간 필터 미적용")
        return df

    cutoff = dt.datetime.now() - dt.timedelta(days=days)
    recent = df[df["timestamp_dt"] >= cutoff]
    if recent.empty:
        print(f"[WARN] 최근 {days}일 이내 로그 없음 → 기간 필터 미적용")
        return df

    print(f"[INFO] 최근 {days}일 필터 적용: {len(recent)} rows")
    return recent


# ─────────────────────────────────────────────
# 5) 복합 점수(Composite Score) 계산
# ─────────────────────────────────────────────

def _rank_norm_higher_better(series: pd.Series) -> pd.Series:
    """높은 값이 좋을 때 (R2): 가장 큰 값 → 1, 가장 작은 값 → 0"""
    n = len(series)
    if n <= 1:
        return pd.Series([1.0] * n, index=series.index, dtype=float)
    ranked = series.rank(method="average", ascending=True)   # 큰 값 = 높은 순위
    return (ranked - 1) / (n - 1)


def _rank_norm_lower_better(series: pd.Series) -> pd.Series:
    """낮은 값이 좋을 때 (RMSE, MAE): 가장 작은 값 → 1, 가장 큰 값 → 0"""
    n = len(series)
    if n <= 1:
        return pd.Series([1.0] * n, index=series.index, dtype=float)
    ranked = series.rank(method="average", ascending=False)  # 작은 값 = 높은 순위
    return (ranked - 1) / (n - 1)


def add_composite_scores(
    df: pd.DataFrame,
    w_r2: float = 0.20,
    w_rmse: float = 0.35,
    w_mae: float = 0.45,
) -> pd.DataFrame:
    """
    그룹 내 순위 기반 정규화 복합 점수를 계산해 'composite_score' 컬럼을 추가한다.

    composite_score = w_r2 * R2_norm + w_rmse * RMSE_norm + w_mae * MAE_norm

    정규화 방향
    -----------
    - R2_norm  : R2 가 클수록 1 (높을수록 좋음)
    - RMSE_norm: RMSE 가 작을수록 1 (낮을수록 좋음)
    - MAE_norm : MAE 가 작을수록 1 (낮을수록 좋음)

    기본 가중치  w_r2=0.20 / w_rmse=0.35 / w_mae=0.45
    (lag_days 예측 도메인: MAE = '평균 N일 오차'로 가장 직관적 → 최고 가중)

    추가 규칙
    ---------
    - NaN: R2→-1.0, RMSE/MAE→그룹 최대 × 1.1 (최하위 취급)
    - R2 < 0 패널티: composite_score -= 0.1 (평균보다 나쁜 모델)
    - timestamp tie-break 컬럼(ts_filled) 함께 생성
    """
    df = df.copy()

    for col in ["R2_valid", "RMSE_valid", "MAE_valid"]:
        if col not in df.columns:
            df[col] = np.nan
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # NaN 처리
    r2 = df["R2_valid"].fillna(-1.0)

    rmse_max = df["RMSE_valid"].dropna().max()
    rmse = df["RMSE_valid"].fillna(
        rmse_max * 1.1 if (rmse_max is not None and not np.isnan(rmse_max)) else 1e9
    )

    mae_max = df["MAE_valid"].dropna().max()
    mae = df["MAE_valid"].fillna(
        mae_max * 1.1 if (mae_max is not None and not np.isnan(mae_max)) else 1e9
    )

    r2_norm   = _rank_norm_higher_better(r2)
    rmse_norm = _rank_norm_lower_better(rmse)
    mae_norm  = _rank_norm_lower_better(mae)

    df["composite_score"] = w_r2 * r2_norm + w_rmse * rmse_norm + w_mae * mae_norm

    # R2 < 0 패널티
    df.loc[df["R2_valid"] < 0, "composite_score"] -= 0.1

    # timestamp tie-break
    if "timestamp_dt" not in df.columns:
        if "timestamp" in df.columns:
            df["timestamp_dt"] = pd.to_datetime(df["timestamp"], errors="coerce")
        else:
            df["timestamp_dt"] = pd.NaT
    df["ts_filled"] = df["timestamp_dt"].fillna(pd.Timestamp("1970-01-01"))

    return df


def _pick_best_row_by_score(
    sub: pd.DataFrame,
    w_r2: float = 0.20,
    w_rmse: float = 0.35,
    w_mae: float = 0.45,
) -> Tuple[pd.Series, str]:
    """
    복합 점수 기준으로 그룹 내 최고성능 1건 선택.

    정렬 기준: composite_score desc → ts_filled desc (최신 timestamp)
    """
    sub = add_composite_scores(sub, w_r2=w_r2, w_rmse=w_rmse, w_mae=w_mae)
    best = sub.sort_values(
        ["composite_score", "ts_filled"], ascending=[False, False]
    ).iloc[0]

    score = best.get("composite_score", float("nan"))
    mape_str = (
        f" MAPE={best.get('MAPE_valid')}"
        if "MAPE_valid" in best.index and pd.notna(best.get("MAPE_valid"))
        else ""
    )
    rule = (
        f"복합점수(w_r2={w_r2}/w_rmse={w_rmse}/w_mae={w_mae}) "
        f"score={score:.4f} "
        f"R2={best.get('R2_valid')} RMSE={best.get('RMSE_valid')} MAE={best.get('MAE_valid')}"
        f"{mape_str}  ※MAPE 참고용"
    )
    return best, rule


# ─────────────────────────────────────────────
# 6) 협력사+engine별 "최고성능 1건" 유지
# ─────────────────────────────────────────────
def keep_best_per_vendor_engine(
    df: pd.DataFrame,
    w_r2: float = 0.20,
    w_rmse: float = 0.35,
    w_mae: float = 0.45,
) -> pd.DataFrame:
    if "협력사" not in df.columns or "engine" not in df.columns:
        print("[ERROR] '협력사' 또는 'engine' 컬럼 없음")
        return df

    df = df.copy()
    df["협력사"] = df["협력사"].astype(str).map(_norm_str)
    df["engine"] = df["engine"].astype(str).str.strip()
    df = df[(df["협력사"] != "") & (df["engine"] != "")]
    if df.empty:
        print("[WARN] 협력사/engine 유효행 없음")
        return df

    rows = []
    for (vendor, engine), sub in df.groupby(["협력사", "engine"]):
        best_row, _ = _pick_best_row_by_score(sub, w_r2=w_r2, w_rmse=w_rmse, w_mae=w_mae)
        rows.append(best_row)

    out = pd.DataFrame(rows).reset_index(drop=True)
    print(f"[INFO] 협력사+engine별 최고성능 로그만 유지: {len(out)} rows")
    return out


# ─────────────────────────────────────────────
# 7) 협력사별 best model 선택
# ─────────────────────────────────────────────
def select_best_models(
    df: pd.DataFrame,
    w_r2: float = 0.20,
    w_rmse: float = 0.35,
    w_mae: float = 0.45,
) -> Tuple[Dict[str, str], pd.DataFrame]:
    if df.empty:
        print("[ERROR] best 모델 선택할 데이터 없음")
        return {}, pd.DataFrame()

    df = df.copy()
    df["협력사"] = df["협력사"].astype(str).map(_norm_str)
    df["engine"] = df["engine"].astype(str).str.strip()
    df = df[(df["협력사"] != "") & (df["engine"] != "")]
    if df.empty:
        print("[ERROR] 협력사/engine 유효행 없음")
        return {}, pd.DataFrame()

    best_map: Dict[str, str] = {}
    best_rows: List[pd.Series] = []

    for vendor, sub in df.groupby("협력사"):
        best, pick_rule = _pick_best_row_by_score(sub, w_r2=w_r2, w_rmse=w_rmse, w_mae=w_mae)
        best_map[vendor] = str(best["engine"]).strip()
        best_rows.append(best)
        print(f"[BEST] 협력사={vendor} / engine={best_map[vendor]} / {pick_rule}")

    best_df = pd.DataFrame(best_rows).reset_index(drop=True)
    return best_map, best_df


# ─────────────────────────────────────────────
# 8) JSON 저장
# ─────────────────────────────────────────────
def save_best_json(best_map: Dict[str, str]) -> Path:
    out_path = OUT_DIR / "best_model_by_vendor_ML.json"
    ordered = {k: best_map[k] for k in sorted(best_map.keys())}
    with open(out_path, "w", encoding="utf-8") as fp:
        json.dump(ordered, fp, ensure_ascii=False, indent=2)
    print(f"[SAVE] JSON 저장 완료: {out_path}")
    return out_path


# ─────────────────────────────────────────────
# 9) best 모델 summary CSV 저장
# ─────────────────────────────────────────────
def save_best_log_csv(best_df: pd.DataFrame, year_for_filename: Optional[int]):
    logs_dir = OUT_DIR / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    today = dt.date.today()
    y = year_for_filename if year_for_filename is not None else today.year
    fname = f"{y}_best_model_ML_{today.strftime('%Y%m%d')}.csv"

    out_path = logs_dir / fname
    best_df.to_csv(out_path, index=False, encoding="utf-8-sig")
    print(f"[SAVE] best summary CSV 저장: {out_path}")


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
def main(
    year: Optional[int] = None,
    recent_days: int = 60,
    w_r2: float = 0.20,
    w_rmse: float = 0.35,
    w_mae: float = 0.45,
):
    print(" ==== ML Best Model Selection (DB Only) ==== ")
    print(
        f"[CONFIG] year={year}, recent_days={recent_days}, "
        f"w_r2={w_r2}, w_rmse={w_rmse}, w_mae={w_mae}"
    )

    df = load_logs_from_db()
    if df.empty:
        print("[ABORT] DB 로그 없음 → 종료")
        return

    df = filter_chosen(df)

    # 협력사별 최신 year 자동 선택
    df_year, selected_year = filter_year_per_vendor_latest(df, year)

    if recent_days > 0:
        df_year = filter_recent(df_year, recent_days)

    if df_year.empty:
        print("[ABORT] 필터링 후 로그 없음 → 종료")
        return

    # (협력사, engine)별 복합 점수 최고성능 1건
    df_best_ve = keep_best_per_vendor_engine(df_year, w_r2=w_r2, w_rmse=w_rmse, w_mae=w_mae)
    if df_best_ve.empty:
        print("[ABORT] 협력사+engine 최고성능 필터 후 로그 없음 → 종료")
        return

    best_map, best_df = select_best_models(df_best_ve, w_r2=w_r2, w_rmse=w_rmse, w_mae=w_mae)
    if not best_map:
        print("[ABORT] best 모델 없음 → 종료")
        return

    save_best_json(best_map)

    # 파일명 year: 강제 year면 그 year, 아니면 현재연도(협력사별 year가 다를 수 있으므로)
    year_for_filename = selected_year if year is not None else None
    save_best_log_csv(best_df, year_for_filename)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--year", type=int, default=None,
                        help="강제 year (미지정 시 협력사별 최신 year 자동 선택)")
    parser.add_argument("--recent_days", type=int, default=60,
                        help="최근 N일 이내 로그만 사용 (기본: 60일, 0 이하면 필터 미적용)")
    parser.add_argument("--w_r2",   type=float, default=0.20,
                        help="복합 점수 R2 가중치  (기본: 0.20)")
    parser.add_argument("--w_rmse", type=float, default=0.35,
                        help="복합 점수 RMSE 가중치 (기본: 0.35)")
    parser.add_argument("--w_mae",  type=float, default=0.45,
                        help="복합 점수 MAE 가중치  (기본: 0.45, lag_days 도메인 최고 가중)")
    args = parser.parse_args()
    main(args.year, args.recent_days, args.w_r2, args.w_rmse, args.w_mae)
