from __future__ import annotations

"""
step_1_TPD.py

- OUT_DIR 폴더 내 파일명에 '협력사_일일조립생산능력.xlsx'가 포함된 엑셀 파일을 찾습니다.
- DRM 회피를 위해 win32com Excel COM으로 파일을 읽어옵니다.
- 1행은 헤더, 2행부터는 데이터로 인식하여 DataFrame으로 변환합니다.
- MySQL (구조조달1_db) 의 '협력사_일일조립생산능력' 테이블에 업로드합니다.
    · if_exists='replace' 이므로, 여러 파일이 매칭되면 마지막 파일 기준으로 테이블이 덮어써집니다.
"""

import os
from pathlib import Path

import pandas as pd
import win32com.client
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine

from step_0_MSF import OUT_DIR  # step_0_MSF에서 준비한 공유폴더 경로 사용
from db_config import DB_URL as ENGINE_URL

print("MySQL 엔진 생성 중…")
engine: Engine = create_engine(
    ENGINE_URL,
    pool_pre_ping=True,  # 유휴 연결로 인한 끊김 방지
    future=True,         # SQLAlchemy 2.x 스타일 사용
)
print("MySQL 엔진 생성 완료")


def load_excel_via_com(file_path: Path) -> pd.DataFrame:
    """
    DRM 회피를 위해 Excel COM(Win32)으로 엑셀을 읽어 DataFrame으로 변환합니다.

    Parameters
    ----------
    file_path : Path
        읽어올 엑셀 파일 경로

    Returns
    -------
    pd.DataFrame
        1행을 헤더로, 2행부터 데이터를 갖는 DataFrame
        데이터가 없으면 빈 DataFrame 반환
    """
    # Excel Application 객체 준비 (매번 생성하면 느릴 수 있으므로,
    # 필요 시 전역 excel 인스턴스를 재사용하는 패턴도 가능)
    excel = win32com.client.Dispatch("Excel.Application")
    excel.Visible = False

    try:
        wb = excel.Workbooks.Open(str(file_path), ReadOnly=True)
        ws = wb.Sheets(1)

        # UsedRange: 실제 데이터가 있는 영역 전체
        used = ws.UsedRange.Value  # 2D tuple (rows, cols) 또는 None
        if used is None:
            return pd.DataFrame()

        # 단일 셀만 있는 경우 등을 대비해서 형태 정규화
        # used 가 (value,) 형태일 수도 있고, ((row1...), (row2...), ...) 형태일 수도 있음
        # 첫 행을 헤더, 나머지를 데이터로 처리
        if not isinstance(used[0], (list, tuple)):
            # 1행 1열만 있는 경우 등
            used = [used]

        rows = list(used)
        if len(rows) == 0:
            return pd.DataFrame()

        header = list(rows[0])
        data_rows = list(rows[1:]) if len(rows) > 1 else []

        # DataFrame 생성
        df = pd.DataFrame(data_rows, columns=header)

        # 전부 None/NaN 인 행 제거(엑셀 여유 행 제거용)
        df = df.dropna(how="all")

        return df

    finally:
        # 워크북은 열려 있으면 닫고, Excel도 종료
        try:
            wb.Close(SaveChanges=False)
        except Exception:
            pass
        excel.Quit()


def upload_tpd_files(out_dir: Path, engine: Engine) -> None:
    """
    OUT_DIR 내에서 '협력사_일일조립생산능력.xlsx' 로 끝나는 파일을 찾아
    MySQL 테이블 '협력사_일일조립생산능력' 에 업로드합니다.

    Parameters
    ----------
    out_dir : Path
        파일을 검색할 기준 폴더 (step_0_MSF.OUT_DIR)
    engine : Engine
        SQLAlchemy MySQL 엔진
    """
    print("Data Upload 중…")

    # 디렉터리 내 파일 목록
    files = os.listdir(out_dir)

    # 업로드 대상만 필터링
    target_files = [
        f for f in files if f.endswith("협력사_일일조립생산능력.xlsx")
    ]

    if not target_files:
        print("업로드 대상 파일이 없습니다. ( *협력사_일일조립생산능력.xlsx )")
        return

    for file_name in target_files:
        file_path = out_dir / file_name
        print(f"엑셀 로딩 중: {file_path}")

        df = load_excel_via_com(file_path)

        if df.empty:
            print(f"  → 데이터가 없어 업로드를 건너뜁니다: {file_name}")
            continue

        # 트랜잭션 컨텍스트에서 업로드 (replace)
        with engine.begin() as conn:
            df.to_sql(
                name="협력사_일일조립생산능력",
                con=conn,
                if_exists="replace",  # 테이블 전체를 덮어씀
                index=False,
                method="multi",
                chunksize=1000,
            )

        print(f"업로드 완료: {file_name} → 테이블 '협력사_일일조립생산능력'")

    print("모든 업로드 작업 완료")


def main() -> None:
    """이 스크립트를 직접 실행할 때 동작하는 메인 루틴입니다."""
    try:
        upload_tpd_files(OUT_DIR, engine)
    finally:
        # 엔진 리소스 정리
        engine.dispose()
        print("DB 연결 해제 완료")


if __name__ == "__main__":
    main()
