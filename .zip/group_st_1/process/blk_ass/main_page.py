from __future__ import annotations
"""
main_page.py  —  사외 블록 조립 예측 시스템 대시보드
======================================================
blk_ass 폴더 내 전체 파이프라인 결과를 Streamlit 으로 시각화한다.

탭 구성
-------
  1) 📊  데이터 현황   — BPA 원천 데이터 분포 요약
  2) 🔗  피처 분석     — step_61 출력 기반 상관계수 히트맵 + 기술통계
  3) 🤖  ML 모델 성능  — 머신러닝 모델 학습 로그 + Best 선정 결과
  4) 🧠  DL 모델 성능  — 딥러닝 모델 학습 로그 + Best 선정 결과
  5) 🎯  예측 정확도   — step_60 출력 기반 MAPE / MAE / RMSE 비교
  6) 🗺️  파이프라인    — step 파일 전체 구조 및 역할 설명

실행 방법
---------
  독립 실행:
    cd group_st_1/process/blk_ass
    streamlit run main_page.py

  team_main_page.py 연동 (새창):
    team_main_page.py에서 inner=사외구조조달1그룹&sub=조립공정 라우트로 자동 실행됨.
    team_main_page.py가 먼저 st.set_page_config()를 호출하므로
    이 파일의 set_page_config()는 try/except 로 감싸 중복 호출을 무시한다.
"""

import datetime as dt
import json
import re
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

_PAGE_LOAD_START = time.time()   # 페이지 로딩 시작 시각

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

# ── blk_ass 폴더를 sys.path 에 추가 (IDE 실행 대응)
_HERE = Path(__file__).parent.resolve()
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

# ── 프로젝트 모듈
try:
    from step_0_MSF import OUT_DIR
    from step_2_BPA_Data import outside_df
    from step_43_utils_label_group import BASE_VENDORS
    from db_config import DB_URL, DB_URL_MART
    _MODULES_OK = True
except Exception as _e:
    _MODULES_OK = False
    _MODULE_ERR = str(_e)

# ─────────────────────────────────────────────
# 페이지 설정
# ─────────────────────────────────────────────
try:
    st.set_page_config(
        page_title="사외 조립 현황 시스템",
        page_icon="",
        layout="wide",
        initial_sidebar_state="expanded",
    )
except Exception:
    pass

# ─────────────────────────────────────────────
# 공통 CSS
# ─────────────────────────────────────────────
st.markdown("""
<style>
  .stApp { background: linear-gradient(160deg, #f0f4ff 0%, #ffffff 40%); }
  section.main > div.block-container {
      padding-top: 1.2rem; padding-bottom: 4rem;
      padding-left: 2.5rem; padding-right: 2.5rem;
  }
  .kpi-row { display: flex; gap: 14px; flex-wrap: wrap; margin-bottom: 1rem; }
  .kpi-card {
      flex: 1; min-width: 140px; padding: 14px 18px; border-radius: 14px;
      background: #fff; border: 1px solid #e5e7eb;
      box-shadow: 0 4px 12px rgba(15,23,42,.07);
  }
  .kpi-label { font-size: 11px; color: #64748b; letter-spacing: .04em; margin-bottom: 4px; }
  .kpi-value { font-size: 22px; font-weight: 800; color: #0f172a; }
  .kpi-sub   { font-size: 11px; color: #94a3b8; margin-top: 3px; }
  .step-badge {
      display: inline-block; padding: 2px 8px; border-radius: 20px;
      font-size: 11px; font-weight: 700; margin-right: 4px;
  }
  .badge-data   { background:#dbeafe; color:#1d4ed8; }
  .badge-ml     { background:#dcfce7; color:#15803d; }
  .badge-dl     { background:#fce7f3; color:#9d174d; }
  .badge-util   { background:#f3f4f6; color:#374151; }
  .badge-out    { background:#fef3c7; color:#92400e; }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
# 사이드바
# ─────────────────────────────────────────────
with st.sidebar:
    st.title("사외 조립 현황 시스템")
    st.markdown("---")

    year_sel = st.selectbox(
        "📅 조회 연도",
        options=list(range(dt.date.today().year, dt.date.today().year - 4, -1)),
        index=0,
    )
    st.markdown("---")

    # 모듈 연결 상태
    if _MODULES_OK:
        st.success("✅ 모듈 연결 정상")
        try:
            out_exists = Path(OUT_DIR).exists()
            st.info(f"📁 OUT_DIR\n`{OUT_DIR}`\n{'존재' if out_exists else '⚠️ 없음'}")
        except Exception:
            st.warning("OUT_DIR 확인 불가")
    else:
        st.error(f"❌ 모듈 오류\n{_MODULE_ERR}")

    st.markdown("---")
    st.caption(f"조회 기준일: {dt.date.today().strftime('%Y-%m-%d')}")


# ─────────────────────────────────────────────
# 헬퍼: 캐시 데이터 로더
# ─────────────────────────────────────────────

@st.cache_data(ttl=300, show_spinner=False)
def _load_bpa(year: int) -> pd.DataFrame:
    return outside_df(year)


@st.cache_data(ttl=300, show_spinner=False)
def _load_ml_log() -> pd.DataFrame:
    from sqlalchemy import create_engine, text
    engine = create_engine(DB_URL, pool_pre_ping=True)
    with engine.connect() as conn:
        df = pd.read_sql(text("SELECT * FROM 예측_모델_log ORDER BY timestamp DESC"), conn)
    engine.dispose()
    return df


@st.cache_data(ttl=300, show_spinner=False)
def _load_dl_log() -> pd.DataFrame:
    from sqlalchemy import create_engine, text
    engine = create_engine(DB_URL, pool_pre_ping=True)
    with engine.connect() as conn:
        df = pd.read_sql(text("SELECT * FROM 예측_모델_log_dl ORDER BY timestamp DESC"), conn)
    engine.dispose()
    return df


@st.cache_data(ttl=600, show_spinner=False)
def _load_best_json(tag: str) -> dict:
    """best_model_by_vendor_ML.json / best_model_by_vendor_DL.json 로드."""
    p = Path(OUT_DIR) / f"best_model_by_vendor_{tag}.json"
    if not p.exists():
        return {}
    return json.loads(p.read_text(encoding="utf-8"))


@st.cache_data(ttl=600, show_spinner=False)
def _scan_accuracy_excel() -> List[Path]:
    """OUT_DIR 에서 예측정확도 엑셀 파일 목록 반환."""
    root = Path(OUT_DIR)
    if not root.exists():
        return []
    return sorted(root.glob("*년도_예측정확도_분석_*.xlsx"), reverse=True)


@st.cache_data(ttl=600, show_spinner=False)
def _scan_corr_excel() -> List[Path]:
    root = Path(OUT_DIR)
    if not root.exists():
        return []
    return sorted(root.glob("*년도_피처_상관계수_분석_*.xlsx"), reverse=True)


def _read_excel_sheet(path: Path, sheet: int | str = 0) -> Optional[pd.DataFrame]:
    try:
        return pd.read_excel(path, sheet_name=sheet, engine="openpyxl")
    except Exception:
        return None


# ─────────────────────────────────────────────
# 파이프라인 메타데이터
# ─────────────────────────────────────────────
PIPELINE: List[dict] = [
    # 데이터 준비
    dict(step="step_0_MSF",           tag="data", role="공유 폴더(네트워크 드라이브) 마운트 및 OUT_DIR 준비"),
    dict(step="step_1_TPD",           tag="data", role="협력사 일일 조립 생산능력(TPD) 엑셀 → DB 업로드"),
    dict(step="step_2_BPA_Data",      tag="data", role="MySQL BPA 원천 데이터 로드·필터·협력사 매핑"),
    dict(step="step_3_Monthly",       tag="data", role="월간 계획/실적/누계차/지연일수 집계 → 엑셀 저장"),
    dict(step="step_4_Weekly",        tag="data", role="주간 계획/실적/누계차/지연일수 집계 → 엑셀 저장"),
    dict(step="step_5_MWD",           tag="data", role="월·주·일 혼합(하이브리드) 축 계획/실적 행렬 생성"),
    # ML 모델
    dict(step="step_6_KNN",           tag="ml",   role="K-최근접이웃(KNN) 모델 학습·예측·엑셀 저장"),
    dict(step="step_7_AR",            tag="ml",   role="자기회귀(AR) 모델 학습·예측·엑셀 저장"),
    dict(step="step_8_MA",            tag="ml",   role="이동평균(MA) 모델 학습·예측·엑셀 저장"),
    dict(step="step_9_ARIMA",         tag="ml",   role="ARIMA 모델 학습·예측·엑셀 저장"),
    dict(step="step_10_Linear",       tag="ml",   role="선형 회귀(Linear Regression) 모델"),
    dict(step="step_11_Ridge",        tag="ml",   role="릿지 회귀(Ridge Regression) 모델"),
    dict(step="step_12_LightGBM",     tag="ml",   role="LightGBM 그래디언트 부스팅 모델"),
    dict(step="step_13_XGBoost",      tag="ml",   role="XGBoost 그래디언트 부스팅 모델"),
    dict(step="step_14_Catboost",     tag="ml",   role="CatBoost 그래디언트 부스팅 모델"),
    dict(step="step_15_best_model_select_ML", tag="ml", role="복합 점수(R²·RMSE·MAE)로 협력사별 Best ML 모델 선정"),
    dict(step="step_16_best_predict_ML",      tag="ml", role="Best ML 모델로 전체 예측 실행 → 엑셀 저장"),
    # DL 모델
    dict(step="step_20_MLP",          tag="dl",   role="다층 퍼셉트론(MLP) PyTorch 모델 학습·예측"),
    dict(step="step_21_CNN",          tag="dl",   role="1D 합성곱 신경망(CNN) PyTorch 모델 학습·예측"),
    dict(step="step_22_TCN",          tag="dl",   role="시계열 합성곱(TCN) PyTorch 모델 학습·예측"),
    dict(step="step_23_LSTM",         tag="dl",   role="장단기 기억망(LSTM) PyTorch 모델 학습·예측"),
    dict(step="step_24_best_model_select_DL", tag="dl", role="복합 점수로 협력사별 Best DL 모델 선정"),
    dict(step="step_25_best_predict_DL",      tag="dl", role="Best DL 모델로 전체 예측 실행 → 엑셀 저장"),
    # 유틸 모듈
    dict(step="step_40_utils_holiday",        tag="util", role="공휴일·영업일 계산 유틸"),
    dict(step="step_41_utils_save_to_folder", tag="util", role="날짜별 폴더 경로 생성 유틸"),
    dict(step="step_42_utils_calendar",       tag="util", role="월·주·일 달력 연산 유틸"),
    dict(step="step_43_utils_label_group",    tag="util", role="행 라벨·협력사 순서·그룹 정의"),
    dict(step="step_44_utils_TPD",            tag="util", role="협력사별 월·주·일 생산능력(TPD) 조회"),
    dict(step="step_45_utils_save_excel",     tag="util", role="공통 엑셀 저장 유틸(헤더·서식·타이틀)"),
    dict(step="step_46_utils_save_logcsv_ML", tag="util", role="ML 모델 선정 로그 CSV + DB 저장"),
    dict(step="step_46_utils_save_logcsv_DL", tag="util", role="DL 모델 선정 로그 CSV + DB 저장"),
    dict(step="step_47_utils_train_table",    tag="util", role="협력사별 학습용 피처 행렬(X, y) 생성"),
    dict(step="step_48_utils_logs_upload_ML", tag="util", role="ML 로그 DataFrame → DB 업로드"),
    dict(step="step_48_utils_logs_upload_DL", tag="util", role="DL 로그 DataFrame → DB 업로드"),
    dict(step="step_49_utils_BPA_upload",     tag="util", role="BPA 데이터 → DB 업로드"),
    # 분석 출력
    dict(step="step_60_predict_accuracy",     tag="out", role="예측 정확도 분석(MAE·RMSE·MAPE) → 엑셀 저장"),
    dict(step="step_61_feature_correlation",  tag="out", role="독립변수 상관계수·기술통계 분석 → 엑셀 저장"),
]

TAG_BADGE = {
    "data": '<span class="step-badge badge-data">데이터</span>',
    "ml":   '<span class="step-badge badge-ml">ML</span>',
    "dl":   '<span class="step-badge badge-dl">DL</span>',
    "util": '<span class="step-badge badge-util">유틸</span>',
    "out":  '<span class="step-badge badge-out">분석출력</span>',
}

TAG_COLOR = {"data": "#3b82f6", "ml": "#22c55e", "dl": "#ec4899", "util": "#9ca3af", "out": "#f59e0b"}


# ─────────────────────────────────────────────
# 로딩 진행률 표시
# ─────────────────────────────────────────────
_LOAD_STAGES = [
    (0.20, "🔌 모듈 및 설정 로드 확인 중..."),
    (0.40, "🗄️ DB 연결 준비 중..."),
    (0.60, "📦 캐시 데이터 로더 초기화 중..."),
    (0.80, "🖥️ UI 레이아웃 구성 중..."),
    (1.00, "✅ 로딩 완료"),
]

_loading = st.empty()
for _pct, _msg in _LOAD_STAGES:
    _elapsed = time.time() - _PAGE_LOAD_START
    with _loading.container():
        st.markdown(
            f"""
            <div style="
                padding: 28px 32px; border-radius: 16px;
                background: #ffffff; border: 1px solid #e5e7eb;
                box-shadow: 0 4px 20px rgba(15,23,42,.10);
                max-width: 560px; margin: 60px auto;
            ">
              <div style="font-size:17px; font-weight:700; color:#1e293b; margin-bottom:10px;">
                🏗️ 사외 블록 조립 예측 시스템 로딩 중
              </div>
              <div style="font-size:14px; color:#475569; margin-bottom:14px;">{_msg}</div>
              <div style="font-size:12px; color:#94a3b8; margin-top:8px;">
                ⏱️ 경과 시간: <b>{_elapsed:.2f}초</b>
                &nbsp;|&nbsp;
                🕐 로딩 시작: <b>{dt.datetime.fromtimestamp(_PAGE_LOAD_START).strftime('%H:%M:%S')}</b>
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.progress(_pct)
    time.sleep(0.07)

_load_elapsed = time.time() - _PAGE_LOAD_START
_loading.empty()   # 로딩 UI 제거


# ═══════════════════════════════════════════════════════════════
# 메인 탭 구성
# ═══════════════════════════════════════════════════════════════
st.title("사외 조립 계획_실적_예측 현황")
st.caption(
    f"🕐 로딩 시작: {dt.datetime.fromtimestamp(_PAGE_LOAD_START).strftime('%Y-%m-%d %H:%M:%S')}"
    f"　　⏱️ 총 로딩 시간: {_load_elapsed:.2f}초"
)

tab_data, tab_feat, tab_ml, tab_dl, tab_acc, tab_pipe = st.tabs([
    "📊 데이터 현황",
    "🔗 피처 분석",
    "🤖 ML 모델 성능",
    "🧠 DL 모델 성능",
    "🎯 예측 정확도",
    "🗺️ 파이프라인",
])
# 기존 with-블록 변수명과 매핑 (코드 블록 이동 없이 순서만 변경)
tab1, tab2, tab3, tab4, tab5, tab6 = tab_pipe, tab_data, tab_ml, tab_dl, tab_acc, tab_feat


# ───────────────────────────────────────────────
# TAB 1  파이프라인 구조
# ───────────────────────────────────────────────
with tab1:
    st.subheader("전체 파이프라인 구조")

    # 태그별 건수 KPI
    counts = {}
    for p in PIPELINE:
        counts[p["tag"]] = counts.get(p["tag"], 0) + 1

    kpi_html = '<div class="kpi-row">'
    for tag, label in [("data","데이터 준비"), ("ml","ML 모델"), ("dl","DL 모델"),
                       ("util","유틸 모듈"), ("out","분석 출력")]:
        kpi_html += f"""
        <div class="kpi-card">
          <div class="kpi-label">{label}</div>
          <div class="kpi-value">{counts.get(tag, 0)}</div>
          <div class="kpi-sub"></div>
        </div>"""
    kpi_html += f"""
        <div class="kpi-card">
          <div class="kpi-label">전체</div>
          <div class="kpi-value">{len(PIPELINE)}</div>
          <div class="kpi-sub"></div>
        </div>"""
    kpi_html += '</div>'
    st.markdown(kpi_html, unsafe_allow_html=True)

    # 태그 필터
    tag_filter = st.multiselect(
        "태그 필터",
        options=["data", "ml", "dl", "util", "out"],
        default=["data", "ml", "dl", "util", "out"],
        format_func=lambda t: {"data":"데이터","ml":"ML","dl":"DL","util":"유틸","out":"분석출력"}[t],
    )

    filtered = [p for p in PIPELINE if p["tag"] in tag_filter]

    # 파이프라인 테이블
    rows_html = ""
    for p in filtered:
        badge  = TAG_BADGE.get(p["tag"], "")
        color  = TAG_COLOR.get(p["tag"], "#aaa")
        rows_html += f"""
        <tr>
          <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;
                     font-family:monospace;font-size:13px;color:{color};font-weight:600;">
            {p['step']}.py
          </td>
          <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;">{badge}</td>
          <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-size:13px;color:#374151;">
            {p['role']}
          </td>
        </tr>"""

    st.markdown(f"""
    <table style="width:100%;border-collapse:collapse;background:#fff;
                  border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.06);">
      <thead>
        <tr style="background:#1e293b;color:#fff;">
          <th style="padding:10px 10px;text-align:left;font-size:13px;width:28%;">파일명</th>
          <th style="padding:10px 10px;text-align:left;font-size:13px;width:10%;">구분</th>
          <th style="padding:10px 10px;text-align:left;font-size:13px;">역할</th>
        </tr>
      </thead>
      <tbody>{rows_html}</tbody>
    </table>
    """, unsafe_allow_html=True)

    # 흐름도 (Sankey 스타일 대신 간단한 단계 다이어그램)
    st.markdown("---")
    st.subheader("실행 흐름")
    flow_cols = st.columns(5)
    flow_items = [
        ("데이터 준비", "step_0 ~ 5", "#dbeafe", "#1d4ed8"),
        ("ML 모델 학습", "step_6 ~ 16", "#dcfce7", "#15803d"),
        ("DL 모델 학습", "step_20 ~ 25", "#fce7f3", "#9d174d"),
        ("예측 정확도", "step_60", "#fef3c7", "#92400e"),
        ("피처 분석", "step_61", "#ede9fe", "#5b21b6"),
    ]
    for col, (title, steps, bg, fg) in zip(flow_cols, flow_items):
        col.markdown(f"""
        <div style="background:{bg};border-radius:12px;padding:14px;text-align:center;height:80px;">
          <div style="color:{fg};font-weight:800;font-size:14px;">{title}</div>
          <div style="color:{fg};font-size:12px;margin-top:4px;">{steps}</div>
        </div>
        """, unsafe_allow_html=True)


# ───────────────────────────────────────────────
# TAB 2  데이터 현황
# ───────────────────────────────────────────────
with tab2:
    st.subheader(f"{year_sel}년 사외 조립 현황")

    if not _MODULES_OK:
        st.error(f"모듈 오류: {_MODULE_ERR}")
    else:
        with st.spinner("BPA 데이터 로딩 중..."):
            try:
                df_bpa = _load_bpa(year_sel)
            except Exception as e:
                df_bpa = pd.DataFrame()
                st.error(f"데이터 로드 실패: {e}")

        if df_bpa.empty:
            st.warning("데이터가 없습니다.")
        else:
            # 날짜 파싱
            for col in ("기준계획_완료", "실적_완료"):
                if col in df_bpa.columns:
                    df_bpa[col] = pd.to_datetime(df_bpa[col], errors="coerce")

            # lag_days 계산
            if {"기준계획_완료", "실적_완료"} <= set(df_bpa.columns):
                df_bpa["lag_days"] = (
                    df_bpa["실적_완료"] - df_bpa["기준계획_완료"]
                ).dt.days

            # KPI
            n_total   = len(df_bpa)
            n_vendors = df_bpa["협력사"].nunique() if "협력사" in df_bpa.columns else 0
            lag_mean  = df_bpa["lag_days"].mean() if "lag_days" in df_bpa.columns else float("nan")
            lag_med   = df_bpa["lag_days"].median() if "lag_days" in df_bpa.columns else float("nan")

            kc1, kc2, kc3, kc4 = st.columns(4)
            kc1.metric("전체 블록 수", f"{n_total:,}건")
            kc2.metric("협력사 수", f"{n_vendors}개")
            kc3.metric("평균 지연일(lag)", f"{lag_mean:+.1f}일" if not np.isnan(lag_mean) else "—")
            kc4.metric("중앙 지연일(lag)", f"{lag_med:+.1f}일" if not np.isnan(lag_med) else "—")

            st.markdown("---")
            c_left, c_right = st.columns(2)

            # ① 협력사별 블록 수
            if "협력사" in df_bpa.columns:
                vendor_cnt = (
                    df_bpa["협력사"].value_counts()
                    .reset_index()
                    .rename(columns={"count": "블록수"})
                )
                fig_v = px.bar(
                    vendor_cnt, x="협력사", y="블록수",
                    title="협력사별 블록 수",
                    color="블록수", color_continuous_scale="Blues",
                    text="블록수",
                )
                fig_v.update_traces(textposition="outside")
                fig_v.update_layout(showlegend=False, coloraxis_showscale=False,
                                    height=380, margin=dict(t=40, b=20))
                c_left.plotly_chart(fig_v, use_container_width=True)

            # ② lag_days 분포
            if "lag_days" in df_bpa.columns:
                lag_clean = df_bpa["lag_days"].dropna().clip(-90, 180)
                fig_lag = px.histogram(
                    lag_clean, nbins=60,
                    title="지연일수(lag_days) 분포  [-90 ~ 180 클리핑]",
                    labels={"value": "lag_days (일)", "count": "건수"},
                    color_discrete_sequence=["#6366f1"],
                )
                fig_lag.add_vline(x=0, line_dash="dash", line_color="red",
                                  annotation_text="기준(0일)")
                fig_lag.add_vline(x=lag_mean, line_dash="dot", line_color="orange",
                                  annotation_text=f"평균 {lag_mean:.1f}일")
                fig_lag.update_layout(height=380, margin=dict(t=40, b=20))
                c_right.plotly_chart(fig_lag, use_container_width=True)

            # ③ 월별 계획/실적 건수 추이
            st.markdown("---")
            if "기준계획_완료" in df_bpa.columns:
                df_bpa["계획_월"] = df_bpa["기준계획_완료"].dt.to_period("M").astype(str)
                df_bpa["실적_월"] = (
                    df_bpa["실적_완료"].dt.to_period("M").astype(str)
                    if "실적_완료" in df_bpa.columns else None
                )
                plan_m = df_bpa.groupby("계획_월").size().rename("계획 건수")
                act_m  = df_bpa.groupby("실적_월").size().rename("실적 건수") if "실적_완료" in df_bpa.columns else None

                fig_m = go.Figure()
                fig_m.add_bar(x=plan_m.index, y=plan_m.values, name="계획",
                              marker_color="#93c5fd", opacity=0.8)
                if act_m is not None:
                    fig_m.add_bar(x=act_m.index, y=act_m.values, name="실적",
                                  marker_color="#34d399", opacity=0.8)
                fig_m.update_layout(
                    barmode="group", title="월별 계획·실적 블록 건수",
                    xaxis_title="월", yaxis_title="건수",
                    height=340, margin=dict(t=40, b=20),
                )
                st.plotly_chart(fig_m, use_container_width=True)

            # ④ 협력사별 평균 lag_days
            if {"협력사", "lag_days"} <= set(df_bpa.columns):
                vlag = (
                    df_bpa.groupby("협력사")["lag_days"]
                    .agg(["mean", "median", "std", "count"])
                    .rename(columns={"mean":"평균","median":"중앙값","std":"표준편차","count":"건수"})
                    .sort_values("평균")
                    .reset_index()
                )
                fig_vl = px.bar(
                    vlag, x="협력사", y="평균",
                    error_y="표준편차",
                    title="협력사별 평균 지연일수(lag_days)",
                    color="평균",
                    color_continuous_scale="RdYlGn_r",
                    hover_data=["중앙값", "건수"],
                    text=vlag["평균"].round(1),
                )
                fig_vl.add_hline(y=0, line_dash="dash", line_color="gray")
                fig_vl.update_traces(textposition="outside")
                fig_vl.update_layout(height=380, margin=dict(t=40, b=20),
                                     coloraxis_showscale=False)
                st.plotly_chart(fig_vl, use_container_width=True)

                with st.expander("📋 협력사별 통계 테이블"):
                    st.dataframe(
                        vlag.style.format({"평균": "{:+.1f}", "중앙값": "{:+.1f}",
                                           "표준편차": "{:.1f}", "건수": "{:,}"}),
                        use_container_width=True,
                    )


# ───────────────────────────────────────────────
# 공통: ML / DL 로그 렌더링
# ───────────────────────────────────────────────
def _render_model_log(df_log: pd.DataFrame, best_json: dict, tag: str) -> None:
    """ML 또는 DL 모델 로그 탭 공통 렌더링."""
    if df_log.empty:
        st.warning("로그 데이터가 없습니다.")
        return

    # 연도 필터
    if "year" in df_log.columns:
        df_log = df_log[df_log["year"] == year_sel]

    if df_log.empty:
        st.info(f"{year_sel}년도 로그가 없습니다.")
        return

    # KPI
    n_rows    = len(df_log)
    n_vendors = df_log["협력사"].nunique() if "협력사" in df_log.columns else 0
    engines   = df_log["engine"].nunique() if "engine" in df_log.columns else 0
    best_cnt  = len(best_json)

    kc1, kc2, kc3, kc4 = st.columns(4)
    kc1.metric("로그 건수", f"{n_rows:,}")
    kc2.metric("분석 협력사", f"{n_vendors}개")
    kc3.metric("모델 종류", f"{engines}종")
    kc4.metric("Best 선정 협력사", f"{best_cnt}개")

    st.markdown("---")

    # ① 엔진별 평균 성능 (R2 / RMSE / MAE)
    perf_cols = [c for c in ("R2_valid", "RMSE_valid", "MAE_valid") if c in df_log.columns]
    if perf_cols and "engine" in df_log.columns:
        eng_perf = df_log.groupby("engine")[perf_cols].mean().reset_index()
        c1, c2 = st.columns(2)

        if "R2_valid" in eng_perf.columns:
            fig_r2 = px.bar(
                eng_perf.sort_values("R2_valid", ascending=False),
                x="engine", y="R2_valid",
                title="엔진별 평균 R² (검증)",
                color="R2_valid", color_continuous_scale="Greens",
                text=eng_perf.sort_values("R2_valid", ascending=False)["R2_valid"].round(3),
            )
            fig_r2.add_hline(y=0, line_dash="dash", line_color="gray")
            fig_r2.update_traces(textposition="outside")
            fig_r2.update_layout(height=360, margin=dict(t=40, b=20),
                                  coloraxis_showscale=False)
            c1.plotly_chart(fig_r2, use_container_width=True)

        if "RMSE_valid" in eng_perf.columns:
            fig_rmse = px.bar(
                eng_perf.sort_values("RMSE_valid"),
                x="engine", y="RMSE_valid",
                title="엔진별 평균 RMSE (검증, 낮을수록 우수)",
                color="RMSE_valid", color_continuous_scale="Reds_r",
                text=eng_perf.sort_values("RMSE_valid")["RMSE_valid"].round(2),
            )
            fig_rmse.update_traces(textposition="outside")
            fig_rmse.update_layout(height=360, margin=dict(t=40, b=20),
                                    coloraxis_showscale=False)
            c2.plotly_chart(fig_rmse, use_container_width=True)

    st.markdown("---")

    # ② 협력사별 Best 모델 결과
    if best_json:
        st.subheader(f"협력사별 Best {tag} 모델")
        rows_best = []
        for vendor, info in best_json.items():
            rows_best.append({
                "협력사"    : vendor,
                "Best 모델" : info.get("engine", info.get("model", "—")),
                "R²"        : info.get("R2_valid", np.nan),
                "RMSE"      : info.get("RMSE_valid", np.nan),
                "MAE"       : info.get("MAE_valid", np.nan),
                "분할 비율" : info.get("split_ratio", "—"),
            })
        df_best = pd.DataFrame(rows_best)

        # 협력사 순서 정렬
        ordered = [v for v in BASE_VENDORS if v in df_best["협력사"].values]
        rest    = [v for v in df_best["협력사"] if v not in ordered]
        df_best = df_best.set_index("협력사").loc[ordered + rest].reset_index()

        # Best 모델 분포 파이차트
        bc1, bc2 = st.columns([1, 2])
        eng_cnt = df_best["Best 모델"].value_counts().reset_index()
        fig_pie = px.pie(
            eng_cnt, names="Best 모델", values="count",
            title="Best 모델 분포",
            hole=0.45,
            color_discrete_sequence=px.colors.qualitative.Set2,
        )
        fig_pie.update_layout(height=300, margin=dict(t=40, b=0))
        bc1.plotly_chart(fig_pie, use_container_width=True)

        # Best 모델 성능 테이블
        fmt_dict = {}
        if "R²" in df_best.columns:    fmt_dict["R²"] = "{:+.4f}"
        if "RMSE" in df_best.columns:  fmt_dict["RMSE"] = "{:.2f}"
        if "MAE" in df_best.columns:   fmt_dict["MAE"] = "{:.2f}"
        bc2.dataframe(
            df_best.style.format(fmt_dict).background_gradient(
                subset=["R²"] if "R²" in df_best.columns else [],
                cmap="Greens",
            ),
            use_container_width=True, height=300,
        )

    # ③ 협력사 × 엔진 R² 히트맵
    if {"협력사", "engine", "R2_valid"} <= set(df_log.columns):
        st.markdown("---")
        st.subheader("협력사 × 엔진별 R² 히트맵")
        pivot = (
            df_log.groupby(["협력사", "engine"])["R2_valid"]
            .mean()
            .unstack(fill_value=np.nan)
        )
        # 협력사 순서
        ordered_v = [v for v in BASE_VENDORS if v in pivot.index]
        rest_v    = [v for v in pivot.index if v not in ordered_v]
        pivot     = pivot.loc[ordered_v + rest_v]

        fig_hm = px.imshow(
            pivot,
            text_auto=".2f",
            color_continuous_scale="RdYlGn",
            zmin=-0.5, zmax=1.0,
            title="협력사 × 엔진별 평균 R²(검증)",
            aspect="auto",
        )
        fig_hm.update_layout(height=max(300, len(pivot) * 35 + 100),
                              margin=dict(t=50, b=20))
        st.plotly_chart(fig_hm, use_container_width=True)

    # ④ 상세 로그 테이블
    with st.expander("📋 전체 로그 테이블"):
        show_cols = [c for c in ("timestamp","협력사","engine","R2_train","R2_valid",
                                  "MAE_valid","RMSE_valid","split_ratio","train_range",
                                  "valid_range") if c in df_log.columns]
        st.dataframe(df_log[show_cols].reset_index(drop=True), use_container_width=True)


# ───────────────────────────────────────────────
# TAB 3  ML 모델 성능
# ───────────────────────────────────────────────
with tab3:
    st.subheader(f"{year_sel}년 ML 모델 학습 성능")
    if not _MODULES_OK:
        st.error(f"모듈 오류: {_MODULE_ERR}")
    else:
        with st.spinner("ML 로그 로딩 중..."):
            try:
                df_ml  = _load_ml_log()
                bj_ml  = _load_best_json("ML")
            except Exception as e:
                df_ml  = pd.DataFrame()
                bj_ml  = {}
                st.error(f"ML 로그 로드 실패: {e}")
        _render_model_log(df_ml, bj_ml, "ML")


# ───────────────────────────────────────────────
# TAB 4  DL 모델 성능
# ───────────────────────────────────────────────
with tab4:
    st.subheader(f"{year_sel}년 DL 모델 학습 성능")
    if not _MODULES_OK:
        st.error(f"모듈 오류: {_MODULE_ERR}")
    else:
        with st.spinner("DL 로그 로딩 중..."):
            try:
                df_dl = _load_dl_log()
                bj_dl = _load_best_json("DL")
            except Exception as e:
                df_dl = pd.DataFrame()
                bj_dl = {}
                st.error(f"DL 로그 로드 실패: {e}")
        _render_model_log(df_dl, bj_dl, "DL")


# ───────────────────────────────────────────────
# TAB 5  예측 정확도 (step_60 출력)
# ───────────────────────────────────────────────
with tab5:
    st.subheader("예측 정확도 분석")

    if not _MODULES_OK:
        st.error(f"모듈 오류: {_MODULE_ERR}")
    else:
        acc_files = _scan_accuracy_excel()
        year_files = [f for f in acc_files if str(year_sel) in f.name]

        if not year_files:
            st.info(f"OUT_DIR 에 {year_sel}년도 예측정확도 엑셀 파일이 없습니다.\n"
                    "step_60_predict_accuracy.py 를 먼저 실행하세요.")
        else:
            sel_file = st.selectbox(
                "분석 파일 선택",
                options=year_files,
                format_func=lambda p: p.name,
            )

            with st.spinner("파일 로딩 중..."):
                # 요약 시트 (시트 0 = 요약)
                df_acc_sum = _read_excel_sheet(sel_file, sheet=0)

            if df_acc_sum is None or df_acc_sum.empty:
                st.warning("요약 시트를 읽을 수 없습니다.")
            else:
                st.markdown(f"**파일**: `{sel_file.name}`")

                # 요약 시트 전체 표시
                with st.expander("📋 요약 시트 (전체)", expanded=True):
                    st.dataframe(df_acc_sum, use_container_width=True)

                # MAPE 컬럼 추출 (요약 시트 구조: 행=협력사, 열=파일별MAPE)
                mape_cols = [c for c in df_acc_sum.columns if "MAPE" in str(c)]
                vendor_col = df_acc_sum.columns[0]

                if mape_cols:
                    st.markdown("---")
                    # MAPE 히트맵
                    df_mape = df_acc_sum[[vendor_col] + mape_cols].copy()
                    df_mape = df_mape[df_mape[vendor_col].notna()]
                    df_mape = df_mape[~df_mape[vendor_col].astype(str).str.startswith("※")]
                    df_mape = df_mape.set_index(vendor_col)

                    for col in mape_cols:
                        df_mape[col] = pd.to_numeric(df_mape[col], errors="coerce")

                    if not df_mape.empty:
                        fig_mape = px.imshow(
                            df_mape.astype(float),
                            text_auto=".1f",
                            color_continuous_scale="RdYlGn_r",
                            zmin=0, zmax=30,
                            title="협력사 × 예측파일별 MAPE(%) 히트맵  (낮을수록 우수)",
                            aspect="auto",
                        )
                        fig_mape.update_layout(
                            height=max(300, len(df_mape) * 36 + 100),
                            margin=dict(t=50, b=20),
                            coloraxis_colorbar=dict(title="MAPE(%)"),
                        )
                        st.plotly_chart(fig_mape, use_container_width=True)

                        # 협력사별 평균 MAPE 막대
                        df_mape["평균MAPE"] = df_mape.mean(axis=1)
                        fig_avg = px.bar(
                            df_mape.reset_index().sort_values("평균MAPE"),
                            x=vendor_col, y="평균MAPE",
                            color="평균MAPE",
                            color_continuous_scale="RdYlGn_r",
                            title="협력사별 평균 MAPE(%) 비교",
                            text=df_mape.reset_index().sort_values("평균MAPE")["평균MAPE"].round(1),
                        )
                        fig_avg.add_hline(y=10, line_dash="dot", line_color="green",
                                          annotation_text="목표 10%")
                        fig_avg.update_traces(textposition="outside")
                        fig_avg.update_layout(height=380, margin=dict(t=40, b=20),
                                               coloraxis_showscale=False)
                        st.plotly_chart(fig_avg, use_container_width=True)


# ───────────────────────────────────────────────
# TAB 6  피처 분석 (step_61 출력)
# ───────────────────────────────────────────────
with tab6:
    st.subheader("피처 상관계수 및 기술통계")

    if not _MODULES_OK:
        st.error(f"모듈 오류: {_MODULE_ERR}")
    else:
        corr_files = _scan_corr_excel()
        year_cfiles = [f for f in corr_files if str(year_sel) in f.name]

        if not year_cfiles:
            st.info(f"OUT_DIR 에 {year_sel}년도 피처 상관계수 엑셀 파일이 없습니다.\n"
                    "step_61_feature_correlation.py 를 먼저 실행하세요.")
        else:
            sel_corr = st.selectbox(
                "분석 파일 선택",
                options=year_cfiles,
                format_func=lambda p: p.name,
            )

            sub_tab1, sub_tab2, sub_tab3, sub_tab4 = st.tabs([
                "📐 기술통계", "🔥 피처 간 상관계수", "🎯 타겟 상관계수", "🏭 협력사별 요약"
            ])

            # ① 기술통계 요약
            with sub_tab1:
                with st.spinner("기술통계 로딩 중..."):
                    df_desc = _read_excel_sheet(sel_corr, sheet="기술통계_요약")
                if df_desc is None or df_desc.empty:
                    st.warning("기술통계_요약 시트를 읽을 수 없습니다.")
                else:
                    # 첫 2행은 타이틀·빈 행 → 정리
                    df_desc = df_desc.dropna(how="all").reset_index(drop=True)

                    # 헤더 자동 감지 (피처명 컬럼이 있는 행)
                    header_row = None
                    for i, row in df_desc.iterrows():
                        if "피처명" in str(row.values):
                            header_row = i
                            break

                    if header_row is not None:
                        df_desc.columns = df_desc.iloc[header_row].astype(str)
                        df_desc = df_desc.iloc[header_row + 1:].reset_index(drop=True)
                        df_desc = df_desc[df_desc.iloc[:, 0].notna()]
                        df_desc = df_desc[~df_desc.iloc[:, 0].astype(str).str.startswith("※")]

                    st.dataframe(df_desc, use_container_width=True, height=520)

                    feat_col = df_desc.columns[0]

                    # ── 왜도 / 첨도 시각화
                    if "왜도(Skewness)" in df_desc.columns and feat_col in df_desc.columns:
                        st.markdown("---")
                        df_plot = df_desc[[feat_col, "왜도(Skewness)", "첨도(Kurtosis)"]].copy()
                        for c in ["왜도(Skewness)", "첨도(Kurtosis)"]:
                            df_plot[c] = pd.to_numeric(df_plot[c], errors="coerce")
                        df_plot = df_plot.dropna()

                        sc1, sc2 = st.columns(2)
                        fig_sk = px.bar(
                            df_plot.sort_values("왜도(Skewness)"),
                            x=feat_col, y="왜도(Skewness)",
                            color="왜도(Skewness)",
                            color_continuous_scale="RdBu_r",
                            title="피처별 왜도(Skewness)  [|값| > 1 → 강한 편향]",
                        )
                        fig_sk.add_hline(y=1,  line_dash="dot", line_color="red")
                        fig_sk.add_hline(y=-1, line_dash="dot", line_color="blue")
                        fig_sk.update_layout(height=360, margin=dict(t=40, b=20),
                                              coloraxis_showscale=False)
                        sc1.plotly_chart(fig_sk, use_container_width=True)

                        fig_ku = px.bar(
                            df_plot.sort_values("첨도(Kurtosis)"),
                            x=feat_col, y="첨도(Kurtosis)",
                            color="첨도(Kurtosis)",
                            color_continuous_scale="PuOr_r",
                            title="피처별 첨도(Kurtosis)  [> 3 → 뾰족(이상치多)]",
                        )
                        fig_ku.add_hline(y=3,  line_dash="dot", line_color="red",
                                         annotation_text="뾰족 기준")
                        fig_ku.add_hline(y=-3, line_dash="dot", line_color="blue",
                                         annotation_text="평탄 기준")
                        fig_ku.update_layout(height=360, margin=dict(t=40, b=20),
                                              coloraxis_showscale=False)
                        sc2.plotly_chart(fig_ku, use_container_width=True)

                    # ── MAE / RMSE / MAPE / R² 시각화
                    _metric_cols = ["MAE", "RMSE", "MAPE(%)", "R²(vs lag_days)"]
                    _avail_m = [c for c in _metric_cols if c in df_desc.columns]
                    if _avail_m:
                        st.markdown("---")
                        st.markdown("#### 📏 MAE · RMSE · MAPE · R² (피처별)")

                        df_m = df_desc[[feat_col] + _avail_m].copy()
                        for c in _avail_m:
                            df_m[c] = pd.to_numeric(df_m[c], errors="coerce")

                        mc1, mc2 = st.columns(2)

                        # MAE / RMSE 나란히
                        if "MAE" in _avail_m and "RMSE" in _avail_m:
                            df_mr = df_m[[feat_col, "MAE", "RMSE"]].dropna()
                            df_mr_melt = df_mr.melt(
                                id_vars=feat_col, value_vars=["MAE", "RMSE"],
                                var_name="지표", value_name="값"
                            )
                            fig_mr = px.bar(
                                df_mr_melt.sort_values([feat_col, "지표"]),
                                x=feat_col, y="값", color="지표",
                                barmode="group",
                                color_discrete_map={"MAE": "#60a5fa", "RMSE": "#f87171"},
                                title="피처별 MAE / RMSE  (0 기준)",
                            )
                            fig_mr.update_layout(height=360, margin=dict(t=40, b=20))
                            mc1.plotly_chart(fig_mr, use_container_width=True)

                        # MAPE
                        if "MAPE(%)" in _avail_m:
                            df_mape = df_m[[feat_col, "MAPE(%)"]].dropna()
                            fig_mp = px.bar(
                                df_mape.sort_values("MAPE(%)", ascending=False),
                                x=feat_col, y="MAPE(%)",
                                color="MAPE(%)",
                                color_continuous_scale="OrRd",
                                title="피처별 MAPE(%)  [lag_days: 계획기간 대비 / 피처: 정규화MAD]",
                            )
                            fig_mp.update_layout(height=360, margin=dict(t=40, b=20),
                                                  coloraxis_showscale=False)
                            mc2.plotly_chart(fig_mp, use_container_width=True)

                        # R²(vs lag_days)
                        if "R²(vs lag_days)" in _avail_m:
                            df_r2 = df_m[[feat_col, "R²(vs lag_days)"]].dropna()
                            # lag_days 행(R²=1.0) 제외하고 피처만
                            df_r2 = df_r2[df_r2["R²(vs lag_days)"] < 1.0]
                            if not df_r2.empty:
                                fig_r2 = px.bar(
                                    df_r2.sort_values("R²(vs lag_days)", ascending=True),
                                    x="R²(vs lag_days)", y=feat_col,
                                    orientation="h",
                                    color="R²(vs lag_days)",
                                    color_continuous_scale="Greens",
                                    title="피처별 R²(vs lag_days)  [결정계수 — 클수록 타겟 설명력↑]",
                                )
                                fig_r2.add_vline(x=0.49, line_dash="dot",
                                                 line_color="green",
                                                 annotation_text="|r|≥0.7")
                                fig_r2.add_vline(x=0.16, line_dash="dot",
                                                 line_color="orange",
                                                 annotation_text="|r|≥0.4")
                                fig_r2.update_layout(
                                    height=max(360, len(df_r2) * 22 + 120),
                                    margin=dict(t=40, b=20),
                                    coloraxis_showscale=False,
                                )
                                st.plotly_chart(fig_r2, use_container_width=True)

            # ② 피처 간 상관계수 히트맵
            with sub_tab2:
                with st.spinner("피처 간 상관계수 로딩 중..."):
                    df_cmat = _read_excel_sheet(sel_corr, sheet="피처간_상관계수")
                if df_cmat is None or df_cmat.empty:
                    st.warning("피처간_상관계수 시트를 읽을 수 없습니다.")
                else:
                    # 첫 열을 index 로 활용, 헤더 행 자동 감지
                    df_cmat = df_cmat.dropna(how="all").reset_index(drop=True)
                    # 숫자 행만 추출 (피처명 행)
                    feat_name_col = df_cmat.columns[0]
                    df_cmat_num = df_cmat.dropna(subset=[feat_name_col])
                    df_cmat_num = df_cmat_num[~df_cmat_num[feat_name_col].astype(str).str.startswith("※")]

                    # 피처명 컬럼 제외하고 숫자 변환
                    feat_names = df_cmat_num[feat_name_col].astype(str).tolist()
                    num_part   = df_cmat_num.drop(columns=[feat_name_col])
                    num_part   = num_part.apply(pd.to_numeric, errors="coerce")

                    if not num_part.empty and len(num_part.columns) > 1:
                        num_part.index = feat_names
                        # 열 이름도 피처명으로 (엑셀에서 읽은 컬럼명 정리)
                        col_labels = [str(c) for c in num_part.columns]
                        num_part.columns = col_labels

                        # 유효한 피처 행/열만 (전부 NaN인 행 제거)
                        num_part = num_part.dropna(how="all")

                        fig_cm = px.imshow(
                            num_part.astype(float),
                            text_auto=".2f",
                            color_continuous_scale="RdBu_r",
                            zmin=-1, zmax=1,
                            title="독립변수 간 피어슨 상관계수 히트맵",
                            aspect="auto",
                        )
                        fig_cm.update_layout(
                            height=max(500, len(num_part) * 32 + 120),
                            margin=dict(t=50, b=20),
                            coloraxis_colorbar=dict(title="r"),
                        )
                        st.plotly_chart(fig_cm, use_container_width=True)

                        # 강한 상관 쌍 목록 (|r| >= 0.4, 대각선 제외)
                        st.markdown("---")
                        st.markdown("**주의: |r| ≥ 0.4 피처 쌍 (다중공선성 위험)**")
                        pairs = []
                        for i, f1 in enumerate(num_part.index):
                            for j, f2 in enumerate(num_part.columns):
                                if i >= j:
                                    continue
                                v = num_part.loc[f1, f2]
                                if pd.notna(v) and abs(v) >= 0.4:
                                    pairs.append({"피처1": f1, "피처2": f2, "r": round(v, 4),
                                                  "|r|": round(abs(v), 4)})
                        if pairs:
                            df_pairs = pd.DataFrame(pairs).sort_values("|r|", ascending=False)
                            st.dataframe(df_pairs, use_container_width=True, height=300)
                        else:
                            st.success("|r| ≥ 0.4 인 피처 쌍이 없습니다.")

            # ③ 타겟 상관계수
            with sub_tab3:
                with st.spinner("타겟 상관계수 로딩 중..."):
                    df_tc = _read_excel_sheet(sel_corr, sheet="타겟_상관계수")
                if df_tc is None or df_tc.empty:
                    st.warning("타겟_상관계수 시트를 읽을 수 없습니다.")
                else:
                    df_tc = df_tc.dropna(how="all").reset_index(drop=True)

                    # 헤더 행 탐색
                    for i, row in df_tc.iterrows():
                        if "피처명" in str(row.values):
                            df_tc.columns = df_tc.iloc[i].astype(str)
                            df_tc = df_tc.iloc[i + 1:].reset_index(drop=True)
                            break

                    df_tc = df_tc[df_tc.iloc[:, 0].notna()]
                    df_tc = df_tc[~df_tc.iloc[:, 0].astype(str).str.startswith("※")]

                    feat_col = df_tc.columns[0]
                    corr_col = next((c for c in df_tc.columns if "상관계수" in str(c)), None)
                    abs_col  = next((c for c in df_tc.columns if "절댓값" in str(c)), None)

                    if corr_col:
                        df_tc[corr_col] = pd.to_numeric(df_tc[corr_col], errors="coerce")
                        df_plot_tc = df_tc[[feat_col, corr_col]].dropna()

                        if abs_col:
                            df_tc[abs_col] = pd.to_numeric(df_tc[abs_col], errors="coerce")
                            df_plot_tc = df_tc[[feat_col, corr_col, abs_col]].dropna()
                            df_plot_tc = df_plot_tc.sort_values(abs_col, ascending=True)
                        else:
                            df_plot_tc = df_plot_tc.sort_values(
                                corr_col, key=abs, ascending=True
                            )

                        fig_tc = px.bar(
                            df_plot_tc,
                            x=corr_col, y=feat_col,
                            orientation="h",
                            color=corr_col,
                            color_continuous_scale="RdBu_r",
                            range_color=[-1, 1],
                            title="타겟(lag_days)과 독립변수 간 피어슨 상관계수",
                            text=df_plot_tc[corr_col].round(4),
                        )
                        fig_tc.add_vline(x=0, line_color="gray", line_dash="dash")
                        fig_tc.update_traces(textposition="outside")
                        fig_tc.update_layout(
                            height=max(400, len(df_plot_tc) * 30 + 100),
                            margin=dict(t=50, l=200, b=20),
                            coloraxis_showscale=False,
                            xaxis_title="피어슨 r",
                        )
                        st.plotly_chart(fig_tc, use_container_width=True)

                    with st.expander("📋 타겟 상관계수 전체 테이블"):
                        st.dataframe(df_tc.reset_index(drop=True), use_container_width=True)

            # ④ 협력사별 요약
            with sub_tab4:
                with st.spinner("협력사별 요약 로딩 중..."):
                    df_vs = _read_excel_sheet(sel_corr, sheet="협력사별_요약")
                if df_vs is None or df_vs.empty:
                    st.warning("협력사별_요약 시트를 읽을 수 없습니다.")
                else:
                    df_vs = df_vs.dropna(how="all").reset_index(drop=True)

                    # 헤더 행 탐색
                    for i, row in df_vs.iterrows():
                        if "협력사" in str(row.values):
                            df_vs.columns = df_vs.iloc[i].astype(str)
                            df_vs = df_vs.iloc[i + 1:].reset_index(drop=True)
                            break

                    vendor_col = df_vs.columns[0]
                    df_vs = df_vs[df_vs[vendor_col].notna()]
                    df_vs = df_vs[~df_vs[vendor_col].astype(str).str.startswith("[")]
                    df_vs = df_vs.set_index(vendor_col)
                    df_vs = df_vs.apply(pd.to_numeric, errors="coerce")

                    if not df_vs.empty:
                        fig_vs = px.imshow(
                            df_vs.astype(float),
                            text_auto=".2f",
                            color_continuous_scale="RdBu_r",
                            zmin=-1, zmax=1,
                            title="협력사별 × 피처별 타겟 상관계수",
                            aspect="auto",
                        )
                        fig_vs.update_layout(
                            height=max(400, len(df_vs) * 36 + 120),
                            margin=dict(t=50, l=160, b=20),
                            coloraxis_colorbar=dict(title="r"),
                        )
                        st.plotly_chart(fig_vs, use_container_width=True)

                    with st.expander("📋 협력사별 상관계수 전체 테이블"):
                        st.dataframe(
                            df_vs.style.background_gradient(cmap="RdBu_r", vmin=-1, vmax=1)
                                  .format("{:.3f}"),
                            use_container_width=True,
                        )
