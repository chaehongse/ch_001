from __future__ import annotations

"""
db_config.py — DB 연결 정보 중앙 관리
======================================
이 파일만 수정하면 blk_ass 폴더 전체 파일에 적용됩니다.

  DB_HOST       : DB 서버 IP
  DB_PORT       : DB 포트
  DB_USER       : DB 사용자명
  DB_PASS       : DB 비밀번호 (환경변수 AS_DB_PASSWORD 에서 로드)
  DB_NAME_MAIN  : 메인 DB 이름  (구조조달1_db)
  DB_NAME_MART  : 마트 DB 이름  (datamart_db)
  DB_URL        : 메인 DB SQLAlchemy URL
  DB_URL_MART   : 마트 DB SQLAlchemy URL
"""

import os

# ─────────────────────────────────────────────
# 공통 접속 정보  ← 변경 시 이 부분만 수정
# ─────────────────────────────────────────────
DB_HOST = "60.100.164.182"
DB_PORT = 3306
DB_USER = "root"
DB_PASS = os.environ.get("AS_DB_PASSWORD", "").strip()
if not DB_PASS:
    raise EnvironmentError(
        "환경변수 AS_DB_PASSWORD 가 설정되지 않았습니다. "
        "DB 비밀번호를 환경변수로 설정 후 실행하세요.\n"
        "  예) set AS_DB_PASSWORD=비밀번호"
    )

# ─────────────────────────────────────────────
# DB 이름  ← 변경 시 이 부분만 수정
# ─────────────────────────────────────────────
DB_NAME_MAIN = "구조조달1_db"   # TPD · BPA · 모델 로그 등
DB_NAME_MART = "datamart_db"    # BPA 원천 데이터

# ─────────────────────────────────────────────
# SQLAlchemy URL (자동 생성 — 직접 수정 불필요)
# ─────────────────────────────────────────────
DB_URL = (
    f"mysql+pymysql://{DB_USER}:{DB_PASS}"
    f"@{DB_HOST}:{DB_PORT}/{DB_NAME_MAIN}?charset=utf8mb4"
)
DB_URL_MART = (
    f"mysql+pymysql://{DB_USER}:{DB_PASS}"
    f"@{DB_HOST}:{DB_PORT}/{DB_NAME_MART}?charset=utf8mb4"
)
