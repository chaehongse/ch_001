from __future__ import annotations
"""
step_46_utils_save_logcsv_DL.py

역할 요약
-----------
딥러닝 계열 모델(MPL, CNN, TCN, LSTM 등)의 학습/검증 로그를

1) CSV 파일로 저장하고
2) DB 테이블(예: 예측_모델_log_dl)에 append 업로드

까지 한 번에 처리하는 유틸 함수 모듈.

다른 step 파일들에서 공통으로 사용하기 위한 단일 진입점:
    → write_csv_log_DL(...)
"""

import datetime as dt
import json
from pathlib import Path
from typing import List

import pandas as pd

from step_0_MSF import OUT_DIR
from step_48_utils_logs_upload_DL import upload_log_df_to_db


def write_csv_log_DL(
    year: int,
    query_date: dt.date,
    rows: List[dict],
    engine_tag: str,
    db_url: str,
    table_name: str = "예측_모델_log_dl",
) -> None:
    """
    딥러닝 계열 모델의 "모델 선정 로그"를 CSV + DB 로 저장하는 함수.

    Parameters
    ----------
    year : int
        조회년도 (파일명/로그용 메타 정보)
    query_date : datetime.date
        조회일 (파일명에 yyMMdd로 들어감)
    rows : List[dict]
        한 행(로그 한 줄)에 해당하는 dict 리스트.
        예시 키:
            - "timestamp"
            - "year"
            - "협력사"
            - "tag"
            - "engine"
            - "R2_train", "R2_valid"
            - "MAE_valid", "RMSE_valid", "val_loss"
            - "split_ratio", "train_range", "valid_range"
            - "params_json" (하이퍼파라미터 JSON 문자열 or dict)
            등등...
    engine_tag : str
        엔진 태그 (파일명/로그 메시지에 사용)
        예) "MLP", "CNN", "TCN", "LSTM", "DL_최적" 등
    db_url : str
        SQLAlchemy 스타일 DB URL
        예) "mysql+pymysql://user:pw@host:3306/dbname?charset=utf8mb4"
    table_name : str, default "예측_모델_log_dl"
        로그를 append 업로드할 대상 테이블명

    Notes
    -----
    1) CSV 파일 위치/파일명
       - 폴더: OUT_DIR / "logs_dl"
       - 파일: {year}_model_selection_log_{engine_tag}_{yyMMdd}.csv

    2) params_json 처리
       - rows 에 "params_json" 컬럼이 있으면 dict/JSON 문자열로 가정하고
         pd.json_normalize 로 펼친 뒤 param_* 컬럼으로 분리합니다.

    3) DB 업로드
       - 마지막에 upload_log_df_to_db(df, db_url, table=table_name) 호출로
         해당 테이블에 append 업로드합니다.
    """
    if not rows:
        print("[LOG] 기록할 행이 없습니다. (빈 로그)")
        return

    # ─────────────────────────────────────
    # 1) 날짜별 로그 폴더 (DL 전용) 생성
    # ─────────────────────────────────────
    logs_dir = OUT_DIR / "logs_dl"
    logs_dir.mkdir(parents=True, exist_ok=True)

    date_suffix = query_date.strftime("%y%m%d")  # 예: 2025-11-30 → "251130"
    csv_path = logs_dir / f"{year}_model_selection_log_{engine_tag}_{date_suffix}.csv"

    # 기존 동일 파일명이 있으면 삭제 후 새로 생성
    try:
        csv_path.unlink(missing_ok=True)
    except Exception as e:
        print(f"[LOG] 기존 로그 삭제 실패: {e}")

    # ─────────────────────────────────────
    # 2) rows → DataFrame 변환
    # ─────────────────────────────────────
    df = pd.DataFrame(rows)

    # params_json 컬럼 dict/JSON → 펼쳐서 param_* 컬럼 분리
    def _ensure_dict(v):
        """
        params_json 컬럼값을 dict로 변환 보정하는 내부 함수.

        - dict 그대로 들어오면 그대로 반환
        - str/bytes 이면 JSON 파싱 시도, 실패하면 {"_raw": "원본"} 형태로 보존
        - 그 외 타입이면 {"_raw": None}
        """
        if isinstance(v, dict):
            return v
        if isinstance(v, (str, bytes)):
            try:
                return json.loads(v)
            except Exception:
                return {"_raw": str(v)}
        return {"_raw": None}

    if "params_json" in df.columns:
        params_df = pd.json_normalize(df["params_json"].apply(_ensure_dict)).add_prefix(
            "param_"
        )
        df = pd.concat(
            [df.drop(columns=["params_json"]), params_df],
            axis=1,
        )

    # ─────────────────────────────────────
    # 3) 컬럼 순서 정리 (우선 컬럼 + param_* + 기타)
    # ─────────────────────────────────────
    priority_cols = [
        "timestamp",
        "year",
        "협력사",
        "tag",
        "engine",
        "R2_train",
        "R2_valid",
        "MAE_valid",
        "RMSE_valid",
        "val_loss",
        "split_ratio",
        "train_range",
        "valid_range",
    ]
    param_cols = sorted([c for c in df.columns if c.startswith("param_")])
    other_cols = [c for c in df.columns if c not in priority_cols + param_cols]

    ordered_cols = [c for c in priority_cols if c in df.columns] + param_cols + other_cols
    df = df[ordered_cols]

    # ─────────────────────────────────────
    # 4) CSV 저장
    # ─────────────────────────────────────
    df.to_csv(csv_path, mode="w", header=True, index=False, encoding="utf-8-sig")
    print(
        f"[LOG] {engine_tag} 모델선정 CSV 저장: {csv_path} "
        f"(rows={len(df)}, cols={len(df.columns)})"
    )

    # ─────────────────────────────────────
    # 5) DB 테이블에 append 업로드
    # ─────────────────────────────────────
    upload_log_df_to_db(df, db_url, table=table_name)
