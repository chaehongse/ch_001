import os
from datetime import date, datetime, timedelta
from typing import Dict, Iterable, List

# =========================
# 1) MSSQL 하드코딩 설정
# =========================
MSSQL_SERVER = "127.0.0.1"
MSSQL_PORT = 1433
MSSQL_DATABASE = "your_database"
MSSQL_USER = "sa"
MSSQL_PASSWORD_ENV = "AS_DB_PASSWORD"  # 비밀번호만 환경변수
MSSQL_DRIVER = "ODBC Driver 18 for SQL Server"

# 서버에서 공휴일/휴무일을 가져올 SQL (컬럼 alias는 아래 키를 맞춰주세요)
# - holiday_date: YYYY-MM-DD 로 변환 가능한 날짜
# - holiday_name: 휴일명
# - is_holiday: 휴일 여부 (1/0)
SQL_HOLIDAY = """
SELECT
    holiday_date,
    holiday_name,
    is_holiday
FROM dbo.your_holiday_table
WHERE YEAR(holiday_date) IN ({years})
ORDER BY holiday_date;
"""

# =========================
# 2) 조회 실패 시 연도별 지정
# =========================
# 필요 시 연도별로 계속 추가하세요.
# date 형식: YYYY-MM-DD
YEARLY_HOLIDAY_CONFIG: Dict[int, Dict[str, object]] = {
    2026: {
        "public_holidays": [
            ("2026-01-01", "신정"),
            ("2026-03-01", "삼일절"),
            ("2026-05-05", "어린이날"),
            ("2026-06-06", "현충일"),
            ("2026-08-15", "광복절"),
            ("2026-10-03", "개천절"),
            ("2026-10-09", "한글날"),
            ("2026-12-25", "성탄절"),
        ],
        "festivals": [
            # 명절(설/추석 등) 직접 지정
            # ("2026-02-16", "설날 연휴"),
            # ("2026-02-17", "설날"),
            # ("2026-02-18", "설날 연휴"),
            # ("2026-09-24", "추석 연휴"),
            # ("2026-09-25", "추석"),
            # ("2026-09-26", "추석 연휴"),
        ],
        "company_days_off": [
            # 회사 지정 휴무일
            # ("2026-05-01", "근로자의 날"),
            # ("2026-12-31", "연말 휴무"),
        ],
        "include_weekends": True,
    },
}


def _parse_date(text: str) -> date:
    return datetime.strptime(text, "%Y-%m-%d").date()


def _weekends_of_year(year: int) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    d = date(year, 1, 1)
    end = date(year, 12, 31)
    while d <= end:
        if d.weekday() >= 5:  # 5:토, 6:일
            rows.append(
                {
                    "holiday_date": d,
                    "holiday_name": "주말휴무",
                    "is_holiday": 1,
                    "source": "fallback",
                }
            )
        d += timedelta(days=1)
    return rows


def _fallback_holidays(years: Iterable[int]) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []

    for y in years:
        cfg = YEARLY_HOLIDAY_CONFIG.get(y, {})

        for key in ["public_holidays", "festivals", "company_days_off"]:
            for d, name in cfg.get(key, []):
                rows.append(
                    {
                        "holiday_date": _parse_date(d),
                        "holiday_name": name,
                        "is_holiday": 1,
                        "source": "fallback",
                    }
                )

        if cfg.get("include_weekends", True):
            rows.extend(_weekends_of_year(y))

    # 날짜 중복 제거(동일일자에 여러 항목이 있으면 이름 병합)
    merged: Dict[date, Dict[str, object]] = {}
    for row in rows:
        d = row["holiday_date"]
        if d not in merged:
            merged[d] = row
        else:
            prev_name = merged[d]["holiday_name"]
            new_name = row["holiday_name"]
            if new_name not in str(prev_name):
                merged[d]["holiday_name"] = f"{prev_name}, {new_name}"

    return [merged[k] for k in sorted(merged.keys())]


def _fetch_from_mssql(years: Iterable[int]) -> List[Dict[str, object]]:
    try:
        import pyodbc
    except ImportError as exc:
        raise RuntimeError("pyodbc 미설치") from exc

    password = os.getenv(MSSQL_PASSWORD_ENV)
    if not password:
        raise RuntimeError(f"{MSSQL_PASSWORD_ENV} 환경변수가 설정되지 않았습니다.")

    year_tokens = ",".join(str(int(y)) for y in sorted(set(years)))
    sql = SQL_HOLIDAY.format(years=year_tokens)

    conn_str = (
        f"DRIVER={{{MSSQL_DRIVER}}};"
        f"SERVER={MSSQL_SERVER},{MSSQL_PORT};"
        f"DATABASE={MSSQL_DATABASE};"
        f"UID={MSSQL_USER};"
        f"PWD={password};"
        "Encrypt=yes;TrustServerCertificate=yes;"
    )

    rows: List[Dict[str, object]] = []
    with pyodbc.connect(conn_str, timeout=5) as conn:
        cursor = conn.cursor()
        cursor.execute(sql)

        col_names = [c[0] for c in cursor.description]
        for rec in cursor.fetchall():
            data = dict(zip(col_names, rec))
            d = data.get("holiday_date")
            if isinstance(d, datetime):
                d = d.date()
            elif isinstance(d, str):
                d = _parse_date(d[:10])

            rows.append(
                {
                    "holiday_date": d,
                    "holiday_name": data.get("holiday_name"),
                    "is_holiday": int(data.get("is_holiday", 1)),
                    "source": "mssql",
                }
            )

    return rows


def get_holidays(years: Iterable[int]) -> List[Dict[str, object]]:
    years = sorted(set(int(y) for y in years))
    if not years:
        return []

    try:
        data = _fetch_from_mssql(years)
        if data:
            return data
        print("[WARN] MSSQL 조회 결과가 비어 있어 fallback 설정을 사용합니다.")
    except Exception as exc:
        print(f"[WARN] MSSQL 조회 실패로 fallback 사용: {exc}")

    return _fallback_holidays(years)


if __name__ == "__main__":
    target_years = [2026]
    holidays = get_holidays(target_years)

    print(f"대상 연도: {target_years}")
    print(f"휴일 건수: {len(holidays)}")
    for row in holidays[:20]:
        print(row)
