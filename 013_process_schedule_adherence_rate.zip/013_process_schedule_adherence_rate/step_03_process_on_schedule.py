from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set

import pandas as pd
from openpyxl import Workbook
from openpyxl.cell.cell import MergedCell
from openpyxl.styles import Border, Side

from step_02_working_day import get_holidays


def _to_date_series(raw: pd.Series) -> pd.Series:
    """여러 형식(YYYYMMDD/int/float/str/datetime)을 date로 안전 변환."""

    def parse_one(v) -> Optional[date]:
        if pd.isna(v):
            return None
        if isinstance(v, datetime):
            return v.date()
        if isinstance(v, date):
            return v

        s = str(v).strip()
        if not s or s.lower() == "nan":
            return None

        # 20260120.0 같은 값 처리
        if s.endswith(".0"):
            s = s[:-2]

        # 숫자 8자리 YYYYMMDD 처리
        digits = "".join(ch for ch in s if ch.isdigit())
        if len(digits) == 8:
            try:
                return datetime.strptime(digits, "%Y%m%d").date()
            except ValueError:
                pass

        # 일반 파싱
        dt = pd.to_datetime(s, errors="coerce")
        if pd.isna(dt):
            return None
        return dt.date()

    return raw.map(parse_one)


def _load_data() -> pd.DataFrame:
    """DB에서 데이터 로드."""
    from step_01_db_config import align_to_excel_schema, fetch_data

    rows = fetch_data()
    rows = align_to_excel_schema(rows)
    return pd.DataFrame(rows)


def _working_day_diff(start_d: date, end_d: date, holidays: Set[date]) -> int:
    """start_d~end_d 구간 working day 차이(종료일 기준 포함, 시작일 제외)."""
    if start_d == end_d:
        return 0

    sign = 1
    s, e = start_d, end_d
    if e < s:
        sign = -1
        s, e = e, s

    count = 0
    cur = s + timedelta(days=1)
    while cur <= e:
        if cur.weekday() < 5 and cur not in holidays:
            count += 1
        cur += timedelta(days=1)

    return count * sign


def calculate_process_on_schedule(df: pd.DataFrame, as_of_date: Optional[date] = None) -> pd.DataFrame:
    """
    공정 적중율 산출 규칙:
    - 실적_W_C명(협력사)별 계산
    - P_stage_코드 == 'A'
    - 블럭 4~5번째 문자열이 NP/NS인 건 제외
    - working day 기준 (step_02 휴일 목록 반영)
    - (실적_완료 - 기준계획_완료) <= 2 이면 준수, >2 이면 미준수
    - 대상 필터: 기준계획_완료 <= 조회일(as_of_date)
    - 실적_완료 결측 시 조회일(as_of_date)로 대체하여 판정
    - 월 단위 피벗
    """
    if as_of_date is None:
        as_of_date = datetime.now().date()

    work = df.copy()

    # 필수 컬럼 보정
    for col in ["P_stage_코드", "블럭", "실적_W_C명", "기준계획_완료", "실적_완료"]:
        if col not in work.columns:
            work[col] = None

    work["기준계획_완료_dt"] = _to_date_series(work["기준계획_완료"])
    work["실적_완료_dt"] = _to_date_series(work["실적_완료"])
    work["실적_완료_대체_dt"] = work["실적_완료_dt"].fillna(as_of_date)

    # 필터: P_stage_코드 == A, 블럭 4~5번째 NP/NS 제외
    block_code = work["블럭"].astype(str).str.strip()
    block_45 = block_code.str[3:5].fillna("")
    filtered = work[(work["P_stage_코드"].astype(str).str.strip() == "A") & (~block_45.isin(["NP", "NS"]))].copy()

    filtered = filtered[
        filtered["기준계획_완료_dt"].notna()
        & (filtered["기준계획_완료_dt"] <= as_of_date)
    ].copy()

    if filtered.empty:
        return pd.DataFrame(
            columns=["협력사", "월", "준수", "미준수", "전체", "적중율(%)"]
        )

    # 대상 연도의 휴일 로드
    years = set(filtered["기준계획_완료_dt"].map(lambda d: d.year))
    years.update(filtered["실적_완료_대체_dt"].map(lambda d: d.year))
    years.add(as_of_date.year)

    holiday_rows = get_holidays(sorted(years))
    holiday_set = {
        r["holiday_date"]
        for r in holiday_rows
        if r.get("is_holiday", 1) == 1 and isinstance(r.get("holiday_date"), date)
    }

    filtered["working_day_gap"] = filtered.apply(
        lambda row: _working_day_diff(
            row["기준계획_완료_dt"], row["실적_완료_대체_dt"], holiday_set
        ),
        axis=1,
    )

    filtered["판정"] = filtered["working_day_gap"].map(
        lambda x: "준수" if x <= 2 else "미준수"
    )

    # 월은 실적완료 기준(결측은 조회일 대체)
    filtered["월"] = filtered["실적_완료_대체_dt"].map(lambda d: d.strftime("%Y-%m"))
    filtered["협력사"] = filtered["실적_W_C명"].fillna("미지정").astype(str).str.strip()
    filtered.loc[filtered["협력사"] == "", "협력사"] = "미지정"

    summary = (
        filtered.groupby(["협력사", "월", "판정"], dropna=False)
        .size()
        .unstack(fill_value=0)
        .reset_index()
    )

    if "준수" not in summary.columns:
        summary["준수"] = 0
    if "미준수" not in summary.columns:
        summary["미준수"] = 0

    summary["전체"] = summary["준수"] + summary["미준수"]
    summary["적중율(%)"] = (summary["준수"] / summary["전체"] * 100).round(1)
    summary = summary[["협력사", "월", "준수", "미준수", "전체", "적중율(%)"]]

    return summary.sort_values(["월", "협력사"]).reset_index(drop=True)


def make_monthly_pivot(summary: pd.DataFrame) -> pd.DataFrame:
    if summary.empty:
        return pd.DataFrame()

    pivot = summary.pivot_table(
        index="협력사",
        columns="월",
        values=["준수", "미준수", "전체", "적중율(%)"],
        aggfunc="sum",
        fill_value=0,
    )

    # 컬럼 평탄화: 준수_2026-01 형식
    pivot.columns = [f"{metric}_{month}" for metric, month in pivot.columns]
    return pivot.reset_index()


def _get_report_year(summary: pd.DataFrame, as_of_date: date) -> int:
    if summary.empty:
        return as_of_date.year

    years = summary["월"].astype(str).str[:4]
    years = pd.to_numeric(years, errors="coerce").dropna().astype(int)
    if years.empty:
        return as_of_date.year
    return int(years.mode().iloc[0])


def _build_company_month_map(summary: pd.DataFrame, report_year: int) -> Dict[str, Dict[int, Dict[str, float]]]:
    target = summary[summary["월"].astype(str).str.startswith(f"{report_year}-")].copy()
    if target.empty:
        return {}

    target["month_num"] = target["월"].astype(str).str[-2:].astype(int)
    data_map: Dict[str, Dict[int, Dict[str, float]]] = {}
    for _, row in target.iterrows():
        company = str(row["협력사"])
        month = int(row["month_num"])
        data_map.setdefault(company, {})[month] = {
            "준수": float(row["준수"]),
            "미준수": float(row["미준수"]),
            "전체": float(row["전체"]),
            "적중율(%)": float(row["적중율(%)"]),
        }
    return data_map


def _write_styled_report(summary: pd.DataFrame, out_path: Path, report_year: int, as_of_date: date) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"

    title_style = ws["A1"]._style
    header_style = ws["A2"]._style
    subheader_style = ws["B3"]._style
    company_style = ws["A4"]._style
    data_style = ws["B4"]._style
    thin_border = ws["B4"].border if isinstance(ws["B4"].border, Border) else Border()

    base_col_a_width = ws.column_dimensions["A"].width
    base_month_widths = [
        ws.column_dimensions["B"].width,
        ws.column_dimensions["C"].width,
        ws.column_dimensions["D"].width,
        ws.column_dimensions["E"].width,
    ]

    for merged in list(ws.merged_cells.ranges):
        ws.unmerge_cells(str(merged))

    max_clear_row = ws.max_row
    max_clear_col = ws.max_column
    for r in range(1, max_clear_row + 1):
        for c in range(1, max_clear_col + 1):
            cell = ws.cell(row=r, column=c)
            cell.value = None
            cell._style = ws["B4"]._style if r >= 4 and c >= 2 else cell._style

    ws["A1"] = f"□ {report_year}년 사외 조립 공정적중률"
    ws["A1"]._style = title_style

    ws["A2"] = "협력사"
    ws["A2"]._style = header_style
    ws.merge_cells(start_row=2, start_column=1, end_row=3, end_column=1)
    ws["A3"]._style = header_style

    company_month_map = _build_company_month_map(summary, report_year)
    companies = sorted(company_month_map.keys())
    months = sorted({m for v in company_month_map.values() for m in v.keys()})
    if not months:
        months = [as_of_date.month]

    metrics = ["준수", "미준수", "계", "적중률"]
    for idx, month_num in enumerate(months):
        start_col = 2 + idx * 4
        end_col = start_col + 3
        ws.cell(row=2, column=start_col, value=f"{month_num}월")._style = header_style
        ws.merge_cells(start_row=2, start_column=start_col, end_row=2, end_column=end_col)
        for c in range(start_col, end_col + 1):
            ws.cell(row=2, column=c)._style = header_style
        for j, metric in enumerate(metrics):
            ws.cell(row=3, column=start_col + j, value=metric)._style = subheader_style

    total_start_col = 2 + len(months) * 4
    total_end_col = total_start_col + 3
    ws.cell(row=2, column=total_start_col, value="합계")._style = header_style
    ws.merge_cells(start_row=2, start_column=total_start_col, end_row=2, end_column=total_end_col)
    for c in range(total_start_col, total_end_col + 1):
        ws.cell(row=2, column=c)._style = header_style
    for j, metric in enumerate(metrics):
        ws.cell(row=3, column=total_start_col + j, value=metric)._style = subheader_style

    start_row = 4
    for i, company in enumerate(companies):
        r = start_row + i
        ws.cell(row=r, column=1, value=company)._style = company_style

        sum_ok = 0
        sum_nok = 0
        sum_total = 0
        for idx, month_num in enumerate(months):
            start_col = 2 + idx * 4
            m = company_month_map.get(company, {}).get(month_num, {})
            ok = int(m.get("준수", 0))
            nok = int(m.get("미준수", 0))
            total = int(m.get("전체", 0))
            rate = round((ok / total * 100), 1) if total else 0.0

            values = [ok, nok, total, rate]
            for j, value in enumerate(values):
                cell = ws.cell(row=r, column=start_col + j, value=value)
                cell._style = data_style
                cell.border = thin_border

            sum_ok += ok
            sum_nok += nok
            sum_total += total

        sum_rate = round((sum_ok / sum_total * 100), 1) if sum_total else 0.0
        total_values = [sum_ok, sum_nok, sum_total, sum_rate]
        for j, value in enumerate(total_values):
            cell = ws.cell(row=r, column=total_start_col + j, value=value)
            cell._style = data_style
            cell.border = thin_border

    ws.column_dimensions["A"].width = base_col_a_width
    for idx in range(len(months) + 1):
        start_col = 2 + idx * 4
        for j in range(4):
            col_letter = ws.cell(row=1, column=start_col + j).column_letter
            ws.column_dimensions[col_letter].width = base_month_widths[j]

    # 표 전체(헤더+데이터) 외곽/내부선 강제 적용
    table_start_row = 2
    table_end_row = max(3, start_row + len(companies) - 1)
    table_start_col = 1
    table_end_col = total_end_col
    thin = Side(style="thin")
    medium = Side(style="medium")

    for r in range(table_start_row, table_end_row + 1):
        for c in range(table_start_col, table_end_col + 1):
            cell = ws.cell(row=r, column=c)
            if isinstance(cell, MergedCell):
                continue

            left = medium if c == table_start_col else thin
            right = medium if c == table_end_col else thin
            top = medium if r == table_start_row else thin
            bottom = medium if r == table_end_row else thin
            cell.border = Border(left=left, right=right, top=top, bottom=bottom)

    wb.save(out_path)


def main() -> None:
    as_of_date = datetime.now().date()
    df = _load_data()
    result = calculate_process_on_schedule(df, as_of_date=as_of_date)
    report_year = _get_report_year(result, as_of_date)

    out_dir = Path("save_folder")
    out_dir.mkdir(parents=True, exist_ok=True)

    excel_path = out_dir / f"{report_year}년도_사외조립_공정적중률_{as_of_date.strftime('%Y%m%d')}.xlsx"

    _write_styled_report(result, excel_path, report_year=report_year, as_of_date=as_of_date)

    print(f"원천 데이터 건수: {len(df)}")
    print(f"엑셀 저장: {excel_path}")
    print("\n[요약 상위 20건]")
    print(result.head(20).to_string(index=False))


if __name__ == "__main__":
    main()
