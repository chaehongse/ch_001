import os
import pymysql
from collections import OrderedDict

# 하드코딩 설정
MYSQL_HOST = "60.100.164.182"
MYSQL_PORT = 3306
MYSQL_USER = "root"
MYSQL_DB = "your_database"
MYSQL_CHARSET = "utf8mb4"

# 조회할 SQL (필요한 형태로 수정)
SQL = """
SELECT *
FROM your_table
LIMIT 100;
"""

COLUMNS = [
    "프로젝트_번호",
    "블럭",
    "P_stage_코드",
    "Type",
    "부문",
    "도크",
    "선종_선형",
    "선주",
    "프로젝트명",
    "운반선_해양_구분",
    "블록구분",
    "블록구획",
    "중량_설비",
    "중량_고유",
    "중량_환산",
    "용접장",
    "용접장_계량",
    "제원_L",
    "제원_B",
    "제원_H",
    "기준계획_착수",
    "기준계획_완료",
    "기준계획_AREA",
    "기준계획_사급",
    "기준계획_공기",
    "N_12주_착수",
    "N_12주완료",
    "N_12주_AREA",
    "N_12주_사급",
    "N_12주_공기",
    "실적_착수",
    "실적_완료",
    "실적_AREA",
    "실적_W_C_코드",
    "실적_W_C명",
    "실적_공기",
    "차질원인코드",
    "차질원인설명",
    "최종변경_착수_변경일시",
    "최종변경_완료_변경일시",
    "CREATE_DATE",
    "용착량",
    "협력사",
]


def align_to_excel_schema(rows):
    aligned = []
    for row in rows:
        ordered_row = OrderedDict((col, row.get(col)) for col in COLUMNS)
        aligned.append(ordered_row)
    return aligned


def fetch_data():
    password = os.getenv("AS_DB_PASSWORD")
    if not password:
        raise EnvironmentError("AS_DB_PASSWORD 환경변수가 설정되지 않았습니다.")

    conn = pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=password,
        database=MYSQL_DB,
        charset=MYSQL_CHARSET,
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True,
    )

    try:
        with conn.cursor() as cursor:
            cursor.execute(SQL)
            rows = cursor.fetchall()
        return rows
    finally:
        conn.close()


if __name__ == "__main__":
    raw_data = fetch_data()
    data = align_to_excel_schema(raw_data)

    print(f"조회 건수: {len(data)}")
    print(f"엑셀 기준 컬럼 수: {len(COLUMNS)}")
    if data:
        print(data[0])
