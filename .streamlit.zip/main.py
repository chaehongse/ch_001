def main():
    print("Hello from 010-team-dash-board!")


if __name__ == "__main__":
    main()
