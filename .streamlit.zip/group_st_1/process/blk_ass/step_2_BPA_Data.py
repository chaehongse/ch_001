from __future__ import annotations

"""
step_2_BPA_Data.py

역할 요약
---------
1. MySQL(datamart_db)의 `schvw_bi_blk_ass_sch` 테이블에서
   - 조회년도 기준: 전년도 1월 1일 ~ 내년 12월 31일까지 데이터 조회
2. AREA 코드 → 협력사명으로 매핑
3. 조회년도(예: 2025년) 데이터만 필터링
4. 사외조달 대상 협력사만 남겨서 OUT_DIR에 엑셀로 저장

단독 실행 시:
    - 파일명: {조회년}년도_사외_조립_계획_실적_data_YYMMDD.xlsx
"""

from pathlib import Path
from datetime import date
import datetime as dt

import pandas as pd
import openpyxl   # to_excel 시 엔진용 (직접 쓰진 않지만 필요)
import pymysql    # SQLAlchemy에서 mysql+pymysql 드라이버로 사용

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from step_0_MSF import OUT_DIR
from step_49_utils_BPA_upload import upload_bpa_data


# =========================================================
# 0) 공통 상수: 협력사 매핑 테이블 (AREA 코드 → 협력사명)
# =========================================================
AREA_TO_VENDOR: dict[str, str] = {
    "EK": "EK",
    "SDK": "디케이(건화)",
    "KM": "기민",
    "KMC": "기민(코밍)",
    "TJST": "DHI(통영)",
    "O2": "오리엔탈",
    "SKA": "디케이(건화)",
    "GH2": "금강",
    "HGD": "기득",
    "CDKA": "동림",
    "CDKB": "동림",
    "CDKC": "동림",
    "CDKP": "동림",
    "SSA1": "HSG성동",
    "SSA2": "HSG성동",
    "SSA3": "HSG성동",
    "SSA4": "HSG성동",
    "SSA9": "HSG성동",
    "SSL1": "HSG성동",
    "SSL3": "HSG성동",
    "SSL4": "HSG성동",
    "SSMM": "HSG성동",
    "SSS": "HSG성동",
    "TUA": "신한",
    "SUA": "욱일",
    "HHJ": "호진",
    "HSGS": "HSG(사천)",
    "USJ": "세진",
    "KGY": "광양",
    "KK": "금광",
    "TDS2": "다성2",
    "DS": "두성",
}

# =========================================================
# 1) SQLAlchemy 엔진 (MySQL 연결 설정)
# =========================================================
MYSQL_HOST = "60.100.164.182"
MYSQL_USER = "root"
MYSQL_PASSWORD = "250404"
MYSQL_DB = "datamart_db"
MYSQL_PORT = 3306


def _make_engine() -> Engine:
    """
    SQLAlchemy MySQL 엔진 생성.

    - 드라이버: pymysql
    - pool_pre_ping=True : 끊어진 커넥션 자동 복구
    """
    conn_str = (
        f"mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}"
        f"@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}?charset=utf8mb4"
    )
    return create_engine(conn_str, pool_pre_ping=True)


# =========================================================
# 2) DB 조회: 전년도~내년까지 데이터 로드
# =========================================================
def fetch_df(year: int | None = None) -> pd.DataFrame:
    """
    MySQL에서 조회년도 기준으로 전년도~내년까지 데이터 조회.

    Parameters
    ----------
    year : int | None
        조회 기준 연도 (None 이면 오늘 기준 연도 사용)

    Returns
    -------
    pd.DataFrame
        기준계획/실적 완료일이 조회기간 내에 포함된 행 전체
    """
    year = year or date.today().year
    start_date = date(year - 1, 1, 1)
    end_date = date(year + 1, 12, 31)

    query = text(
        """
        SELECT DISTINCT *
        FROM schvw_bi_blk_ass_sch
        WHERE
            (CAST(기준계획_완료 AS DATE) BETWEEN :start_date AND :end_date)
            OR
            (CAST(실적_완료   AS DATE) BETWEEN :start_date AND :end_date)
        """
    )
    params = {"start_date": start_date, "end_date": end_date}

    print(f"[INFO] MySQL 연결 및 데이터 로딩... (조회연도: {year})")
    engine = _make_engine()
    try:
        with engine.connect() as conn:
            df = pd.read_sql_query(query, conn, params=params)
    finally:
        engine.dispose()

    print(f"[INFO] 로딩 완료: {len(df):,}건")

    # 날짜 컬럼 문자열(YYYYMMDD) 정규화
    for col in ("기준계획_완료", "실적_완료"):
        if col in df.columns:
            df[col] = (
                pd.to_datetime(df[col], errors="coerce")
                .dt.strftime("%Y%m%d")
            )

    # 중량_고유 숫자 변환
    if "중량_고유" in df.columns:
        df["중량_고유"] = (
            pd.to_numeric(df["중량_고유"], errors="coerce")
            .fillna(0)
        )

    # 필수 컬럼 체크
    required = {"기준계획_완료", "실적_완료", "중량_고유", "기준계획_AREA"}
    missing = required - set(df.columns)
    if missing:
        raise KeyError(f"DB 결과에 필수 컬럼 누락: {sorted(missing)}")

    return df


# =========================================================
# 3) 정규화 및 연도 필터링
# =========================================================
def _normalize_area(series: pd.Series) -> pd.Series:
    """AREA 코드: 공백 제거 + 대문자 통일"""
    return series.astype(str).str.strip().str.upper()


def _filter_year_only(df: pd.DataFrame, year: int) -> pd.DataFrame:
    """
    조회년도에 해당하는 행만 필터링.

    기준
    ----
    - 기준계획_완료 또는 실적_완료 둘 중 하나라도
      해당 연도(year)에 속하면 포함 (OR 조건)
    """
    if df.empty:
        return df

    mask = pd.Series(False, index=df.index)

    for col in ["기준계획_완료", "실적_완료"]:
        if col in df.columns:
            # fetch_df에서 한 번 문자열로 바꾼 상태이므로 다시 datetime 변환
            dt_col = pd.to_datetime(df[col], errors="coerce")
            mask |= dt_col.dt.year.eq(year)

    # 두 컬럼 모두 없으면 원본 그대로 반환
    if not mask.any():
        return df

    return df[mask].copy()


# =========================================================
# 4) 사외조달 협력사 매핑 (AREA → 협력사)
# =========================================================
def outside_df(year: int | None = None) -> pd.DataFrame:
    """
    사외조달 협력사 대상 데이터 생성.

    - schvw_bi_blk_ass_sch 에서 조회년도±1년 범위 데이터 로딩
    - AREA 코드 → 협력사명 매핑
    - 해양(운반선_해양_구분='해양')인 경우 협력사명 뒤에 '(해양)' suffix
    """
    y = year or dt.date.today().year
    df = fetch_df(y).copy()

    if "기준계획_AREA" not in df.columns:
        raise KeyError("'기준계획_AREA' 누락. DB 스키마 확인 필요")

    # AREA 코드 정규화 및 매핑 대상만 필터
    df["기준계획_AREA"] = _normalize_area(df["기준계획_AREA"])
    df = df[df["기준계획_AREA"].isin(AREA_TO_VENDOR.keys())].copy()

    # 협력사명 매핑
    df["협력사"] = df["기준계획_AREA"].map(AREA_TO_VENDOR)

    # 매핑 실패 코드가 있으면 예외 발생 (코드 추가 필요)
    if df["협력사"].isna().any():
        missing_codes = sorted(
            df.loc[df["협력사"].isna(), "기준계획_AREA"].unique()
        )
        raise ValueError(f"AREA_TO_VENDOR 매핑 실패 코드: {missing_codes}")

    # 해양 구분 시 협력사명 뒤에 '(해양)' 붙이기
    if "운반선_해양_구분" in df.columns:
        ocean_mask = (
            df["운반선_해양_구분"].astype(str).str.strip() == "해양"
        )
        df.loc[ocean_mask, "협력사"] = (
            df.loc[ocean_mask, "협력사"] + "(해양)"
        )

    return df


def outside_df2(year: int | None = None) -> pd.DataFrame:
    """
    outside_df 결과 중에서 '조회년도 데이터만' 별도로 추출.
    """
    y = year or dt.date.today().year
    df_all = outside_df(y)
    return _filter_year_only(df_all, y)



# =========================================================
# 5) 단독 실행 시: 조회년도 데이터 엑셀 저장
# =========================================================
if __name__ == "__main__":
    # 현재 연도와 날짜
    year = dt.date.today().year
    query_date = dt.date.today()

    try:
        # 데이터프레임 가져오기
        df_out = outside_df2(year)

        # -------------------------------------------------
        # 저장 디렉터리 설정
        #   - 기본 OUT_DIR (예: "./output")
        #   - 날짜별 서브 폴더 (yyyy-mm-dd)
        # -------------------------------------------------
        date_folder = query_date.strftime("%Y-%m-%d")  
        target_dir = OUT_DIR / date_folder

        # 폴더가 없으면 생성
        target_dir.mkdir(parents=True, exist_ok=True)

        # -------------------------------------------------
        # 파일명 및 전체 경로 생성
        # -------------------------------------------------
        date_suffix = query_date.strftime("%y%m%d")   
        file_name = f"{year}년도_사외_조립_계획_실적_data_{date_suffix}.xlsx"
        out_path = target_dir / file_name

        # 엑셀 저장
        df_out.to_excel(out_path, index=False)
        print(f"[OK] 조회년도 데이터 저장 완료: {out_path} ({len(df_out):,}건)")

        # MySQL 업로드 (조립_계획_실적_data)
        upload_bpa_data(df_out)

    except Exception as e:
        print("실행 실패:", e)
        raise
