from __future__ import annotations
"""
step_47_utils_train_table.py

역할 요약
-----------
협력사(벤더)별로 "실적_완료일 - 기준계획_완료일"을 타겟(lag_days)으로 하는
회귀 모델 학습용 테이블(X, y)을 만드는 유틸 함수 모듈.

주요 내용
---------
1) _weight_col(df)
   - 중량 컬럼명을 자동으로 선택하는 헬퍼
   - 우선순위: "고유_중량" > "중량_고유"

2) _build_vendor_table(df_all, vendor)
   - 한 협력사(vendor)에 대해 다음을 수행:
     - 완료일/착수일 컬럼을 date로 변환
     - lag_days = (실적일 - 계획일).days (클리핑: [-90, 180])
     - 착수 기반 피처:
         · start_lag = (실적_착수 - 기준계획_착수) 일수
         · proc_days = (실적_완료 - 실적_착수) 일수
     - 블록 기반 피처:
         · block_alpha = 블록명에서 첫 알파벳 → A=1, B=2, ..., Z=26 (없으면 0)
     - 구분 기반 피처:
         · is_mid   : "중조" 포함 여부 (0/1)
         · is_large : "대조" 포함 여부 (0/1)
     - 계획일 기반 피처:
         · plan_month (월), plan_dow (요일), plan_dom (일), plan_week (월요일 기준 주차)
     - weight : 중량(ton) 숫자 컬럼

   - 최종 반환:
       X     : (N, 10) float32 피처 행렬
       y     : (N,) float32 타겟(lag_days)
       feats : 피처 이름 리스트
       dates : pd.Series (계획일, 시계열 분할 등에 사용)
"""

from typing import List, Optional, Tuple

import numpy as np
import pandas as pd

from step_42_utils_calendar import _to_date, week_no_mon


def _weight_col(df: pd.DataFrame) -> str:
    """
    중량 컬럼명 선택 유틸.

    우선순위
    --------
    1) "고유_중량"
    2) "중량_고유"

    두 컬럼 모두 없으면 KeyError 를 발생시켜 학습 파이프라인에서
    조기에 문제를 발견할 수 있도록 합니다.
    """
    if "고유_중량" in df.columns:
        return "고유_중량"
    if "중량_고유" in df.columns:
        return "중량_고유"
    raise KeyError("중량 컬럼 누락 ('고유_중량' 또는 '중량_고유').")


def _build_vendor_table(
    df_all: pd.DataFrame,
    vendor: str,
) -> Optional[Tuple[np.ndarray, np.ndarray, List[str], pd.Series]]:
    """
    특정 협력사(vendor)에 대한 학습용 테이블(X, y) 생성.

    타겟
    ----
    lag_days = (실적_완료일 - 기준계획_완료일).days
               → -90 ~ 180 범위로 클리핑

    생성 피처
    --------
    1) 계획일 기반
       - plan_month : 계획월 (1~12)
       - plan_dow   : 계획일 요일 (월=0 ~ 일=6)
       - plan_dom   : 계획일 일(day-of-month)
       - plan_week  : 월요일 기준 주차 번호 (week_no_mon)

    2) 착수 기반
       - start_lag  : (실적_착수일 - 계획_착수일).days
       - proc_days  : (실적일 - 실적_착수일).days
         ※ 각 컬럼은 NaN 시 중앙값으로 대체 후 [-90, 180] 범위로 클리핑

    3) 블록/구분 기반
       - block_alpha : 블록명에서 첫 알파벳(A~Z)을 찾아 A=1, ..., Z=26, 없으면 0
       - is_mid      : "중조" 포함 여부 (1/0)
       - is_large    : "대조" 포함 여부 (1/0)

    4) 중량
       - weight      : 중량 톤 값 (숫자 변환 실패 시 0.0)

    반환값
    ------
    (X, y, feats, dates) or None

    - X     : np.ndarray, shape (N, len(feats)), dtype=float32
    - y     : np.ndarray, shape (N,), dtype=float32
    - feats : List[str]  (사용된 피처 이름 순서)
    - dates : pd.Series (계획일, 시계열 분할/로그용)

    ※ 필수 컬럼 누락/결측으로 인해 학습 가능한 행이 없으면 None 반환.
    """
    wcol = _weight_col(df_all)

    # 협력사 필터링
    df = df_all.copy()
    df["협력사"] = df["협력사"].astype(str).str.strip()
    df = df.loc[df["협력사"] == vendor].copy()

    # 완료일(계획/실적) 파싱
    df["계획일"] = pd.to_datetime(df["기준계획_완료"].apply(_to_date), errors="coerce")
    df["실적일"] = pd.to_datetime(df["실적_완료"].apply(_to_date), errors="coerce")

    # 착수일(없으면 NaT 유지 후 나중에 중앙값/0으로 처리)
    if "기준계획_착수" in df.columns:
        df["계획_착수일"] = pd.to_datetime(df["기준계획_착수"].apply(_to_date), errors="coerce")
    else:
        df["계획_착수일"] = pd.NaT

    if "실적_착수" in df.columns:
        df["실적_착수일"] = pd.to_datetime(df["실적_착수"].apply(_to_date), errors="coerce")
    else:
        df["실적_착수일"] = pd.NaT

    # 최소 조건: 완료 기준 데이터 + weight 있어야 학습 가능
    df = df.dropna(subset=["계획일", "실적일", wcol]).copy()
    if df.empty:
        return None

    # ────────────── 타겟: lag_days ──────────────
    df["lag_days"] = (df["실적일"] - df["계획일"]).dt.days.clip(-90, 180)

    # ────────────── 착수 기반 파생 피처 ──────────────
    # 1) start_lag : (실적_착수 - 기준계획_착수) → 착수 지연일
    df["start_lag"] = (df["실적_착수일"] - df["계획_착수일"]).dt.days

    # 2) proc_days : (실적_완료 - 실적_착수) → 실제 작업 기간
    df["proc_days"] = (df["실적일"] - df["실적_착수일"]).dt.days

    # NaN 처리 / 이상값 클리핑 (각 컬럼별 median 사용, 없으면 0.0)
    for col in ["start_lag", "proc_days"]:
        vals = df[col]
        if vals.notna().any():
            default = float(vals.median())
        else:
            default = 0.0
        df[col] = vals.fillna(default).clip(-90, 180).astype(float)

    # ────────────── 블록/구분 기반 파생 피처 ──────────────
    # 블록: 첫 번째 알파벳 → A=1, B=2, ..., Z=26, 알파벳 없으면 0
    if "블록" in df.columns:
        def _first_alpha_to_num(val):
            if pd.isna(val):
                return 0.0
            s = str(val).strip().upper()
            for ch in s:
                if "A" <= ch <= "Z":
                    return float(ord(ch) - ord("A") + 1)
            return 0.0

        df["block_alpha"] = df["블록"].apply(_first_alpha_to_num).astype(float)
    else:
        df["block_alpha"] = 0.0

    # 구분: "중조" / "대조" 여부를 one-hot으로 표현
    if "구분" in df.columns:
        g = df["구분"].astype(str)
        df["is_mid"] = g.str.contains("중조", na=False).astype(float)
        df["is_large"] = g.str.contains("대조", na=False).astype(float)
    else:
        df["is_mid"] = 0.0
        df["is_large"] = 0.0

    # ────────────── 기존 계획일 기반 피처 ──────────────
    df["plan_month"] = df["계획일"].dt.month
    df["plan_dow"]   = df["계획일"].dt.weekday      # 월=0 ~ 일=6
    df["plan_dom"]   = df["계획일"].dt.day          # day of month
    df["plan_week"]  = df["계획일"].apply(lambda d: week_no_mon(d, d.year))
    df["weight"]     = pd.to_numeric(df[wcol], errors="coerce").fillna(0.0)

    # 시간 순 정렬 (계획일 기준)
    df = df.sort_values("계획일").reset_index(drop=True)

    # 최종 피처 목록: 기존 + 착수 기반 2개 + 블록/구분 3개
    feats: List[str] = [
        "plan_month",   # 계획월
        "plan_dow",     # 계획 요일
        "plan_dom",     # 계획 일(day-of-month)
        "plan_week",    # 월요일 기준 주차
        "start_lag",    # (실적_착수 - 기준계획_착수)
        "proc_days",    # (실적_완료 - 실적_착수)
        "block_alpha",  # 블록 첫 알파벳 번호
        "is_mid",       # 구분: 중조 여부
        "is_large",     # 구분: 대조 여부
        "weight",       # 중량
    ]

    X = df[feats].values.astype(np.float32)
    y = df["lag_days"].values.astype(np.float32)
    dates = pd.to_datetime(df["계획일"])

    return X, y, feats, dates
