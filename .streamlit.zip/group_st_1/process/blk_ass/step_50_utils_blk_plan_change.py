# -*- coding: utf-8 -*-
"""
step_50_utils_blk_plan_chaege.py

역할 요약
---------
1. 지정된 엑셀 파일에서 "블록 계획 및 실적" 데이터를 로드합니다.
2. W/C 컬럼을 AREA 코드로 보고, step_2_BPA_Data.AREA_TO_VENDOR을 활용해서
   협력사명을 매핑하여 '협력사' 컬럼을 추가합니다.
3. 실적_완료 컬럼의 빈칸을 예측일로 채운 두 가지 버전을 만듭니다.
   - ML 버전:  예측일 컬럼명 = PRED_COL_ML (기본: '예측_실적일')
   - DL 버전:  예측일 컬럼명 = PRED_COL_DL (기본: '예측_실적일_DL')
4. 완성된 DataFrame 을 MySQL(구조조달1_db)에 업로드합니다.
   - table: 조립_블록_변경_점검_ML
   - table: 조립_블록_변경_점검_DL
   - 테이블이 없으면 자동 생성 (pandas.to_sql)
5. 엑셀 저장
   - 각 버전(ML/DL)마다 **파일 1개**만 생성
   - 파일명:
       조립_블록_변경_점검_ML_YYMMDD.xlsx
       조립_블록_변경_점검_DL_YYMMDD.xlsx
     (YYMMDD = query_date 기준)
   - 시트 구성:
       시트 이름 = "monthly"
       내용 = 조회년 ~ 조회년+1년 기간의 행만 모아서 한 시트에 저장
       (월별 구간 필터는 날짜로 하고, 형식은 step_3의 monthly처럼
        "월 단위 기준 데이터"를 한 시트에 모으는 개념)

사용 예시
---------
(1) 파일 경로만 수정해서 단독 실행:

    python step_50_utils_blk_plan_chaege.py ^
        --excel "D:/some_folder/블록_계획_실적.xlsx" ^
        --query_date 2025-11-30

    → 조회년 = 2025
      → 2025-01-01 ~ 2026-12-31 데이터만 필터링 후
         ML/DL 각각 1개 파일에 monthly 시트로 저장

(2) 다른 모듈에서 함수 호출:

    from step_50_utils_blk_plan_chaege import run_blk_plan_change_upload

    run_blk_plan_change_upload(
        excel_path=r"D:/some_folder/블록_계획_실적.xlsx",
        query_date_str="2025-11-30",
    )
"""

from __future__ import annotations

import argparse
import datetime as dt
from pathlib import Path
from typing import Optional

import pandas as pd
import pymysql  # to_sql 드라이버
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine

# AREA_TO_VENDOR, _normalize_area 재사용
from step_2_BPA_Data import AREA_TO_VENDOR, _normalize_area

# step_45에서 사용하는 것과 동일한 폴더 규칙
from step_41_utils_save_to_folder import get_excel_save_dir


# =========================================================
# 0) 사용자 설정: 엑셀 파일 경로 & 예측 컬럼명
# =========================================================

# 기본 엑셀 경로 (단독 실행 시 이 값만 수정해서 사용)
DEFAULT_EXCEL_PATH = Path(r"D:/blk_plan/블록_계획_실적.xlsx")

# 실적 예측일 컬럼명 (step_16 / step_25 에서 이 이름으로 생성했다고 가정)
PRED_COL_ML = "예측_실적일"       # ML 예측 실적일 컬럼
PRED_COL_DL = "예측_실적일_DL"    # DL 예측 실적일 컬럼


# =========================================================
# 1) MySQL 엔진 (구조조달1_db)
# =========================================================

MYSQL_HOST = "60.100.164.182"
MYSQL_USER = "root"
MYSQL_PASSWORD = "250404"
MYSQL_DB = "구조조달1_db"
MYSQL_PORT = 3306


def _make_engine() -> Engine:
    """
    구조조달1_db용 MySQL 엔진 생성.

    - 드라이버: pymysql
    - pool_pre_ping=True : 끊어진 커넥션 자동 복구
    """
    conn_str = (
        f"mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}"
        f"@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}?charset=utf8mb4"
    )
    return create_engine(conn_str, pool_pre_ping=True)


# =========================================================
# 2) 엑셀 로드 + 협력사 매핑
# =========================================================

def load_blk_plan_excel(excel_path: Path) -> pd.DataFrame:
    """
    블록 계획/실적 엑셀을 DataFrame으로 로드.

    - 필수 컬럼 가정:
        · 'W/C' : AREA 코드
        · '기준계획_완료', '실적_완료' 등 (있으면 사용)
    """
    if not excel_path.is_file():
        raise FileNotFoundError(f"엑셀 파일을 찾을 수 없습니다: {excel_path}")

    print(f"[INFO] 엑셀 로딩: {excel_path}")
    df = pd.read_excel(excel_path)
    print(f"[INFO] 로딩 완료: {len(df):,}건")

    if "W/C" not in df.columns:
        raise KeyError("엑셀에 'W/C' 컬럼이 없습니다. AREA 코드가 있는 컬럼명을 확인해주세요.")

    # AREA 코드 정규화 (공백 제거 + 대문자) 후 매핑
    df = df.copy()
    df["W/C_norm"] = _normalize_area(df["W/C"])
    df = df[df["W/C_norm"].isin(AREA_TO_VENDOR.keys())].copy()

    # 협력사명 매핑
    df["협력사"] = df["W/C_norm"].map(AREA_TO_VENDOR)

    # 매핑 실패 있을 경우 명시적으로 에러
    if df["협력사"].isna().any():
        missing_codes = sorted(df.loc[df["협력사"].isna(), "W/C_norm"].unique())
        raise ValueError(f"AREA_TO_VENDOR 매핑 실패 코드(W/C): {missing_codes}")

    # 보조 컬럼 제거
    df = df.drop(columns=["W/C_norm"])

    return df


# =========================================================
# 3) 실적_완료 빈칸 → 예측일 채우기
# =========================================================

def _fill_completion_with_prediction(
    df: pd.DataFrame,
    pred_col: str,
) -> pd.DataFrame:
    """
    실적_완료 컬럼의 NaN(또는 빈값)을 pred_col 예측일로 채워주는 유틸.

    Parameters
    ----------
    df : pd.DataFrame
        원본 데이터 (최소 '실적_완료' 컬럼이 있으면 좋음)
    pred_col : str
        예측일이 들어있는 컬럼 이름
        예: '예측_실적일', '예측_실적일_DL'

    Returns
    -------
    pd.DataFrame
        실적_완료가 예측일로 채워진 DataFrame (날짜는 YYYY-MM-DD 문자열)
    """
    df = df.copy()

    # 실적_완료 컬럼이 없으면 새로 생성 (전부 NaT)
    if "실적_완료" not in df.columns:
        df["실적_완료"] = pd.NaT

    if pred_col not in df.columns:
        print(f"[WARN] '{pred_col}' 컬럼이 없어 실적_완료 예측일 채우기를 생략합니다.")
        # 그래도 최소한 날짜 컬럼을 문자열로 정리
        df["실적_완료"] = pd.to_datetime(df["실적_완료"], errors="coerce").dt.strftime("%Y-%m-%d")
        return df

    # 날짜 변환
    act = pd.to_datetime(df["실적_완료"], errors="coerce")
    pred = pd.to_datetime(df[pred_col], errors="coerce")

    # 기존 실적이 있는 경우 그대로 두고, 없는 경우 예측일로 채움
    filled = act.where(~act.isna(), pred)

    # 문자열(YYYY-MM-DD)로 통일
    df["실적_완료"] = filled.dt.strftime("%Y-%m-%d")

    return df


# =========================================================
# 4) MySQL 업로드 유틸
# =========================================================

def upload_blk_change_df(
    df: pd.DataFrame,
    table_name: str,
) -> None:
    """
    DataFrame을 MySQL(구조조달1_db)에 업로드.

    - if_exists='append' 이므로:
      · 테이블이 없으면 자동 생성
      · 있으면 이어서 INSERT
    """
    if df.empty:
        print(f"[WARN] 업로드할 데이터가 없습니다. (table={table_name})")
        return

    engine = _make_engine()
    try:
        print(f"[INFO] MySQL 업로드 시작: table={table_name}, rows={len(df):,}")
        with engine.begin() as conn:
            df.to_sql(
                name=table_name,
                con=conn,
                if_exists="append",
                index=False,
                method="multi",
            )
        print(f"[OK] MySQL 업로드 완료: table={table_name}, rows={len(df):,}")
    finally:
        engine.dispose()


# =========================================================
# 5) 엑셀 저장 유틸 (monthly 한 시트, 조회년+내년까지)
# =========================================================

def save_blk_change_excel_monthly_sheet(
    df: pd.DataFrame,
    tag: str,
    query_date: dt.date,
    base_year: int,
    date_col_candidate: Optional[str] = None,
) -> None:
    """
    조립_블록_변경_점검_{tag}_YYMMDD.xlsx 파일 하나에
    'monthly' 시트를 만들어 저장.

    - 대상 기간: base_year ~ base_year+1 (1월1일 ~ 12월31일)
    - 월별 개념은 "월 단위로 필터링된 전체 행을 한 시트에 모으는 것"으로 처리

    Parameters
    ----------
    df : pd.DataFrame
        저장할 데이터 전체
    tag : str
        'ML' 또는 'DL' 등 파일명에 들어갈 태그
    query_date : datetime.date
        생성 기준일 (폴더 및 파일명 suffix에 사용)
    base_year : int
        "조회년". [base_year ~ base_year+1] 기간만 저장 대상
    date_col_candidate : str | None
        월/기간 판단 기준으로 우선 사용할 날짜 컬럼명.
        None 이면 아래 우선순위로 자동 선택:
        '기준계획_완료' → '계획_완료' → '실적_완료'
    """
    if df.empty:
        print(f"[WARN] 엑셀로 저장할 데이터가 없습니다. (tag={tag})")
        return

    df = df.copy()

    # 1) 기준 날짜 컬럼 선택
    priority_cols = []
    if date_col_candidate:
        priority_cols.append(date_col_candidate)
    priority_cols.extend(["기준계획_완료", "계획_완료", "실적_완료"])

    base_col = None
    date_series = None
    for col in priority_cols:
        if col in df.columns:
            s = pd.to_datetime(df[col], errors="coerce")
            if s.notna().any():
                base_col = col
                date_series = s
                break

    if base_col is None or date_series is None:
        print(f"[WARN] 사용할 수 있는 날짜 컬럼이 없어 기간 필터 없이 전체를 저장합니다. (tag={tag})")
        df_period = df
    else:
        print(f"[INFO] monthly 시트 기간 기준 날짜 컬럼: {base_col}")
        # 2) 기간 필터링: base_year ~ base_year+1
        start_date = dt.date(base_year, 1, 1)
        end_date = dt.date(base_year + 1, 12, 31)

        mask = (date_series >= pd.Timestamp(start_date)) & (date_series <= pd.Timestamp(end_date))
        df_period = df[mask].copy()

        if df_period.empty:
            print(
                f"[WARN] {start_date} ~ {end_date} 기간에 해당하는 데이터가 없어 "
                f"엑셀 저장을 건너뜁니다. (tag={tag})"
            )
            return

    # 3) 저장 폴더 및 파일명
    excel_dir = get_excel_save_dir(query_date)
    excel_dir.mkdir(parents=True, exist_ok=True)

    date_suffix = query_date.strftime("%y%m%d")  # 예: 2025-11-30 → "251130"
    filename = f"조립_블록_변경_점검_{tag}_{date_suffix}.xlsx"
    out_path = excel_dir / filename

    # 기존 파일 삭제 후 새로 저장
    try:
        Path(out_path).unlink(missing_ok=True)
    except Exception as e:
        print(f"[LOG] 기존 엑셀 삭제 실패({out_path}): {e}")

    # 4) monthly 시트 한 개로 저장
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        df_period.to_excel(writer, sheet_name="monthly", index=False)

    print(f"[OK] 엑셀 저장(월별 한 시트 monthly): {out_path} (rows={len(df_period):,})")


# =========================================================
# 6) 메인 로직 (엑셀 → 협력사 매핑 → ML/DL 버전 → DB 업로드 + 엑셀 저장)
# =========================================================

def run_blk_plan_change_upload(
    excel_path: str | Path,
    query_date_str: Optional[str] = None,
) -> None:
    """
    블록 계획/실적 엑셀을 읽어서
    - 협력사 매핑
    - ML/DL 예측일로 실적_완료 채우기
    - MySQL 업로드
    - 엑셀 저장 (monthly 시트 1개, 조회년~내년 기간만)
    까지 한 번에 수행.

    Parameters
    ----------
    excel_path : str | Path
        블록 계획/실적 엑셀 경로
    query_date_str : str | None
        조회일 (YYYY-MM-DD).
        None 이면 오늘 날짜 사용.
        → base_year = 조회일.year 로 간주하여
          [base_year ~ base_year+1] 기간만 monthly 시트에 저장.
    """
    excel_path = Path(excel_path)
    if query_date_str:
        query_date = dt.datetime.strptime(query_date_str, "%Y-%m-%d").date()
    else:
        query_date = dt.date.today()
    base_year = query_date.year

    print("====================================================")
    print(f"[INFO] 조회일(query_date) = {query_date} → 조회년(base_year) = {base_year}")
    print("====================================================")

    print("====================================================")
    print(f"[STEP] 1. 엑셀 로드 및 협력사 매핑")
    print("====================================================")
    base_df = load_blk_plan_excel(excel_path)

    # ----------------------------------------------------
    # ML 버전 (조립_블록_변경_점검_ML용)
    # ----------------------------------------------------
    print("====================================================")
    print(f"[STEP] 2. ML 예측일로 실적_완료 채우기 (컬럼: {PRED_COL_ML})")
    print("====================================================")
    df_ml = _fill_completion_with_prediction(base_df, PRED_COL_ML)

    print("====================================================")
    print("[STEP] 3. MySQL 업로드 (조립_블록_변경_점검_ML)")
    print("====================================================")
    upload_blk_change_df(df_ml, "조립_블록_변경_점검_ML")

    print("====================================================")
    print("[STEP] 4. 엑셀 저장 (조립_블록_변경_점검_ML_YYMMDD.xlsx, 시트: monthly)")
    print("====================================================")
    save_blk_change_excel_monthly_sheet(df_ml, "ML", query_date, base_year)

    # ----------------------------------------------------
    # DL 버전 (조립_블록_변경_점검_DL용)
    # ----------------------------------------------------
    print("====================================================")
    print(f"[STEP] 5. DL 예측일로 실적_완료 채우기 (컬럼: {PRED_COL_DL})")
    print("====================================================")
    df_dl = _fill_completion_with_prediction(base_df, PRED_COL_DL)

    print("====================================================")
    print("[STEP] 6. MySQL 업로드 (조립_블록_변경_점검_DL)")
    print("====================================================")
    upload_blk_change_df(df_dl, "조립_블록_변경_점검_DL")

    print("====================================================")
    print("[STEP] 7. 엑셀 저장 (조립_블록_변경_점검_DL_YYMMDD.xlsx, 시트: monthly)")
    print("====================================================")
    save_blk_change_excel_monthly_sheet(df_dl, "DL", query_date, base_year)

    print("====================================================")
    print("[DONE] step_50_utils_blk_plan_chaege 전체 처리 완료")
    print("====================================================")


# =========================================================
# 7) 단독 실행 진입점
# =========================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="블록 계획/실적 변경 점검(ML/DL) 업로드 & monthly 시트 엑셀 저장 유틸"
    )
    parser.add_argument(
        "--excel",
        type=str,
        default=str(DEFAULT_EXCEL_PATH),
        help="블록 계획/실적 엑셀 경로 (기본: DEFAULT_EXCEL_PATH 상수)",
    )
    parser.add_argument(
        "--query_date",
        type=str,
        default=None,
        help="조회일 (YYYY-MM-DD, 기본: 오늘). "
             "조회년 ~ 조회년+1년 기간만 monthly 시트에 저장.",
    )

    args = parser.parse_args()

    run_blk_plan_change_upload(
        excel_path=args.excel,
        query_date_str=args.query_date,
    )