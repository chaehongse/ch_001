from __future__ import annotations
"""
step_24_best_model_select_DL.py (DB Only)

협력사별 최종 best engine 선정:
- val_loss가 있으면: val_loss 최소 우선
- val_loss가 전부 NaN이면: RMSE → MAE → R2
- 동률이면 최신 timestamp

[출력]
- OUT_DIR / best_model_by_vendor_dl.json
- OUT_DIR / logs_dl / {year}_best_model_dl_YYYYMMDD.csv
  (year는 강제 year 지정 시 그 year, 미지정이면 현재연도 사용)
"""

import argparse
import datetime as dt
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import pymysql
from sqlalchemy import create_engine, text

pymysql.install_as_MySQLdb()

from step_0_MSF import OUT_DIR

# ─────────────────────────────────────────────
# DB 설정
# ─────────────────────────────────────────────
DB_HOST = "60.100.164.182"
DB_PORT = 3306
DB_USER = "root"
DB_PASS = "250404"
DB_NAME = "구조조달1_db"
DB_URL = (
    f"mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    "?charset=utf8mb4"
)


# ─────────────────────────────────────────────
# Utils
# ─────────────────────────────────────────────
def _norm_str(x) -> str:
    return str(x).replace(" ", " ").strip() if x is not None else ""


# ─────────────────────────────────────────────
# 1) DB 로그 로드
# ─────────────────────────────────────────────
def load_logs_from_db() -> pd.DataFrame:
    try:
        engine = create_engine(DB_URL, pool_pre_ping=True, future=True)
        with engine.connect() as conn:
            df = pd.read_sql(text("SELECT * FROM 예측_모델_log_dl"), conn)
        print(f"[DB] 예측_모델_log_dl 로드 완료: {len(df)} rows")
        return df
    except Exception as e:
        print(f"[DB-ERROR] 예측_모델_log_dl 로드 실패: {e}")
        return pd.DataFrame()


# ─────────────────────────────────────────────
# 2) CHOSEN 필터
# ─────────────────────────────────────────────
def filter_chosen(df: pd.DataFrame) -> pd.DataFrame:
    if "tag" not in df.columns:
        print("[WARN] tag 컬럼 없음 → 전체 데이터 사용")
        return df

    chosen = df[df["tag"].astype(str).str.upper() == "CHOSEN"].copy()
    if chosen.empty:
        print("[WARN] CHOSEN 행 없음 → 전체 데이터 사용")
        return df

    print(f"[INFO] CHOSEN 필터 적용: {len(chosen)} rows")
    return chosen


# ─────────────────────────────────────────────
# 3) year 필터 (협력사별 최신 year 자동 선택)
# ─────────────────────────────────────────────
def filter_year_per_vendor_latest(df: pd.DataFrame, year: Optional[int]) -> Tuple[pd.DataFrame, Optional[int]]:
    """
    - year 지정 시: 해당 year만 사용
    - year 미지정(None) 시: 협력사별 최신 year 자동 선택

    반환: (df_filtered, selected_year)
      - selected_year는 강제 year 지정 시 그 값을 반환
      - 미지정이면 None (협력사별 year가 다를 수 있음)
    """
    if "year" not in df.columns:
        print("[WARN] year 컬럼 없음 → year 필터 스킵")
        return df, year
    if "협력사" not in df.columns:
        print("[WARN] 협력사 컬럼 없음 → year 필터 스킵")
        return df, year

    df = df.copy()
    df["협력사"] = df["협력사"].astype(str).map(_norm_str)
    df["year"] = pd.to_numeric(df["year"], errors="coerce").astype("Int64")
    df = df.dropna(subset=["year"])
    if df.empty:
        print("[WARN] year 파싱 후 데이터 없음 → year 필터 스킵")
        return df, year

    if year is not None:
        sub = df[df["year"] == year].copy()
        if sub.empty:
            print(f"[WARN] year={year} 데이터 없음 → year 필터 무시(전체 사용)")
            return df, year
        print(f"[INFO] year 강제 지정: {year} (rows={len(sub)})")
        return sub, year

    # 협력사별 최신 year 자동 선택
    idx = df.groupby("협력사")["year"].transform("max") == df["year"]
    sub = df[idx].copy()

    vendors = sub["협력사"].nunique()
    year_dist = sub.groupby("협력사")["year"].max().value_counts().to_dict()
    print(f"[INFO] year 미지정 → 협력사별 최신 year 자동 선택: vendors={vendors}, year_dist={year_dist}")
    return sub, None


# ─────────────────────────────────────────────
# 4) 최근 N일 필터 (timestamp 기준)
# ─────────────────────────────────────────────
def filter_recent(df: pd.DataFrame, days: int) -> pd.DataFrame:
    if "timestamp" not in df.columns:
        print("[INFO] timestamp 없음 → 최근 N일 필터 스킵")
        return df

    df = df.copy()
    df["timestamp_dt"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df = df.dropna(subset=["timestamp_dt"])
    if df.empty:
        print("[WARN] timestamp 파싱 후 데이터 없음 → 기간 필터 미적용")
        return df

    cutoff = dt.datetime.now() - dt.timedelta(days=days)
    recent = df[df["timestamp_dt"] >= cutoff]
    if recent.empty:
        print(f"[WARN] 최근 {days}일 이내 로그 없음 → 기간 필터 미적용")
        return df

    print(f"[INFO] 최근 {days}일 필터 적용: {len(recent)} rows")
    return recent


# ─────────────────────────────────────────────
# 5) 스코어링 컬럼 생성
# ─────────────────────────────────────────────
def add_score_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    DL 선정 우선순위:
      1) val_loss가 있으면 val_loss 최소
      2) 없으면 RMSE → MAE → R2
    타이브레이크: 최신 timestamp

    NaN 대비 filled 컬럼 생성
    """
    df = df.copy()

    for col in ["val_loss", "RMSE_valid", "MAE_valid", "R2_valid"]:
        if col not in df.columns:
            df[col] = np.nan
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # val_loss: 작을수록 좋음
    max_vl = df["val_loss"].dropna().max()
    if pd.isna(max_vl):
        max_vl = 1e9
    df["val_loss_f"] = df["val_loss"].fillna(max_vl)

    # RMSE/MAE: 작을수록 좋음
    max_rmse = df["RMSE_valid"].dropna().max()
    if pd.isna(max_rmse):
        max_rmse = 1e9
    df["RMSE_f"] = df["RMSE_valid"].fillna(max_rmse)

    max_mae = df["MAE_valid"].dropna().max()
    if pd.isna(max_mae):
        max_mae = 1e9
    df["MAE_f"] = df["MAE_valid"].fillna(max_mae)

    # R2: 클수록 좋음
    df["R2_f"] = df["R2_valid"].fillna(-1e9)

    # timestamp tie-break
    if "timestamp_dt" not in df.columns:
        if "timestamp" in df.columns:
            df["timestamp_dt"] = pd.to_datetime(df["timestamp"], errors="coerce")
        else:
            df["timestamp_dt"] = pd.NaT
    df["ts_f"] = df["timestamp_dt"].fillna(pd.Timestamp("1970-01-01"))

    # val_loss 존재 여부
    df["has_vl"] = df["val_loss"].notna().astype(int)

    return df


def pick_best_row_dl(sub: pd.DataFrame) -> Tuple[pd.Series, str]:
    """
    단일 그룹(sub)에서 DL 최고 성능 1건 선택

    규칙:
      - val_loss 있는 후보가 있으면:
          val_loss asc → RMSE asc → MAE asc → R2 desc → 최신 ts
      - val_loss 전부 NaN이면:
          RMSE asc → MAE asc → R2 desc → 최신 ts
    """
    sub = add_score_columns(sub)

    has_any_vl = bool(sub["has_vl"].sum() > 0)
    if has_any_vl:
        sub2 = sub[sub["has_vl"] == 1].copy()
        best = sub2.sort_values(
            by=["val_loss_f", "RMSE_f", "MAE_f", "R2_f", "ts_f"],
            ascending=[True, True, True, False, False],
        ).iloc[0]
        return best, "val_loss 우선"
    else:
        best = sub.sort_values(
            by=["RMSE_f", "MAE_f", "R2_f", "ts_f"],
            ascending=[True, True, False, False],
        ).iloc[0]
        return best, "RMSE/MAE 우선(val_loss 없음)"


# ─────────────────────────────────────────────
# 6) (협력사, engine)별 최고성능 1건 유지
# ─────────────────────────────────────────────
def keep_best_per_vendor_engine(df: pd.DataFrame) -> pd.DataFrame:
    if "협력사" not in df.columns or "engine" not in df.columns:
        print("[ERROR] '협력사' 또는 'engine' 컬럼 없음")
        return df

    df = df.copy()
    df["협력사"] = df["협력사"].astype(str).map(_norm_str)
    df["engine"] = df["engine"].astype(str).str.strip().str.lower()
    df = df[(df["협력사"] != "") & (df["engine"] != "")]
    if df.empty:
        print("[WARN] 협력사/engine 유효행 없음")
        return df

    rows = []
    for (vendor, engine), sub in df.groupby(["협력사", "engine"]):
        best_row, _ = pick_best_row_dl(sub)
        rows.append(best_row)

    out = pd.DataFrame(rows).reset_index(drop=True)
    print(f"[INFO] 협력사+engine별 최고성능 로그만 유지: {len(out)} rows")
    return out


# ─────────────────────────────────────────────
# 7) 협력사별 best engine 선정
# ─────────────────────────────────────────────
def select_best_engine_per_vendor(df: pd.DataFrame) -> Tuple[Dict[str, str], pd.DataFrame]:
    if df.empty:
        return {}, pd.DataFrame()

    df = df.copy()
    df["협력사"] = df["협력사"].astype(str).map(_norm_str)
    df["engine"] = df["engine"].astype(str).str.strip().str.lower()
    df = df[(df["협력사"] != "") & (df["engine"] != "")]
    if df.empty:
        print("[WARN] 협력사/engine 정보 유효한 행 없음")
        return {}, pd.DataFrame()

    best_map: Dict[str, str] = {}
    best_rows: List[pd.Series] = []

    for vendor, sub in df.groupby("협력사"):
        best, rule = pick_best_row_dl(sub)
        engine = str(best["engine"]).strip().lower()
        best_map[vendor] = engine
        best_rows.append(best)

        print(
            f"[BEST] 협력사={vendor} / engine={engine} "
            f"(rule={rule}, val_loss={best.get('val_loss')}, RMSE={best.get('RMSE_valid')}, "
            f"MAE={best.get('MAE_valid')}, R2={best.get('R2_valid')})"
        )

    best_df = pd.DataFrame(best_rows).reset_index(drop=True) if best_rows else pd.DataFrame()
    return best_map, best_df


# ─────────────────────────────────────────────
# 8) JSON 저장
# ─────────────────────────────────────────────
def save_best_json(best_map: Dict[str, str]) -> Path:
    out_path = OUT_DIR / "best_model_by_vendor_dl.json"
    ordered = {k: best_map[k] for k in sorted(best_map.keys())}
    with open(out_path, "w", encoding="utf-8") as fp:
        json.dump(ordered, fp, ensure_ascii=False, indent=2)
    print(f"[SAVE] 협력사별 best DL 모델 JSON 저장: {out_path} (vendors={len(ordered)})")
    return out_path


# ─────────────────────────────────────────────
# 9) best 모델 로그 CSV 저장
# ─────────────────────────────────────────────
def save_best_log_csv(best_df: pd.DataFrame, year_for_filename: Optional[int]) -> Optional[Path]:
    if best_df is None or best_df.empty:
        print("[WARN] best_df 비어있음 → CSV 저장 스킵")
        return None

    logs_dir = OUT_DIR / "logs_dl"
    logs_dir.mkdir(parents=True, exist_ok=True)

    today = dt.date.today()
    y = year_for_filename if year_for_filename is not None else today.year
    fname = f"{y}_best_model_dl_{today.strftime('%Y%m%d')}.csv"

    out_path = logs_dir / fname

    drop_cols = ["val_loss_f", "RMSE_f", "MAE_f", "R2_f", "ts_f", "has_vl", "timestamp_dt"]
    best_df_to_save = best_df.drop(columns=[c for c in drop_cols if c in best_df.columns], errors="ignore")
    best_df_to_save.to_csv(out_path, index=False, encoding="utf-8-sig")

    print(f"[SAVE] best DL 모델 로그 CSV 저장: {out_path} (rows={len(best_df_to_save)})")
    return out_path


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
def main(year: Optional[int] = None, recent_days: int = 30):
    print(" ==== DL Best Model Selection (DB Only) ==== ")
    print(f"[CONFIG] recent_days={recent_days}, year={year}")

    df = load_logs_from_db()
    if df.empty:
        print("[ABORT] DB 로그 없음 → 종료")
        return

    df = filter_chosen(df)

    # 협력사별 최신 year 자동 선택
    df_year, selected_year = filter_year_per_vendor_latest(df, year)

    if recent_days > 0:
        df_year = filter_recent(df_year, recent_days)

    if df_year.empty:
        print("[ABORT] 필터링 후 로그 없음 → 종료")
        return

    # (협력사, engine)별 최고성능 1건
    df_best_ve = keep_best_per_vendor_engine(df_year)
    if df_best_ve.empty:
        print("[ABORT] 협력사+engine 최고성능 필터 후 로그 없음 → 종료")
        return

    # 협력사별 최종 best engine
    best_map, best_df = select_best_engine_per_vendor(df_best_ve)
    if not best_map:
        print("[ABORT] best DL 모델 없음 → 종료")
        return

    save_best_json(best_map)

    # 파일명 year: 강제 year면 그 year, 미지정이면 현재연도(협력사별 year가 다를 수 있음)
    year_for_filename = selected_year if year is not None else None
    save_best_log_csv(best_df, year_for_filename)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--year", type=int, default=None, help="강제 year (미지정 시 협력사별 최신 year 자동 선택)")
    parser.add_argument("--recent_days", type=int, default=30, help="최근 N일 이내 로그만 사용 (0 이하이면 미적용)")
    args = parser.parse_args()
    main(args.year, args.recent_days)