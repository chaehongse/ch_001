from __future__ import annotations
"""
step_15_best_model_select_ML.py (DB Only)


[선정 규칙]
1) (협력사, engine)별 "최고 성능 1건" 유지
   - R2_valid > r2_threshold 후보가 있으면: R2 desc → RMSE asc → MAE asc → 최신 timestamp
   - 없으면: RMSE asc → MAE asc → R2 desc → 최신 timestamp
2) 협력사별 최적 engine 1개 선정 (위 규칙 동일)

[출력]
- OUT_DIR / best_model_by_vendor_ML.json
- OUT_DIR / logs / {year}_best_model_ML_YYYYMMDD.csv
"""

import argparse
import datetime as dt
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import pymysql
from sqlalchemy import create_engine, text

pymysql.install_as_MySQLdb()

from step_0_MSF import OUT_DIR

# ─────────────────────────────────────────────
# DB 연결 정보
# ─────────────────────────────────────────────
DB_HOST = "60.100.164.182"
DB_PORT = 3306
DB_USER = "root"
DB_PASS = "250404"
DB_NAME = "구조조달1_db"
DB_URL = (
    f"mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    "?charset=utf8mb4"
)


# ─────────────────────────────────────────────
# Utils
# ─────────────────────────────────────────────
def _norm_str(x) -> str:
    return str(x).replace(" ", " ").strip() if x is not None else ""


# ─────────────────────────────────────────────
# 1) DB 로그 로딩
# ─────────────────────────────────────────────
def load_logs_from_db() -> pd.DataFrame:
    try:
        engine = create_engine(DB_URL, pool_pre_ping=True, future=True)
        with engine.connect() as conn:
            df = pd.read_sql(text("SELECT * FROM 예측_모델_log"), conn)
        print(f"[DB] 예측_모델_log 로드 완료: {len(df)} rows")
        return df
    except Exception as e:
        print(f"[DB-ERROR] 로그 로딩 실패: {e}")
        return pd.DataFrame()


# ─────────────────────────────────────────────
# 2) CHOSEN 필터
# ─────────────────────────────────────────────
def filter_chosen(df: pd.DataFrame) -> pd.DataFrame:
    if "tag" not in df.columns:
        print("[WARN] tag 컬럼 없음 → 전체 데이터 사용")
        return df
    chosen = df[df["tag"].astype(str).str.upper() == "CHOSEN"].copy()
    if chosen.empty:
        print("[WARN] CHOSEN 행 없음 → 전체 데이터 사용")
        return df
    print(f"[INFO] CHOSEN 필터 적용: {len(chosen)} rows")
    return chosen


# ─────────────────────────────────────────────
# 3) year 필터 (협력사별 최신 year 자동 선택)
# ─────────────────────────────────────────────
def filter_year_per_vendor_latest(df: pd.DataFrame, year: Optional[int]) -> Tuple[pd.DataFrame, Optional[int]]:
    """
    - year 지정 시: 해당 year만 사용
    - year 미지정(None) 시: 협력사별 최신 year 자동 선택

    반환값 (df_filtered, selected_year)
    - selected_year는 강제 year 지정 시 그 값을 반환, 미지정이면 None (협력사별로 다를 수 있으므로)
    """
    if "year" not in df.columns:
        print("[WARN] year 컬럼 없음 → year 필터 스킵")
        return df, year

    if "협력사" not in df.columns:
        print("[WARN] 협력사 컬럼 없음 → year 필터 스킵")
        return df, year

    df = df.copy()
    df["협력사"] = df["협력사"].astype(str).map(_norm_str)
    df["year"] = pd.to_numeric(df["year"], errors="coerce").astype("Int64")
    df = df.dropna(subset=["year"])
    if df.empty:
        print("[WARN] year 파싱 후 데이터 없음 → year 필터 스킵")
        return df, year

    if year is not None:
        sub = df[df["year"] == year].copy()
        if sub.empty:
            print(f"[WARN] year={year} 데이터 없음 → year 필터 무시(전체 사용)")
            return df, year
        print(f"[INFO] year 강제 지정: {year} (rows={len(sub)})")
        return sub, year

    # 협력사별 최신 year 자동 선택
    idx = df.groupby("협력사")["year"].transform("max") == df["year"]
    sub = df[idx].copy()

    # 같은 협력사에 year 최신이 여러 행이면 그대로 두고, 다음 단계에서 성능으로 정리
    vendors = sub["협력사"].nunique()
    years_info = sub.groupby("협력사")["year"].max().value_counts().to_dict()
    print(f"[INFO] year 미지정 → 협력사별 최신 year 자동 선택: vendors={vendors}, year_dist={years_info}")
    return sub, None


# ─────────────────────────────────────────────
# 4) 최근 N일 필터 (timestamp 기준)
# ─────────────────────────────────────────────
def filter_recent(df: pd.DataFrame, days: int) -> pd.DataFrame:
    if "timestamp" not in df.columns:
        print("[INFO] timestamp 없음 → 최근 N일 필터 스킵")
        return df

    df = df.copy()
    df["timestamp_dt"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df = df.dropna(subset=["timestamp_dt"])
    if df.empty:
        print("[WARN] timestamp 파싱 후 데이터 없음 → 기간 필터 미적용")
        return df

    cutoff = dt.datetime.now() - dt.timedelta(days=days)
    recent = df[df["timestamp_dt"] >= cutoff]
    if recent.empty:
        print(f"[WARN] 최근 {days}일 이내 로그 없음 → 기간 필터 미적용")
        return df

    print(f"[INFO] 최근 {days}일 필터 적용: {len(recent)} rows")
    return recent


# ─────────────────────────────────────────────
# 5) 스코어링 컬럼 생성
# ─────────────────────────────────────────────
def add_score_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    for col in ["R2_valid", "RMSE_valid", "MAE_valid"]:
        if col not in df.columns:
            df[col] = np.nan
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df["R2_valid_filled"] = df["R2_valid"].fillna(-1e9)

    max_rmse = df["RMSE_valid"].dropna().max()
    if pd.isna(max_rmse):
        max_rmse = 1e9
    df["RMSE_valid_filled"] = df["RMSE_valid"].fillna(max_rmse)

    max_mae = df["MAE_valid"].dropna().max()
    if pd.isna(max_mae):
        max_mae = 1e9
    df["MAE_valid_filled"] = df["MAE_valid"].fillna(max_mae)

    # timestamp tie-break
    if "timestamp_dt" not in df.columns:
        if "timestamp" in df.columns:
            df["timestamp_dt"] = pd.to_datetime(df["timestamp"], errors="coerce")
        else:
            df["timestamp_dt"] = pd.NaT
    df["ts_filled"] = df["timestamp_dt"].fillna(pd.Timestamp("1970-01-01"))

    return df


def _pick_best_row_by_rule(sub: pd.DataFrame, r2_threshold: float) -> Tuple[pd.Series, str]:
    """
    sub(단일 그룹)에서 최고성능 1건 선택
    규칙:
      1) R2 > threshold 후보 있으면: R2 desc, RMSE asc, MAE asc, 최신 ts
      2) 없으면: RMSE asc, MAE asc, R2 desc, 최신 ts
    """
    sub = add_score_columns(sub)

    cond = sub["R2_valid"].notna() & (sub["R2_valid"] > float(r2_threshold))
    sub_r2 = sub[cond].copy()

    if not sub_r2.empty:
        sort_cols = ["R2_valid_filled", "RMSE_valid_filled", "MAE_valid_filled", "ts_filled"]
        asc = [False, True, True, False]
        rule = f"R2>{r2_threshold} 우선"
        best = sub_r2.sort_values(sort_cols, ascending=asc).iloc[0]
        return best, rule

    sort_cols = ["RMSE_valid_filled", "MAE_valid_filled", "R2_valid_filled", "ts_filled"]
    asc = [True, True, False, False]
    rule = f"RMSE/MAE 우선(R2<={r2_threshold})"
    best = sub.sort_values(sort_cols, ascending=asc).iloc[0]
    return best, rule


# ─────────────────────────────────────────────
# 6) 협력사+engine별 "최고성능 1건" 유지
# ─────────────────────────────────────────────
def keep_best_per_vendor_engine(df: pd.DataFrame, r2_threshold: float = 0.5) -> pd.DataFrame:
    if "협력사" not in df.columns or "engine" not in df.columns:
        print("[ERROR] '협력사' 또는 'engine' 컬럼 없음")
        return df

    df = df.copy()
    df["협력사"] = df["협력사"].astype(str).map(_norm_str)
    df["engine"] = df["engine"].astype(str).str.strip()
    df = df[(df["협력사"] != "") & (df["engine"] != "")]
    if df.empty:
        print("[WARN] 협력사/engine 유효행 없음")
        return df

    rows = []
    for (vendor, engine), sub in df.groupby(["협력사", "engine"]):
        best_row, _ = _pick_best_row_by_rule(sub, r2_threshold=r2_threshold)
        rows.append(best_row)

    out = pd.DataFrame(rows).reset_index(drop=True)
    print(f"[INFO] 협력사+engine별 최고성능 로그만 유지: {len(out)} rows")
    return out


# ─────────────────────────────────────────────
# 7) 협력사별 best model 선택
# ─────────────────────────────────────────────
def select_best_models(df: pd.DataFrame, r2_threshold: float = 0.5) -> Tuple[Dict[str, str], pd.DataFrame]:
    if df.empty:
        print("[ERROR] best 모델 선택할 데이터 없음")
        return {}, pd.DataFrame()

    df = df.copy()
    df["협력사"] = df["협력사"].astype(str).map(_norm_str)
    df["engine"] = df["engine"].astype(str).str.strip()
    df = df[(df["협력사"] != "") & (df["engine"] != "")]
    if df.empty:
        print("[ERROR] 협력사/engine 유효행 없음")
        return {}, pd.DataFrame()

    best_map: Dict[str, str] = {}
    best_rows: List[pd.Series] = []

    for vendor, sub in df.groupby("협력사"):
        best, pick_rule = _pick_best_row_by_rule(sub, r2_threshold=r2_threshold)
        best_map[vendor] = str(best["engine"]).strip()
        best_rows.append(best)
        print(
            f"[BEST] 협력사={vendor} / engine={best_map[vendor]} "
            f"(rule={pick_rule}, R2={best.get('R2_valid')}, RMSE={best.get('RMSE_valid')}, MAE={best.get('MAE_valid')})"
        )

    best_df = pd.DataFrame(best_rows).reset_index(drop=True)
    return best_map, best_df


# ─────────────────────────────────────────────
# 8) JSON 저장
# ─────────────────────────────────────────────
def save_best_json(best_map: Dict[str, str]) -> Path:
    out_path = OUT_DIR / "best_model_by_vendor_ML.json"
    ordered = {k: best_map[k] for k in sorted(best_map.keys())}
    with open(out_path, "w", encoding="utf-8") as fp:
        json.dump(ordered, fp, ensure_ascii=False, indent=2)
    print(f"[SAVE] JSON 저장 완료: {out_path}")
    return out_path


# ─────────────────────────────────────────────
# 9) best 모델 summary CSV 저장
# ─────────────────────────────────────────────
def save_best_log_csv(best_df: pd.DataFrame, year_for_filename: Optional[int]):
    logs_dir = OUT_DIR / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    today = dt.date.today()
    y = year_for_filename if year_for_filename is not None else today.year
    fname = f"{y}_best_model_ML_{today.strftime('%Y%m%d')}.csv"

    out_path = logs_dir / fname
    best_df.to_csv(out_path, index=False, encoding="utf-8-sig")
    print(f"[SAVE] best summary CSV 저장: {out_path}")


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
def main(year: Optional[int] = None, recent_days: int = 30, r2_threshold: float = 0.5):
    print(" ==== ML Best Model Selection (DB Only) ==== ")
    print(f"[CONFIG] recent_days={recent_days}, r2_threshold={r2_threshold}, year={year}")

    df = load_logs_from_db()
    if df.empty:
        print("[ABORT] DB 로그 없음 → 종료")
        return

    df = filter_chosen(df)

    # 협력사별 최신 year 자동 선택
    df_year, selected_year = filter_year_per_vendor_latest(df, year)

    if recent_days > 0:
        df_year = filter_recent(df_year, recent_days)

    if df_year.empty:
        print("[ABORT] 필터링 후 로그 없음 → 종료")
        return

    # ✅ (협력사, engine)별 최고성능 1건
    df_best_ve = keep_best_per_vendor_engine(df_year, r2_threshold=r2_threshold)
    if df_best_ve.empty:
        print("[ABORT] 협력사+engine 최고성능 필터 후 로그 없음 → 종료")
        return

    best_map, best_df = select_best_models(df_best_ve, r2_threshold=r2_threshold)
    if not best_map:
        print("[ABORT] best 모델 없음 → 종료")
        return

    save_best_json(best_map)

    # 파일명 year는: 강제 year면 그 year, 아니면 "현재연도"로 저장(협력사별 year가 다를 수 있으니)
    year_for_filename = selected_year if year is not None else None
    save_best_log_csv(best_df, year_for_filename)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--year", type=int, default=None, help="강제 year (미지정 시 협력사별 최신 year 자동 선택)")
    parser.add_argument(
        "--recent_days",
        type=int,
        default=30,
        help="최근 N일 이내 로그만 사용 (기본: 30일, 0 또는 음수면 필터 미적용)",
    )
    parser.add_argument(
        "--r2_threshold",
        type=float,
        default=0.5,
        help="R2 우선 적용 임계값 (기본: 0.5, 초과일 때만 R2 우선)",
    )
    args = parser.parse_args()
    main(args.year, args.recent_days, args.r2_threshold)