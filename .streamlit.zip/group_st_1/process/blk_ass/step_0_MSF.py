from __future__ import annotations

import os
import subprocess
from pathlib import Path

"""
step_0_MSF.py (Mount Shared Folder)

- Windows `net use` 명령으로 공유 폴더를 연결하고
- 그 아래에 작업용 OUT_DIR 폴더(예: baechaehong)를 생성한 뒤
- Path 객체로 경로를 반환하는 모듈입니다.

다른 모듈에서는 다음처럼 사용합니다.
    from step_0_MSF import connect_and_prepare_outdir, OUT_DIR
"""

# ─────────────────────────────────────────────
# 환경 설정: 공유 계정 정보 (환경변수로 덮어쓰기 가능)
#   - SHARE_USER, SHARE_PWD 가 설정되어 있으면 그 값을 사용
#   - 없으면 기본값("samsung" / "shi_2025")으로 동작
# ─────────────────────────────────────────────
USER = os.getenv("SHARE_USER", "samsung")
PWD  = os.getenv("SHARE_PWD",  "shi_2025")

# ─────────────────────────────────────────────
# 공유 폴더 루트 및 산출물 경로
#   REMOTE_PATH : 공유 폴더(또는 네트워크 드라이브) 루트
#   WORK_DIR    : 작업 기준 폴더
#   OUT_DIR     : 실제 산출물 저장 폴더 (예: D:\...\BLK_ASS_PREDICT_4\baechaehong)
#                 → 다른 모듈에서 import 하여 사용
# ─────────────────────────────────────────────
REMOTE_PATH = r"\\60.100.164.182\d\001_python_source\A01_WeGrow"
WORK_DIR = Path(REMOTE_PATH)
OUT_DIR  = WORK_DIR / "baechaehong01"   # 모듈 외부에서 import 해 사용


def connect_and_prepare_outdir(persistent: bool = False) -> Path:
    """
    공유 폴더 연결 후 OUT_DIR(작업 산출 폴더)을 생성하고, 그 경로(Path)를 반환합니다.

    Parameters
    ----------
    persistent : bool, optional
        - True  : Windows 재부팅 후에도 연결 유지(/persistent:yes)
        - False : 한 번 연결만 시도(기본값)

    Returns
    -------
    Path
        OUT_DIR 경로 (예: D:\\08_Python_uv\\BLK_ASS_PREDICT_4\\baechaehong)
    """
    # /persistent 옵션 구성
    persistent_opt = "/persistent:yes" if persistent else ""

    # Windows net use 명령어 구성
    #   예) net use "D:\08_Python_uv\BLK_ASS_PREDICT_4" "비밀번호" /user:"계정" /persistent:yes
    cmd = f'net use "{REMOTE_PATH}" "{PWD}" /user:"{USER}" {persistent_opt}'.strip()

    try:
        # 공유 폴더 연결 시도
        # - 이미 연결되어 있거나 오류 코드가 떠도, 아래 except에서 무시 후 진행
        subprocess.run(
            cmd,
            check=True,
            shell=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError:
        # 이미 연결되어 있는 경우 등 비정상 종료 코드가 나와도,
        # 실제 경로에 접근 가능한 경우가 많으므로 여기서는 단순히 통과만 합니다.
        # 필요하다면 로그 출력이나 예외 처리 로직을 추가할 수 있습니다.
        pass

    # OUT_DIR(산출 폴더) 생성
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    return OUT_DIR


if __name__ == "__main__":
    # 단독 실행 시, 연결 + OUT_DIR 경로를 출력해 간단히 확인
    out = connect_and_prepare_outdir(persistent=False)
    print(f"[OK] OUT_DIR: {out}")
