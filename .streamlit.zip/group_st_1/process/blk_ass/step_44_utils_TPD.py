from __future__ import annotations
"""
step_44_utils_TPD.py

협력사별 일일 조립 생산능력(TPD: Ton Per Day)을
DB에서 불러오고, 월/주/일 단위로 조회하는 유틸 모듈.

구조 요약
---------
1) load_capacity(year)
   - MySQL 테이블 '협력사_일일조립생산능력' 에서 해당 연도(year)의
     협력사별 월별 능력(TPD)을 읽어 DataFrame으로 반환

2) tpd_month(cap_df, vendor, month)
   - cap_df (load_capacity 결과)에서
     특정 협력사/월의 능력(TPD)을 반환

3) tpd_week(cap_df, vendor, year, week_no)
   - 해당 연도/주차에 포함된 날짜들의 '월'을 기준으로
     tpd_month(...)들을 조회한 뒤, 유효값 중 최댓값을
     "그 주의 능력(TPD)"으로 간주

4) tpd_day(cap_df, vendor, date)
   - 현재 모델에서는 "해당 월의 능력(TPD)"을 그대로 하루 능력으로 사용
"""

import datetime as dt
from typing import Optional  # (다른 모듈에서 타입 힌트로 쓸 수도 있어 남겨둠)

import numpy as np
import pandas as pd
from sqlalchemy import create_engine, text

from step_42_utils_calendar import dates_of_week

# ─────────────────────────────────────────────
# DB 접속 정보 (월별 능력 TPD 조회용)
# ─────────────────────────────────────────────
DB_HOST = "60.100.164.182"
DB_PORT = 3306
DB_USER = "root"
DB_PASS = "250404"
DB_NAME = "구조조달1_db"
DB_URL = (
    f"mysql+pymysql://{DB_USER}:{DB_PASS}"
    f"@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"
)


# ─────────────────────────────────────────────
# 1) 협력사 월별 능력(TPD) 로딩
# ─────────────────────────────────────────────
def load_capacity(year: int) -> pd.DataFrame:
    """
    협력사_일일조립생산능력 테이블에서 해당 연도의 월별 능력(TPD)을 로드한다.

    Parameters
    ----------
    year : int
        조회 연도 (예: 2025)

    Returns
    -------
    pd.DataFrame
        컬럼 구성:
        - '협력사': str
        - '1월' ~ '12월': float (NaN 허용, 숫자 변환 실패 시 NaN)

    Notes
    -----
    기대하는 DB 테이블 스키마 예:
        CREATE TABLE 협력사_일일조립생산능력 (
            협력사 VARCHAR(...),
            년도   INT,
            `1월`  FLOAT, ... `12월` FLOAT
        );
    """
    sql = text(
        """
        SELECT 협력사, 년도,
               `1월`,`2월`,`3월`,`4월`,`5월`,`6월`,
               `7월`,`8월`,`9월`,`10월`,`11월`,`12월`
        FROM 협력사_일일조립생산능력
        WHERE 년도 = :y
        """
    )

    engine = create_engine(DB_URL, pool_pre_ping=True, future=True)
    with engine.connect() as conn:
        cap = pd.read_sql(sql, conn, params={"y": year})

    # 월 컬럼 이름 리스트
    months = [f"{m}월" for m in range(1, 13)]

    # 협력사 문자열 정리 및 월별 숫자 변환
    cap["협력사"] = cap["협력사"].astype(str).str.strip()
    cap[months] = cap[months].apply(pd.to_numeric, errors="coerce")

    return cap[["협력사"] + months]


# ─────────────────────────────────────────────
# 2) 월 단위 능력(TPD)
# ─────────────────────────────────────────────
def tpd_month(cap_df: pd.DataFrame, vendor: str, month: int) -> float:
    """
    월 단위 능력(TPD) 조회.

    Parameters
    ----------
    cap_df : pd.DataFrame
        load_capacity(year) 결과 DataFrame
    vendor : str
        협력사명 (좌우 공백은 내부에서 제거)
    month : int
        1 ~ 12 (조회 월)

    Returns
    -------
    float
        - 해당 협력사의 지정 월 능력(TPD)
        - 데이터 없거나 숫자 변환 실패 시 NaN 반환
    """
    row = cap_df.loc[cap_df["협력사"] == str(vendor).strip()]
    if row.empty:
        return np.nan
    return row.iloc[0][f"{month}월"]


# ─────────────────────────────────────────────
# 3) 주 단위 능력(TPD)
# ─────────────────────────────────────────────
def tpd_week(cap_df: pd.DataFrame, vendor: str, year: int, week_no: int) -> float:
    """
    주 단위 능력(TPD) 조회.

    로직
    ----
    1) dates_of_week(year, week_no) 로 해당 주(월~일) 날짜들을 구한다.
    2) 그 중 '해당 연도(year)에 속한 날짜'들의 월(month)을 set으로 모은다.
       (예: 1월 말~2월 초에 걸친 주라면 {1, 2})
    3) 각 월에 대해 tpd_month(cap_df, vendor, month) 값을 조회
    4) 유효값(Non-NaN) 중 최대값을 그 주의 TPD로 사용

    Parameters
    ----------
    cap_df : pd.DataFrame
        load_capacity(year) 결과
    vendor : str
        협력사명
    year : int
        기준 연도 (주차 계산 기준)
    week_no : int
        월요일 기준 주차 번호 (step_42_utils_calendar.week_no_mon 결과)

    Returns
    -------
    float
        - 해당 주의 능력(TPD)
        - 주에 연도 내 날짜가 없거나, 모든 월 TPD가 NaN이면 NaN
    """
    # 해당 주(월~일) 중 기준 연도에 속하는 날짜들의 month 집합
    months_in_week = {d.month for d in dates_of_week(year, week_no) if d.year == year}
    if not months_in_week:
        return np.nan

    vals = [tpd_month(cap_df, vendor, m) for m in months_in_week]
    vals = [v for v in vals if pd.notna(v)]
    return max(vals) if vals else np.nan


# ─────────────────────────────────────────────
# 4) 일 단위 능력(TPD)
# ─────────────────────────────────────────────
def tpd_day(cap_df: pd.DataFrame, vendor: str, d: dt.date) -> float:
    """
    일 단위 능력(TPD) 조회.

    현재 모델 가정
    -------------
    - 하루 능력(TPD)는 '해당 월의 능력(TPD)'과 동일하게 사용한다.
      즉, 날짜 d가 2025-03-15라면 3월 월간 능력값을 그대로 사용.

    Parameters
    ----------
    cap_df : pd.DataFrame
        load_capacity(year) 결과
    vendor : str
        협력사명
    d : datetime.date
        조회 일자

    Returns
    -------
    float
        - d가 속한 월의 능력(TPD)
        - 해당 협력사의 월 능력이 없으면 NaN
    """
    return tpd_month(cap_df, vendor, d.month)
