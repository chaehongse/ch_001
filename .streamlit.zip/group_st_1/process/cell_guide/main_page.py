# main_app_ML.py — 예측 오버레이 대시보드 (주석 확장/안정화판)
# ──────────────────────────────────────────────────────────────────────────────
# 목적
#  • 생산/납품 월별 현황(막대+누계차 라인) + 오늘 이후 실적/누계차 끊김(NaN)
#  • 누계/달성률(오늘까지) + "현재월 포함" 예측 누계/달성률 점선 오버레이
#  • 사이드바: 조회 조건(연/협력사/제외협력사), 예측 파라미터, 실행 버튼
#  • Data 새로고침 → 데이터만 최신으로 갱신 + 초기 조건 리셋
#
# 설계 메모(정합성)
#  • 생산 계획 월축: 기본 '조립완료(계획)' 월 기준. 없으면 '관리납품일'로 폴백(실데이터 결측 대비).
#  • 납품 실적 월축: 기본 '납품/선적일' 월 기준(✓ step_3_2.py와 일관). 
#    └ 필요하면 DELI_ACTUAL_BY_SHIP=False로 바꿔 '관리납품일' 기준으로 한 줄 전환.
#  • 예측 라벨/단위: "SET"로 통일(EA 혼용 제거).
# ──────────────────────────────────────────────────────────────────────────────


from datetime import datetime, timezone, timedelta
from typing import List, Optional

import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from step_2 import main as load_master_df   # DB → 표준 컬럼 DF 로드
from step_1 import OUT_DIR                  # 결과 저장 경로(output)
from step_8 import run_forecast_on_df       # 예측/전망 실행 API

# (선택) 점검 모듈 — 없으면 앱이 죽지 않도록 try/except

# (전역 제외 협력사) — UI 옵션 구성/필터 둘 다에 적용
EXCLUDE_SUPPLIERS = {"영성법인1공장", "한화오션(산동)"}
def _norm_supplier(name: str) -> str:
    """협력사 비교를 위한 정규화(소문자 + trim)."""
    return str(name).strip().lower()
_EXC_NORM = {_norm_supplier(s) for s in EXCLUDE_SUPPLIERS}

# 페이지 세팅
try:
    st.set_page_config(page_title="셀가이드 공정관리 시스템", layout="wide")
except Exception:
    pass
st.title("셀가이드 공정 현황 대시보드")

# KPI 카드 스타일(간결한 CSS)
st.markdown(
    """
    <style>
      :root {
        --ink: #0f172a;
        --muted: #64748b;
        --card: #ffffff;
        --line: #e5e7eb;
        --shadow: 0 10px 30px rgba(15, 23, 42, 0.08);
        --shadow-soft: 0 6px 16px rgba(15, 23, 42, 0.06);
      }
      .stApp {
        background:
          radial-gradient(1200px 600px at -10% -10%, #eef2ff 0%, rgba(238,242,255,0) 60%),
          radial-gradient(900px 500px at 110% 0%, #f0fdf4 0%, rgba(240,253,244,0) 60%),
          linear-gradient(180deg, #f8fafc 0%, #ffffff 30%, #ffffff 100%);
      }
      .kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }
      .kpi-card {
        padding: 16px 18px; border-radius: 18px; background: var(--card);
        border: 1px solid var(--line); box-shadow: var(--shadow-soft);
        position: relative; overflow: hidden;
      }
      .kpi-card:before {
        content: ""; position: absolute; inset: 0;
        background: linear-gradient(135deg, rgba(124,140,161,0.06), rgba(79,178,134,0.06));
        opacity: 0.6; pointer-events: none;
      }
      .kpi-title { font-size: 12px; letter-spacing: .02em; color: var(--muted); margin-bottom: 6px; }
      .kpi-value { font-size: 24px; font-weight: 800; color: var(--ink); }
      .kpi-sub { font-size: 12px; color: #94a3b8; margin-top: 4px; }
      /* 본문과 사이드바 사이 여백 + 본문 스크롤 강제 복구 */
      html, body, .stApp {
        height: 100% !important;
        overflow: hidden !important;
      }
      [data-testid="stAppViewContainer"] {
        height: 100vh !important;
        overflow: hidden !important;
      }
      [data-testid="stAppViewContainer"] > .main,
      section.main {
        height: 100vh !important;
        max-height: 100vh !important;
        overflow-y: auto !important;
        overflow-x: hidden !important;
        overscroll-behavior-y: contain;
        padding-left: 1.1rem !important;
      }
      section.main > div.block-container {
        padding-top: 1.15rem;
        padding-bottom: 6rem;
        padding-left: 4.2rem;
        padding-right: 3.25rem;
        max-width: none;
      }
      @media (min-width: 1200px) {
        section.main > div.block-container {
          padding-left: 4.8rem;
          padding-right: 3.4rem;
        }
      }
      section[data-testid="stSidebar"] {
        min-width: 320px !important;
        border-right: 1px solid #e5e7eb;
        box-shadow: 8px 0 24px rgba(15, 23, 42, 0.05);
        margin-right: 0.65rem !important;
      }
      section[data-testid="stSidebar"] > div {
        padding-right: 1.1rem;
      }
      div[data-testid="stHorizontalBlock"] {
        gap: 2rem;
        align-items: flex-start;
      }
      .stPlotlyChart, [data-testid="stPlotlyChart"] {
        min-height: 420px;
      }
      /* 사이드바 버튼 일괄 사이즈/색 통일 */
      section[data-testid="stSidebar"] .stButton button {
        width: 100% !important; height: 44px !important; padding: 0 12px !important;
        border-radius: 12px !important; font-weight: 700 !important; margin: 6px 0 !important;
        background: #fff !important; color: var(--ink) !important; border: 1px solid #e5e7eb !important;
        box-shadow: var(--shadow);
      }
      section[data-testid="stSidebar"] .stButton button:hover { background: #f8fafc !important; }
    </style>
    """,
    unsafe_allow_html=True,
)

# 한국 표준시(오늘/마스킹 계산에 사용)
KST = timezone(timedelta(hours=9))
TODAY = datetime.now(KST).date()
TODAY_YM = (TODAY.year, TODAY.month)  # (YYYY, M)

# ──────────────────────────────────────────────────────────────────────────────
# 데이터 로딩/캐시
# ──────────────────────────────────────────────────────────────────────────────
@st.cache_data(show_spinner=True, ttl=60*10)
def get_master_df() -> pd.DataFrame:
    """DB에서 표준 DF 로드 후 주요 날짜 컬럼 파싱."""
    df = load_master_df()
    if df is None or df.empty:
        return pd.DataFrame()
    for c in [
        "관리납품일", "12주EPC착수(블록)",
        "납품/선적일", "납품/선적예정일",
        "조립착수(실적)", "조립완료(실적)",
        "조립착수(계획)", "조립완료(계획)",
        "조립P/R확정일",
        "도장P/R확정일1", "도장P/R확정일2",
        "도장착수(실적)", "도장완료(실적)",
    ]:
        if c in df.columns:
            df[c] = pd.to_datetime(df[c], errors="coerce")
    return df

def clear_cache_and_reload():
    get_master_df.clear()
    st.session_state.pop("filtered_df", None)

# ── 하드 리셋 게이트 (위젯 생성 전) ─────────────────────────────────────
# 새로고침 버튼은 __hard_reset__ 플래그만 True로 세움 → 다음 런에서 이 블록이 먼저 실행됨
if st.session_state.get("__hard_reset__", False):
    try:
        # 데이터 캐시 비우기 (있으면)
        if "get_master_df" in globals():
            get_master_df.clear()
    except Exception:
        pass
    # 세션 상태 전체 초기화 (위젯 생성 전이라 안전)
    st.session_state.clear()
    st.session_state["__hard_reset__"] = False
    # 버전에 따라 rerun 함수명이 다름
    if hasattr(st, "rerun"):
        st.rerun()
    else:
        st.experimental_rerun()
# ──────────────────────────────────────────────────────────────────────────────
# 공통 유틸(라벨/정렬/포맷)
# ──────────────────────────────────────────────────────────────────────────────
def to_yy_mm_label(x) -> str:
    """임의 문자열/타임스탬프 → 'yy_mm' 라벨. 실패 시 원문 반환."""
    try:
        if isinstance(x, str):
            s = x.replace("_", "-").replace("/", "-").strip()
            p = s.split("-")
            if len(p) >= 2 and p[0].isdigit() and p[1].isdigit():
                return f"{p[0][-2:]}_{p[1].zfill(2)}"
        ts = pd.to_datetime(x, errors="raise")
        return ts.strftime("%y_%m")
    except Exception:
        return str(x)

def month_sort_key(x):
    """월 정렬키: (yy, mm). 실패 시 맨 뒤."""
    try:
        if isinstance(x, str):
            s = x.replace("_", "-").replace("/", "-").strip()
            p = s.split("-")
            if len(p) >= 2 and p[0].isdigit() and p[1].isdigit():
                return (int(p[0][-2:]), int(p[1]))
        ts = pd.to_datetime(x, errors="raise")
        return (int(ts.strftime("%y")), int(ts.strftime("%m")))
    except Exception:
        return (999, 99)

def format_num(v, decimals=1):
    """숫자 콤마/소수 포맷. 실패 시 '-'."""
    try:
        return f"{float(v):,.{decimals}f}"
    except Exception:
        return "-"

def ym_of_label(label: str) -> tuple[int, int]:
    """'yy_mm' → (YYYY, M)."""
    s = to_yy_mm_label(label)
    yy = int(s[:2]); mm = int(s[3:5])
    return (2000 + yy, mm)

def mask_until_today(months: list[str]) -> np.ndarray:
    """월 라벨 배열에서 오늘 이후는 False(마스킹)로."""
    return np.array([ym_of_label(m) <= TODAY_YM for m in months], dtype=bool)

def _chunk(lst, n):
    """리스트를 n개씩 슬라이스(사이드바 체크박스 그리드에 사용)."""
    for i in range(0, len(lst), n):
        yield lst[i:i+n]


def _build_forecast_descriptive_stats(forecast_df: pd.DataFrame) -> pd.DataFrame:
    """예측 결과(pred_adj)의 기술통계 요약 표 생성."""
    if forecast_df is None or forecast_df.empty:
        return pd.DataFrame()
    if "series" not in forecast_df.columns or "pred_adj" not in forecast_df.columns:
        return pd.DataFrame()

    name_map = {"prod_ton": "생산(톤)", "deli_set": "납품(SET)"}
    rows: list[dict] = []
    for series_key, label in name_map.items():
        s = pd.to_numeric(
            forecast_df.loc[forecast_df["series"] == series_key, "pred_adj"],
            errors="coerce",
        ).dropna()
        if s.empty:
            continue
        rows.append(
            {
                "구분": label,
                #"건수": int(s.count()),
                "평균": round(float(s.mean()), 2),
                "표준편차": round(float(s.std(ddof=1)) if s.count() > 1 else 0.0, 2),
                "최소": round(float(s.min()), 2),
                "1사분위": round(float(s.quantile(0.25)), 2),
                "중앙값": round(float(s.median()), 2),
                "3사분위": round(float(s.quantile(0.75)), 2),
                "최대": round(float(s.max()), 2),
                "합계": round(float(s.sum()), 2),
            }
        )
    return pd.DataFrame(rows)


def _horizon_months_label(months_ahead: int) -> str:
    m = max(0, int(months_ahead))
    return "다음월" if m == 0 else f"{m}개월"


def _horizon_days_by_months(months_ahead: int) -> int:
    """현재월을 제외하고 다음월부터 선택 구간의 마지막 월 말일까지 일수로 환산."""
    m = max(0, int(months_ahead))
    cur_p = pd.Timestamp(TODAY).to_period("M")
    end_p = cur_p + max(1, m)
    end_date = end_p.to_timestamp(how="end").date()
    return max(1, int((end_date - TODAY).days))


def render_forecast_summary_block() -> None:
    """예측/전망 상태 메시지 + 기술통계 요약을 함께 표시."""
    if not st.session_state.get("forecast_generated", False):
        return

    status = st.session_state.get("forecast_status")
    msg = st.session_state.get("forecast_status_message")
    if status == "success" and msg:
        st.success(msg)
    elif status == "warning" and msg:
        st.warning(msg)
    elif status == "error" and msg:
        st.error(msg)

    forecast_df_top = st.session_state.get("forecast_df")
    if not isinstance(forecast_df_top, pd.DataFrame) or forecast_df_top.empty:
        return

    st.markdown("#### 예측/전망 통계적 기술 요약")
    months_ahead = int(st.session_state.get("horizon_months", 0))
    period_label = _horizon_months_label(months_ahead)
    f_mon = forecast_df_top["yyyymm"].astype(str) if "yyyymm" in forecast_df_top.columns else pd.Series(dtype=str)
    start_mon = to_yy_mm_label(f_mon.min()) if not f_mon.empty else "-"
    end_mon = to_yy_mm_label(f_mon.max()) if not f_mon.empty else "-"
    meta_l, meta_r = st.columns(2)
    with meta_l:
        st.caption(f"예측 구간: {period_label}부터 적용 (해당월 제외)")
    with meta_r:
        st.caption(f"대상 월: {start_mon} ~ {end_mon}")

    stats_df = _build_forecast_descriptive_stats(forecast_df_top)
    if not stats_df.empty:
        st.dataframe(stats_df, use_container_width=True, hide_index=True)
    else:
        st.info("예측 통계 요약을 생성할 데이터가 없습니다.")

# ──────────────────────────────────────────────────────────────────────────────
# 조회 보조
# ──────────────────────────────────────────────────────────────────────────────
def derive_year_options(df: pd.DataFrame) -> List[str]:
    if df.empty or "관리납품일" not in df.columns:
        return []
    years = df["관리납품일"].dropna().dt.year.astype("Int64").dropna().astype(int).unique().tolist()
    years.sort()
    return [f"{str(y)[-2:]}년" for y in years]

def filter_by_years(df: pd.DataFrame, years_labels: List[str]) -> pd.DataFrame:
    if not years_labels or df.empty or "관리납품일" not in df.columns:
        return df
    years_int = {int(y.replace("년","")) for y in years_labels}
    mask = df["관리납품일"].dt.year.astype("Int64").isin({2000+y for y in years_int})
    return df.loc[mask].copy()

# ──────────────────────────────────────────────────────────────────────────────
# 데이터 로딩
# ──────────────────────────────────────────────────────────────────────────────
with st.spinner("데이터 로딩 중…"):
    df_master = get_master_df()
if df_master.empty:
    st.error("원본 데이터가 비어있습니다. DB 연결/권한/쿼리 결과를 확인해 주세요.")
    st.stop()


# 기본값 세팅 함수(위젯 생성 전에서만 호출)
def _reset_start_state(df_master: pd.DataFrame):
    year_opts = derive_year_options(df_master)
    current_label = datetime.now(KST).strftime("%y") + "년" if year_opts else None
    st.session_state["year_checked"] = {yl: (yl == current_label) for yl in year_opts}
    st.session_state["year_all"] = False               #
    st.session_state["supplier_multi"] = []
    st.session_state["exclude_input"] = ""
    st.session_state.pop("filtered_snapshot", None)
    st.session_state.pop("forecast_df", None)
    st.session_state.pop("forecast_generated", None)

# 최초 1회 초기화
if "initialized" not in st.session_state:
    _reset_start_state(df_master)
    st.session_state["initialized"] = True

# 새로고침 플래그 처리 (버튼 on_click에서 __do_reset__=True만 세움)
if st.session_state.pop("__do_reset__", False):
    clear_cache_and_reload()
    _reset_start_state(df_master)
    # Streamlit 1.30+ : st.rerun(), 구버전: st.experimental_rerun()
    if hasattr(st, "rerun"):
        st.rerun()
    else:
        st.experimental_rerun()             

# ──────────────────────────────────────────────────────────────────────────────
# 사이드바 (조회 + 예측 파라미터 + 실행)
# ──────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("⟦조회 조건⟧")

    # 조회 연도 — '관리납품일' 존재 연도만 추출
    st.subheader("[조회 년도]")
    df_master = get_master_df()
    if df_master.empty:
        st.error("원본 데이터가 비어있습니다. DB 연결/권한/쿼리를 확인해주세요.")
        st.stop()

    year_opts_actual = derive_year_options(df_master)
    current_year_label = datetime.now(KST).strftime("%y") + "년" if year_opts_actual else None

    # 체크박스 초기 상태(최초 진입 시 올해만 체크)
    if "year_checked" not in st.session_state:
        st.session_state["year_checked"] = {yl: (yl == current_year_label) for yl in year_opts_actual}
        st.session_state["year_all"] = False

    # 3열 그리드로 체크박스 배치
    for row in _chunk(year_opts_actual, 3):
        cols = st.columns(len(row))
        for col, ylab in zip(cols, row):
            with col:
                st.session_state["year_checked"][ylab] = st.checkbox(
                    ylab, value=st.session_state["year_checked"].get(ylab, False), key=f"year_{ylab}"
                )

    # 전체 선택 토글
    chk_all_years = st.checkbox("전체", value=st.session_state.get("year_all", False), key="year_all")
    selected_year_labels = [ylab for ylab, on in st.session_state["year_checked"].items() if on]
    if chk_all_years:
        selected_year_labels = year_opts_actual[:]
    elif not selected_year_labels and current_year_label in year_opts_actual:
        selected_year_labels = [current_year_label]

    # 협력사 멀티 선택 — 전역 제외 목록을 먼저 제거하여 옵션 구성
    st.subheader("[협력사 선택]")
    suppliers_all = (
        df_master.get("협력사명", pd.Series(dtype=str))
        .dropna().astype(str).str.strip().unique().tolist()
    )
    suppliers = sorted([s for s in suppliers_all if _norm_supplier(s) not in _EXC_NORM])
    supplier_multi = st.multiselect("협력사 선택(복수 가능)", suppliers, default=[])
    
    st.markdown("*중국 제작처 제외")

    # 조회버튼
    btn_query = st.button("조회", key="btn_query", type="secondary", use_container_width=True)

    # ── 예측/전망 설정 ─────────────────────────────────────────────────────
    st.subheader("[예측/전망 설정]")
    horizon_months = st.radio(
        "예측 기간(월 기준)",
        options=[1, 2, 3],
        index=0,
        horizontal=True,
        key="horizon_months",
        format_func=lambda m: "다음월" if int(m) == 0 else f"{int(m)}개월",
    )
    train_months     = st.slider("선형회귀 학습기간(최근 개월)", min_value=3, max_value=36, value=24, step=1, key="train_months")
    use_history_scale = st.checkbox("과거 예측 기반 보정 사용", value=True, key="use_history_scale")
    save_hist = st.checkbox("예측 히스토리 저장", value=True, key="save_hist")
    
    # 예측/전망 실행
    btn_forecast = st.button("예측/전망 실행", type="secondary", use_container_width=True, help="선형회귀 기반 예측 라인 오버레이", key="btn_forecast")

    # 예측 요약 표시(버튼 하단)
    if "forecast_summary" in st.session_state and st.session_state["forecast_summary"]:
        st.caption(st.session_state["forecast_summary"])

    def _request_reset():
        st.session_state["__do_reset__"] = True

    # 새로고침 버튼
    btn_refresh  = st.button("Data 새로고침", help="캐시를 비우고 DB에서 다시 불러옵니다", key="btn_refresh", type="secondary", use_container_width=True, on_click=_request_reset)

    # 결과저장 버튼
    btn_save    = st.button("조회 결과 저장", key="btn_save", type="secondary", use_container_width=True, help=f"저장 위치: {OUT_DIR}")

# 새로고침: 데이터만 갱신 + 초기 조건 리셋
if btn_refresh:
    clear_cache_and_reload()
    _reset_start_state(df_master)
    st.success("데이터 캐시를 갱신하고 초기 조건으로 되돌렸습니다. (현재 연도만 선택)")
    st.stop()

# ──────────────────────────────────────────────────────────────────────────────
# 조회 조건 적용
# ──────────────────────────────────────────────────────────────────────────────
filtered = df_master.copy()

filtered = filter_by_years(filtered, selected_year_labels)

# 전역 제외 협력사 제거
if "협력사명" in filtered.columns and _EXC_NORM:
    filtered = filtered[~filtered["협력사명"].astype(str).map(_norm_supplier).isin(_EXC_NORM)]

# 협력사 멀티 선택 적용
if supplier_multi:
    filtered = filtered[filtered["협력사명"].astype(str).str.strip().isin(supplier_multi)]

if btn_query:
    st.toast("조회 조건을 적용했어요 ✨", icon="✅")
st.session_state["filtered_df"] = filtered  # 저장 버튼에서 재활용

suppliers_title = ", ".join(supplier_multi) if supplier_multi else "전체"
st.subheader(f"{suppliers_title} 셀가이드 월별 공정 현황")
render_forecast_summary_block()

# ──────────────────────────────────────────────────────────────────────────────
# 월별 집계(생산/납품) — 정합성/가용성 폴백 포함
# ──────────────────────────────────────────────────────────────────────────────

# ▣ 플래그: 납품 실적 월축을 납품/선적일로 잡을지 여부(권장: True)
DELI_ACTUAL_BY_SHIP = True

def _agg_monthly_sum(df: pd.DataFrame, val_col: str, date_col: str) -> pd.Series:
    """수치열(val_col)을 날짜열(date_col)의 월로 묶어 합산(yy_mm)."""
    if val_col not in df.columns or date_col not in df.columns:
        return pd.Series(dtype=float)
    vals = pd.to_numeric(df[val_col], errors="coerce")
    dts = pd.to_datetime(df[date_col], errors="coerce")
    key = dts.dt.strftime("%y_%m")
    s = vals.groupby(key).sum(min_count=1)
    return s.dropna()

def build_prod_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """생산(톤) 매트릭스(계획/실적/누계차)."""
    plan_kg = _agg_monthly_sum(df, "중량합계(A)", "관리납품일")
    actual_kg = _agg_monthly_sum(df, "중량합계(A)", "조립완료(실적)")
    plan = (plan_kg / 1000.0).rename("계획")      # 톤 환산
    actual = (actual_kg / 1000.0).rename("실적")
    months = sorted(set(plan.index).union(set(actual.index)), key=month_sort_key)
    mtx = pd.DataFrame(index=["계획", "실적", "누계차"], columns=months, dtype=float).fillna(0.0)
    mtx.loc["계획", months] = plan.reindex(months).fillna(0).values
    mtx.loc["실적", months] = actual.reindex(months).fillna(0).values
    mtx.loc["누계차", months] = mtx.loc["실적"].cumsum() - mtx.loc["계획"].cumsum()
    return mtx

def build_deli_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """납품(SET) 매트릭스
       - 계획: '관리납품일' 월 기준으로, '조립P/R확정일' 존재(True) 건수
       - 실적: '납품/선적일' 월 기준으로, '납품/선적일' 존재(True) 건수
    """
    if df is None or df.empty:
        return pd.DataFrame()

    mng  = pd.to_datetime(df.get("관리납품일"), errors="coerce")
    ship = pd.to_datetime(df.get("납품/선적일"), errors="coerce")
    pr   = pd.to_datetime(df.get("조립P/R확정일"), errors="coerce")

    key_plan = mng.dt.strftime("%y_%m")
    plan_mask = pr.notna()
    plan_cnt = plan_mask.groupby(key_plan).sum(min_count=1)

    key_act = ship.dt.strftime("%y_%m")
    act_mask = ship.notna()
    act_cnt = act_mask.groupby(key_act).sum(min_count=1)

    months = sorted(set(plan_cnt.index).union(set(act_cnt.index)), key=month_sort_key)

    # float dtype로 생성(미래 마스킹 NaN 허용 → Plotly와 궁합 좋음)
    mtx = pd.DataFrame(index=["계획", "실적", "누계차"], columns=months, dtype=float).fillna(0.0)
    mtx.loc["계획", months] = plan_cnt.reindex(months).fillna(0).values
    mtx.loc["실적", months] = act_cnt.reindex(months).fillna(0).values
    mtx.loc["누계차", months] = mtx.loc["실적"].cumsum() - mtx.loc["계획"].cumsum()
    return mtx

prod_matrix = build_prod_matrix(filtered)
deli_matrix = build_deli_matrix(filtered)

# ──────────────────────────────────────────────────────────────────────────────
# KPI 계산
# ──────────────────────────────────────────────────────────────────────────────
def kpi_prod_from_matrix(mtx: pd.DataFrame):
    if mtx is None or mtx.empty:
        return {"계획_총합계": "-", "실적_총합계": "-", "잔여조립량": "-", "조립완료률": "-"}
    plan_total = float(mtx.loc["계획"].sum()) if "계획" in mtx.index else 0.0
    actual_total = float(mtx.loc["실적"].sum()) if "실적" in mtx.index else 0.0
    remain = plan_total - actual_total
    rate = (actual_total / plan_total * 100.0) if plan_total > 0 else 0.0
    return {
        "계획_총합계": format_num(plan_total, 1),
        "실적_총합계": format_num(actual_total, 1),
        "잔여조립량": format_num(remain, 1),
        "조립완료률": format_num(rate, 1),
    }

def kpi_deli_from_matrix(mtx: pd.DataFrame):
    if mtx is None or mtx.empty:
        return {"계획_납품합계": "-", "실적_납품합계": "-", "잔여납품량": "-", "납품완료률": "-"}
    plan_total = float(mtx.loc["계획"].sum()) if "계획" in mtx.index else 0.0
    actual_total = float(mtx.loc["실적"].sum()) if "실적" in mtx.index else 0.0
    remain = plan_total - actual_total
    rate = (actual_total / plan_total * 100.0) if plan_total > 0 else 0.0
    return {
        "계획_납품합계": f"{int(round(plan_total)):,}",
        "실적_납품합계": f"{int(round(actual_total)):,}",
        "잔여납품량": f"{int(round(remain)):,}",
        "납품완료률": format_num(rate, 1),
    }

# Plotly 스타일 팔레트(좌/우 그래프를 서로 다르게 보이도록 시리즈별 분리)
PLOTLY_THEME_BY_SERIES = {
    "prod_ton": {
        "plan": "#93C5FD",          # 라이트 블루
        "actual": "#2DD4BF",        # 민트
        "diff": "#FDBA74",          # 살구 오렌지
        "forecast": "#38BDF8",      # 스카이 블루
        "plan_line": "#60A5FA",     # 블루
        "rate": "#F9A8D4",          # 라이트 핑크
        "rate_forecast": "#C4B5FD", # 라이트 퍼플
        "fill": "rgba(45, 212, 191, 0.18)",
        "grid": "#E2E8F0",
    },
    "deli_set": {
        "plan": "#FDE68A",          # 라이트 옐로우
        "actual": "#34D399",        # 선명한 민트 그린
        "diff": "#F472B6",          # 밝은 핑크
        "forecast": "#A78BFA",      # 선명한 바이올렛
        "plan_line": "#A78BFA",     # 바이올렛
        "rate": "#FB7185",          # 로즈
        "rate_forecast": "#22D3EE", # 시안
        "fill": "rgba(134, 239, 172, 0.18)",
        "grid": "#E2E8F0",
    },
    "default": {
        "plan": "#CBD5E1",
        "actual": "#5EEAD4",
        "diff": "#FDBA74",
        "forecast": "#7DD3FC",
        "plan_line": "#93C5FD",
        "rate": "#F9A8D4",
        "rate_forecast": "#C4B5FD",
        "fill": "rgba(94, 234, 212, 0.18)",
        "grid": "#E2E8F0",
    },
}


def _palette_for(series_name: Optional[str]) -> dict:
    return PLOTLY_THEME_BY_SERIES.get(series_name or "", PLOTLY_THEME_BY_SERIES["default"])


def _apply_plotly_layout(fig, palette: dict):
    fig.update_layout(
        template="plotly_white",
        colorway=[
            palette["plan"],
            palette["actual"],
            palette["diff"],
            palette["forecast"],
        ],
        font=dict(family="Pretendard, Noto Sans KR, Apple SD Gothic Neo, Segoe UI, sans-serif", size=12, color="#0F172A"),
        hovermode="x unified",
        hoverlabel=dict(bgcolor="rgba(255,255,255,0.96)", bordercolor="#CBD5E1", font=dict(color="#334155", size=11)),
        legend=dict(
            orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1,
            bgcolor="rgba(255,255,255,0.7)", bordercolor="#E5E7EB", borderwidth=1,
        ),
        margin=dict(l=10, r=10, t=30, b=10),
        paper_bgcolor="#FFFFFF",
        plot_bgcolor="#FFFFFF",
    )
    fig.update_xaxes(showgrid=False, zeroline=False, tickfont=dict(size=11), ticks="outside", tickcolor="#CBD5E1")
    fig.update_yaxes(showgrid=True, gridcolor=palette["grid"], zeroline=False, tickfont=dict(size=11), ticks="outside", tickcolor="#CBD5E1")
    return fig

# ──────────────────────────────────────────────────────────────────────────────
# 그래프 빌더(막대+선, 누계/달성률)
# ──────────────────────────────────────────────────────────────────────────────
def _series_to_list_with_none(s: pd.Series) -> list:
    """NaN → None 변환(Plotly 호환), 숫자형으로 강제."""
    if not isinstance(s, pd.Series):
        s = pd.Series(s)
    s = pd.to_numeric(s, errors="coerce")
    return [None if pd.isna(v) else float(v) for v in s.tolist()]

def build_barline_fig(
    months: List[str],
    plan: pd.Series,
    actual_plot: pd.Series,
    diff_cum_plot: pd.Series,
    unit_left: str,           # "톤" 또는 "SET"
    title_left: str |  None=None,
    series_name: Optional[str]= None,         # "prod_ton" / "deli_set" (예측 시리즈 키)
    forecast_df: Optional[pd.DataFrame] = None,
    palette: Optional[dict] = None,
):
    palette = palette or _palette_for(series_name)
    x_labels = [to_yy_mm_label(m) for m in months]
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    # 계획(막대)
    fig.add_trace(go.Bar(
        x=x_labels, y=_series_to_list_with_none(plan), name="계획",
        marker_color=palette["plan"],
        marker_line=dict(color="#FFFFFF", width=1),
        opacity=0.9,
        hovertemplate=f"<b>계획</b><br>%{{x}}<br>값: %{{y:.1f}} {unit_left}<extra></extra>",
    ), secondary_y=False)

    # 실적(막대, 오늘 이후 NaN)
    fig.add_trace(go.Bar(
        x=x_labels, y=_series_to_list_with_none(actual_plot), name="실적",
        marker_color=palette["actual"],
        marker_line=dict(color="#FFFFFF", width=1),
        opacity=0.95,
        hovertemplate=f"<b>실적</b><br>%{{x}}<br>값: %{{y:.1f}} {unit_left}<extra></extra>",
    ), secondary_y=False)

    # 누계차(선, 우측축)
    fig.add_trace(go.Scatter(
        x=x_labels, y=_series_to_list_with_none(diff_cum_plot), name="누계차",
        mode="lines+markers", line=dict(color=palette["diff"], width=2.8, shape="spline"),
        marker=dict(size=7, symbol="diamond", line=dict(width=1, color="#FFFFFF")),
        hovertemplate=f"<b>누계차</b><br>%{{x}}<br>값: %{{y:.1f}} {unit_left}<extra></extra>",
    ), secondary_y=True)


    # 예측(현재월 포함, 점선 오버레이) — 왼쪽 축에 표시
    if forecast_df is not None and not forecast_df.empty:
        f = forecast_df[(forecast_df["series"] == series_name)].copy()
        if not f.empty:
            future_months = sorted(f["yyyymm"].astype(str).tolist(), key=month_sort_key)
            fx = [to_yy_mm_label(m) for m in future_months]
            fy = pd.to_numeric(f.set_index("yyyymm").loc[future_months, "pred_adj"], errors="coerce").fillna(0.0).values
            fig.add_trace(go.Scatter(
                x=fx, y=fy, name="예측(현재월 포함)",
                mode="lines+markers",
                line=dict(color=palette["forecast"], width=2.6, dash="dash", shape="spline"),
                marker=dict(size=7, symbol="triangle-up", line=dict(width=1, color="#FFFFFF")),
                hovertemplate=f"<b>예측</b><br>%{{x}}<br>값: %{{y:.1f}} {unit_left}<extra></extra>",
            ), secondary_y=False)

    fig.update_yaxes(title_text=unit_left, secondary_y=False)
    fig.update_yaxes(title_text=f"누계차({unit_left})", secondary_y=True)
    fig.update_layout(bargap=0.18)
    _apply_plotly_layout(fig, palette)
    return fig

def build_cum_rate_fig(
    months: List[str],
    plan_cum: pd.Series,
    actual_cum_plot: pd.Series,
    rate_cum_plot: pd.Series,
    left_ylabel: str,         # "생산"/"납품"
    unit_left: str,           # "톤"/"SET"
    title: Optional[str]=None,
    plan_until_today: bool =False,
    forecast_df: Optional[pd.DataFrame] = None,
    series_name: Optional[str] = None,
    palette: Optional[dict] = None,
):
    """누계(계획/실적) + 달성률(%) 복합 그래프."""
    palette = palette or _palette_for(series_name)
    x_labels = [to_yy_mm_label(m) for m in months]
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    forecast_rate_values = np.array([], dtype=float)

    # 실적 누계(영역+라인, 오늘 이후 NaN)
    fig.add_trace(go.Scatter(
        x=x_labels, y=_series_to_list_with_none(actual_cum_plot),
        name="실적 누계", mode="lines+markers",
        line=dict(color=palette["actual"], width=2.8, shape="spline"),
        marker=dict(size=7, symbol="circle", line=dict(width=1, color="#FFFFFF")),
        fill="tozeroy", fillcolor=palette["fill"],
        hovertemplate=f"<b>실적 누계</b><br>%{{x}}<br>누계: %{{y:.1f}} {unit_left}<extra></extra>",
    ), secondary_y=False)

    # 계획 누계(옵션: 오늘 이후 끊기)
    plan_cum_plot = plan_cum.copy()
    if plan_until_today:
        mask = mask_until_today(months)
        for i, m in enumerate(months):
            if not mask[i]:
                plan_cum_plot.loc[m] = np.nan

    fig.add_trace(go.Scatter(
        x=x_labels, y=_series_to_list_with_none(plan_cum_plot),
        name="계획 누계", mode="lines+markers",
        line=dict(color=palette["plan_line"], width=2.4, dash="dot", shape="spline"),
        marker=dict(size=7, symbol="square", line=dict(width=1, color="#FFFFFF")),
        hovertemplate=f"<b>계획 누계</b><br>%{{x}}<br>누계: %{{y:.1f}} {unit_left}<extra></extra>",
    ), secondary_y=False)

    # 달성률(오늘 이후 NaN)
    fig.add_trace(go.Scatter(
        x=x_labels, y=_series_to_list_with_none(rate_cum_plot),
        name="달성률", mode="lines+markers",
        line=dict(color=palette["rate"], width=2.4, dash="dash", shape="spline"),
        marker=dict(size=7, symbol="x", line=dict(width=1, color="#FFFFFF")),
        hovertemplate="<b>달성률</b><br>%{x}<br>%{y:.1f}%<extra></extra>",
    ), secondary_y=True)

    # 예측: 누계/달성률(현재월 포함)
    if forecast_df is not None and series_name is not None and not forecast_df.empty:
        f = forecast_df[(forecast_df["series"] == series_name)].copy()
        if not f.empty:
            future_months = sorted(f["yyyymm"].astype(str).tolist(), key=month_sort_key)
            fx = [to_yy_mm_label(m) for m in future_months]
            fvals = pd.to_numeric(f.set_index("yyyymm").loc[future_months, "pred_adj"], errors="coerce").fillna(0.0)

            last_actual_cum = float(pd.to_numeric(pd.Series(actual_cum_plot), errors="coerce").dropna().tail(1).values[0]) \
                              if pd.Series(actual_cum_plot).notna().any() else 0.0
            f_cum = fvals.cumsum() + last_actual_cum

            # 계획 누계: 미래월 인덱스가 없으면 마지막 값으로 연장(미래 계획이 없다고 가정)
            plan_cum_ext = plan_cum.copy()
            for lbl in future_months:
                if lbl not in plan_cum_ext.index:
                    plan_cum_ext.loc[lbl] = plan_cum_ext.iloc[-1] if len(plan_cum_ext) else 0.0
            plan_cum_ext = plan_cum_ext.sort_index(key=lambda idx: [month_sort_key(x) for x in idx])
            # 예측 구간 월과 분모 월을 정확히 맞춰 달성률(예측) 누락을 방지
            denom = pd.to_numeric(
                plan_cum_ext.reindex(future_months),
                errors="coerce"
            ).replace(0, np.nan)
            if denom.isna().all():
                denom = pd.Series([np.nan] * len(future_months), index=future_months, dtype=float)
            else:
                denom = denom.ffill().bfill()

            f_rate = (pd.Series(f_cum.values, index=future_months, dtype=float) / denom) * 100.0
            f_rate = f_rate.replace([np.inf, -np.inf], np.nan)
            forecast_rate_values = pd.to_numeric(f_rate, errors="coerce").to_numpy(dtype=float)

            fig.add_trace(go.Scatter(
                x=fx, y=f_cum.values, name="누계(예측)",
                mode="lines+markers", line=dict(color=palette["forecast"], width=2.6, dash="dash", shape="spline"),
                marker=dict(size=7, symbol="triangle-up", line=dict(width=1, color="#FFFFFF")),
                hovertemplate=f"<b>누계(예측)</b><br>%{{x}}<br>누계: %{{y:.1f}} {unit_left}<extra></extra>",
            ), secondary_y=False)

            fig.add_trace(go.Scatter(
                x=fx, y=f_rate.values, name="달성률(예측)",
                mode="lines+markers", line=dict(color=palette["rate_forecast"], width=2.2, dash="dot", shape="spline"),
                marker=dict(size=7, symbol="cross", line=dict(width=1, color="#FFFFFF")),
                hovertemplate="<b>달성률(예측)</b><br>%{x}<br>%{y:.1f}%<extra></extra>",
            ), secondary_y=True)

    # 우측축 범위(0~최대+10, 최소 상한 110)
    try:
        current_vals = pd.to_numeric(pd.Series(rate_cum_plot), errors="coerce").to_numpy(dtype=float)
        axis_vals = np.concatenate([current_vals, forecast_rate_values]) if forecast_rate_values.size else current_vals
        ymax = float(np.nanmax(axis_vals))
        if not np.isfinite(ymax):
            ymax = 100.0
    except Exception:
        ymax = 100.0

    fig.update_yaxes(title_text=f"{left_ylabel}({unit_left})", secondary_y=False)
    fig.update_yaxes(title_text="달성률(%)", range=[0, max(110, ymax + 10)], secondary_y=True)
    _apply_plotly_layout(fig, palette)
    return fig

# ──────────────────────────────────────────────────────────────────────────────
# 예측 실행 (세션 저장) — 현재월 포함
# ──────────────────────────────────────────────────────────────────────────────
def _filter_forecast_horizon_exclude_current(fore_df: pd.DataFrame, months_ahead: int) -> pd.DataFrame:
    """현재월은 제외하고 다음월부터 선택 구간의 마지막 월까지만 남긴다."""
    if fore_df is None or fore_df.empty:
        return pd.DataFrame(columns=["series","yyyymm","pred_raw","pred_adj"])
    months_ahead = max(0, int(months_ahead))
    cur_p = pd.Timestamp(TODAY).to_period("M")
    start_p = cur_p + 1
    end_p = cur_p + max(1, months_ahead)
    f = fore_df.copy()
    f["_p"] = pd.PeriodIndex(["20"+s.replace("_","-") for s in f["yyyymm"].astype(str)], freq="M")
    f = f[(f["_p"] >= start_p) & (f["_p"] <= end_p)].copy()
    f = f.drop(columns=["_p"])
    return f

if btn_forecast:
    st.session_state["forecast_generated"] = True
    horizon_days = _horizon_days_by_months(st.session_state["horizon_months"])
    horizon_label = _horizon_months_label(st.session_state["horizon_months"])
    try:
        preds = run_forecast_on_df(
            filtered,
            horizons_days=[horizon_days],
            train_months=st.session_state["train_months"],
            save=st.session_state["save_hist"],
            use_history_scale=st.session_state["use_history_scale"],
        )
    except Exception as e:
        st.session_state["forecast_status"] = "error"
        st.session_state["forecast_status_message"] = f"예측 실행 중 오류: {e}"
        preds = pd.DataFrame()

    if preds is not None and not preds.empty:
        filtered_preds = _filter_forecast_horizon_exclude_current(
            preds, st.session_state["horizon_months"]
        )
        st.session_state["forecast_df"] = filtered_preds
        # 간단 요약(사이드바 표시용)
        try:
            prod_rows = filtered_preds[filtered_preds["series"] == "prod_ton"]
            deli_rows = filtered_preds[filtered_preds["series"] == "deli_set"]
            prod_mean = pd.to_numeric(prod_rows["pred_adj"], errors="coerce").mean()
            deli_mean = pd.to_numeric(deli_rows["pred_adj"], errors="coerce").mean()
            summary = (
                f"모델: 선형회귀 | 예측기간: {horizon_label}(현재월 포함) | "
                f"학습기간: 최근 {st.session_state['train_months']}개월 | "
                f"예측 건수: 생산 {len(prod_rows)} / 납품 {len(deli_rows)} | "
                f"평균 예측: 생산 {format_num(prod_mean, 1)}톤 / 납품 {format_num(deli_mean, 1)}SET"
            )
        except Exception:
            summary = "모델: 선형회귀 | 예측 요약 계산 실패"
        st.session_state["forecast_summary"] = summary
        if filtered_preds.empty:
            st.session_state["forecast_status"] = "warning"
            st.session_state["forecast_status_message"] = "예측/전망 결과는 생성됐지만, 해당월 제외 조건으로 표시할 월이 없습니다."
        else:
            st.session_state["forecast_status"] = "success"
            st.session_state["forecast_status_message"] = f"예측 /전망 결과를 적용했습니다. ({horizon_label}부터, 해당월 제외)"
    else:
        st.session_state["forecast_summary"] = "예측 결과가 비어 있습니다."
        st.session_state["forecast_status"] = "warning"
        st.session_state["forecast_status_message"] = "예측 결과가 비어 있습니다."

# ──────────────────────────────────────────────────────────────────────────────
# 생산/납품 행렬 및 그래프
# ──────────────────────────────────────────────────────────────────────────────
def render_barline_block(title: str, matrix: pd.DataFrame, unit_left: str, series_name: str):
    st.markdown(f"### {title}")
    if matrix.empty:
        st.info("선택 조건에 해당하는 데이터가 없습니다.")
        return
col_left, col_right = st.columns(2, gap="large")

with col_left:
    prod_matrix = build_prod_matrix(filtered)
    year_title = ", ".join(selected_year_labels) if selected_year_labels else "전체"
    render_barline_block(f"{year_title} 셀가이드 월별 생산 현황", prod_matrix, "톤", "prod_ton")

    if not prod_matrix.empty:
        prod_kpi = kpi_prod_from_matrix(prod_matrix)
        kpi_items = [
            ("계획 합계", prod_kpi.get("계획_총합계", "-"), "톤"),
            ("실적 합계", prod_kpi.get("실적_총합계", "-"), "톤"),
            ("잔여생산량", prod_kpi.get("잔여조립량", "-"), "톤"),
            ("생산완료률", prod_kpi.get("조립완료률", "-"), "%"),
        ]
        st.markdown('<div class="kpi-grid">' + ''.join([
            f'<div class="kpi-card"><div class="kpi-title">{t}</div>'
            f'<div class="kpi-value">{v}</div><div class="kpi-sub">{u}</div></div>'
            for t, v, u in kpi_items
        ]) + '</div>', unsafe_allow_html=True)

        months = sorted(list(prod_matrix.columns), key=month_sort_key)
        plan   = prod_matrix.loc["계획", months].astype(float)
        actual = prod_matrix.loc["실적", months].astype(float)
        diff_cum = (actual.cumsum() - plan.cumsum()).astype(float)

        past_mask = mask_until_today(months)
        actual_plot   = actual.copy();   actual_plot[~past_mask] = np.nan
        diff_cum_plot = diff_cum.copy(); diff_cum_plot[~past_mask] = np.nan

        forecast_df = st.session_state.get("forecast_df")
        fig = build_barline_fig(
            months, plan, actual_plot, diff_cum_plot,
            unit_left="톤", series_name="prod_ton", title_left="생산",
            forecast_df=forecast_df, palette=_palette_for("prod_ton"),
        )
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("선택 조건에 해당하는 생산 데이터가 없습니다.")

with col_right:
    deli_matrix = build_deli_matrix(filtered)
    year_title = ", ".join(selected_year_labels) if selected_year_labels else "전체"
    render_barline_block(f"{year_title} 셀가이드 월별 납품 현황", deli_matrix, "SET", "deli_set")

    if not deli_matrix.empty:
        deli_kpi = kpi_deli_from_matrix(deli_matrix)
        kpi_items = [
            ("계획 납품", deli_kpi.get("계획_납품합계", "-"), "SET"),
            ("실적 납품", deli_kpi.get("실적_납품합계", "-"), "SET"),
            ("잔여납품량", deli_kpi.get("잔여납품량", "-"), "SET"),
            ("납품완료률", deli_kpi.get("납품완료률", "-"), "%"),
        ]
        st.markdown('<div class="kpi-grid">' + ''.join([
            f'<div class="kpi-card"><div class="kpi-title">{t}</div>'
            f'<div class="kpi-value">{v}</div><div class="kpi-sub">{u}</div></div>'
            for t, v, u in kpi_items
        ]) + '</div>', unsafe_allow_html=True)

        months = sorted(list(deli_matrix.columns), key=month_sort_key)
        plan   = deli_matrix.loc["계획", months].astype(float)
        actual = deli_matrix.loc["실적", months].astype(float)
        diff_cum = (actual.cumsum() - plan.cumsum()).astype(float)

        past_mask = mask_until_today(months)
        actual_plot   = actual.copy();   actual_plot[~past_mask] = np.nan
        diff_cum_plot = diff_cum.copy(); diff_cum_plot[~past_mask] = np.nan

        forecast_df = st.session_state.get("forecast_df")
        fig = build_barline_fig(
            months, plan, actual_plot, diff_cum_plot,
            unit_left="SET", series_name="deli_set",
            forecast_df=forecast_df, palette=_palette_for("deli_set")
        )
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("선택 조건에 해당하는 납품 데이터가 없습니다.")

st.markdown("※ 생산 계획 : 관리납품일 기준, 납품 계획 : 조립 PR발행 셀가이드의 관리납품일 기준")

# ──────────────────────────────────────────────────────────────────────────────
# 누계/달성률 추이 (+ 예측 누계/달성률 : 현재월 포함)
# ──────────────────────────────────────────────────────────────────────────────
st.markdown("#### 누계/달성률 추이")
col_tr_l, col_tr_r = st.columns(2, gap="large")

def plot_cum_rate(matrix: pd.DataFrame, left_ylabel: str, unit_left: str, series_name: str):
    """누계(계획/실적) + 달성률(오늘 이후 NaN) 2축 그래프."""
    if matrix is None or matrix.empty:
        st.info("데이터가 없어 추이 그래프를 표시할 수 없습니다.")
        return
    months = sorted([c for c in matrix.columns if isinstance(c, str)], key=month_sort_key)
    if not months:
        st.info("표시할 월 데이터가 없습니다.")
        return

    plan   = matrix.loc["계획", months].astype(float).fillna(0)
    actual = matrix.loc["실적", months].astype(float).fillna(0)
    
    plan_cum   = plan.cumsum()
    actual_cum = actual.cumsum()

    past_mask = mask_until_today(months)
    actual_cum_plot = actual_cum.copy(); actual_cum_plot[~past_mask] = np.nan
    rate_cum  = (actual_cum / plan_cum.replace(0, np.nan) * 100)
    rate_cum_plot = rate_cum.copy(); rate_cum_plot[~past_mask] = np.nan

    forecast_df = st.session_state.get("forecast_df")
    fig = build_cum_rate_fig(
        months, plan_cum, actual_cum_plot, rate_cum_plot,
        left_ylabel=left_ylabel, unit_left=unit_left, title=f"{left_ylabel} 누계/달성률 추이",
        forecast_df=forecast_df, series_name=series_name, palette=_palette_for(series_name),
    )
    st.plotly_chart(fig, use_container_width=True)

col_tr_l, col_tr_r = st.columns(2, gap="large")
with col_tr_l:
    plot_cum_rate(prod_matrix, "생산", "톤", "prod_ton")
with col_tr_r:
    plot_cum_rate(deli_matrix, "납품", "SET", "deli_set")

# ──────────────────────────────────────────────────────────────────────────────
# 상세 테이블
# ──────────────────────────────────────────────────────────────────────────────
st.markdown("### 셀가이드 상세 테이블")

COL_MAP = {
    "프로젝트": "프로젝트",
    "블록": "블록",
    "관리납품일": "관리납품일",
    "12주EPC착수(블록)": "12주EPC착수일(블록)",
    "협력사명": "제작처",
    "납품처": "납품처",
    "중량합계(A)": "중량_Kg",
    "셀가이드개수": "수량_EA",
    "조립착수(실적)": "조립착수(실적)",
    "조립완료(실적)": "조립완료(실적)",
    "도장여부":"도장",
    "도장착수(실적)": "도장착수(실적)",
    "도장완료(실적)": "도장완료(실적)",
    "납품/선적일": "납품/선적일",
}
missing = [src for src in COL_MAP.keys() if src not in filtered.columns]
if missing:
    st.warning("다음 컬럼이 원본 데이터에 없어 제외됩니다: " + ", ".join(missing))
present_map = {src: dst for src, dst in COL_MAP.items() if src in filtered.columns}

df_detail = filtered[list(present_map.keys())].rename(columns=present_map)

# 날짜 표준 포맷(YYYY-MM-DD)
for dc in ["관리납품일", "12주EPC착수일(블록)", "납품/선적일", "조립착수(실적)", "조립완료(실적)", "도장착수(실적)", "도장완료(실적)"]:
    if dc in df_detail.columns:
        df_detail[dc] = pd.to_datetime(df_detail[dc], errors="coerce").dt.strftime("%Y-%m-%d")

# 중량 정수 콤마
if "중량_Kg" in df_detail.columns:
    w = pd.to_numeric(df_detail["중량_Kg"], errors="coerce")
    df_detail["중량_Kg"] = w.map(lambda v: f"{int(v):,}" if pd.notna(v) else "")

st.dataframe(df_detail, use_container_width=True, hide_index=True)
st.caption(f"행 수: {len(df_detail):,} · 컬럼 수: {df_detail.shape[1]}")


# ──────────────────────────────────────────────────────────────────────────────
# PR 미발행/지연 현황(간단 버전: 내부 로직 이미 step_5/6/7에 있음)
# ──────────────────────────────────────────────────────────────────────────────
st.markdown("#### 조립/도장 PR 미발행 및 미납품 현황")

def _fmt_dates(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    out = df.copy()
    for c in cols:
        if c in out.columns:
            out[c] = pd.to_datetime(out[c], errors="coerce").dt.strftime("%Y-%m-%d")
    return out

def _is_blank_series(s: pd.Series) -> pd.Series:
    """빈값 판정: datetime → isna(), 그 외 → (NaN/공백/'NaT')."""
    if pd.api.types.is_datetime64_any_dtype(s):
        return s.isna()
    return s.isna() | (s.astype(str).str.strip().isin(["", "NaT"]))

limit_30 = TODAY + timedelta(days=30)
mng_date = pd.to_datetime(filtered.get("관리납품일"), errors="coerce").dt.date if "관리납품일" in filtered.columns else pd.Series([None]*len(filtered), index=filtered.index)

# ① 조립 PR 미발행(관리납품일 ≤ +30 & 조립P/R확정일 결측)
col_pr_a = "조립P/R확정일"
mask_assem_due = (mng_date.notna()) & (mng_date <= limit_30)
assem_pr_missing = _is_blank_series(filtered[col_pr_a]) if col_pr_a in filtered.columns else pd.Series(False, index=filtered.index)
df_assem = filtered.loc[mask_assem_due & assem_pr_missing, ["프로젝트", "블록", "관리납품일", "협력사명"]].copy()
df_assem = df_assem.rename(columns={"협력사명": "제작처"})
df_assem = _fmt_dates(df_assem, ["관리납품일"])

# ② 도장 PR 미발행(관리납품일 ≤ +30 & 도장여부==1 & 도장PR1/2 결측)
do_col_flag = "도장여부" if "도장여부" in filtered.columns else ("도장" if "도장" in filtered.columns else None)
coat_flag = pd.to_numeric(filtered[do_col_flag], errors="coerce").fillna(0).astype(int) if do_col_flag else pd.Series(0, index=filtered.index)
mask_paint_due = (mng_date.notna()) & (mng_date <= limit_30) & (coat_flag == 1)
pr1 = filtered["도장P/R확정일1"] if "도장P/R확정일1" in filtered.columns else pd.Series(pd.NaT, index=filtered.index)
pr2 = filtered["도장P/R확정일2"] if "도장P/R확정일2" in filtered.columns else pd.Series(pd.NaT, index=filtered.index)
paint_pr_missing = _is_blank_series(pr1) & _is_blank_series(pr2)
df_paint = filtered.loc[mask_paint_due & paint_pr_missing, ["프로젝트", "블록", "관리납품일", "협력사명"]].copy()
df_paint = df_paint.rename(columns={"협력사명": "제작처"})
df_paint = _fmt_dates(df_paint, ["관리납품일"])

# ③ 납품 지연(관리납품일 ≤ 조회일 & '납품/선적일' 결측)
ship_col = "납품/선적일"
mask_delay = (mng_date.notna()) & (mng_date <= TODAY)
ship_missing = _is_blank_series(filtered[ship_col]) if ship_col in filtered.columns else pd.Series(False, index=filtered.index)
cols_delay = ["프로젝트", "블록", "관리납품일", "협력사명", "납품처", "조립완료(실적)", "조립착수(실적)"]
existing_delay_cols = [c for c in cols_delay if c in filtered.columns]
df_delay = filtered.loc[mask_delay & ship_missing, existing_delay_cols].copy()
df_delay = df_delay.rename(columns={"협력사명": "제작처", "조립완료(실적)": "조립실적(완료)", "조립착수(실적)": "조립실적(착수)"})
df_delay = _fmt_dates(df_delay, ["관리납품일", "조립실적(완료)", "조립실적(착수)"])

c1, c2, c3 = st.columns(3, gap="large")
with c1:
    st.markdown("##### 조립 PR 미발행")
    st.dataframe(df_assem.reset_index(drop=True), use_container_width=True, hide_index=True)
    st.caption(f"조립PR 미발행수: {len(df_assem)}")
with c2:
    st.markdown("##### 도장 PR 미발행")
    st.dataframe(df_paint.reset_index(drop=True), use_container_width=True, hide_index=True)
    st.caption(f"도장PR 미발행수: {len(df_paint)}")
with c3:
    st.markdown("##### 미납품 셀가이드 현황")
    st.dataframe(df_delay.reset_index(drop=True), use_container_width=True, hide_index=True)
    st.caption(f"미납품 셀가이드: {len(df_delay)}")

st.markdown("※ PR발행 점검 기준 : 조회일 + 30일까지 관리납품일 셀가이드")
st.markdown("※ 미납품 셀가이드  기준 : 조회일까지 관리납품일 셀가이드")

# ──────────────────────────────────────────────────────────────────────────────
# 저장 — 조회 결과(result) + 상세(detail) 2시트 엑셀
# ──────────────────────────────────────────────────────────────────────────────

if btn_save:
    df_to_save = st.session_state.get("filtered_df", pd.DataFrame())
    if df_to_save.empty:
        st.warning("저장할 결과가 없습니다. 먼저 조회 조건을 확인해주세요.")
    else:
        OUT_DIR.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        years_tag = "_".join([y.replace("년", "") for y in selected_year_labels]) or "all"
        if not supplier_multi:
            supplier_tag = "all"
        elif len(supplier_multi) <= 3:
            supplier_tag = "-".join(s.replace("/", "_") for s in supplier_multi)
        else:
            supplier_tag = f"multi{len(supplier_multi)}"
        fname = f"조회결과_{years_tag}_{supplier_tag}_{ts}.xlsx"
        xlsx_path = OUT_DIR / fname
        with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
            df_to_save.to_excel(writer, index=False, sheet_name="result")
            df_detail.to_excel(writer, index=False, sheet_name="detail")
        st.success(f"엑셀 저장 완료: {xlsx_path}")
        st.balloons()
