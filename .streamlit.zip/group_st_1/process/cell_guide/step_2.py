# -*- coding: utf-8 -*-
"""
step_2.py — MySQL에서 원천 데이터 로드 → 정제 → 엑셀 저장 (리뷰/주석 확장판)
──────────────────────────────────────────────────────────────────────────────
목적
  • MySQL(DB)에서 2개 연도 테이블을 합쳐(UNION) 표준화된 DataFrame으로 변환.
  • 날짜/텍스트 컬럼 정제 및 시각화/분석 단계에서 쓰기 좋은 컬럼명으로 재정의.
  • 최종 결과를 공유 폴더(OUT_DIR)에 날짜 스탬프를 붙여 Excel로 저장.

핵심 포인트(운영 관점)
  • ini 파싱은 “아주 단순”하므로 주석/섹션 미지원(= 기입 형식 엄수).
  • 포트 키는 기존 코드 호환을 위해 'post'를 우선 존중(※ 일반적 'port'가 아님).
    - 다만, 안전성을 위해 'port'도 허용(둘 다 없으면 3306 사용).
  • 일부 원천은 “첫 행에 컬럼명이 데이터로 들어있는” 경우가 있어 1행을 헤더로 재지정.
  • '셀가이드개수'는 'P/R/_P/O품목개수'에서 슬래시 앞 숫자만 파생.
  • OUT_DIR 정리 시, 접두어/확장자 이중 확인으로 과삭제(오탑) 방지.

출력 예시
  • \\서버\공유\...\baechaehong\셀가이드_계획_실적_data_YYYYMMDD.xlsx
──────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

import os
from datetime import datetime
from typing import Dict, Optional, List
from urllib.parse import quote_plus

import pandas as pd
from sqlalchemy import create_engine, text

from step_1 import OUT_DIR  # 네트워크 공유 경로(Path). step_1에서 준비됨.

# ──────────────────────────────────────────────────────────────────────────────
# 설정
# ──────────────────────────────────────────────────────────────────────────────

# 오늘 날짜(파일명 스탬프용)
today = datetime.today().strftime("%Y%m%d")


# 원천에서 날짜로 취급할 컬럼 목록(원본 명칭 기준: 개행 \n 포함)
DATE_COLUMNS: List[str] = [
    "관리납품일", "12주EPC\n착수(블록)", "납품요청일", "조립P/R\n확정일",
    "조립P/O\n확정일", "조립착수\n(계획)", "조립완료\n(계획)", "조립착수\n(실적)",
    "조립완료\n(실적)", "도장P/R\n확정일1", "도장P/O\n생성일1", "도장P/R\n확정일2",
    "도장P/O\n생성일2", "도장착수\n(계획)", "도장완료\n(계획)", "도장착수\n(실적)",
    "도장완료\n(실적)", "납품/선적\n예정일", "납품/선적일",
]

# 대시보드/분석에서 쓰기 좋은 표준 컬럼명 (원본 컬럼 순서에 맞춰 매핑)
STANDARD_COLUMNS: List[str] = [
    "No", "프로젝트", "블록", "STAGE", "관리납품일", "12주EPC착수(블록)",
    "납품처", "납품요청장소", "납품요청일", "조립P/R확정일", "조립P/O확정일",
    "중량합계(A)", "P/R중량합계(B)", "중량차이(A-B)", "P/O중량", "P/R/_P/O품목개수",
    "협력사", "협력사명", "조립착수(계획)", "조립완료(계획)", "조립착수(실적)", "조립완료(실적)",
    "도장여부", "도장블록1", "도장P/R확정일1", "도장P/O생성일1", "도장블록2", "도장P/R확정일2",
    "도장P/O생성일2", "도장착수(계획)", "도장완료(계획)", "도장착수(실적)", "도장완료(실적)",
    "납품/선적예정일", "납품/선적일", "입고증", "반출", "반출내용", "A2코드",
]

# 협력사명 정규화 매핑(리포트 표기 통일)
SUPPLIER_NAME_MAP: Dict[str, str] = {
    "금강중공업": "금강",
    "신영기업": "신영",
    "주식회사 하진": "하진",
}


# ──────────────────────────────────────────────────────────────────────────────
# 유틸: 설정/연결/정제
# ──────────────────────────────────────────────────────────────────────────────

def create_db_engine():
    """SQLAlchemy 엔진 생성 (PyMySQL 드라이버).
    - pool_pre_ping=True: 커넥션 유휴 시에도 헬스체크로 끊김 감지
    """

    db_user = os.getenv("DB_USER","root")
    password = os.getenv("DB_PASSWORD")
    db_host = os.getenv("DB_HOST", "60.100.164.182")
    db_port = os.getenv("DB_PORT", "3306")
    database = os.getenv("DB_NAME", "배채홍_db")

    missing = [k for k, v in {
        "DB_USER": db_user,
        "DB_PASSWORD": password,
        "DB_HOST": db_host,
        "DB_NAME": database,
    }.items() if not v]
    if missing:
        raise EnvironmentError(
            "환경변수 DB 설정이 누락되었습니다: " + ", ".join(missing) + "\n"
            " - 필요: DB_USER, DB_PASSWORD, DB_HOST, DB_NAME\n"
            " - 선택: DB_PORT (기본 3306)"
        )

    # URL 인코딩(특수문자 비밀번호 대응)
    pw_escaped = quote_plus(str(password))
    url = f"mysql+pymysql://{db_user}:{pw_escaped}@{db_host}:{db_port}/{database}?charset=utf8mb4"
    engine = create_engine(url, pool_pre_ping=True)
    return engine


def _try_union_two_tables(engine) -> pd.DataFrame:
    """연속 연도 3개 테이블을 UNION으로 병합.
    - 원본 의도: `24년_셀가이드_data` ∪ `25년_셀가이드_data` ∪ `26년_셀가이드_data`
    - 스키마 동일 가정.
    - UNION 자체가 중복 제거지만, pandas 레벨에서도 drop_duplicates()로 이중 방어.
    - 일부 원천은 '1행이 헤더' 케이스 → 1행을 컬럼으로 올리고 제거.
    """
    sql = text("""
        SELECT * FROM (
            SELECT * FROM `24년_셀가이드_data`
            UNION
            SELECT * FROM `25년_셀가이드_data`
            UNION
            SELECT * FROM `26년_셀가이드_data`
        ) AS merged
    """)
    df = pd.read_sql(sql, engine)

    # (안전) pandas 레벨 중복 제거
    df = df.drop_duplicates()

    # 1행 헤더 케이스 처리
    #  - df.iloc[0]이 진짜 데이터인 경우도 있을 수 있으므로, 필요시 아래 구간을 주석 처리 가능
    df.columns = df.iloc[0]
    df = df.drop(df.index[0]).reset_index(drop=True)

    return df


def load_merged_data(engine) -> pd.DataFrame:
    """DB에서 원천 로드 → 중복/헤더 처리"""
    return _try_union_two_tables(engine)


def convert_date_columns(df: pd.DataFrame, date_cols: List[str]) -> pd.DataFrame:
    """날짜 문자열 컬럼을 YYYY-MM-DD로 통일.
    - 파싱 실패는 NaT → 최종 문자열 NaN 처리
    - 시간(HH:MM:SS)은 일자로 절삭(요건상 일자만 활용)
    """
    for col in date_cols:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce").dt.strftime("%Y-%m-%d")
    return df


def _derive_count_from_slash_prefix(val) -> Optional[int]:
    """'P/R/_P/O품목개수'에서 슬래시 앞 정수 추출.
    - 예) '12 / 34' → 12,  '7/9' → 7
    - 그 외(형식 불일치)는 None
    """
    if isinstance(val, str) and "/" in val:
        left = val.split("/", 1)[0].strip()
        if left.isdigit():
            return int(left)
    return None


def _cleanup_supplier_name(s: str) -> str:
    """협력사명 클렌징: 공백→NaN→'미정', 매핑 적용."""
    if s is None:
        return "미정"
    s2 = str(s).strip()
    if s2 == "":
        return "미정"
    return SUPPLIER_NAME_MAP.get(s2, s2)


def _safe_remove_old_outputs():
    """기존 산출물 정리: 접두어/확장자 이중 확인으로 안전하게 삭제."""
    if not OUT_DIR.exists():
        return
    for file in os.listdir(OUT_DIR):
        # 과삭제 방지: 반드시 우리가 생성한 패턴만 제거
        if file.startswith("셀가이드_계획_실적_data") and file.endswith(".xlsx"):
            try:
                os.remove(os.path.join(OUT_DIR, file))
                print("기존 파일 삭제:", file)
            except Exception as e:
                print("기존 파일 삭제 실패:", file, "|", e)


# ──────────────────────────────────────────────────────────────────────────────
# 메인 파이프라인
# ──────────────────────────────────────────────────────────────────────────────

def main() -> pd.DataFrame:
    """DB 연결 → 데이터 로드/정제 → 엑셀 저장까지 전체 파이프라인 실행.
    반환: 정제 완료 DataFrame (대시보드/분석에서 바로 사용)
    """
    engine = create_db_engine()
    df: Optional[pd.DataFrame] = None

    try:
        # 1) 연결성 사전 점검(실패 시 즉시 원인 노출)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        print("[OK] DB 연결 확인")

        # 2) 데이터 로드 & 중복/헤더 처리
        df = load_merged_data(engine)
        if df is None or df.empty:
            print("[WARN] DB에서 가져온 데이터가 비었습니다.")
            return pd.DataFrame()

        # 3) 날짜 컬럼 표준화(원본 컬럼명 기준)
        df = convert_date_columns(df, DATE_COLUMNS)

        # 4) 컬럼명 표준 재정의(대시보드/분석 규격)
        if len(df.columns) != len(STANDARD_COLUMNS):
            # 컬럼 개수가 다르면 차후 단계가 깨질 수 있으므로 즉시 경고
            print(f"[WARN] 예상 컬럼 수({len(STANDARD_COLUMNS)}) != 실제({len(df.columns)}). "
                  f"원본 스키마 변경 여부 확인 필요.")
        # 가능한 범위까지 앞쪽에서 매핑(남는 컬럼은 유지)
        df.columns = list(STANDARD_COLUMNS[:len(df.columns)])

        # 5) 파생 컬럼: '셀가이드개수'
        if "P/R/_P/O품목개수" in df.columns:
            df["셀가이드개수"] = df["P/R/_P/O품목개수"].apply(_derive_count_from_slash_prefix)
        else:
            df["셀가이드개수"] = None  # 컬럼 부재 대비

        # 6) 협력사명 정리(리포트 표기 통일)
        if "협력사명" in df.columns:
            df["협력사명"] = df["협력사명"].map(_cleanup_supplier_name)
        else:
            print("[WARN] '협력사명' 컬럼 없음 → 클렌징 스킵")

        # 7) (옵션) 주요 수치형 컬럼 안전 캐스팅
        #    - downstream(집계/그래프)에서의 에러 확률을 줄이기 위해 숫자 변환
        for num_col in ["중량합계(A)", "P/R중량합계(B)", "중량차이(A-B)", "P/O중량"]:
            if num_col in df.columns:
                df[num_col] = pd.to_numeric(df[num_col], errors="coerce")

        # (디버깅) 현재 DF 상태(Log)
        print(df.head(3))
        print(f"[INFO] 로우 수: {len(df):,}, 컬럼 수: {df.shape[1]}")

        # 8) 기존 산출물 정리(선택): 최신본만 유지하고 싶을 때 사용
        _safe_remove_old_outputs()

        # 9) 새 파일 저장
        OUT_DIR.mkdir(parents=True, exist_ok=True)
        out_path = OUT_DIR / f"셀가이드_계획_실적_data_{today}.xlsx"
        df.to_excel(out_path, index=False)
        print("[OK] 엑셀 저장 완료:", out_path)

    except Exception as e:
        # 운영에서는 로깅 프레임워크 사용 권장(여기선 콘솔 출력)
        print("[ERROR] step_2 파이프라인 실패:", e)

    # 다운스트림(대시보드/분석) 연계를 위해 df 반환(실패 시 None/Empty DataFrame)
    return df if df is not None else pd.DataFrame()


if __name__ == "__main__":
    # 단독 실행 시 전체 파이프라인 수행
    _ = main()
