# -*- coding: utf-8 -*-
"""
safety_daily_report.py
현장 점검 및 조치 사항 - Streamlit 시각화 대시보드 (MySQL 연동)

실행: streamlit run safety_daily_report.py
비밀번호 환경변수: set DB_PASSWORD=<password>  (Windows)
                   export DB_PASSWORD=<password> (Linux/Mac)
"""

import base64
import io
import os
from datetime import datetime

import pandas as pd
import pymysql
import streamlit as st
import plotly.express as px
from PIL import Image

# ─── DB 연결 설정 ─────────────────────────────────────────────

DB_HOST = "60.100.164.182"
DB_USER = "root"
DB_PASSWORD_ENV = os.environ.get("AS_DB_PASSWORD", "")   # 환경변수 우선

# ─── 상수 ────────────────────────────────────────────────────

CMP_MARK = "#cmp="

# MySQL 컬럼명(공백 포함) → 앱 표준 키(공백 없음)
MYSQL_COL_MAP = {
    "점검 내용": "점검내용",
    "점검 사진": "점검사진",
    "조치 내용": "조치내용",
    "조치 사진": "조치사진",
}

DISPLAY_COLS = [
    "NO", "협력사", "호선", "블록", "구분", "점검자",
    "점검일", "위반유형", "점검내용", "조치일", "조치내용", "조치완료",
]

# ─── 유틸 ────────────────────────────────────────────────────

def strip_cmp_marker(s: str) -> str:
    """data URL 뒤에 붙은 압축 마커(#cmp=...) 제거"""
    idx = s.find(CMP_MARK)
    return s[:idx] if idx >= 0 else s


def bytes_to_data_url(val) -> str:
    """MySQL LONGBLOB(bytes) → data:image/jpeg;base64,... 변환"""
    if not val:
        return ""
    try:
        b = bytes(val) if not isinstance(val, (bytes, bytearray)) else val
        return "data:image/jpeg;base64," + base64.b64encode(b).decode("ascii")
    except Exception:
        return ""


def data_url_to_pil(data_url: str) -> "Image.Image | None":
    """data URL → PIL Image. 실패 또는 빈 값이면 None 반환."""
    clean = strip_cmp_marker(str(data_url or ""))
    if not clean.startswith("data:image"):
        return None
    try:
        _, b64 = clean.split(",", 1)
        return Image.open(io.BytesIO(base64.b64decode(b64)))
    except Exception:
        return None


def fmt_date_col(series: pd.Series) -> pd.Series:
    return series.dt.strftime("%Y-%m-%d").where(series.notna(), "")


def _finalize_df(df: pd.DataFrame) -> pd.DataFrame:
    """날짜 변환 · 조치완료 컬럼 · 문자열 공백 정리 공통 처리"""
    if df.empty:
        return df

    # MySQL 컬럼명 정규화 (공백 유무 혼재 대응)
    df = df.rename(columns=MYSQL_COL_MAP)

    # LONGBLOB bytes → data URL (MySQL에서 온 경우)
    for col in ("점검사진", "조치사진"):
        if col in df.columns:
            df[col] = df[col].apply(
                lambda v: bytes_to_data_url(v) if isinstance(v, (bytes, bytearray, memoryview))
                else (str(v) if v else "")
            )

    # 날짜 변환
    for col in ("점검일", "조치일"):
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")

    # 조치완료 여부
    df["조치완료"] = df["조치일"].notna()

    # pandas 3.0.1: include=["object","str"]
    str_cols = df.select_dtypes(include=["object", "str"]).columns
    for c in str_cols:
        df[c] = df[c].apply(lambda v: v.strip() if isinstance(v, str) else v)

    return df


@st.cache_data(show_spinner=False, ttl=300)   # 5분마다 자동 갱신
def load_from_mysql(host: str, user: str, password: str,
                    database: str, table: str) -> pd.DataFrame:
    """MySQL에서 전체 데이터를 읽어 DataFrame으로 반환 (5분 캐시)"""
    conn = pymysql.connect(
        host=host, user=user, password=password,
        database=database, charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
    )
    try:
        df = pd.read_sql(f"SELECT * FROM `{table}`", conn)
    finally:
        conn.close()
    return _finalize_df(df)


# ─── 페이지 설정 ──────────────────────────────────────────────

st.set_page_config(
    page_title="현장 점검 대시보드",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("□ 현장 점검 및 조치 사항 대시보드")

# ─── 사이드바 ─────────────────────────────────────────────────

with st.sidebar:
    # ── DB 연결 설정 ──────────────────────────────────────────
    st.header("🗄️ DB 연결 설정")

    db_name    = st.text_input("Database", value="")
    table_name = st.text_input("Table",    value="")

    # 비밀번호: 환경변수 우선 → 없으면 직접 입력
    if DB_PASSWORD_ENV:
        db_password = DB_PASSWORD_ENV
        st.caption("🔑 비밀번호: 환경변수(`DB_PASSWORD`) 적용됨")
    else:
        db_password = st.text_input("Password", type="password",
                                    placeholder="DB_PASSWORD 환경변수 또는 직접 입력")

    if st.button("🔄 새로고침", use_container_width=True):
        load_from_mysql.clear()
        st.rerun()

    st.divider()

    # ── 필터 ─────────────────────────────────────────────────
    st.header("🔍 필터")

    # (필터는 데이터 로드 후 아래에서 채워짐 — placeholder)
    filter_placeholder = st.empty()

# ─── MySQL 자동 로드 ──────────────────────────────────────────

if not db_name or not table_name:
    st.info("사이드바에서 **Database**와 **Table** 이름을 입력하세요.")
    st.stop()

if not db_password:
    st.warning("사이드바에서 **Password**를 입력하거나 `DB_PASSWORD` 환경변수를 설정하세요.")
    st.stop()

with st.spinner("MySQL에서 데이터 로드 중..."):
    try:
        df_raw = load_from_mysql(DB_HOST, DB_USER, db_password, db_name, table_name)
    except Exception as e:
        st.error(f"MySQL 연결 실패: {e}")
        st.stop()

if df_raw.empty:
    st.warning("테이블에 데이터가 없습니다.")
    st.stop()

# ─── 필터 위젯 (데이터 로드 후 동적 생성) ────────────────────

with filter_placeholder.container():
    # 날짜 범위
    date_range = None
    if "점검일" in df_raw.columns and df_raw["점검일"].notna().any():
        valid_d = df_raw["점검일"].dropna()
        min_d, max_d = valid_d.min().date(), valid_d.max().date()
        date_range = st.date_input(
            "점검일 범위", value=(min_d, max_d), min_value=min_d, max_value=max_d
        )

    partners   = sorted(df_raw["협력사"].dropna().unique())  if "협력사"   in df_raw.columns else []
    divisions  = sorted(df_raw["구분"].dropna().unique())    if "구분"     in df_raw.columns else []
    vtypes     = sorted(df_raw["위반유형"].dropna().unique()) if "위반유형" in df_raw.columns else []

    sel_partners  = st.multiselect("협력사",   options=partners)
    sel_divisions = st.multiselect("구분",     options=divisions)
    sel_vtypes    = st.multiselect("위반유형", options=vtypes)
    sel_status    = st.radio("조치 여부", ["전체", "조치완료", "미조치"], horizontal=True)

    st.divider()
    st.success(f"총 **{len(df_raw):,}건** 로드 완료")
    st.caption(f"호스트: {DB_HOST}  \nDB: `{db_name}`  \nTable: `{table_name}`")

# ─── 필터 적용 ────────────────────────────────────────────────

df = df_raw.copy()

if date_range and len(date_range) == 2 and "점검일" in df.columns:
    s, e = pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1])
    df = df[df["점검일"].isna() | df["점검일"].between(s, e)]

if sel_partners  and "협력사"   in df.columns: df = df[df["협력사"].isin(sel_partners)]
if sel_divisions and "구분"     in df.columns: df = df[df["구분"].isin(sel_divisions)]
if sel_vtypes    and "위반유형" in df.columns: df = df[df["위반유형"].isin(sel_vtypes)]

if sel_status == "조치완료":
    df = df[df["조치완료"]]
elif sel_status == "미조치":
    df = df[~df["조치완료"]]

if df.empty:
    st.warning("필터 조건에 맞는 데이터가 없습니다.")
    st.stop()

# ─── 탭 ──────────────────────────────────────────────────────

tab1, tab2, tab3 = st.tabs(["📊 대시보드", "📋 상세 목록", "🖼️ 이미지 갤러리"])

# ════════════════════════════════════════════════════════════
# TAB 1 — 대시보드
# ════════════════════════════════════════════════════════════
with tab1:
    total     = len(df)
    completed = int(df["조치완료"].sum())
    pending   = total - completed
    rate      = round(completed / total * 100) if total > 0 else 0

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("총 점검 건수", f"{total:,}건")
    k2.metric("조치 완료",   f"{completed:,}건")
    k3.metric("미조치",      f"{pending:,}건",
              delta=f"-{pending}건" if pending else None, delta_color="inverse")
    k4.metric("조치 완료율", f"{rate}%")

    st.divider()

    c_l, c_r = st.columns(2)

    with c_l:
        st.subheader("위반유형별 건수")
        if "위반유형" in df.columns:
            vt = df["위반유형"].value_counts().reset_index()
            vt.columns = ["위반유형", "건수"]
            fig = px.bar(vt, x="건수", y="위반유형", orientation="h",
                         color="건수", color_continuous_scale="Blues", text="건수")
            fig.update_traces(textposition="outside")
            fig.update_layout(height=360, yaxis={"categoryorder": "total ascending"},
                              showlegend=False, coloraxis_showscale=False,
                              margin=dict(l=0, r=30, t=20, b=0))
            st.plotly_chart(fig, use_container_width=True)

    with c_r:
        st.subheader("협력사별 건수")
        if "협력사" in df.columns:
            pc = df["협력사"].value_counts().reset_index()
            pc.columns = ["협력사", "건수"]
            fig2 = px.bar(pc, x="협력사", y="건수",
                          color="건수", color_continuous_scale="Greens", text="건수")
            fig2.update_traces(textposition="outside")
            fig2.update_layout(height=360, showlegend=False, coloraxis_showscale=False,
                               margin=dict(l=0, r=0, t=20, b=0))
            st.plotly_chart(fig2, use_container_width=True)

    c_l2, c_r2 = st.columns(2)

    with c_l2:
        st.subheader("점검일별 건수 추이")
        if "점검일" in df.columns and df["점검일"].notna().any():
            sub = df.dropna(subset=["점검일"])
            ts = sub.groupby(sub["점검일"].dt.date).size().reset_index(name="건수")
            ts.columns = ["점검일", "건수"]
            fig3 = px.line(ts, x="점검일", y="건수", markers=True)
            fig3.update_layout(height=300, margin=dict(l=0, r=0, t=20, b=0))
            st.plotly_chart(fig3, use_container_width=True)

    with c_r2:
        st.subheader("구분별 비율 (안전 / 품질)")
        if "구분" in df.columns:
            dc = df["구분"].value_counts().reset_index()
            dc.columns = ["구분", "건수"]
            fig4 = px.pie(dc, names="구분", values="건수", hole=0.5,
                          color_discrete_sequence=px.colors.qualitative.Pastel)
            fig4.update_layout(height=300, margin=dict(l=0, r=0, t=20, b=0))
            st.plotly_chart(fig4, use_container_width=True)

    if "협력사" in df.columns and "위반유형" in df.columns:
        st.subheader("협력사 × 위반유형 히트맵")
        pivot = (
            df.groupby(["협력사", "위반유형"]).size()
            .reset_index(name="건수")
            .pivot(index="협력사", columns="위반유형", values="건수")
            .fillna(0).astype(int)
        )
        fig5 = px.imshow(pivot, text_auto=True, aspect="auto",
                         color_continuous_scale="YlOrRd")
        fig5.update_layout(height=max(200, len(pivot) * 52 + 80),
                           coloraxis_showscale=False,
                           margin=dict(l=0, r=0, t=20, b=0))
        st.plotly_chart(fig5, use_container_width=True)

# ════════════════════════════════════════════════════════════
# TAB 2 — 상세 목록
# ════════════════════════════════════════════════════════════
with tab2:
    st.subheader(f"점검 목록 ({len(df):,}건)")

    show_cols = [c for c in DISPLAY_COLS if c in df.columns]
    df_disp = df[show_cols].copy()
    for col in ("점검일", "조치일"):
        if col in df_disp.columns:
            df_disp[col] = fmt_date_col(df[col])

    st.dataframe(
        df_disp,
        use_container_width=True,
        height=520,
        column_config={
            "NO":    st.column_config.NumberColumn("NO", width="small"),
            "조치완료": st.column_config.CheckboxColumn("조치완료", width="small"),
        },
    )

    csv = df_disp.to_csv(index=False, encoding="utf-8-sig")
    st.download_button(
        "⬇️ CSV 다운로드", data=csv,
        file_name=f"현장점검_{datetime.now().strftime('%Y%m%d')}.csv",
        mime="text/csv",
    )

# ════════════════════════════════════════════════════════════
# TAB 3 — 이미지 갤러리
# ════════════════════════════════════════════════════════════
with tab3:
    st.subheader("점검 / 조치 사진 갤러리")

    HAS_IMG1 = "점검사진" in df.columns
    HAS_IMG2 = "조치사진" in df.columns

    if not HAS_IMG1 and not HAS_IMG2:
        st.info("이미지 컬럼이 없습니다.")
    else:
        def _has_img(val):
            return isinstance(val, str) and val.startswith("data:image")

        mask = pd.Series(False, index=df.index)
        if HAS_IMG1: mask |= df["점검사진"].apply(_has_img)
        if HAS_IMG2: mask |= df["조치사진"].apply(_has_img)
        img_df = df[mask]

        if img_df.empty:
            st.info("표시할 이미지가 없습니다.")
        else:
            st.caption(f"사진 포함 건수: {len(img_df):,}건")

            _NO_IMG_HTML = (
                "<div style='height:120px;display:flex;align-items:center;"
                "justify-content:center;border:1px dashed #ccc;"
                "border-radius:8px;color:#aaa;font-size:13px;'>사진 없음</div>"
            )

            for _, row in img_df.iterrows():
                점검일_str = (
                    row["점검일"].strftime("%Y-%m-%d")
                    if "점검일" in row and pd.notna(row["점검일"]) else ""
                )
                조치일_str = (
                    row["조치일"].strftime("%Y-%m-%d")
                    if "조치일" in row and pd.notna(row["조치일"]) else "미조치"
                )
                label = (
                    f"NO {row.get('NO', '-')} │ {row.get('협력사', '')} │ "
                    f"{row.get('호선', '')} {row.get('블록', '')} │ "
                    f"{row.get('위반유형', '')} │ 점검일: {점검일_str}"
                )

                with st.expander(label, expanded=False):
                    col_info, col_img1, col_img2 = st.columns([2, 3, 3])

                    with col_info:
                        st.markdown(
                            f"**구분:** {row.get('구분', '')}  \n"
                            f"**점검자:** {row.get('점검자', '')}  \n"
                            f"**점검일:** {점검일_str}  \n"
                            f"**점검내용:** {row.get('점검내용', '')}  \n"
                            f"---  \n"
                            f"**조치일:** {조치일_str}  \n"
                            f"**조치내용:** {row.get('조치내용', '')}"
                        )

                    with col_img1:
                        st.caption("🔍 점검 사진")
                        img1 = data_url_to_pil(row.get("점검사진", "")) if HAS_IMG1 else None
                        if img1: st.image(img1, use_container_width=True)
                        else: st.markdown(_NO_IMG_HTML, unsafe_allow_html=True)

                    with col_img2:
                        st.caption("✅ 조치 사진")
                        img2 = data_url_to_pil(row.get("조치사진", "")) if HAS_IMG2 else None
                        if img2: st.image(img2, use_container_width=True)
                        else: st.markdown(_NO_IMG_HTML, unsafe_allow_html=True)
