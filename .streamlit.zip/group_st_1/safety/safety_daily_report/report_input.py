"""
report_input.py
사외 현장 점검 입력 — Streamlit 래퍼 + 내장 DB API 서버

실행:
    streamlit run report_input.py

필수 환경변수:
    AS_DB_PASSWORD=<MySQL root 비밀번호>

동작:
    1. 최초 실행 시 백그라운드 스레드로 HTTP API 서버 기동 (60.100.164.182:8506)
    2. safety_daily_report.html 을 전체 화면 iframe 으로 렌더링
    3. HTML 내 '서버조회' / '서버저장' 버튼이 내장 API 서버와 직접 통신
"""

import base64
import datetime as dt
import json
import os
import socket
import threading
import time
from decimal import Decimal
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import pymysql
import streamlit as st
import streamlit.components.v1 as components

# ─── 설정 ──────────────────────────────────────────────────────
_BASE      = Path(__file__).resolve().parent
HTML_FILE  = _BASE / "safety_daily_report.html"

DB_HOST    = "60.100.164.182"
DB_PORT    = 3306
DB_USER    = "root"
DB_NAME    = "구조조달1_db"
TABLE_NAME = "협력사_점검_현황"

DEDUPE_KEYS = ["협력사", "호선", "블록", "구분", "점검자", "점검일", "위반유형"]

FIELD_CANDIDATES = {
    "NO":     ["NO"],
    "협력사": ["협력사"],
    "호선":   ["호선"],
    "블록":   ["블록"],
    "구분":   ["구분"],
    "점검자": ["점검자"],
    "점검일": ["점검일"],
    "위반유형": ["위반유형"],
    "점검내용": ["점검내용", "점검 내용"],
    "점검사진": ["점검사진", "점검 사진"],
    "조치일":   ["조치일"],
    "조치내용": ["조치내용", "조치 내용"],
    "조치사진": ["조치사진", "조치 사진"],
}

SPACED_TO_APP = {
    "점검 내용": "점검내용",
    "점검 사진": "점검사진",
    "조치 내용": "조치내용",
    "조치 사진": "조치사진",
}

IMAGE_FIELDS = {"점검사진", "조치사진"}
DATE_FIELDS  = {"점검일", "조치일"}


# ─── 페이지 설정 ───────────────────────────────────────────────
st.set_page_config(
    page_title="사외 현장 점검 입력",
    layout="wide",
    initial_sidebar_state="collapsed",
)


# ══════════════════════════════════════════════════════════════
# DB 헬퍼
# ══════════════════════════════════════════════════════════════

def _get_conn():
    pw = os.environ.get("AS_DB_PASSWORD", "").strip()
    if not pw:
        raise RuntimeError("환경변수 AS_DB_PASSWORD가 설정되지 않았습니다.")
    return pymysql.connect(
        host=DB_HOST, port=DB_PORT, user=DB_USER, password=pw,
        database=DB_NAME, charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor, autocommit=False,
    )


def _to_image_data_url(raw):
    if raw is None:
        return ""
    if isinstance(raw, memoryview):
        raw = raw.tobytes()
    if isinstance(raw, (bytes, bytearray)):
        return "data:image/jpeg;base64," + base64.b64encode(raw).decode("ascii")
    return str(raw)


def _parse_image_bytes(value):
    if value is None:
        return None
    if isinstance(value, memoryview):
        return value.tobytes()
    if isinstance(value, (bytes, bytearray)):
        return bytes(value)
    s = str(value).strip()
    if not s:
        return None
    if s.startswith("data:image"):
        try:
            _, b64 = s.split(",", 1)
            return base64.b64decode(b64)
        except Exception as exc:
            raise ValueError(f"이미지 data URL 파싱 실패: {exc}") from exc
    return None


def _normalize_input_row(row):
    return {SPACED_TO_APP.get(k, k): v for k, v in (row or {}).items()}


def _normalize_outgoing_value(field, value):
    if field in IMAGE_FIELDS:
        return _to_image_data_url(value)
    if value is None:
        return ""
    if isinstance(value, dt.datetime):
        return value.strftime("%Y-%m-%d")
    if isinstance(value, dt.date):
        return value.isoformat()
    if isinstance(value, Decimal):
        return float(value)
    return value


def _normalize_outgoing_row(row):
    return {
        SPACED_TO_APP.get(col, col): _normalize_outgoing_value(
            SPACED_TO_APP.get(col, col), v
        )
        for col, v in row.items()
    }


def _get_column_map(cur):
    cur.execute(f"SHOW COLUMNS FROM `{TABLE_NAME}`")
    cols = {r["Field"] for r in cur.fetchall()}
    cmap = {}
    for app_key, candidates in FIELD_CANDIDATES.items():
        for c in candidates:
            if c in cols:
                cmap[app_key] = c
                break
    return cmap


def _get_pk_columns(cur):
    cur.execute(f"SHOW KEYS FROM `{TABLE_NAME}` WHERE Key_name = 'PRIMARY'")
    rows = sorted(cur.fetchall(), key=lambda r: int(r.get("Seq_in_index", 0) or 0))
    return [r["Column_name"] for r in rows if r.get("Column_name")]


def _to_db_value(app_field, value):
    if app_field in IMAGE_FIELDS:
        return _parse_image_bytes(value)
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    if app_field in DATE_FIELDS:
        return s[:10]
    return s


def _build_key_where(cmap, row):
    clauses, params, used_keys = [], [], []
    for app_key in DEDUPE_KEYS:
        db_col = cmap.get(app_key)
        if not db_col:
            continue
        used_keys.append(app_key)
        val = _to_db_value(app_key, row.get(app_key))
        if val is None:
            clauses.append(f"(`{db_col}` IS NULL OR TRIM(CAST(`{db_col}` AS CHAR)) = '')")
        elif app_key in DATE_FIELDS:
            clauses.append(f"DATE(`{db_col}`) = %s")
            params.append(val)
        else:
            clauses.append(f"CAST(`{db_col}` AS CHAR) = %s")
            params.append(str(val))
    if not clauses:
        raise RuntimeError("중복 체크 키 컬럼을 테이블에서 찾을 수 없습니다.")
    return " AND ".join(clauses), params, used_keys


def _db_value_equal(app_field, old_val, new_val):
    if app_field in IMAGE_FIELDS:
        old_bin = old_val.tobytes() if isinstance(old_val, memoryview) else old_val
        return (old_bin or None) == (new_val or None)
    if old_val is None and new_val is None:
        return True
    if app_field in DATE_FIELDS:
        def _ds(v):
            if isinstance(v, dt.datetime):
                return v.strftime("%Y-%m-%d")
            if isinstance(v, dt.date):
                return v.isoformat()
            return "" if v is None else str(v).strip()[:10]
        return _ds(old_val) == _ds(new_val)
    return (
        ("" if old_val is None else str(old_val).strip())
        == ("" if new_val is None else str(new_val).strip())
    )


def _query_rows(date_from="", date_to="", company="", done=False, undone=False):
    conn = _get_conn()
    try:
        with conn.cursor() as cur:
            cmap   = _get_column_map(cur)
            where  = ["1=1"]
            params = []
            check_col  = cmap.get("점검일")
            co_col     = cmap.get("협력사")
            action_col = cmap.get("조치일")
            no_col     = cmap.get("NO")
            if date_from and check_col:
                where.append(f"DATE(`{check_col}`) >= %s"); params.append(date_from)
            if date_to and check_col:
                where.append(f"DATE(`{check_col}`) <= %s"); params.append(date_to)
            if company and co_col:
                where.append(f"`{co_col}` = %s"); params.append(company)
            if done and not undone and action_col:
                where.append(
                    f"`{action_col}` IS NOT NULL AND TRIM(CAST(`{action_col}` AS CHAR)) <> ''"
                )
            elif undone and not done and action_col:
                where.append(
                    f"(`{action_col}` IS NULL OR TRIM(CAST(`{action_col}` AS CHAR)) = '')"
                )
            order = f" ORDER BY CAST(`{no_col}` AS UNSIGNED), `{no_col}`" if no_col else ""
            cur.execute(
                f"SELECT * FROM `{TABLE_NAME}` WHERE {' AND '.join(where)}{order}", params
            )
            rows = cur.fetchall()
        conn.commit()
        return [_normalize_outgoing_row(r) for r in rows]
    finally:
        conn.close()


def _save_rows_append(rows):
    conn = _get_conn()
    inserted = updated = skipped = 0
    try:
        with conn.cursor() as cur:
            cmap       = _get_column_map(cur)
            pk_cols    = _get_pk_columns(cur)
            app_fields = [f for f in FIELD_CANDIDATES if f in cmap]
            if not app_fields:
                raise RuntimeError("저장 가능한 컬럼을 테이블에서 찾을 수 없습니다.")

            for raw in rows:
                row = _normalize_input_row(raw)
                where_sql, where_params, used_keys = _build_key_where(cmap, row)
                cur.execute(
                    f"SELECT * FROM `{TABLE_NAME}` WHERE {where_sql} LIMIT 1", where_params
                )
                exists = cur.fetchone()

                if not exists:
                    cols = [f"`{cmap[f]}`" for f in app_fields]
                    vals = [_to_db_value(f, row.get(f)) for f in app_fields]
                    cur.execute(
                        f"INSERT INTO `{TABLE_NAME}` ({', '.join(cols)})"
                        f" VALUES ({', '.join(['%s'] * len(cols))})",
                        vals,
                    )
                    inserted += 1
                    continue

                key_set = set(used_keys)
                changed_cols, changed_vals = [], []
                for f in app_fields:
                    if f in key_set:
                        continue
                    db_col = cmap[f]
                    new_v  = _to_db_value(f, row.get(f))
                    if not _db_value_equal(f, exists.get(db_col), new_v):
                        changed_cols.append(f"`{db_col}` = %s")
                        changed_vals.append(new_v)

                if changed_cols:
                    if pk_cols:
                        pk_where, pk_params = [], []
                        for pk in pk_cols:
                            old_pk = exists.get(pk)
                            if old_pk is None:
                                pk_where.append(f"`{pk}` IS NULL")
                            else:
                                pk_where.append(f"`{pk}` = %s")
                                pk_params.append(old_pk)
                        cur.execute(
                            f"UPDATE `{TABLE_NAME}` SET {', '.join(changed_cols)}"
                            f" WHERE {' AND '.join(pk_where)}",
                            changed_vals + pk_params,
                        )
                    else:
                        cur.execute(
                            f"UPDATE `{TABLE_NAME}` SET {', '.join(changed_cols)}"
                            f" WHERE {where_sql} LIMIT 1",
                            changed_vals + where_params,
                        )
                    updated += 1
                else:
                    skipped += 1

        conn.commit()
        return {"inserted": inserted, "updated": updated, "skipped": skipped}
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ══════════════════════════════════════════════════════════════
# 내장 HTTP API 핸들러
# ══════════════════════════════════════════════════════════════

class _Handler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def _send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path != "/api/inspection/query":
            return super().do_GET()
        qs        = parse_qs(parsed.query)
        date_from = (qs.get("date_from", [""])[0] or "").strip()
        date_to   = (qs.get("date_to",   [""])[0] or "").strip()
        company   = (qs.get("company",   [""])[0] or "").strip()
        done      = qs.get("done",   ["0"])[0] == "1"
        undone    = qs.get("undone", ["0"])[0] == "1"
        try:
            rows = _query_rows(
                date_from=date_from, date_to=date_to,
                company=company, done=done, undone=undone,
            )
            self._send_json(200, {"ok": True, "count": len(rows), "rows": rows})
        except Exception as exc:
            self._send_json(500, {"ok": False, "error": str(exc)})

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path != "/api/inspection/save":
            return self._send_json(404, {"ok": False, "error": "Not found"})
        try:
            length  = int(self.headers.get("Content-Length", "0"))
            raw     = self.rfile.read(length) if length > 0 else b"{}"
            payload = json.loads(raw.decode("utf-8"))
            rows    = payload.get("rows", [])
            if not isinstance(rows, list):
                raise ValueError("rows는 배열이어야 합니다.")
            result = _save_rows_append(rows)
            self._send_json(200, {"ok": True, **result})
        except Exception as exc:
            self._send_json(500, {"ok": False, "error": str(exc)})

    def log_message(self, *_):  # noqa: ANN002  # 콘솔 접근 로그 억제
        pass


# ══════════════════════════════════════════════════════════════
# 백그라운드 API 서버 기동 (세션 최초 1회)
# ══════════════════════════════════════════════════════════════

def _is_alive(host: str, port: int, timeout: float = 1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _start_api_server():
    server = ThreadingHTTPServer(("0.0.0.0", 8506), _Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.name = "db-api-server"
    t.start()


if "api_server_status" not in st.session_state:
    if _is_alive(DB_HOST, 8506):
        st.session_state.api_server_status = "running"
    else:
        try:
            _start_api_server()
            for _ in range(6):          # 최대 3초 대기
                if _is_alive(DB_HOST, 8506):
                    break
                time.sleep(0.5)
            st.session_state.api_server_status = (
                "ok" if _is_alive(DB_HOST, 8506) else "failed"
            )
        except Exception as exc:
            st.session_state.api_server_status = f"error: {exc}"

# ─── 사이드바: 서버 상태 ───────────────────────────────────────
with st.sidebar:
    st.markdown("### ⚙️ DB API 서버")
    _s = st.session_state.api_server_status
    if _s in ("running", "ok"):
        label = "이미 실행 중" if _s == "running" else "기동 완료"
        st.success(f"✅ {label}  \n`{DB_HOST}:{8506}`")
    elif _s == "failed":
        st.error(f"❌ 기동 실패  \n`{DB_HOST}:{8506}`\n\n페이지를 새로고침하세요.")
    else:
        st.error(f"❌ {_s}")
    st.divider()
    st.caption(
        f"MySQL: `{DB_HOST}:{DB_PORT}`  \n"
        f"DB: `{DB_NAME}`  \n"
        f"Table: `{TABLE_NAME}`  \n"
        f"API: `http://{DB_HOST}:{8506}`"
    )

# ─── 전체 화면 CSS ─────────────────────────────────────────────
st.markdown(
    """
    <style>
      html, body, .stApp,
      [data-testid="stAppViewContainer"],
      [data-testid="stApp"] {
        height: 100vh !important;
        margin: 0 !important;
        overflow: hidden !important;
      }
      main, [data-testid="stMain"] {
        height: 100vh !important;
        overflow: hidden !important;
      }
      header, #MainMenu, footer { display: none !important; }
      .block-container {
        padding: 0 !important;
        max-width: 100% !important;
        height: 100vh !important;
        overflow: hidden !important;
      }
      [data-testid="stVerticalBlock"] {
        gap: 0 !important;
        height: 100vh !important;
        overflow: hidden !important;
      }
      [data-testid="stElementContainer"] { margin-bottom: 0 !important; }
      [data-testid="stIFrame"] {
        height: 100vh !important;
        overflow: hidden !important;
      }
      [data-testid="stIFrame"] iframe {
        width: 100vw !important;
        height: 100vh !important;
        border: 0 !important;
        display: block !important;
      }
    </style>
    """,
    unsafe_allow_html=True,
)

# ─── HTML 렌더링 ───────────────────────────────────────────────
if not HTML_FILE.exists():
    st.error(f"HTML 파일을 찾을 수 없습니다: {HTML_FILE}")
else:
    html_src = HTML_FILE.read_text(encoding="utf-8")
    components.html(html_src, height=2000, scrolling=False)
