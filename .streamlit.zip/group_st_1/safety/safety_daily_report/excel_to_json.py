# -*- coding: utf-8 -*-
"""
Excel(3rd-row header, data from 4th row) → JSON
- 임베디드(삽입) 이미지 전용: 점검사진/조치사진은 셀에 삽입된 그림만 추출하여 base64 data URL로 저장
- URL/로컬 경로/텍스트 기반 이미지 변환은 배제
- 키 이름(공백 없음): 점검내용, 조치내용, 점검사진, 조치사진
- 날짜 보정: 'M/D' 또는 'M-D' → 2025-.. 로 변환, 그 외는 파서로 'YYYY-MM-DD'
- 여러 시트 선택: target_sheets = None | "ALL" | ["시트명1", ...] | [0, 2]
"""

import os
import io
import re
import json
import base64
import mimetypes
import shutil
import tempfile
from datetime import datetime, timezone
from typing import List, Union, Optional, Dict, Tuple

import pandas as pd

# ========== 설정 ==========
DATE_COLS = ["점검일", "조치일"]
DEFAULT_YEAR_FOR_MD = datetime.now().year  # '10/1' -> '{현재연도}-10-01'

# 입력 헤더 별칭(공백 유무 등)을 "공백 없는 표준 키"로 통합
ALIAS_MAP = {
    "점검내용": ["점검 내용", "점검내용", "  점검 내용", "점검  내용"],
    "조치내용": ["조치 내용", "조치내용", "  조치 내용", "조치  내용"],
    "점검사진": ["점검 사진", "점검사진", "  점검 사진"],
    "조치사진": ["조치 사진", "조치사진", "  조치 사진"],
}

# --- alias 역추적(엑셀 헤더 → 표준 키 매핑용, 공백 제거 기준) ---
_alias_flat = {}
for std, aliases in ALIAS_MAP.items():
    for a in aliases:
        _alias_flat[a.replace(" ", "")] = std  # 공백 제거 후 표준 명으로 매핑


# ========== 유틸 ==========
def _guess_mime(path: str) -> str:
    mime, _ = mimetypes.guess_type(path)
    return mime or "image/png"  # Shape.Export를 PNG로 내보냄

def _encode_file_to_data_url(file_path: str) -> str:
    with open(file_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("ascii")
    return f"data:{_guess_mime(file_path)};base64,{b64}"

def _fmt_date(val, default_year: int = DEFAULT_YEAR_FOR_MD) -> str:
    """
    YYYY-MM-DD 포맷으로 변환.
    - 'M/D' 또는 'M-D' → 지정 연도(default_year) 보정
    - 그 외 파서는 엑셀 직렬값 포함
    """
    if val is None or (isinstance(val, str) and val.strip() == "") or (not isinstance(val, str) and pd.isna(val)):
        return ""
    if isinstance(val, str):
        s = val.strip()
        m = re.match(r"^(\d{1,2})[/-](\d{1,2})$", s)
        if m:
            mm = int(m.group(1))
            dd = int(m.group(2))
            try:
                return datetime(default_year, mm, dd).strftime("%Y-%m-%d")
            except ValueError:
                return ""
    try:
        dt = pd.to_datetime(val, errors="coerce")
        if pd.isna(dt):
            return ""
        if hasattr(dt, "tzinfo") and dt.tzinfo is not None:
            try:
                dt = dt.tz_convert("Asia/Seoul").tz_localize(None)
            except Exception:
                dt = dt.tz_localize(None)
        return pd.Timestamp(dt).strftime("%Y-%m-%d")
    except Exception:
        return ""

def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """헤더 공백/BOM 정리 + Unnamed:* 제거 + 엑셀 실제 행번호 보존(__excel_row__)."""
    if "__excel_row__" not in df.columns:
        df["__excel_row__"] = pd.RangeIndex(start=4, stop=4 + len(df))  # 데이터 시작이 4행
    new_cols = []
    for c in df.columns:
        sc = str(c).replace("\ufeff", "").strip()
        if sc.lower().startswith("unnamed:"):
            new_cols.append(None)  # 제거
        else:
            sc = re.sub(r"\s+", " ", sc)
            new_cols.append(sc)
    df.columns = new_cols
    df = df[[c for c in df.columns if c is not None]]
    return df

def _apply_aliases_no_space(df: pd.DataFrame) -> pd.DataFrame:
    """
    별칭을 공백 없는 표준 컬럼명(점검내용/조치내용/점검사진/조치사진)으로 통합.
    두 컬럼이 공존하면 표준 컬럼의 빈칸만 별칭 값으로 보충.
    """
    def unify(output_name: str, aliases: list):
        for a in aliases:
            if a in df.columns:
                if output_name in df.columns and a != output_name:
                    df[output_name] = df[output_name].where(
                        df[output_name].astype(str).str.strip() != "", df[a]
                    )
                else:
                    df.rename(columns={a: output_name}, inplace=True)
        if output_name not in df.columns:
            df[output_name] = ""
    for std, alias_list in ALIAS_MAP.items():
        unify(std, alias_list)
    return df


# ========== COM: 임베디드 그림 + 헤더 위치 추출 ==========
def _extract_embedded_images_and_headers(
    excel_path: str,
    target_sheet_names: List[str]
) -> Tuple[
    Dict[str, Dict[Tuple[int, int], str]],
    Dict[str, Dict[str, int]],
    str
]:
    """
    Excel을 COM으로 열어, 각 시트의:
      - (row, col) → exported_png_path (임베디드 그림 위치 맵)
      - 공백없는헤더표준명 → 엑셀열번호(1-based) (헤더→열번호 맵)
    를 반환.
    """
    images_by_sheet: Dict[str, Dict[Tuple[int, int], str]] = {}
    headercol_by_sheet: Dict[str, Dict[str, int]] = {}

    try:
        import win32com.client as win32
    except Exception as e:
        raise RuntimeError("임베디드 이미지 추출을 위해서는 Windows + Excel + pywin32가 필요합니다. "
                           "pip install pywin32 후 재시도하세요.") from e

    excel = win32.Dispatch("Excel.Application")
    excel.Visible = False
    wb = excel.Workbooks.Open(excel_path)
    tmpdir = tempfile.mkdtemp(prefix="excel_img_")

    try:
        all_names = [ws.Name for ws in wb.Worksheets]
        for sname in target_sheet_names:
            if sname not in all_names:
                continue
            ws = wb.Worksheets(sname)

            # 1) 헤더(3행) 스캔 → 엑셀 열 번호 매핑
            header_map: Dict[str, int] = {}
            used_cols = ws.UsedRange.Columns.Count
            for col_idx in range(1, used_cols + 1):
                val = ws.Cells(3, col_idx).Value  # 3행이 헤더
                if val is None:
                    continue
                raw = str(val).replace("\ufeff", "").strip()
                if not raw or raw.lower().startswith("unnamed:"):
                    continue
                norm = re.sub(r"\s+", " ", raw).strip()
                key_nospace = norm.replace(" ", "")
                # 별칭 → 표준 키(공백 없음)로 치환
                std = _alias_flat.get(key_nospace, key_nospace)
                if std not in header_map:
                    header_map[std] = col_idx
            headercol_by_sheet[sname] = header_map

            # 2) 그림(Shapes) → (row,col) 매핑 (TopLeftCell 기준), 셀당 첫 장만 사용
            cell2img: Dict[Tuple[int, int], str] = {}
            for shp in ws.Shapes:
                try:
                    shp_type = getattr(shp, "Type", None)
                    # msoLinkedPicture(11), msoPicture(13)
                    if shp_type in (11, 13):
                        tl = shp.TopLeftCell
                        r = int(tl.Row)
                        c = int(tl.Column)
                        out_path = os.path.join(tmpdir, f"{sname}_{r}_{c}_{shp.Name}.png")
                        shp.Export(out_path, 2)  # 2 = PNG
                        # 같은 셀에 여러 장이면 첫 장만 기록
                        cell2img.setdefault((r, c), out_path)
                except Exception:
                    continue
            if cell2img:
                images_by_sheet[sname] = cell2img

    finally:
        wb.Close(False)
        excel.Quit()

    return images_by_sheet, headercol_by_sheet, tmpdir


# ========== 시트 로딩 ==========
def _select_sheet_names(excel_path: str, target_sheets: Optional[Union[str, List[Union[str, int]]]]) -> List[str]:
    xl = pd.ExcelFile(excel_path)
    sheet_names = xl.sheet_names
    if target_sheets is None or (isinstance(target_sheets, list) and len(target_sheets) == 0):
        return [sheet_names[0]]
    if isinstance(target_sheets, str) and target_sheets.upper() == "ALL":
        return sheet_names
    if isinstance(target_sheets, list):
        picked = []
        for s in target_sheets:
            if isinstance(s, int) and 0 <= s < len(sheet_names):
                picked.append(sheet_names[s])
            elif isinstance(s, str) and s in sheet_names:
                picked.append(s)
        return picked or [sheet_names[0]]
    return [sheet_names[0]]

def _read_selected_sheets(excel_path: str, target_sheet_names: List[str]) -> pd.DataFrame:
    frames = []
    for s in target_sheet_names:
        df = pd.read_excel(excel_path, sheet_name=s, header=2, dtype=str)  # 3행 헤더
        if df is None:
            continue
        df["__excel_row__"] = pd.RangeIndex(start=4, stop=4 + len(df))  # 실제 엑셀 행번호
        df["__sheet__"] = s
        df = df.dropna(how="all")
        df = _normalize_columns(df)
        frames.append(df)

    if not frames:
        return pd.DataFrame()

    df_all = pd.concat(frames, ignore_index=True)

    # 문자열 트림
    for c in df_all.columns:
        if df_all[c].dtype == object:
            df_all[c] = df_all[c].apply(lambda x: x.strip() if isinstance(x, str) else x)

    # 별칭 → 공백 없는 표준 키 통합
    df_all = _apply_aliases_no_space(df_all)
    return df_all


# ========== 변환 본체 ==========
def convert_excel_to_json(
    excel_path: str,
    target_sheets: Optional[Union[str, List[Union[str, int]]]] = None
) -> dict:
    """
    임베디드 이미지 전용 변환:
    - 점검사진/조치사진 값은 항상 "해당 셀의 임베디드 그림"으로 채움(없으면 빈 문자열)
    - URL/로컬경로/텍스트 기반 이미지는 사용하지 않음
    """
    sheet_names = _select_sheet_names(excel_path, target_sheets)
    df = _read_selected_sheets(excel_path, sheet_names)

    # 날짜 보정
    for col in DATE_COLS:
        if col in df.columns:
            df[col] = df[col].apply(_fmt_date)

    # 임베디드 그림 및 헤더 위치 추출
    images_by_sheet = {}
    headercol_by_sheet = {}
    tmpdir = ""
    try:
        images_by_sheet, headercol_by_sheet, tmpdir = _extract_embedded_images_and_headers(excel_path, sheet_names)

        # 이미지 컬럼(공백 없는 표준 명) 강제 초기화
        for key in ("점검사진", "조치사진"):
            if key not in df.columns:
                df[key] = ""
            else:
                # 기존 값(텍스트 등)은 버리고, 임베디드 기반으로만 채움
                df[key] = ""

        # 각 행에 대해 임베디드 그림 주입
        for i in range(len(df)):
            sname = df.at[i, "__sheet__"] if "__sheet__" in df.columns else None
            erow = df.at[i, "__excel_row__"] if "__excel_row__" in df.columns else None
            if not sname or erow is None:
                continue
            cell2img = images_by_sheet.get(sname, {})
            header_map = headercol_by_sheet.get(sname, {})
            # 점검사진 / 조치사진
            for key in ("점검사진", "조치사진"):
                xcol = header_map.get(key)  # 헤더 맵은 공백 없는 표준명 기준
                if not xcol:
                    continue
                img_path = cell2img.get((int(erow), int(xcol)))
                if img_path and os.path.isfile(img_path):
                    df.at[i, key] = _encode_file_to_data_url(img_path)
                else:
                    # 해당 셀에 임베디드 그림이 없으면 빈 문자열 유지
                    df.at[i, key] = ""
    finally:
        if tmpdir and os.path.isdir(tmpdir):
            shutil.rmtree(tmpdir, ignore_errors=True)

    # 보조 컬럼 제거
    for aux in ("__excel_row__", "__sheet__"):
        if aux in df.columns:
            df.drop(columns=[aux], inplace=True)

    df = df.fillna("")

    payload = {
        "meta": {
            "title": "□ 현장 점검 및 조치 사항",
            "작성일": datetime.now().strftime("%Y-%m-%d"),
            "savedAt": datetime.now(timezone.utc).isoformat(),
            "compressedMark": "#cmp=v2",
        },
        "data": df.to_dict(orient="records"),
    }
    return payload

def convert_folder(
    folder: str,
    target_sheets: Optional[Union[str, List[Union[str, int]]]] = None
) -> list:
    """
    폴더 내 모든 .xlsx → 동일 폴더에 동명 .json 생성
    (임베디드 이미지 전용)
    """
    out_files = []
    for name in os.listdir(folder):
        if not name.lower().endswith(".xlsx"):
            continue
        if name.startswith("~$"):
            continue
        excel_path = os.path.join(folder, name)
        json_obj = convert_excel_to_json(excel_path, target_sheets=target_sheets)
        json_name = os.path.splitext(name)[0] + ".json"
        json_path = os.path.join(folder, json_name)
        with io.open(json_path, "w", encoding="utf-8") as f:
            json.dump(json_obj, f, ensure_ascii=False, indent=2)
        out_files.append(json_path)
    return out_files

if __name__ == "__main__":
    convert_folder(r"C:\Users\posda\OneDrive\Desktop\TEST", ["Sheet1"])
    pass
