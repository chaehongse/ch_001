// ═══════════════════════════════════════════════════════
// STATE
// ═══════════════════════════════════════════════════════
const COLORS=['#3dd8e8','#3de87a','#f5c518','#a78bf5','#f5873d',
  '#f578b8','#5ef5b0','#f5e23d','#8be0f5','#f5a03d',
  '#c8f55e','#7b8ff5','#f55e8b','#5ef5d8','#e8f53d'];
const PURP_COL={general:'#7090a8',assembly:'#3dd8e8',outdoor:'#f5873d',staging:'#3de87a'};
const PURP_LBL={general:'일반',assembly:'조립',outdoor:'옥외',staging:'출고대기'};
const TYPE_LBL={pre:'선행중조',mid:'중조',maj:'대조'};
const TYPE_COL={pre:'#a78bf5',mid:'#3de87a',maj:'#3dd8e8'};
// 블록 순서 (선행중조→중조→대조 = 낮을수록 먼저)
const TYPE_ORDER={pre:1,mid:2,maj:3};

// ── 블록코드 파싱 헬퍼 ──────────────────────────────────
// 블록 5자리: [1]=영대문자(구역) [2~3]=숫자 [4]=0→대조/1~9→중조/영문→선행중조 [5]=영대문자
// 프로젝트 6자리: [1~2]=영대문자 [3~6]=숫자
const RE_BLOCK=/^([A-Z])(\d{2})([0-9A-Z])([A-Z])$/;
const RE_PROJECT=/^[A-Z]{2}\d{4}$/;

function parseBlockCode(code){
  if(!code||typeof code!=='string') return null;
  const m=code.trim().toUpperCase().match(RE_BLOCK);
  if(!m) return null;
  const [,zone,num,sub]=m;
  let type;
  if(sub==='0')       type='maj';          // 대조
  else if(/[1-9]/.test(sub)) type='mid';   // 중조
  else                type='pre';          // 선행중조 (영문)
  // 대조그룹: 구역+번호 (1~3자리)
  const group=zone+num;
  // 우선순위: 선행중조=1, 중조=2, 대조=3 (작업 순서)
  const priority=TYPE_ORDER[type];
  return {type, group, priority};
}

function validateProjectCode(code){
  if(!code) return false;
  return RE_PROJECT.test(code.trim().toUpperCase());
}

let yards=[], blocks=[], placements=[], failedBlocks=[];
let colorIdx=0, zoom=1;
const SCALE=3.5;

// helpers
const d2n=s=>s?new Date(s).getTime():null;
const n2d=n=>n?new Date(n).toISOString().slice(0,10):'-';
const daysInRange=(s,e)=>Math.round((e-s)/(86400000))+1;
const addDays=(n,d)=>new Date(n+d*86400000).getTime();
const parseD=s=>{if(!s)return null;const d=new Date(s);return isNaN(d)?null:d.getTime();};

// ═══════════════════════════════════════════════════════
// YARD MANAGEMENT
// ═══════════════════════════════════════════════════════
function openAddYard(){
  document.getElementById('mPurp').value='general';
  toggleOutdoorFields('m');
  document.getElementById('yardModal').classList.remove('hidden');
}
function closeModal(){
  document.getElementById('yardModal').classList.add('hidden');
  document.getElementById('editYardModal').classList.add('hidden');
}

function toggleOutdoorFields(pfx){
  const isOutdoor=document.getElementById(pfx+'Purp').value==='outdoor';
  document.getElementById(pfx+'AdvFields').style.display=isOutdoor?'none':'';
}

function confirmYard(){
  const purpose=document.getElementById('mPurp').value;
  const isOutdoor=purpose==='outdoor';
  yards.push({
    id:Date.now(),
    name:document.getElementById('mYN').value.trim()||`작업장${yards.length+1}`,
    W:+document.getElementById('mW').value||100,
    L:+document.getElementById('mL').value||200,
    gap:isOutdoor?2:+document.getElementById('mGap').value||3,
    margin:isOutdoor?0:+document.getElementById('mMgn').value||5,
    crane:isOutdoor?false:document.getElementById('mCrane').checked,
    craneH:isOutdoor?0:+document.getElementById('mCrH').value||15,
    turnoverH:isOutdoor?0:+document.getElementById('mTurnH').value||0,
    purpose,
    placements:[]
  });
  closeModal();
  renderYardList();
}

function openEditYard(id){
  const y=yards.find(y=>y.id===id);if(!y)return;
  document.getElementById('eYid').value=id;
  document.getElementById('eYN').value=y.name;
  document.getElementById('eW').value=y.W;
  document.getElementById('eL').value=y.L;
  document.getElementById('eGap').value=y.gap;
  document.getElementById('eMgn').value=y.margin;
  document.getElementById('eCrane').checked=y.crane;
  document.getElementById('eCrH').value=y.craneH;
  document.getElementById('eTurnH').value=y.turnoverH||0;
  document.getElementById('ePurp').value=y.purpose;
  toggleOutdoorFields('e');
  document.getElementById('editYardModal').classList.remove('hidden');
}

function confirmEditYard(){
  const id=+document.getElementById('eYid').value;
  const y=yards.find(y=>y.id===id);if(!y)return;
  const purpose=document.getElementById('ePurp').value;
  const isOutdoor=purpose==='outdoor';
  y.name=document.getElementById('eYN').value.trim()||y.name;
  y.W=+document.getElementById('eW').value||y.W;
  y.L=+document.getElementById('eL').value||y.L;
  y.gap=isOutdoor?2:+document.getElementById('eGap').value;
  y.margin=isOutdoor?0:+document.getElementById('eMgn').value;
  y.crane=isOutdoor?false:document.getElementById('eCrane').checked;
  y.craneH=isOutdoor?0:+document.getElementById('eCrH').value||y.craneH;
  y.turnoverH=isOutdoor?0:+document.getElementById('eTurnH').value||0;
  y.purpose=purpose;
  closeModal();
  renderYardList();
}

function deleteYard(id){
  if(!confirm('작업장을 삭제하시겠습니까?'))return;
  yards=yards.filter(y=>y.id!==id);
  renderYardList();
}

function getYardUtil(y, dateN){
  // placements on dateN for this yard
  const ps=placements.filter(p=>p.yardId===y.id&&p.inDate<=dateN&&p.outDate>=dateN);
  if(!ps.length)return 0;
  const eff=(y.W-2*y.margin)*(y.L-2*y.margin);
  return +(ps.reduce((s,p)=>s+p.w*p.h,0)/eff*100).toFixed(1);
}

function renderYardList(){
  // 헤더 협력사 뱃지 업데이트
  const pn=document.getElementById('partnerName').value.trim();
  const hdrP=document.getElementById('hdrPartner');
  if(pn){hdrP.textContent='🏢 '+pn;hdrP.style.display='block';}
  else hdrP.style.display='none';

  document.getElementById('yardCt').textContent=yards.length;
  const el=document.getElementById('yardList');
  if(!yards.length){el.innerHTML='<div class="empty-hint">작업장을 추가하세요</div>';return;}
  el.innerHTML=yards.map(y=>{
    const pc=PURP_COL[y.purpose];
    const cnt=placements.filter(p=>p.yardId===y.id).length;
    const isOutdoor=y.purpose==='outdoor';
    if(isOutdoor){
      return `<div class="ycard">
        <div class="ycard-hdr">
          <div class="ydot" style="background:${pc};box-shadow:0 0 5px ${pc}66;"></div>
          <span class="yname">${y.name}</span>
          <span class="ytag" style="color:${pc};border-color:${pc}44;background:${pc}11;">옥외대기</span>
          <button class="ybtn" onclick="openEditYard(${y.id})" style="color:var(--cyan);">✎</button>
          <button class="ybtn" onclick="deleteYard(${y.id})">✕</button>
        </div>
        ${pn?`<div style="font-family:var(--mono);font-size:9px;color:var(--amber);margin-bottom:4px;">🏢 ${pn}</div>`:''}
        <div class="ygrid">
          <div><div class="fl">W</div><span>${y.W}m</span></div>
          <div><div class="fl">L</div><span>${y.L}m</span></div>
        </div>
        <div class="ystats">
          <span class="ystat" style="color:var(--orange);">🏗 대기 <b>${cnt}</b>건</span>
          <span class="ystat" style="color:var(--muted);font-size:9px;">대조완료 블록 대기장소</span>
        </div>
      </div>`;
    }
    return `<div class="ycard">
      <div class="ycard-hdr">
        <div class="ydot" style="background:${pc};box-shadow:0 0 5px ${pc}66;"></div>
        <span class="yname">${y.name}</span>
        <span class="ytag" style="color:${pc};border-color:${pc}44;background:${pc}11;">${PURP_LBL[y.purpose]}</span>
        <button class="ybtn" onclick="openEditYard(${y.id})" style="color:var(--cyan);">✎</button>
        <button class="ybtn" onclick="deleteYard(${y.id})">✕</button>
      </div>
      ${pn?`<div style="font-family:var(--mono);font-size:9px;color:var(--amber);margin-bottom:4px;">🏢 ${pn}</div>`:''}
      <div class="ygrid">
        <div><div class="fl">W</div><span>${y.W}m</span></div>
        <div><div class="fl">L</div><span>${y.L}m</span></div>
        <div><div class="fl">이격</div><span>${y.gap}m</span></div>
        <div><div class="fl">여유</div><span>${y.margin}m</span></div>
      </div>
      <div class="ystats">
        <span class="ystat">배치 <b>${cnt}</b>건</span>
        ${y.crane
          ? `<span class="ystat" style="color:var(--cyan);">🏗 한계${y.craneH}m${y.turnoverH?` − 턴오버${y.turnoverH}m = <b style="color:var(--green);">가용${y.craneH-y.turnoverH}m</b>`:''}</span>`
          : `<span class="ystat" style="color:var(--muted);">크레인없음</span>`}
      </div>
    </div>`;
  }).join('');
}

// ═══════════════════════════════════════════════════════
// BLOCK MANAGEMENT
// ═══════════════════════════════════════════════════════
// 블록코드 입력 시 구분·우선순위 자동 세팅
function autoFillBlockType(code){
  const parsed=parseBlockCode(code);
  const dispEl=document.getElementById('bTypeDisp');
  const typeEl=document.getElementById('bType');
  const prioEl=document.getElementById('bPrio');
  if(parsed){
    typeEl.value=parsed.type;
    prioEl.value=parsed.priority;
    dispEl.value=TYPE_LBL[parsed.type];
    dispEl.style.color=TYPE_COL[parsed.type];
  } else {
    typeEl.value='maj';
    prioEl.value=1;
    dispEl.value=code.length===5?'⚠ 형식 오류':'';
    dispEl.style.color='var(--red)';
  }
}

function addBlock(){
  const name=document.getElementById('bName').value.trim().toUpperCase();
  if(!name){alert('블록 코드를 입력하세요.');return;}
  const parsed=parseBlockCode(name);
  if(!parsed){
    if(!confirm(`'${name}'은 표준 5자리 블록코드 형식이 아닙니다.\n계속 추가하시겠습니까?`))return;
  }
  const proj=document.getElementById('bProj').value.trim().toUpperCase();
  if(proj&&!validateProjectCode(proj)){
    if(!confirm(`'${proj}'은 표준 프로젝트코드 형식(영2+숫자4)이 아닙니다.\n계속 추가하시겠습니까?`))return;
  }
  const inDate=document.getElementById('bIn').value;
  let outDate=document.getElementById('bOut').value;
  const wd=+document.getElementById('bWD').value||0;
  // W/D 입력 시 완료일 자동계산 (완료일 없을 때)
  if(!outDate&&wd>0&&inDate){
    const inTs=parseD(inDate);
    if(inTs) outDate=n2d(inTs+(wd-1)*86400000);
  }
  const inTs=parseD(inDate), outTs=parseD(outDate);
  const duration=(inTs&&outTs)?Math.round((outTs-inTs)/86400000)+1:wd||null;
  const type=document.getElementById('bType').value||parsed?.type||'maj';
  const group=parsed?.group||(name.length>=3?name.slice(0,3):name);
  const priority=parsed?.priority||TYPE_ORDER[type]||1;
  blocks.push({
    id:Date.now()+Math.random(),
    name,
    project:proj||'',
    shipType:document.getElementById('bShipType').value.trim(),
    L:+document.getElementById('bL').value||20,
    B:+document.getElementById('bB').value||15,
    H:+document.getElementById('bH').value||8,
    weight:+document.getElementById('bWt').value||0,
    type, group, priority,
    inDate, outDate, duration,
    outdoorDate:document.getElementById('bOutdoor').value||null,
    outdoorEnd:null,
    needCrane:true,
    rotatable:document.getElementById('bRot').checked,
    remark:'',
    color:COLORS[colorIdx++%COLORS.length]
  });
  renderBlockList();
  document.getElementById('bName').value='';
  document.getElementById('bTypeDisp').value='';
  document.getElementById('bType').value='maj';
  document.getElementById('bPrio').value=1;
  document.getElementById('bWD').value='';
}

function deleteBlock(id){blocks=blocks.filter(b=>b.id!==id);renderBlockList();}

function renderBlockList(){
  document.getElementById('blockCt').textContent=blocks.length;
  const el=document.getElementById('blockList');
  if(!blocks.length){el.innerHTML='<div class="empty-hint">블록을 추가하세요</div>';return;}
  el.innerHTML=blocks.map(b=>{
    const tc=TYPE_COL[b.type];
    const tlbl=TYPE_LBL[b.type];
    const projTag=b.project?`<span style="font-family:var(--mono);font-size:8px;color:var(--amber);background:rgba(245,197,24,.1);border:1px solid rgba(245,197,24,.22);border-radius:2px;padding:1px 4px;">${b.project}</span>`:'';
    const shipTag=b.shipType?`<span style="font-size:9px;color:var(--dim);">${b.shipType}</span>`:'';
    return `<div class="bitem">
      <div class="bdot" style="background:${b.color};"></div>
      <div class="binfo">
        <div style="display:flex;align-items:center;gap:4px;flex-wrap:wrap;">
          ${projTag}${shipTag}
        </div>
        <div style="display:flex;align-items:center;gap:4px;margin-top:2px;">
          <span class="bname">${b.name}</span>
          <span class="btag" style="background:${tc}18;color:${tc};border:1px solid ${tc}44;">${tlbl}</span>
          <span style="font-family:var(--mono);font-size:8px;color:var(--dim);">그룹:${b.group}</span>
        </div>
        <div class="bmeta">${b.L}×${b.B}×${b.H}m · ${b.weight?b.weight+'t':'중량미입력'}</div>
        <div class="bmeta">${b.inDate||'착수미정'} ~ ${b.outDate||'완료미정'}${b.duration?' · W/D '+b.duration:''}일</div>
        ${b.outdoorDate?`<div class="bmeta" style="color:var(--orange);">옥외이동: ${b.outdoorDate}</div>`:''}
        ${b.remark?`<div class="bmeta" style="color:var(--dim);">💬 ${b.remark}</div>`:''}
        ${!b.inDate||!b.outDate?`<div class="bwarn">⚠ 착수일 또는 완료일 누락</div>`:''}
      </div>
      <button class="delbtn" onclick="deleteBlock(${b.id})">✕</button>
    </div>`;
  }).join('');
}

// ═══════════════════════════════════════════════════════
// EXCEL INPUT — 표준 3시트 양식 파싱
// ═══════════════════════════════════════════════════════
function loadExcel(event){
  const file=event.target.files[0];if(!file)return;
  const reader=new FileReader();
  reader.onload=e=>{
    try{
      const wb=XLSX.read(e.target.result,{type:'binary',cellDates:true});
      const sheetNames=wb.SheetNames;
      let loadedBlocks=0, loadedYards=0, settingsLoaded=false;

      // ── 날짜 변환 헬퍼 ──
      const fmtDate=v=>{
        if(!v&&v!==0)return '';
        if(v instanceof Date){const d=new Date(v.getTime()-v.getTimezoneOffset()*60000);return d.toISOString().slice(0,10);}
        const s=v.toString().trim();
        if(/^\d{4}-\d{2}-\d{2}$/.test(s))return s;
        if(/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(s)){const p=s.split('/');return `${p[0]}-${p[1].padStart(2,'0')}-${p[2].padStart(2,'0')}`;}
        if(!isNaN(s)&&s!==''){const d=new Date((+s-25569)*86400000);return isNaN(d)?'':d.toISOString().slice(0,10);}
        return '';
      };


      // ── 설정값 시트 파싱 ──
      const cfgSheet=wb.Sheets['설정값']||wb.Sheets['설정'];
      if(cfgSheet){
        const cfgRows=XLSX.utils.sheet_to_json(cfgSheet,{header:1,defval:''});
        const cfg={};
        cfgRows.forEach(row=>{
          const k=(row[0]||'').toString().trim();
          const v=(row[1]||'').toString().trim();
          if(k&&v) cfg[k]=v;
        });
        if(cfg['검토 시작일'])document.getElementById('pStart').value=fmtDate(cfg['검토 시작일'])||cfg['검토 시작일'];
        if(cfg['검토 종료일'])document.getElementById('pEnd').value=fmtDate(cfg['검토 종료일'])||cfg['검토 종료일'];
        if(cfg['배치 정렬 전략'])document.getElementById('strategy').value=cfg['배치 정렬 전략'];
        if(cfg['작업장 선택 방식'])document.getElementById('yardSel').value=cfg['작업장 선택 방식'];
        // 설정값 저장 (기본값으로 사용)
        window._cfg={
          defL:+(cfg['기본 L(m)']||20),
          defB:+(cfg['기본 B(m)']||15),
          defH:+(cfg['기본 H(m)']||8),
          defDays:+(cfg['기본 W/D']||90),
          defGap:+(cfg['기본 이격거리(m)']||3),
          defMargin:+(cfg['기본 경계여유(m)']||5),
        };
        settingsLoaded=true;
      }
      const cfg=window._cfg||{defL:20,defB:15,defH:8,defDays:90,defGap:3,defMargin:5};

      // ── 작업장정보 시트 파싱 ──
      const yardSheet=wb.Sheets['작업장정보']||wb.Sheets['작업장'];
      if(yardSheet){
        const yardRows=XLSX.utils.sheet_to_json(yardSheet,{defval:''});
        // 협력사명: 첫 번째 유효 데이터 행에서 1회만 읽기
        let partnerFromFile='';
        yardRows.forEach(r=>{
          if(!partnerFromFile){
            const p=(r['협력사명']||r['협력사']||'').toString().trim();
            if(p&&!p.startsWith('※')) partnerFromFile=p;
          }
        });
        if(partnerFromFile) document.getElementById('partnerName').value=partnerFromFile;

        // 예시 행 제외 (작업장명이 있고 숫자 치수가 있는 행만)
        yardRows.forEach(r=>{
          const name=(r['작업장명']||r['작업장이름']||'').toString().trim();
          if(!name||name.startsWith('※'))return;
          const W=+(r['W폭(m)']||r['W']||100);
          const L=+(r['L길이(m)']||r['L']||200);
          if(!W||!L)return; // 치수 없는 예시행 스킵
          const purposeRaw=(r['용도코드']||r['용도']||'general').toString().trim().toLowerCase();
          const purposeMap={'general':'general','일반':'general','assembly':'assembly','조립':'assembly','조립용':'assembly','outdoor':'outdoor','옥외':'outdoor','옥외대기':'outdoor','staging':'staging','출고대기':'staging'};
          const craneRaw=(r['크레인(Y/N)']||r['크레인']||'N').toString().trim().toUpperCase();
          yards.push({
            id:Date.now()+Math.random(),
            name,
            W, L,
            gap:+(r['블록간이격(m)']||r['이격']||cfg.defGap),
            margin:+(r['경계여유(m)']||r['여유']||cfg.defMargin),
            crane:craneRaw==='Y',
            craneH:+(r['크레인높이제한(m)']||r['크레인높이']||15),
            turnoverH:+(r['턴오버필요높이(m)']||r['턴오버높이']||r['turnoverH']||0),
            purpose:purposeMap[purposeRaw]||'general',
            sortOrder:+(r['우선사용순위(1=최우선)']||r['우선순위']||99),
            placements:[]
          });
          loadedYards++;
        });
        // 우선순위 정렬
        yards.sort((a,b)=>a.sortOrder-b.sortOrder);
      }

      // ── 블록데이터 시트 파싱 ──
      const blockSheet=wb.Sheets['블록데이터']||wb.Sheets['블록']||wb.Sheets[sheetNames[0]];
      if(blockSheet){
        const rows=XLSX.utils.sheet_to_json(blockSheet,{defval:''});
        rows.forEach(r=>{
          const name=(r['블록']||r['블록코드']||r['블록번호']||r['block_id']||'').toString().trim().toUpperCase();
          if(!name||name.startsWith('※'))return;

          const proj=(r['프로젝트']||r['프로젝트코드']||'').toString().trim().toUpperCase();
          const shipType=(r['선종/선형']||r['선종']||r['선형']||'').toString().trim();

          // 블록코드 자동 판별
          const parsed=parseBlockCode(name);
          // 수동 입력된 구분이 있으면 우선, 없으면 자동판별
          const typeRaw=(r['블록구분']||r['구분']||r['type']||'').toString().trim();
          const typeMapManual={'선행중조':'pre','pre':'pre','중조':'mid','mid':'mid','대조':'maj','maj':'maj'};
          const type=typeMapManual[typeRaw]||parsed?.type||'maj';
          const group=parsed?.group||(r['대조그룹']||r['group']||name.slice(0,3)||name).toString().trim();
          const priority=parsed?.priority||TYPE_ORDER[type]||1;

          // 완료일 vs W/D 처리
          let inDateStr=fmtDate(r['착수일']||r['입고일']||r['in_date']||'');
          let outDateStr=fmtDate(r['완료일']||r['출고일']||r['out_date']||'');
          const durRaw=r['W/D']||r['duration']||'';
          const durDays=durRaw!==''?+durRaw:null;
          if(!outDateStr&&durDays&&durDays>0&&inDateStr){
            const inTs=parseD(inDateStr);
            if(inTs)outDateStr=n2d(inTs+(durDays-1)*86400000);
          }
          if(!outDateStr&&inDateStr){
            const inTs=parseD(inDateStr);
            if(inTs)outDateStr=n2d(inTs+(cfg.defDays-1)*86400000);
          }

          const craneNeed=(r['크레인필요(Y/N)']||r['크레인필요']||'Y').toString().trim().toUpperCase();
          const rotRaw=(r['회전허용(Y/N)']||r['회전허용']||'Y').toString().trim().toUpperCase();
          const yardAssign=(r['작업장지정(없으면 공란)']||r['작업장지정']||'').toString().trim();

          const inTs=parseD(inDateStr), outTs=parseD(outDateStr);
          const calcDur=(inTs&&outTs)?Math.round((outTs-inTs)/86400000)+1:null;

          blocks.push({
            id:Date.now()+Math.random(),
            name,
            project:proj,
            shipType,
            L:+(r['L(m)길이']||r['L(m)']||r['L']||cfg.defL),
            B:+(r['B(m)폭']||r['B(m)']||r['B']||cfg.defB),
            H:+(r['H(m)높이']||r['H(m)']||r['H']||cfg.defH),
            weight:+(r['중량(ton)']||r['중량']||r['weight']||0),
            type, group, priority,
            inDate:inDateStr,
            outDate:outDateStr,
            duration:calcDur,
            outdoorDate:fmtDate(r['옥외이동일(없으면 공란)']||r['옥외이동일']||r['outdoor_date']||'')||null,
            outdoorEnd:fmtDate(r['옥외완료일(없으면 공란)']||r['옥외완료일']||'')||null,
            needCrane:craneNeed!=='N',
            rotatable:rotRaw!=='N',
            maxH:+(r['최대높이제한(m)']||r['최대높이']||0)||null,
            yardAssign:yardAssign||null,
            remark:(r['비고']||'').toString().trim(),
            color:COLORS[colorIdx++%COLORS.length]
          });
          loadedBlocks++;
        });
      }

      renderYardList();renderBlockList();

      // 업로드 상태 표시
      const msg=`블록 ${loadedBlocks}개${loadedYards?` · 작업장 ${loadedYards}개`:''}${settingsLoaded?' · 설정값 적용':''}`;
      document.getElementById('uploadMsg').textContent=msg;
      const us=document.getElementById('uploadStatus');
      us.style.display='flex';
      setTimeout(()=>us.style.display='none',5000);

      // 작업장와 블록이 모두 있으면 자동 배치 실행
      if(yards.length&&blocks.length){
        setTimeout(runOptimize,120);
      }
    }catch(err){alert('Excel 파싱 오류: '+err.message+'\n\n표준양식을 사용하고 있는지 확인하세요.');}
  };
  reader.readAsBinaryString(file);
  event.target.value='';
}

// ═══════════════════════════════════════════════════════
// OPTIMIZER
// ═══════════════════════════════════════════════════════
function runOptimize(){
  if(!yards.length){alert('작업장을 먼저 추가하세요.');return;}
  if(!blocks.length){alert('블록을 먼저 추가하세요.');return;}

  placements=[];
  failedBlocks=[];
  const strategy=document.getElementById('strategy').value;
  const yardSelMode=document.getElementById('yardSel').value;
  const pStart=parseD(document.getElementById('pStart').value);
  const pEnd=parseD(document.getElementById('pEnd').value);

  // Filter blocks within review period
  const activeBlocks=blocks.filter(b=>{
    const bIn=parseD(b.inDate), bOut=parseD(b.outDate);
    if(!bIn||!bOut)return false;
    return bIn<=pEnd&&bOut>=pStart; // overlaps with review period
  });

  // Identify outdoor yard
  const outdoorYards=yards.filter(y=>y.purpose==='outdoor');
  const indoorYards=yards.filter(y=>y.purpose!=='outdoor');

  // Group blocks by 대조 group
  const groups={};
  activeBlocks.forEach(b=>{
    if(!groups[b.group])groups[b.group]=[];
    groups[b.group].push(b);
  });

  // Sort groups/blocks
  let sortedBlocks=[];
  if(strategy==='group_prio'){
    // Sort groups by earliest inDate and highest priority
    const groupOrder=Object.keys(groups).sort((a,b)=>{
      const minPrioA=Math.min(...groups[a].map(x=>x.priority));
      const minPrioB=Math.min(...groups[b].map(x=>x.priority));
      if(minPrioA!==minPrioB)return minPrioA-minPrioB;
      const minInA=Math.min(...groups[a].map(x=>parseD(x.inDate)||Infinity));
      const minInB=Math.min(...groups[b].map(x=>parseD(x.inDate)||Infinity));
      return minInA-minInB;
    });
    // Within each group: maj first, then mid, then pre (largest first)
    const typeOrder={maj:0,mid:1,pre:2};
    groupOrder.forEach(g=>{
      const sorted=[...groups[g]].sort((a,b)=>{
        if(typeOrder[a.type]!==typeOrder[b.type])return typeOrder[a.type]-typeOrder[b.type];
        return (b.L*b.B)-(a.L*a.B);
      });
      sortedBlocks.push(...sorted);
    });
  } else if(strategy==='area_bl'){
    sortedBlocks=[...activeBlocks].sort((a,b)=>(b.L*b.B)-(a.L*a.B));
  } else {
    sortedBlocks=[...activeBlocks].sort((a,b)=>a.priority!==b.priority?a.priority-b.priority:(b.L*b.B)-(a.L*a.B));
  }

  // Track group→yard assignments (must be same yard)
  const groupYardMap={}; // groupId → yardId

  for(const blk of sortedBlocks){
    const bIn=parseD(blk.inDate);
    const bOut=parseD(blk.outDate);
    if(!bIn||!bOut){failedBlocks.push({...blk,reason:'착수일 또는 완료일 누락'});continue;}
    const outdoorAfter=parseD(blk.outdoorDate);
    const outdoorEnd=parseD(blk.outdoorEnd)||bOut;

    // Determine periods: indoor period, then outdoor period
    const indoorEnd=outdoorAfter?Math.min(bOut,outdoorAfter-86400000):bOut;
    const hasOutdoor=outdoorAfter&&outdoorAfter<=bOut&&outdoorYards.length>0;

    // ── INDOOR PLACEMENT ──
    // 작업장지정 우선 처리
    const forcedYardId=groupYardMap[blk.group]||
      (blk.yardAssign?yards.find(y=>y.name===blk.yardAssign||y.id===blk.yardAssign)?.id:null);
    let chosenYard=null, chosenPos=null;

    // 크레인 필요 여부 필터 — 가용높이 = 크레인높이 − 턴오버높이
    let candidateYards;
    if(forcedYardId){
      candidateYards=indoorYards.filter(y=>y.id===forcedYardId);
    } else {
      candidateYards=indoorYards.filter(y=>{
        if(!y.crane) return true;           // 크레인 없는 작업장은 높이 제한 없음
        const availH = y.craneH - (y.turnoverH||0);
        if(blk.needCrane!==false && blk.H>0 && availH>0 && blk.H>availH) return false;
        return true;
      });
    }

    if(yardSelMode==='firstfit'){
      for(const y of candidateYards){
        const pos=findPos(y,blk,bIn,indoorEnd);
        if(pos){chosenYard=y;chosenPos=pos;break;}
      }
    } else if(yardSelMode==='bestfit'){
      let bestScore=Infinity;
      for(const y of candidateYards){
        const pos=findPos(y,blk,bIn,indoorEnd);
        if(!pos)continue;
        const score=calcScore(y,blk,bIn,indoorEnd,pos);
        if(score<bestScore){bestScore=score;chosenYard=y;chosenPos=pos;}
      }
    } else { // balance
      let bestUtil=Infinity;
      for(const y of candidateYards){
        const pos=findPos(y,blk,bIn,indoorEnd);
        if(!pos)continue;
        const u=getAvgUtil(y,bIn,indoorEnd);
        if(u<bestUtil){bestUtil=u;chosenYard=y;chosenPos=pos;}
      }
    }

    if(!chosenYard){
      let reason='공간 부족 (모든 작업장 포화)';
      if(forcedYardId){
        const fy=yards.find(y=>y.id===forcedYardId);
        const isGroupForced=!!groupYardMap[blk.group];
        if(blk.yardAssign&&!isGroupForced) reason=`작업장 지정(${blk.yardAssign}) 공간 부족`;
        else reason=`대조그룹 작업장(${fy?.name||'?'}) 공간 부족`;
      } else if(candidateYards.length===0){
        const availList=indoorYards.filter(y=>y.crane).map(y=>y.craneH-(y.turnoverH||0));
        const maxAvailH=availList.length?Math.max(...availList):0;
        reason=`크레인 가용높이 초과 (블록 H:${blk.H}m, 최대가용:${maxAvailH}m)`;
      } else if(indoorYards.length===0){
        reason='실내 작업장 없음';
      }
      failedBlocks.push({...blk,reason});
      continue;
    }

    // Record indoor placement
    const duration=Math.round((indoorEnd-bIn)/86400000)+1;
    placements.push({
      blockId:blk.id,blockName:blk.name,
      yardId:chosenYard.id,yardName:chosenYard.name,
      x:chosenPos.x,y:chosenPos.y,w:chosenPos.w,h:chosenPos.h,
      rotated:chosenPos.rot,
      inDate:bIn,outDate:indoorEnd,
      duration,
      type:blk.type,group:blk.group,
      color:blk.color,priority:blk.priority,
      weight:blk.weight,L:blk.L,B:blk.B,H:blk.H,
      needCrane:blk.needCrane,remark:blk.remark||'',
      isOutdoor:false
    });

    // Lock group to this yard
    if(!groupYardMap[blk.group]) groupYardMap[blk.group]=chosenYard.id;

    // ── OUTDOOR PLACEMENT ──
    if(hasOutdoor){
      const outStart=outdoorAfter;
      const outEnd=outdoorEnd||bOut;
      for(const oy of outdoorYards){
        const opos=findPos(oy,blk,outStart,outEnd);
        if(opos){
          placements.push({
            blockId:blk.id,blockName:blk.name+' [옥외]',
            yardId:oy.id,yardName:oy.name,
            x:opos.x,y:opos.y,w:opos.w,h:opos.h,
            rotated:opos.rot,
            inDate:outStart,outDate:outEnd,
            duration:Math.round((outEnd-outStart)/86400000)+1,
            type:blk.type,group:blk.group,
            color:blk.color,priority:blk.priority,
            weight:blk.weight,L:blk.L,B:blk.B,H:blk.H,
            needCrane:false,remark:blk.remark||'',
            isOutdoor:true
          });
          break;
        }
      }
    }
  }

  updateStats();
  renderYardList();
  renderGantt();
  renderLayout();
  renderResultTable();
}

// Find a position for block in yard during [startN, endN]
function findPos(y,blk,startN,endN){
  const ew=y.W-2*y.margin, el=y.L-2*y.margin;
  const oris=[{w:blk.L,h:blk.B,rot:false}];
  if(blk.rotatable&&blk.L!==blk.B)oris.push({w:blk.B,h:blk.L,rot:true});

  // Get all placements in this yard overlapping [startN,endN]
  const concurrent=placements.filter(p=>
    p.yardId===y.id && p.inDate<=endN && p.outDate>=startN
  );

  const cands=[{x:y.margin,y:y.margin}];
  concurrent.forEach(p=>{
    cands.push({x:p.x+p.w+y.gap,y:p.y});
    cands.push({x:p.x,y:p.y+p.h+y.gap});
    cands.push({x:p.x+p.w+y.gap,y:p.y+p.h+y.gap});
  });

  let best=null;
  for(const ori of oris){
    for(const c of cands){
      if(c.x+ori.w>y.margin+ew||c.y+ori.h>y.margin+el)continue;
      if(overlapsT(concurrent,c.x,c.y,ori.w,ori.h,y.gap))continue;
      const score=c.y*1e7+c.x;
      if(!best||score<best.score)best={x:c.x,y:c.y,w:ori.w,h:ori.h,rot:ori.rot,score};
    }
  }
  return best;
}

function overlapsT(placed,x,y,w,h,gap){
  return placed.some(p=>x<p.x+p.w+gap&&x+w+gap>p.x&&y<p.y+p.h+gap&&y+h+gap>p.y);
}

function calcScore(y,_blk,startN,endN,pos){
  const eff=(y.W-2*y.margin)*(y.L-2*y.margin);
  const used=placements.filter(p=>p.yardId===y.id&&p.inDate<=endN&&p.outDate>=startN)
    .reduce((s,p)=>s+p.w*p.h,0);
  return eff-used-pos.w*pos.h;
}

function getAvgUtil(y,startN,endN){
  const eff=(y.W-2*y.margin)*(y.L-2*y.margin);
  const used=placements.filter(p=>p.yardId===y.id&&p.inDate<=endN&&p.outDate>=startN)
    .reduce((s,p)=>s+p.w*p.h,0);
  return used/eff;
}

function updateStats(){
  const total=blocks.length;
  const placedIds=new Set(placements.filter(p=>!p.isOutdoor).map(p=>p.blockId));
  const placed=placedIds.size;
  const fail=failedBlocks.length;
  document.getElementById('sTotal').textContent=total;
  document.getElementById('sPlaced').textContent=placed;
  document.getElementById('sFail').textContent=fail;
  const groups=new Set(blocks.map(b=>b.group)).size;
  document.getElementById('sGroups').textContent=groups;

  // 총W/D 계산 (배치된 블록 기준 최대 기간)
  if(placements.length){
    const minIn=Math.min(...placements.map(p=>p.inDate));
    const maxOut=Math.max(...placements.map(p=>p.outDate));
    document.getElementById('sTotalDays').textContent=Math.round((maxOut-minIn)/86400000)+1;
  } else document.getElementById('sTotalDays').textContent='-';

  // Overall util
  if(yards.length){
    const pStart=parseD(document.getElementById('pStart').value);
    const totEff=yards.filter(y=>y.purpose!=='outdoor').reduce((s,y)=>(s+(y.W-2*y.margin)*(y.L-2*y.margin)),0);
    const totUsed=yards.filter(y=>y.purpose!=='outdoor').reduce((s,y)=>s+placements.filter(p=>p.yardId===y.id&&!p.isOutdoor&&p.inDate<=pStart&&p.outDate>=pStart).reduce((ss,p)=>ss+p.w*p.h,0),0);
    document.getElementById('sUtil').textContent=totEff?(totUsed/totEff*100).toFixed(1)+'%':'-';
  }
}

// ═══════════════════════════════════════════════════════
// GANTT CHART
// ═══════════════════════════════════════════════════════
function renderGantt(){
  const pStart=parseD(document.getElementById('pStart').value);
  const pEnd=parseD(document.getElementById('pEnd').value);
  if(!pStart||!pEnd)return;

  const totalDays=daysInRange(pStart,pEnd);
  const DAY_W=16; // px per day
  const LABEL_W=100;

  const el=document.getElementById('ganttInner');
  let html='';

  // Month header
  html+=`<div style="display:flex;padding-left:${LABEL_W}px;margin-bottom:2px;">`;
  let cur=pStart;
  while(cur<=pEnd){
    const d=new Date(cur);
    const y=d.getFullYear(),m=d.getMonth();
    // Count days in this month within range
    const monthEnd=new Date(y,m+1,0).getTime();
    const rangeEnd=Math.min(monthEnd,pEnd);
    const days=daysInRange(cur,rangeEnd);
    html+=`<div style="font-family:var(--mono);font-size:9px;color:var(--dim);width:${days*DAY_W}px;overflow:hidden;white-space:nowrap;border-left:1px solid var(--b1);padding-left:2px;">${y}.${String(m+1).padStart(2,'0')}</div>`;
    cur=addDays(new Date(y,m+1,1).getTime(),0);
  }
  html+='</div>';

  // Week numbers
  html+=`<div style="display:flex;padding-left:${LABEL_W}px;margin-bottom:3px;">`;
  for(let i=0;i<totalDays;i++){
    const d=new Date(addDays(pStart,i));
    const dow=d.getDay();
    html+=`<div style="width:${DAY_W}px;font-family:var(--mono);font-size:8px;color:${dow===0?'var(--red)':dow===6?'var(--cyan)':'var(--b2)'};text-align:center;">${dow===1?Math.ceil((d.getDate()+(new Date(d.getFullYear(),d.getMonth(),1).getDay()))/7):'·'}</div>`;
  }
  html+='</div>';

  // Yard rows
  // For each yard, show a stacked bar of blocks per day
  const today=new Date().getTime();

  // Render outdoor yards after indoor
  const orderedYards=[...yards.filter(y=>y.purpose!=='outdoor'),...yards.filter(y=>y.purpose==='outdoor')];

  orderedYards.forEach(y=>{
    const pc=PURP_COL[y.purpose];
    const yPlacements=placements.filter(p=>p.yardId===y.id);

    html+=`<div class="gantt-section-lbl" style="color:${pc};">── ${y.name} (${y.W}×${y.L}m)</div>`;

    if(!yPlacements.length){
      html+=`<div class="gantt-row"><div class="gantt-yd-label" style="color:var(--muted);min-width:${LABEL_W}px;">배치없음</div>`;
      html+=`<div class="gantt-bars">`;
      for(let i=0;i<totalDays;i++){
        html+=`<div class="gantt-day" style="background:var(--s2);opacity:.4;"></div>`;
      }
      html+=`</div></div>`;
      return;
    }

    // Group unique blocks placed in this yard
    const uniqueBlocks=[...new Map(yPlacements.map(p=>[p.blockId,p])).values()];
    uniqueBlocks.sort((a,b)=>a.priority-b.priority||(a.inDate-b.inDate));

    uniqueBlocks.forEach(pl=>{
      // Get both indoor and outdoor placements for this block
      const allPl=yPlacements.filter(p=>p.blockId===pl.blockId);
      const blkName=blocks.find(b=>b.id===pl.blockId)?.name||pl.blockName;
      html+=`<div class="gantt-row">`;
      html+=`<div class="gantt-yd-label" title="${blkName}" style="min-width:${LABEL_W}px;">${blkName.length>11?blkName.slice(0,10)+'…':blkName}</div>`;
      html+=`<div class="gantt-bars">`;
      for(let i=0;i<totalDays;i++){
        const dayN=addDays(pStart,i);
        const activePl=allPl.find(p=>p.inDate<=dayN&&p.outDate>=dayN);
        const isToday=Math.abs(dayN-today)<86400000;
        if(activePl){
          const col=activePl.isOutdoor?'var(--orange)':activePl.color;
          const alpha=activePl.isOutdoor?'0.7':'0.85';
          html+=`<div class="gantt-day${isToday?' today':''}" style="background:${col};opacity:${alpha};"
            data-bid="${pl.blockId}" data-day="${dayN}" onclick="jumpToDate(${dayN})"
            onmouseover="showGanttTip(event,${pl.blockId},${dayN})" onmouseout="hideTip()"></div>`;
        } else {
          const dow=new Date(dayN).getDay();
          const wkend=dow===0||dow===6;
          html+=`<div class="gantt-day${isToday?' today':''}" style="background:${wkend?'var(--s3)':'var(--s2)'};cursor:default;" onclick="jumpToDate(${dayN})"></div>`;
        }
      }
      html+=`</div></div>`;
    });
  });

  // Failed blocks row
  if(failedBlocks.length){
    html+=`<div class="gantt-section-lbl" style="color:var(--red);">── 미배치 블록 (${failedBlocks.length})</div>`;
    failedBlocks.forEach(b=>{
      const bIn=parseD(b.inDate),bOut=parseD(b.outDate);
      html+=`<div class="gantt-row">`;
      html+=`<div class="gantt-yd-label" title="${b.name}" style="color:var(--red);min-width:${LABEL_W}px;">${b.name.length>11?b.name.slice(0,10)+'…':b.name}</div>`;
      html+=`<div class="gantt-bars">`;
      for(let i=0;i<totalDays;i++){
        const dayN=addDays(pStart,i);
        const inRange=bIn&&bOut&&dayN>=bIn&&dayN<=bOut;
        html+=`<div class="gantt-day" style="background:${inRange?'rgba(245,90,90,.35)':'var(--s2)'};${inRange?'border-top:1px solid rgba(245,90,90,.5);':''}"></div>`;
      }
      html+=`</div></div>`;
    });
  }

  el.innerHTML=html;

  // Legend
  document.getElementById('ganttLegend').innerHTML=`
    <div class="gl-item"><div class="gl-dot" style="background:var(--cyan);"></div>실내 배치</div>
    <div class="gl-item"><div class="gl-dot" style="background:var(--orange);"></div>옥외 이동</div>
    <div class="gl-item"><div class="gl-dot" style="background:rgba(245,90,90,.35);border:1px solid rgba(245,90,90,.5);"></div>미배치 기간</div>
    <div class="gl-item"><div class="gl-dot" style="background:var(--s3);border:1px solid var(--b1);"></div>주말</div>
    <div class="gl-item"><div class="gl-dot" style="outline:1px solid var(--amber);"></div>오늘</div>`;
}

function showGanttTip(e,blockId,dayN){
  const blk=blocks.find(b=>b.id===blockId);
  const pls=placements.filter(p=>p.blockId===blockId&&p.inDate<=dayN&&p.outDate>=dayN);
  if(!blk||!pls.length)return;
  const pl=pls[0];
  const tip=document.getElementById('tip');
  tip.style.display='block';
  tip.style.left=(e.clientX+14)+'px';
  tip.style.top=(e.clientY-10)+'px';
  tip.innerHTML=`<div class="tn" style="color:${blk.color}">${blk.name}</div>
    <div class="tr"><span class="tk">작업장</span><span class="tv">${pl.yardName}</span></div>
    <div class="tr"><span class="tk">구분</span><span class="tv">${TYPE_LBL[blk.type]}</span></div>
    <div class="tr"><span class="tk">그룹</span><span class="tv">${blk.group}</span></div>
    <div class="tr"><span class="tk">착수</span><span class="tv">${n2d(pl.inDate)}</span></div>
    <div class="tr"><span class="tk">완료</span><span class="tv">${n2d(pl.outDate)}</span></div>
    <div class="tr"><span class="tk">W/D</span><span class="tg">${pl.duration||'－'}일</span></div>
    <div class="tr"><span class="tk">크기</span><span class="tv">${pl.w}×${pl.h}m${pl.rotated?' [90°]':''}</span></div>
    <div class="tr"><span class="tk">위치</span><span class="tv">X${pl.x.toFixed(1)} Y${pl.y.toFixed(1)}</span></div>
    ${pl.isOutdoor?'<div class="tr"><span class="to">★ 옥외 이동 중</span></div>':''}
    ${blk.remark?`<div class="tr"><span class="tk">비고</span><span class="tv">${blk.remark}</span></div>`:''}`;
}

function hideTip(){document.getElementById('tip').style.display='none';}

function jumpToDate(dayN){
  document.getElementById('lyDate').value=n2d(dayN);
  switchTab('layout');
  renderLayout();
}

// ═══════════════════════════════════════════════════════
// LAYOUT VIEW
// ═══════════════════════════════════════════════════════
function renderLayout(){
  const dateStr=document.getElementById('lyDate').value;
  if(!dateStr)return;
  const dateN=parseD(dateStr);
  document.getElementById('lyDateInfo').textContent=`${dateStr} 작업장 현황`;

  const wrap=document.getElementById('yardsRow');
  if(!placements.length){
    wrap.innerHTML='<div class="empty-panel full-w">최적 배치를 실행한 후 날짜를 선택하세요</div>';
    return;
  }

  const orderedYards=[...yards.filter(y=>y.purpose!=='outdoor'),...yards.filter(y=>y.purpose==='outdoor')];
  wrap.innerHTML='';

  orderedYards.forEach(y=>{
    const activePl=placements.filter(p=>p.yardId===y.id&&p.inDate<=dateN&&p.outDate>=dateN);
    const s=SCALE*zoom;
    const cw=Math.ceil(y.W*s), ch=Math.ceil(y.L*s);
    const util=activePl.length?+(activePl.reduce((ss,p)=>ss+p.w*p.h,0)/((y.W-2*y.margin)*(y.L-2*y.margin))*100).toFixed(1):0;
    const pc=PURP_COL[y.purpose];

    const wrapDiv=document.createElement('div');
    wrapDiv.className='yc-wrap';

    const lbl=document.createElement('div');
    lbl.className='yc-lbl';
    const isOutdoorYard=y.purpose==='outdoor';
    lbl.innerHTML=`<span style="color:${pc};font-size:10px;">●</span>
      <span class="yn">${y.name}</span>
      <span>${y.W}×${y.L}m</span>
      ${isOutdoorYard
        ? `<span style="color:var(--orange);">대기 ${activePl.length}블록</span>`
        : `<span style="color:var(--cyan);">${util}%</span>
           <span style="color:var(--green);">${activePl.length}블록</span>
           ${y.crane
             ? `<span style="color:var(--dim);">🏗 가용${y.craneH-(y.turnoverH||0)}m${y.turnoverH?`(−${y.turnoverH})`:''}</span>`
             : ''}`
      }`;

    const cvs=document.createElement('canvas');
    cvs.width=cw;cvs.height=ch;
    cvs.style.border='1px solid var(--b1)';
    cvs.style.background='#080c11';
    cvs.style.display='block';
    cvs.style.cursor='crosshair';

    cvs.addEventListener('mousemove',e=>{
      const r=cvs.getBoundingClientRect();
      const mx=(e.clientX-r.left)/s, my=(e.clientY-r.top)/s;
      const hit=activePl.find(p=>mx>=p.x&&mx<=p.x+p.w&&my>=p.y&&my<=p.y+p.h);
      const tip=document.getElementById('tip');
      if(hit){
        tip.style.display='block';
        tip.style.left=(e.clientX+14)+'px';
        tip.style.top=(e.clientY-8)+'px';
        tip.innerHTML=`<div class="tn" style="color:${hit.color}">${hit.blockName.replace(' [옥외]','')}</div>
          <div class="tr"><span class="tk">구분</span><span class="tv">${TYPE_LBL[hit.type]}</span></div>
          <div class="tr"><span class="tk">그룹</span><span class="tv">${hit.group}</span></div>
          <div class="tr"><span class="tk">원본 LBH</span><span class="tv">${hit.L}×${hit.B}×${hit.H}m</span></div>
          <div class="tr"><span class="tk">배치크기</span><span class="tv">${hit.w}×${hit.h}m${hit.rotated?' [90°]':''}</span></div>
          <div class="tr"><span class="tk">위치</span><span class="tv">X${hit.x.toFixed(1)} Y${hit.y.toFixed(1)}</span></div>
          <div class="tr"><span class="tk">중량</span><span class="tv">${hit.weight?hit.weight+'t':'－'}</span></div>
          <div class="tr"><span class="tk">착수</span><span class="tv">${n2d(hit.inDate)}</span></div>
          <div class="tr"><span class="tk">완료</span><span class="tv">${n2d(hit.outDate)}</span></div>
          <div class="tr"><span class="tk">W/D</span><span class="tg">${hit.duration||'－'}일</span></div>
          <div class="tr"><span class="tk">우선순위</span><span class="tv">P${hit.priority}</span></div>
          ${hit.isOutdoor?`<div class="tr"><span class="to">★ 옥외 배치</span></div>`:''}
          ${hit.remark?`<div class="tr"><span class="tk">비고</span><span class="tv">${hit.remark}</span></div>`:''}`;
      } else tip.style.display='none';
    });
    cvs.addEventListener('mouseleave',()=>document.getElementById('tip').style.display='none');

    wrapDiv.appendChild(lbl);
    wrapDiv.appendChild(cvs);
    wrap.appendChild(wrapDiv);

    drawYardCanvas(cvs,y,activePl,s,pc);
  });
}

function drawYardCanvas(cvs,y,activePl,s,pc){
  const ctx=cvs.getContext('2d');
  const W=y.W,L=y.L;
  ctx.fillStyle='#080c11';ctx.fillRect(0,0,cvs.width,cvs.height);

  // Grid
  ctx.strokeStyle='rgba(37,53,69,.7)';ctx.lineWidth=.5;
  for(let x=0;x<=W;x+=10){ctx.beginPath();ctx.moveTo(x*s,0);ctx.lineTo(x*s,cvs.height);ctx.stroke();}
  for(let lv=0;lv<=L;lv+=10){ctx.beginPath();ctx.moveTo(0,lv*s);ctx.lineTo(cvs.width,lv*s);ctx.stroke();}

  // Margin zone
  const m=y.margin;
  ctx.fillStyle='rgba(245,90,90,.04)';
  [[0,0,cvs.width,m*s],[0,(L-m)*s,cvs.width,m*s],[0,0,m*s,cvs.height],[(W-m)*s,0,m*s,cvs.height]]
    .forEach(r=>ctx.fillRect(...r));
  ctx.setLineDash([3,4]);ctx.strokeStyle='rgba(245,90,90,.18)';ctx.lineWidth=1;
  ctx.strokeRect(m*s,m*s,(W-2*m)*s,(L-2*m)*s);
  ctx.setLineDash([]);

  // Yard border
  ctx.strokeStyle=pc+'55';ctx.lineWidth=1.5;ctx.strokeRect(0,0,cvs.width,cvs.height);

  // Yard label
  ctx.fillStyle=pc+'88';ctx.font=`bold 10px JetBrains Mono,monospace`;
  ctx.textAlign='left';ctx.textBaseline='top';
  ctx.fillText(`${y.name}  ${W}×${L}m`,6,5);

  // Group color rings (same group = same outline color)
  activePl.forEach(p=>{
    const px=p.x*s,py=p.y*s,pw=p.w*s,ph=p.h*s;
    // Background fill
    const fillCol=p.isOutdoor?ha('#f5873d',.18):ha(p.color,.2);
    ctx.fillStyle=fillCol;ctx.fillRect(px,py,pw,ph);
    // Type stripe at top
    const tc=TYPE_COL[p.type]||p.color;
    ctx.fillStyle=ha(tc,.6);ctx.fillRect(px,py,pw,Math.min(3,ph*.07));
    // Border
    ctx.strokeStyle=p.isOutdoor?'#f5873d':p.color;ctx.lineWidth=1.2;ctx.strokeRect(px,py,pw,ph);
    // Label
    if(pw>14&&ph>10){
      const fs=Math.min(10.5,Math.max(6,pw/9));
      ctx.fillStyle='rgba(224,240,255,.9)';ctx.font=`bold ${fs}px JetBrains Mono,monospace`;
      ctx.textAlign='center';ctx.textBaseline='middle';
      const displayName=p.blockName.replace(' [옥외]','');
      ctx.fillText(displayName,px+pw/2,py+ph/2-(pw>30?4:0));
      if(pw>30&&ph>16){
        ctx.fillStyle='rgba(160,200,220,.5)';ctx.font=`${Math.max(6,fs-1.5)}px JetBrains Mono,monospace`;
        ctx.fillText(`P${p.priority} ${p.w}×${p.h}`,px+pw/2,py+ph/2+5);
      }
    }
  });

  // Scale bar
  const sbLen=Math.min(50,W/4)*s, sbM=Math.min(50,W/4);
  ctx.fillStyle='rgba(200,220,240,.5)';ctx.fillRect(8,cvs.height-17,sbLen,2);
  ctx.fillRect(8,cvs.height-20,2,5);ctx.fillRect(8+sbLen-2,cvs.height-20,2,5);
  ctx.font='8px JetBrains Mono,monospace';ctx.textAlign='center';ctx.textBaseline='bottom';
  ctx.fillText(`${sbM}m`,8+sbLen/2,cvs.height-2);
}

function ha(hex,a){
  if(hex.startsWith('rgba'))return hex;
  const r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);
  return `rgba(${r},${g},${b},${a})`;
}

function prevDay(){
  const el=document.getElementById('lyDate');
  const d=new Date(el.value);d.setDate(d.getDate()-1);
  el.value=d.toISOString().slice(0,10);renderLayout();
}
function nextDay(){
  const el=document.getElementById('lyDate');
  const d=new Date(el.value);d.setDate(d.getDate()+1);
  el.value=d.toISOString().slice(0,10);renderLayout();
}

// ═══════════════════════════════════════════════════════
// RESULT TABLE
// ═══════════════════════════════════════════════════════
function renderResultTable(){
  const el=document.getElementById('resWrap');
  if(!placements.length&&!failedBlocks.length){
    el.innerHTML='<div class="empty-panel">최적 배치를 실행하면 결과가 표시됩니다</div>';
    return;
  }

  const partnerName=document.getElementById('partnerName').value.trim();
  const pStart=document.getElementById('pStart').value;
  const pEnd=document.getElementById('pEnd').value;

  // ── 협력사 정보 헤더 배너 ──
  const mainPl=placements.filter(p=>!p.isOutdoor);
  const totalBlocks=blocks.length;
  const placedCnt=new Set(mainPl.map(p=>p.blockId)).size;
  const failCnt=failedBlocks.length;
  const yardNames=[...new Set(mainPl.map(p=>p.yardName))].join(', ');

  let html=`<div style="background:var(--s2);border:1px solid var(--b2);border-radius:4px;padding:10px 14px;margin-bottom:12px;">
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
      ${partnerName
        ? `<div style="font-size:13px;font-weight:700;color:var(--amber);">🏢 ${partnerName}</div>
           <div style="width:1px;height:16px;background:var(--b2);"></div>`
        : ''}
      <div style="font-family:var(--mono);font-size:10px;color:var(--dim);">검토기간</div>
      <div style="font-family:var(--mono);font-size:10px;color:var(--text);">${pStart} ~ ${pEnd}</div>
      <div style="width:1px;height:16px;background:var(--b2);"></div>
      <div style="font-family:var(--mono);font-size:10px;color:var(--dim);">작업장</div>
      <div style="font-family:var(--mono);font-size:10px;color:var(--cyan);">${yardNames||'－'}</div>
      <div style="width:1px;height:16px;background:var(--b2);"></div>
      <div style="font-family:var(--mono);font-size:10px;color:var(--dim);">블록</div>
      <div style="font-family:var(--mono);font-size:10px;">전체 <b style="color:var(--text);">${totalBlocks}</b> · 배치 <b style="color:var(--green);">${placedCnt}</b> · 미배치 <b style="color:${failCnt?'var(--red)':'var(--muted)'};">${failCnt}</b></div>
    </div>
  </div>`;

  // Deduplicate: show one row per block (main indoor placement)
  const typeOrderMap={maj:0,mid:1,pre:2};
  const sorted=[...mainPl].sort((a,b)=>a.priority-b.priority||(typeOrderMap[a.type]-typeOrderMap[b.type])||(a.inDate-b.inDate));

  html+=`<table class="rtbl">
    <thead><tr>
      <th>프로젝트</th><th>선종/선형</th><th>블록</th><th>블록구분</th><th>대조그룹</th>
      ${partnerName?'<th>협력사</th>':''}
      <th>작업장</th>
      <th>크기(배치)</th><th>위치(X,Y)</th><th>회전</th>
      <th>착수일</th><th>완료일</th><th>W/D</th><th>옥외이동</th>
      <th>중량</th><th>비고</th>
    </tr></thead><tbody>`;

  sorted.forEach(p=>{
    const outdoorPl=placements.find(op=>op.blockId===p.blockId&&op.isOutdoor);
    const tc=TYPE_COL[p.type];
    const blk=blocks.find(b=>b.id===p.blockId)||{};
    html+=`<tr>
      <td style="font-family:var(--mono);font-size:10px;color:var(--amber);">${blk.project||'－'}</td>
      <td style="font-size:10px;color:var(--dim);">${blk.shipType||'－'}</td>
      <td><span style="display:inline-block;width:7px;height:7px;border-radius:2px;background:${p.color};margin-right:4px;"></span><span style="font-family:var(--mono);font-size:10px;">${p.blockName}</span></td>
      <td><span style="font-family:var(--mono);font-size:9px;color:${tc};">${TYPE_LBL[p.type]}</span></td>
      <td style="font-family:var(--mono);font-size:10px;">${p.group}</td>
      ${partnerName?`<td style="font-family:var(--mono);font-size:10px;color:var(--amber);">${partnerName}</td>`:''}
      <td style="font-family:var(--mono);font-size:10px;color:var(--cyan);">${p.yardName}</td>
      <td style="font-family:var(--mono);font-size:10px;">${p.w}×${p.h}m</td>
      <td style="font-family:var(--mono);font-size:10px;">(${p.x.toFixed(1)}, ${p.y.toFixed(1)})</td>
      <td style="font-family:var(--mono);font-size:10px;color:${p.rotated?'var(--amber)':'var(--muted)'};">${p.rotated?'90°':'－'}</td>
      <td style="font-family:var(--mono);font-size:10px;">${n2d(p.inDate)}</td>
      <td style="font-family:var(--mono);font-size:10px;">${n2d(p.outDate)}</td>
      <td style="font-family:var(--mono);font-size:10px;color:var(--green);">${p.duration||'－'}</td>
      <td style="font-family:var(--mono);font-size:10px;color:${outdoorPl?'var(--orange)':'var(--muted)'};">${outdoorPl?n2d(outdoorPl.inDate)+'~'+n2d(outdoorPl.outDate)+'('+outdoorPl.yardName+')':'－'}</td>
      <td style="font-family:var(--mono);font-size:10px;">${p.weight?p.weight+'t':'－'}</td>
      <td style="font-size:10px;color:var(--dim);">${p.remark||''}</td>
    </tr>`;
  });
  html+=`</tbody></table>`;

  if(failedBlocks.length){
    html+=`<div class="fail-sec">
      <div class="fail-hdr">✗ 미배치 블록 (${failedBlocks.length}개) — 작업장 용량 또는 조건 재검토 필요</div>
      <table class="rtbl"><thead><tr>
        <th>블록번호</th><th>구분</th><th>대조그룹</th><th>LBH(m)</th>
        <th>착수일</th><th>완료일</th><th>W/D</th><th>미배치 이유</th>
      </tr></thead><tbody>`;
    failedBlocks.forEach(b=>{
      const tc=TYPE_COL[b.type];
      const dur=b.duration||(b.inDate&&b.outDate?Math.round((parseD(b.outDate)-parseD(b.inDate))/86400000)+1:'－');
      html+=`<tr>
        <td style="color:var(--red);">${b.name}</td>
        <td><span style="font-family:var(--mono);font-size:9px;color:${tc};">${TYPE_LBL[b.type]}</span></td>
        <td style="font-family:var(--mono);font-size:10px;">${b.group}</td>
        <td style="font-family:var(--mono);font-size:10px;">${b.L}×${b.B}×${b.H}</td>
        <td style="font-family:var(--mono);font-size:10px;">${b.inDate||'－'}</td>
        <td style="font-family:var(--mono);font-size:10px;">${b.outDate||'－'}</td>
        <td style="font-family:var(--mono);font-size:10px;color:var(--amber);">${dur}</td>
        <td style="color:var(--red);font-size:10px;">⚠ ${b.reason}</td>
      </tr>`;
    });
    html+=`</tbody></table></div>`;
  }
  el.innerHTML=html;
}

// ═══════════════════════════════════════════════════════
// EXCEL EXPORT — 결과 출력 (표준양식 컬럼 기준)
// ═══════════════════════════════════════════════════════
function exportExcel(){
  if(!placements.length&&!failedBlocks.length){alert('배치 결과가 없습니다.');return;}
  const wb=XLSX.utils.book_new();
  const partnerName=document.getElementById('partnerName').value.trim();
  const pStart=document.getElementById('pStart').value;
  const pEnd=document.getElementById('pEnd').value;

  // ── Sheet 0: 요약(커버) ──
  const mainPl=placements.filter(p=>!p.isOutdoor);
  const placedCnt=new Set(mainPl.map(p=>p.blockId)).size;
  const totalW=yards.filter(y=>y.purpose!=='outdoor').reduce((s,y)=>(s+(y.W-2*y.margin)*(y.L-2*y.margin)),0);
  const coverData=[
    ['항목','내용'],
    ['협력사명', partnerName||'(미입력)'],
    ['검토기간', `${pStart} ~ ${pEnd}`],
    ['작업장 목록', yards.map(y=>y.name).join(', ')],
    ['전체 블록 수', blocks.length],
    ['배치 완료', placedCnt],
    ['미배치', failedBlocks.length],
    ['총 유효면적(m²)', +totalW.toFixed(1)],
    ['출력일시', new Date().toLocaleString('ko-KR')],
  ];
  const ws0=XLSX.utils.aoa_to_sheet(coverData);
  ws0['!cols']=[22,40].map(w=>({wch:w}));
  XLSX.utils.book_append_sheet(wb,ws0,'요약');

  // ── Sheet 1: 배치 결과 ──
  const headers=['협력사','프로젝트','선종/선형','블록','블록구분','대조그룹','작업장',
    '배치크기W(m)','배치크기H(m)','위치X','위치Y','회전',
    '착수일','완료일','W/D',
    '옥외작업장','옥외착수일','옥외완료일','중량(ton)','비고'];
  const data=mainPl.map(p=>{
    const op=placements.find(x=>x.blockId===p.blockId&&x.isOutdoor);
    const blk=blocks.find(b=>b.id===p.blockId)||{};
    return [partnerName||'', blk.project||'', blk.shipType||'',
      p.blockName, TYPE_LBL[p.type], p.group, p.yardName,
      p.w, p.h, +p.x.toFixed(1), +p.y.toFixed(1), p.rotated?'90°':'',
      n2d(p.inDate), n2d(p.outDate), p.duration||'',
      op?op.yardName:'', op?n2d(op.inDate):'', op?n2d(op.outDate):'',
      p.weight||'', p.remark||''];
  });
  const ws1=XLSX.utils.aoa_to_sheet([headers,...data]);
  ws1['!cols']=[16,12,16,12,10,10,12,10,10,8,8,6,12,12,8,12,12,12,10,20].map(w=>({wch:w}));
  XLSX.utils.book_append_sheet(wb,ws1,'배치결과');

  // ── Sheet 2: 미배치 목록 ──
  if(failedBlocks.length){
    const fh=['협력사','프로젝트','선종/선형','블록','블록구분','대조그룹',
      'L(m)','B(m)','H(m)','착수일','완료일','W/D','미배치이유'];
    const fd=failedBlocks.map(b=>{
      const dur=b.duration||(b.inDate&&b.outDate?Math.round((parseD(b.outDate)-parseD(b.inDate))/86400000)+1:'');
      return [partnerName||'', b.project||'', b.shipType||'',
        b.name, TYPE_LBL[b.type], b.group,
        b.L, b.B, b.H, b.inDate||'', b.outDate||'', dur, b.reason];
    });
    const ws2=XLSX.utils.aoa_to_sheet([fh,...fd]);
    ws2['!cols']=[16,12,16,12,10,10,8,8,8,12,12,8,36].map(w=>({wch:w}));
    XLSX.utils.book_append_sheet(wb,ws2,'미배치목록');
  }

  // ── Sheet 3: 작업장별 통계 ──
  const yh=['협력사','작업장명','용도','크기W(m)','크기L(m)','이격','크레인','크레인높이(m)',
    '턴오버높이(m)','가용높이(m)',
    '배치블록수','유효면적(m²)','사용면적(m²)','평균활용률(%)'];
  const yd=yards.map(y=>{
    const yPl=mainPl.filter(p=>p.yardId===y.id);
    const cnt=yPl.length;
    const effArea=(y.W-2*y.margin)*(y.L-2*y.margin);
    const usedArea=yPl.reduce((s,p)=>s+p.w*p.h,0);
    const availH=y.crane?(y.craneH-(y.turnoverH||0)):'-';
    return [partnerName||'', y.name, PURP_LBL[y.purpose], y.W, y.L, y.gap,
      y.crane?'Y':'N', y.crane?y.craneH:'-',
      y.crane?(y.turnoverH||0):'-', availH,
      cnt, +effArea.toFixed(1), +usedArea.toFixed(1),
      effArea?+(usedArea/effArea*100).toFixed(1):0];
  });
  const ws3=XLSX.utils.aoa_to_sheet([yh,...yd]);
  ws3['!cols']=[16,14,10,10,10,8,8,12,12,10,10,14,14,14].map(w=>({wch:w}));
  XLSX.utils.book_append_sheet(wb,ws3,'작업장통계');

  // ── Sheet 4: 기간별 작업장 활용률 (월별 스냅샷) ──
  const pStartTs=parseD(document.getElementById('pStart').value);
  const pEndTs=parseD(document.getElementById('pEnd').value);
  if(pStartTs&&pEndTs){
    const months=[];
    let cur=pStartTs;
    while(cur<=pEndTs){
      months.push(cur);
      const d=new Date(cur);
      cur=new Date(d.getFullYear(),d.getMonth()+1,1).getTime();
    }
    const indY=yards.filter(y=>y.purpose!=='outdoor');
    const utilHdr=['월',...indY.map(y=>y.name+'(%)'),'전체(%)'];
    const utilData=months.map(mTs=>{
      const label=n2d(mTs).slice(0,7);
      const row=[label];
      let totEff=0,totUsed=0;
      indY.forEach(y=>{
        const eff=(y.W-2*y.margin)*(y.L-2*y.margin);
        const used=placements.filter(p=>p.yardId===y.id&&!p.isOutdoor&&p.inDate<=mTs&&p.outDate>=mTs).reduce((s,p)=>s+p.w*p.h,0);
        row.push(eff?+(used/eff*100).toFixed(1):0);
        totEff+=eff;totUsed+=used;
      });
      row.push(totEff?+(totUsed/totEff*100).toFixed(1):0);
      return row;
    });
    const ws4=XLSX.utils.aoa_to_sheet([utilHdr,...utilData]);
    ws4['!cols']=[10,...indY.map(()=>({wch:14})),{wch:12}].map((v,i)=>i===0?{wch:10}:v);
    XLSX.utils.book_append_sheet(wb,ws4,'월별활용률');
  }

  XLSX.writeFile(wb,'블록작업장배치결과.xlsx');
}

// ═══════════════════════════════════════════════════════
// UI HELPERS
// ═══════════════════════════════════════════════════════
function switchTab(tab){
  document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('on',t.dataset.tab===tab));
  document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('on',p.id==='panel-'+tab));
  if(tab==='layout')renderLayout();
}

function adjustZoom(f){zoom=Math.min(8,Math.max(.15,zoom*f));renderLayout();}
function autoFit(){
  if(!yards.length)return;
  const wrap=document.getElementById('yardsRow');
  const maxL=Math.max(...yards.map(y=>y.L));
  zoom=Math.min(2.5,(wrap.clientHeight-80)/(maxL*SCALE));
  renderLayout();
}

function clearResult(){
  placements=[];failedBlocks=[];
  yards.forEach(y=>y.placements=[]);
  ['sTotal','sPlaced','sFail','sGroups'].forEach(id=>document.getElementById(id).textContent='0');
  document.getElementById('sUtil').textContent='-';
  document.getElementById('sTotalDays').textContent='-';
  document.getElementById('uploadStatus').style.display='none';
  document.getElementById('ganttInner').innerHTML='<div class="empty-panel">최적 배치를 실행하면 간트 차트가 표시됩니다</div>';
  document.getElementById('yardsRow').innerHTML='<div class="empty-panel full-w">최적 배치를 실행한 후 날짜를 선택하세요</div>';
  document.getElementById('resWrap').innerHTML='<div class="empty-panel">최적 배치를 실행하면 결과가 표시됩니다</div>';
  renderYardList();
}

// ═══════════════════════════════════════════════════════
// TEMPLATE DOWNLOAD — 표준 양식 xlsx 클라이언트 생성
// ═══════════════════════════════════════════════════════
function downloadTemplate(){
  const wb=XLSX.utils.book_new();

  // ── 블록데이터 시트 ──
  const blkHdr=[
    '프로젝트','선종/선형','블록','블록구분',
    'L(m)','B(m)','H(m)','중량(ton)',
    '착수일','완료일','W/D',
    '옥외이동일','옥외완료일',
    '크레인필요(Y/N)','회전허용(Y/N)','최대높이제한(m)',
    '작업장지정','비고'
  ];
  const blkEx=[
    ['AB1001','VLCC 300K','H100P','대조',  40,30,13,2800,'2025-04-15','2025-07-31','','2025-06-15','2025-07-31','Y','N','','','대조 — 4자리=0'],
    ['AB1001','VLCC 300K','H101P','중조',  22,18,11,980, '2025-03-01','2025-04-30','','','','Y','Y','','','중조 — 4자리=1'],
    ['AB1001','VLCC 300K','H10AP','선행중조',12,10,7,340,'2025-03-01','',30,'','','N','Y','','A작업장','W/D 입력 예시 — 4자리=영문'],
    ['AB1001','VLCC 300K','H200P','대조',  35,28,12,2400,'2025-05-01','2025-08-31','','2025-07-15','','Y','N',14,'','크레인가용높이 점검용'],
    ['AB1001','VLCC 300K','M20AP','선행중조',16,14,8,560,'2025-04-01','2025-06-15','','','','Y','Y','','',''],
  ];
  const blkNote=[['※ 블록구분 입력 불필요 — 블록코드에서 자동판별 (4자리=0→대조 / 1~9→중조 / 영문→선행중조)  │  W/D 입력 시 완료일 자동계산  │  위 예시 행 삭제 후 입력']];
  const ws1=XLSX.utils.aoa_to_sheet([blkHdr,...blkEx,...blkNote]);
  ws1['!cols']=[12,16,10,12,8,8,8,9,13,13,8,13,13,11,10,12,12,20].map(w=>({wch:w}));
  XLSX.utils.book_append_sheet(wb,ws1,'블록데이터');

  // ── 작업장정보 시트 ──
  const yHdr=['협력사명\n(1회만 입력)','작업장명(필수)','작업장코드','W폭(m)','L길이(m)','블록간이격(m)','경계여유(m)',
    '크레인(Y/N)','크레인높이제한(m)','턴오버필요높이(m)','용도코드','용도설명','우선사용순위(1=최우선)','비고'];
  const yEx=[
    ['(주)한국조선기계','A작업장','A',120,200,3,5,'Y',14,3,'assembly','조립용(대형 블록)',1,'가용높이=14-3=11m'],
    ['','B작업장','B',90,160,2,4,'Y',10,2,'general','일반',2,'가용높이=10-2=8m'],
    ['','C작업장','C',60,100,3,5,'N',0,0,'general','일반',3,'크레인없음'],
    ['','옥외작업장','OUT',150,100,5,5,'N',0,0,'outdoor','옥외대기',4,'대조완료 후 이동'],
  ];
  const yNote=[['※ 협력사명은 첫 번째 행에만 1회 입력 (나머지 행 공란)  │  가용높이 = 크레인높이제한 − 턴오버필요높이  │  용도코드: general/assembly/outdoor/staging  │  예시 행 삭제 후 입력']];
  const ws2=XLSX.utils.aoa_to_sheet([yHdr,...yEx,...yNote]);
  ws2['!cols']=[18,14,10,9,9,12,10,10,13,13,12,18,14,18].map(w=>({wch:w}));
  XLSX.utils.book_append_sheet(wb,ws2,'작업장정보');

  // ── 설정값 시트 ──
  const cfgData=[
    ['설정항목','값','형식','설명'],
    ['── 기간 설정 ──','','',''],
    ['검토 시작일','2025-03-01','YYYY-MM-DD','시뮬레이션 기간 시작'],
    ['검토 종료일','2025-09-30','YYYY-MM-DD','시뮬레이션 기간 종료'],
    ['── 배치 전략 ──','','',''],
    ['배치 정렬 전략','group_prio','group_prio / prio_bl / area_bl','대조그룹+우선순위 / 우선순위+BL / 면적큰순+BL'],
    ['작업장 선택 방식','bestfit','bestfit / firstfit / balance','Best-Fit / First-Fit / 균등분배'],
    ['── 기본값 ──','','',''],
    ['기본 L(m)','20','숫자','블록 L 미입력 시 사용'],
    ['기본 B(m)','15','숫자','블록 B 미입력 시 사용'],
    ['기본 H(m)','8','숫자','블록 H 미입력 시 사용'],
    ['기본 W/D','90','숫자','완료일·W/D 모두 미입력 시 자동계산 기준'],
    ['기본 이격거리(m)','3','숫자','작업장 이격 미입력 시 사용'],
    ['기본 경계여유(m)','5','숫자','작업장 경계 미입력 시 사용'],
  ];
  const ws3=XLSX.utils.aoa_to_sheet(cfgData);
  ws3['!cols']=[22,16,30,42].map(w=>({wch:w}));
  XLSX.utils.book_append_sheet(wb,ws3,'설정값');

  // ── 작성요령 시트 ──
  const guide=[
    ['순서','항목','설명'],
    ['①','블록데이터 시트에 블록 정보 입력','예시 행 삭제 후 2행(헤더 다음)부터 입력'],
    ['②','작업장정보 시트에 작업장 정보 입력','예시 행 삭제 후 입력. 작업장이 이미 설정돼 있으면 생략 가능'],
    ['③','설정값 시트에서 검토기간·전략 확인','B열 값만 수정'],
    ['④','파일 저장 후 웹 앱에 업로드 → 자동 배치 실행','📂 표준양식 업로드 버튼 사용'],
    ['','',''],
    ['★','크레인 가용높이 계산','가용높이 = 크레인높이제한 − 턴오버필요높이'],
    ['','','예) 크레인높이 14m, 턴오버높이 3m → 가용높이 11m → H≤11m 블록만 배치 가능'],
    ['','','턴오버높이 = 0 이면 크레인높이 전체가 가용높이'],
    ['','',''],
    ['구분코드','pre','선행중조 (Preceding Sub-Assembly)'],
    ['','mid','중조 (Sub-Assembly)'],
    ['','maj','대조 (Grand Assembly)'],
    ['','',''],
    ['용도코드','general','일반 작업장'],
    ['','assembly','조립용 작업장 (대형 크레인)'],
    ['','outdoor','옥외 대기작업장 (대조 완료 후 이동)'],
    ['','staging','출고 대기작업장'],
    ['','',''],
    ['Q&A','완료일과 W/D를 둘 다 입력하면?','완료일 우선 (W/D 무시)'],
    ['','둘 다 안 쓰면?','설정값의 기본 W/D로 완료일 자동계산'],
    ['','같은 그룹 블록이 다른 작업장에 배치되면?','가능한 같은 작업장에 배치 시도, 불가시 미배치 처리'],
    ['','배치 불가 블록은?','미배치 목록 탭 및 결과 Excel에 이유와 함께 표시'],
    ['','크레인 가용높이 초과 블록은?','해당 작업장 배치 제외. 미배치 사유에 블록H vs 최대가용H 표시'],
  ];
  const ws4=XLSX.utils.aoa_to_sheet(guide);
  ws4['!cols']=[8,30,50].map(w=>({wch:w}));
  XLSX.utils.book_append_sheet(wb,ws4,'작성요령');

  XLSX.writeFile(wb,'블록작업장배치_표준양식.xlsx');
}

// ═══════════════════════════════════════════════════════
// SAMPLE DATA
// ═══════════════════════════════════════════════════════
function loadSample(){
  colorIdx=0;yards=[];blocks=[];placements=[];failedBlocks=[];
  document.getElementById('pStart').value='2025-03-01';
  document.getElementById('pEnd').value='2025-09-30';
  document.getElementById('lyDate').value='2025-05-01';

  yards=[
    {id:1001,name:'A작업장',W:120,L:200,gap:3,margin:5,crane:true,craneH:14,turnoverH:3,purpose:'assembly',placements:[]},
    {id:1002,name:'B작업장',W:90,L:160,gap:2,margin:4,crane:true,craneH:10,turnoverH:2,purpose:'general',placements:[]},
    {id:1003,name:'C작업장',W:60,L:100,gap:3,margin:5,crane:false,craneH:0,turnoverH:0,purpose:'general',placements:[]},
    {id:1004,name:'옥외작업장',W:150,L:100,gap:5,margin:5,crane:false,craneH:0,turnoverH:0,purpose:'outdoor',placements:[]},
  ];

  // 샘플: 프로젝트 AB1001, 선종 VLCC
  const sampleBlocks=[
    // 대조그룹 H10 (H100P=대조, H101P/H102P=중조, H10AP/H10BP=선행중조)
    {name:'H100P',project:'AB1001',shipType:'VLCC 300K',  L:40,B:30,H:13,weight:2800,inDate:'2025-04-15',outDate:'2025-07-31',outdoorDate:'2025-06-15',rotatable:false},
    {name:'H101P',project:'AB1001',shipType:'VLCC 300K',  L:22,B:18,H:11,weight:980, inDate:'2025-03-01',outDate:'2025-04-30',outdoorDate:null,rotatable:true},
    {name:'H102P',project:'AB1001',shipType:'VLCC 300K',  L:20,B:16,H:10,weight:860, inDate:'2025-03-10',outDate:'2025-05-10',outdoorDate:null,rotatable:true},
    {name:'H10AP',project:'AB1001',shipType:'VLCC 300K',  L:12,B:10,H:7, weight:340, inDate:'2025-03-01',outDate:'2025-03-31',outdoorDate:null,rotatable:true},
    {name:'H10BP',project:'AB1001',shipType:'VLCC 300K',  L:11,B:9, H:6, weight:290, inDate:'2025-03-05',outDate:'2025-04-05',outdoorDate:null,rotatable:true},
    {name:'H10CP',project:'AB1001',shipType:'VLCC 300K',  L:10,B:8, H:6, weight:250, inDate:'2025-03-10',outDate:'2025-04-10',outdoorDate:null,rotatable:true},
    // 대조그룹 H20 (H200P=대조, H201P=중조, H20AP=선행중조)
    {name:'H200P',project:'AB1001',shipType:'VLCC 300K',  L:35,B:28,H:12,weight:2400,inDate:'2025-05-01',outDate:'2025-08-31',outdoorDate:'2025-07-15',rotatable:false},
    {name:'H201P',project:'AB1001',shipType:'VLCC 300K',  L:20,B:16,H:9, weight:760, inDate:'2025-03-15',outDate:'2025-05-15',outdoorDate:null,rotatable:true},
    {name:'H202P',project:'AB1001',shipType:'VLCC 300K',  L:18,B:15,H:9, weight:680, inDate:'2025-03-20',outDate:'2025-05-20',outdoorDate:null,rotatable:true},
    {name:'H20AP',project:'AB1001',shipType:'VLCC 300K',  L:10,B:8, H:5, weight:220, inDate:'2025-03-15',outDate:'2025-04-15',outdoorDate:null,rotatable:true},
    {name:'H20BP',project:'AB1001',shipType:'VLCC 300K',  L:9, B:7, H:5, weight:190, inDate:'2025-03-20',outDate:'2025-04-20',outdoorDate:null,rotatable:true},
    // 대조그룹 M20 (M200P=대조, M201P=중조, M20AP=선행중조)
    {name:'M200P',project:'AB1001',shipType:'VLCC 300K',  L:30,B:25,H:9, weight:1800,inDate:'2025-06-01',outDate:'2025-09-15',outdoorDate:'2025-08-01',rotatable:true},
    {name:'M201P',project:'AB1001',shipType:'VLCC 300K',  L:16,B:14,H:8, weight:560, inDate:'2025-04-01',outDate:'2025-06-15',outdoorDate:null,rotatable:true},
    {name:'M20AP',project:'AB1001',shipType:'VLCC 300K',  L:9, B:7, H:5, weight:190, inDate:'2025-04-01',outDate:'2025-05-01',outdoorDate:null,rotatable:true},
    // 가용높이 초과 테스트
    {name:'X900P',project:'AB1001',shipType:'VLCC 300K',  L:25,B:20,H:16,weight:1500,inDate:'2025-04-01',outDate:'2025-07-31',outdoorDate:null,rotatable:false},
  ];
  sampleBlocks.forEach(b=>{
    const parsed=parseBlockCode(b.name);
    const inTs=parseD(b.inDate),outTs=parseD(b.outDate);
    const dur=(inTs&&outTs)?Math.round((outTs-inTs)/86400000)+1:null;
    blocks.push({...b,
      id:Date.now()+Math.random(),
      type:parsed?.type||'maj',
      group:parsed?.group||b.name.slice(0,3),
      priority:parsed?.priority||1,
      color:COLORS[colorIdx++%COLORS.length],
      outdoorDate:b.outdoorDate||null,
      outdoorEnd:null,
      needCrane:true,
      duration:dur,
      remark:''
    });
  });

  renderYardList();renderBlockList();
  setTimeout(runOptimize,100);
}

window.onload=()=>{
  document.getElementById('lyDate').value=new Date().toISOString().slice(0,10);
  renderYardList();renderBlockList();
};
window.addEventListener('resize',()=>{if(yards.length&&placements.length)renderLayout();});
